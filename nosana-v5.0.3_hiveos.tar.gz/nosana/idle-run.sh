#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
DEBUG_LOG="$LOG_DIR/debug.log"
PARSED_DIR="$MINER_DIR/parsed"

for d in /var/log/miner "$LOG_DIR" "$PARSED_DIR"; do
  mkdir -p "$d" 2>/dev/null || true
done
: > "$IDLE_LOG" || true
: > "$NOSANA_LOG" || true
: > "$DEBUG_LOG" || true

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

IDLE_COMMAND="$(cat "$PARSED_DIR/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$PARSED_DIR/idle_args" 2>/dev/null || true)"

if [[ -z "${IDLE_COMMAND:-}" ]]; then
  echo "[$(date -Iseconds)] idle-run: no idle command set" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  msg "NOS: idle start failed (no command)"
  exit 1
fi

if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then
  screen -S nosana-idle -X quit || true
  sleep 0.2
fi

echo "[$(date -Iseconds)] idle-run: starting idle miner: $IDLE_COMMAND $IDLE_ARGS" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"

# Start via screen; do not use bash -lc here to avoid reading profiles; pass a clean sh
# Use exec to ensure the command becomes the child process of the screen.
screen -dmS nosana-idle sh -c '
  set -o pipefail
  '"$(printf "exec %q " "$IDLE_COMMAND" $IDLE_ARGS)"' 2>&1 \
  | awk '"'"'{print "[idle] " $0}'"'"' \
  | tee -a "'"$IDLE_LOG"'" \
  | tee -a "'"$NOSANA_LOG"'"
'

# Verify start: session exists and has a process attached
sleep 0.6
if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then
  echo "[$(date -Iseconds)] idle-run: idle miner started" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  msg "NOS: idle miner started"
  exit 0
else
  echo "[$(date -Iseconds)] idle-run: failed to start idle miner" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  msg "NOS: idle miner failed to start"
  exit 2
fi
