#!/usr/bin/env bash
set -euo pipefail
WRAP_SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/h-stats-wrapper.sh"
WRAP_DST="/hive/miners/custom/h-stats.sh"
install -m 0755 "$WRAP_SRC" "$WRAP_DST"
echo "[nosana] installed fixed stats wrapper to $WRAP_DST"
