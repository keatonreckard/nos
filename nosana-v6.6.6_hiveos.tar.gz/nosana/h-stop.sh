\
    #!/usr/bin/env bash
    set -euo pipefail
    LOG_DIR="/var/log/miner/nosana"
    echo "[h-stop] $(date -Iseconds) stopping" >> "$LOG_DIR/agent.log"

    # Stop nosana cli
    pkill -f "@nosana/cli" >/dev/null 2>&1 || true

    # Stop idle miner as well
    if command -v screen >/dev/null 2>&1; then
      screen -ls | awk '/\t[0-9]+\.(idle|idle-run|qli|qubic)/{print $1}' | while read -r sid; do
        screen -S "$sid" -X quit || true
      done
    fi
    pkill -f 'qli-Client'    >/dev/null 2>&1 || true
    pkill -f 'qubic.li'      >/dev/null 2>&1 || true
    pkill -f 'pplns.*jetski' >/dev/null 2>&1 || true
    echo "[h-stop] $(date -Iseconds) done" >> "$LOG_DIR/agent.log"
