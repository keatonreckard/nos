#!/usr/bin/env bash
set -Eeuo pipefail
export LC_ALL=C

MINER_DIR="${MINER_DIR:-/hive/miners/custom/nosana}"
RUN_DIR="${RUN_DIR:-/var/run}"
LOG_DIR="${LOG_DIR:-/var/log/miner/nosana}"
STATE_FILE="${STATE_FILE:-$RUN_DIR/nosana.state}"
IDLE_LOG="$LOG_DIR/idle.log"
WATCH_LOG="$LOG_DIR/idle_watcher.log"
DOCKER="${DOCKER_BIN:-docker}"

mkdir -p "$LOG_DIR" "$RUN_DIR"

write_kv() {
  local k="$1" v="$2" tmp="$STATE_FILE.tmp"
  # remove existing key, keep others
  { [[ -f "$STATE_FILE" ]] && sed -E "s|^${k}=.*$||" "$STATE_FILE" || true; echo "${k}=\"${v}\"" ; } > "$tmp"
  mv -f "$tmp" "$STATE_FILE"
}

start_idle() {
  # reads idle_enabled from state if present
  local idle_enabled=0
  [[ -f "$STATE_FILE" ]] && . "$STATE_FILE" || true
  if [[ "${idle_enabled:-0}" != "1" ]]; then
    echo "[$(date -Iseconds)] idle-watcher: idle not enabled; skip start" >> "$WATCH_LOG"
    return 0
  fi
  if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then
    echo "[$(date -Iseconds)] idle-watcher: idle already running" >> "$WATCH_LOG"
    return 0
  fi
  if [[ -x "$MINER_DIR/idle-run.sh" ]]; then
    echo "[$(date -Iseconds)] idle-watcher: starting idle-run.sh" >> "$WATCH_LOG"
    bash "$MINER_DIR/idle-run.sh" >>"$IDLE_LOG" 2>&1 || true
  elif [[ -x "$MINER_DIR/idle-screen.sh" ]]; then
    echo "[$(date -Iseconds)] idle-watcher: attaching idle-screen.sh (if present)" >> "$WATCH_LOG"
    bash "$MINER_DIR/idle-screen.sh" >>"$IDLE_LOG" 2>&1 || true
  fi
}

stop_idle() {
  echo "[$(date -Iseconds)] idle-watcher: stopping idle screen if any" >> "$WATCH_LOG"
  screen -S nosana-idle -X quit >/dev/null 2>&1 || true
}

# Begin in initializing state so h-stats can show 1 kH/s
write_kv status "nos - initializing"

# Follow docker logs and react to state transitions
$DOCKER logs -f --tail=200 nosana-node 2>&1 | while IFS= read -r line; do
  printf '%s
' "$line" >> "$WATCH_LOG"
  # Detect job start
  if echo "$line" | grep -q -E "Job .* started successfully"; then
    write_kv status "nos - job"
    stop_idle
    continue
  fi
  # Detect queued + position
  if echo "$line" | grep -q -E "QUEUED.*position"; then
    qpos="$(echo "$line" | sed -n 's/.*position[[:space:]]*\([0-9]\+\/[0-9]\+\).*/\1/p')"
    [[ -z "$qpos" ]] && qpos=""
    write_kv queue "$qpos"
    if [[ -n "$qpos" ]]; then
      write_kv status "nos - queued $qpos"
    else
      write_kv status "nos - queued"
    fi
    start_idle
    continue
  fi
  # Detect restart/cleanup to move back to initializing (until QUEUED arrives)
  if echo "$line" | grep -q -E "RESTARTING|Node has restarted"; then
    write_kv status "nos - initializing"
    continue
  fi
done
