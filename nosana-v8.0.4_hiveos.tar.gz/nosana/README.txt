NOSANA (HiveOS custom miner package)
-----------------------------------
Built: 2025-08-21T15:40:40
Top-level dir: nosana

Changes in v8.0.1_hiveos:
- Add **idle-watcher.sh**: tails docker logs and sets state back to "nos - queued X/Y" after jobs finish.
  - Starts idle miner when queued; stops it when job starts.
  - Also sets status to "nos - initializing" on restart/cleanup messages.
- Keep minimal h-stats tweak from v8.0.0: 1 kH/s during "nos - initializing".
- One-line hook in h-run.sh to launch the watcher in background (no other behavior changes).

How idle command is picked:
- Place in Extra Config JSON: {"idleSettings": {"command": "...", "arguments": "..."}}
- h-config.sh writes parsed files at nosana/parsed/idle_command and nosana/parsed/idle_args.
- watcher+idle-run will use them automatically when queued.
