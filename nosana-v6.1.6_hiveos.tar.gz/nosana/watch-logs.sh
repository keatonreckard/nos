#!/usr/bin/env bash
set -euo pipefail
LOG_DIR="/var/log/miner/nosana"
NOS="$LOG_DIR/nosana.log"
IDL="$LOG_DIR/idle.log"
mkdir -p "$LOG_DIR"
touch "$NOS" "$IDL"
# Interleave lines from both logs with a prefix showing the source.
# Uses process substitution and line-buffering for real-time updates.
exec awk '
  { gsub(/\r/, "", $0);
    src = (ARGIND==1 ? "NOS" : "IDLE");
    printf("[%s] %s\n", src, $0);
    fflush();
  }
' <(stdbuf -oL tail -F -n 0 "$NOS") <(stdbuf -oL tail -F -n 0 "$IDL")
