NOSANA (HiveOS custom miner package)
-----------------------------------
Built: 2025-08-21T16:25:11

v8.0.7_hiveos:
- Idle logic: from your uploaded files (monitor.sh, idle-run/kill/screen, config + wrappers).
- Stats: keep current algo/version formatting; KH/s rules = {init,job}→1, queued X/Y→X; no "ar" field.
