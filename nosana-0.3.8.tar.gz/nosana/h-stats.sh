#!/usr/bin/env bash
# Emit Hive stats JSON. Always exit 0.
set +e

LOG="/var/log/miner/nosana/nosana.log"
STATE="/var/run/nosana.state"
IDLE_LOG="/var/log/miner/nosana/idle.log"
IDLE_START="/var/run/nosana_idle.start"
JOB_START="/var/run/nosana_job.start"

cleaned="$(tail -n 1500 "$LOG" 2>/dev/null | tr -d '\r')"

wallet="$(echo "$cleaned" | sed -n 's/.*Wallet:[[:space:]]*\([A-Za-z0-9]\{32,64\}\).*/\1/p' | tail -n1)"
sol="$(echo "$cleaned" | sed -n 's/.*SOL balance:[[:space:]]*\([0-9.]*\).*/\1/p' | tail -n1)"
nos="$(echo "$cleaned" | sed -n 's/.*NOS balance:[[:space:]]*\([0-9.]*\).*/\1/p' | tail -n1)"
queue="$(echo "$cleaned" | sed -n 's/.*QUEUED.*position[[:space:]]\([0-9]\+\/[0-9]\+\).*/\1/p' | tail -n1)"

last_queued_line="$(echo "$cleaned" | nl -ba | grep -E 'QUEUED.*position[[:space:]][0-9]+/[0-9]+' | tail -n1 | awk '{print $1}')"
last_job_line="$(echo "$cleaned" | nl -ba | grep -Ei 'claimed job|started successfully|is resuming|resumed|is running|Running container ' | tail -n1 | awk '{print $1}')"

status="nos - initializing"
if [ -n "$last_job_line" ] && [ -z "$last_queued_line" ]; then
  status="nos - job"
elif [ -n "$last_job_line" ] && [ -n "$last_queued_line" ]; then
  if [ "$last_job_line" -gt "$last_queued_line" ] 2>/dev/null; then
    status="nos - job"
  else
    [ -n "$queue" ] && status="nos - queued $queue" || status="nos - initializing"
  fi
else
  [ -n "$queue" ] && status="nos - queued $queue" || status="nos - initializing"
fi

# Merge with STATE if exists (fill blanks)
if [ -f "$STATE" ]; then
  . "$STATE"
  [ -z "$wallet" ] && wallet="${wallet:-}"
  [ -z "$sol" ] && sol="${sol:-}"
  [ -z "$nos" ] && nos="${nos:-}"
  if echo "$status" | grep -q 'initializing' && [ -n "${status:-}" ]; then
    status="${status:-$status}"
  fi
  [ -z "$queue" ] && queue="${queue:-}"
fi

format4(){ awk -v n="${1:-0}" 'BEGIN{printf("%.4f", n+0)}'; }
sol4="N/A"; [ -n "$sol" ] && sol4="$(format4 "$sol")"
nos4="N/A"; [ -n "$nos" ] && nos4="$(format4 "$nos")"
wal5="N/A"; [ -n "$wallet" ] && wal5="$(printf '%s' "$wallet" | cut -c1-5)"
ver="S:${sol4} N:${nos4} W:${wal5}"; [ -n "$queue" ] && ver="${ver} Q:${queue}"

# GPU stats
temp_json='[]'; fan_json='[]'; bus_json='[]'
if [ -f /hive/bin/gpu-stats ]; then
  . /hive/bin/gpu-stats 2>/dev/null
  if [ "${#GPU_TEMP[@]}" -gt 0 ] 2>/dev/null; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [ "${#GPU_FAN[@]}" -gt 0 ] 2>/dev/null; then fan_json="["$(printf "%s," "${GPU_FAN[@]}" | sed 's/,$//')"]"; fi
  if [ "${#BUS_IDS[@]}" -gt 0 ] 2>/dev/null; then buses=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); buses+=("$d"); done; bus_json="["$(printf "%s," "${buses[@]}" | sed 's/,$//')"]"; fi
fi

# Idle miner hashrate (best-effort)
parse_idle_khs(){
  local L hs_val hs_unit khs="0"
  L="$(tail -n 400 "$IDLE_LOG" 2>/dev/null)"
  if [ -z "$L" ]; then echo "0"; return; fi
  hs_val="$(echo "$L" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1 | awk '{print $1}')"
  hs_unit="$(echo "$L" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1 | awk '{print $2}' | sed 's#/s##I')"
  case "${hs_unit^^}" in
    H)   khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v/1000)}') ;;
    KH)  khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v)}') ;;
    MH)  khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v*1000)}') ;;
    GH)  khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v*1000*1000)}') ;;
    *)   khs="0" ;;
  esac
  echo "$khs"
}

khs="0"; ar_acc="0"; ar_rej="0"
if echo "$status" | grep -qi 'queued' && screen -ls | grep -q '\.nosana-idle'; then
  khs="$(parse_idle_khs)"
fi

# uptime preference: job start > idle start > system uptime
if [ -f "$JOB_START" ]; then
  now=$(date +%s); start=$(cat "$JOB_START" 2>/dev/null); uptime=$((now - start ))
elif [ -f "$IDLE_START" ]; then
  now=$(date +%s); start=$(cat "$IDLE_START" 2>/dev/null); uptime=$((now - start ))
else
  uptime=$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 0)
fi

echo "$khs"
printf '{"hs":[%s],"hs_units":"khs","temp":%s,"fan":%s,"uptime":%s,"ver":"%s","ar":[%s,%s],"algo":"%s","bus_numbers":%s}\n'   "$khs" "$temp_json" "$fan_json" "$uptime" "$ver" "$ar_acc" "$ar_rej" "$status" "$bus_json"

exit 0
