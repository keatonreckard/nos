#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
CONF="$MINER_DIR/nosana.conf"
RAW_EXTRA="$MINER_DIR/extra.raw"

mkdir -p "$MINER_DIR" /var/log/miner/nosana

# Hive passes extra config in $CUSTOM_USER_CONFIG; ensure VERBOSE= prefix once.
EC="${CUSTOM_USER_CONFIG:-}"
if [[ "$EC" =~ ^VERBOSE= ]]; then
  echo "$EC" > "$CONF"
  echo "${EC#VERBOSE=}" > "$RAW_EXTRA"
else
  echo "VERBOSE=$EC" > "$CONF"
  echo "$EC" > "$RAW_EXTRA"
fi

# If keypair is present in extra config, write /root/.nosana/nosana_key.json
mkdir -p /root/.nosana
key_json="$(echo "$EC" | sed -n 's/.*"keypair"[[:space:]]*:[[:space:]]*\(\[[^]]*\]\).*/\1/p' | tail -n1)"
if [[ -n "${key_json}" ]]; then
  printf '%s
' "${key_json}" > /root/.nosana/nosana_key.json
  chmod 600 /root/.nosana/nosana_key.json
fi

# Save idle command/args helper (monitor also reads RAW_EXTRA)
exit 0
