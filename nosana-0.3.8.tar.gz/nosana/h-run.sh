#!/usr/bin/env bash
# Start Nosana node in Docker (with Podman sidecar) + monitor.
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
NOSLOG="$LOG_DIR/nosana.log"
DBG="$LOG_DIR/debug.log"
STATE="/var/run/nosana.state"
LOCK="/var/run/nosana.lock"

log(){ printf '[h-run] %s %s\n' "$(date -Is)" "$*" | tee -a "$DBG" >/dev/null; }

mkdir -p "$LOG_DIR"
: > "$DBG"
: > "$NOSLOG"
echo 'status="nos - initializing"' > "$STATE"

# prevent double-run
exec 9>"$LOCK"
if ! flock -n 9; then
  log "another instance is holding the lock; exiting"
  exit 0
fi

cleanup_containers(){
  docker rm -f nosana-node podman >/dev/null 2>&1 || true
  pkill -f "screen.*nosana-idle" >/dev/null 2>&1 || true
  if [[ -f /var/run/nosana_monitor.pid ]]; then
    kill -9 "$(cat /var/run/nosana_monitor.pid 2>/dev/null || echo 0)" >/dev/null 2>&1 || true
    rm -f /var/run/nosana_monitor.pid
  fi
}

install_reqs(){
  # gpg (as requested)
  if ! command -v gpg >/dev/null 2>&1; then
    log "installing gpg"
    apt-get update -y || true
    DEBIAN_FRONTEND=noninteractive apt-get install -y gpg || true
  fi
  # docker via provided flow if missing
  if ! command -v docker >/dev/null 2>&1; then
    log "docker not found, installing via provided script"
    tmpdir=$(mktemp -d)
    pushd "$tmpdir" >/dev/null
    cat > install_docker_slave.sh <<'EOS'
#!/bin/bash
set -e
sudo apt-get update || true
sudo apt-get install -y --allow-downgrades ca-certificates curl || true
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
sudo apt-get update || true
sudo apt-get install -y --allow-downgrades docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin || true
if [ -f "/etc/hiveos-release" ]; then
  sudo apt-get install -y --allow-downgrades iptables arptables ebtables
  sudo update-alternatives --set iptables /usr/sbin/iptables-legacy
  sudo update-alternatives --set ip6tables /usr/sbin/ip6tables-legacy
fi
sudo mkdir -p /etc/systemd/system/docker.service.d
echo -e "[Service]\nExecStart=\nExecStart=/usr/bin/dockerd -H fd:// --containerd=/run/containerd/containerd.sock --ip6tables=false" | sudo tee /etc/systemd/system/docker.service.d/override.conf
sudo systemctl daemon-reload
sudo systemctl enable --now docker
sudo systemctl restart docker
EOS
    chmod +x install_docker_slave.sh
    ./install_docker_slave.sh || true
    popd >/dev/null
  fi
}

start_podman_sidecar(){
  log "starting podman sidecar"
  docker volume create podman-cache >/dev/null 2>&1 || true
  docker volume create podman-socket >/dev/null 2>&1 || true
  docker rm -f podman >/dev/null 2>&1 || true
  docker run -d --pull=always --gpus=all --name podman     --device /dev/fuse     --mount source=podman-cache,target=/var/lib/containers     --volume podman-socket:/podman     --privileged -e ENABLE_GPU=true     nosana/podman:v1.1.0 unix:/podman/podman.sock >>"$DBG" 2>&1 || true
  sleep 5
}

start_nosana_node(){
  log "starting nosana-node container"
  docker rm -f nosana-node >/dev/null 2>&1 || true
  docker run -d --pull=always --name nosana-node     --network host     --gpus all     --volume /root/.nosana/:/root/.nosana/     --volume podman-socket:/root/.nosana/podman:ro     -e CLI_VERSION=     nosana/nosana-cli:latest       node start --network mainnet >>"$DBG" 2>&1
}

start_monitor(){
  log "monitor start"
  bash -lc "nohup $MINER_DIR/monitor.sh >> '$DBG' 2>&1 &" >/dev/null 2>&1 || true
}

stream_logs(){
  # stream container logs to miner log
  ( docker logs -f nosana-node 2>&1 | stdbuf -oL -eL sed -u 's/\r//g' >> "$NOSLOG" ) &
}

log "cleaning previous containers"
cleanup_containers
install_reqs
start_podman_sidecar
start_nosana_node
stream_logs
start_monitor

# keep process alive while container lives
( while docker ps --format '{{.Names}}' | grep -q '^nosana-node$'; do sleep 5; done ) || true
exit 0
