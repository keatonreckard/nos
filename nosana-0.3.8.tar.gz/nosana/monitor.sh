#!/usr/bin/env bash
set -u

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
NOSLOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
DBG="$LOG_DIR/debug.log"
STATE="/var/run/nosana.state"
RAW_EXTRA="$MINER_DIR/extra.raw"
IDLE_START="/var/run/nosana_idle.start"
JOB_START="/var/run/nosana_job.start"

mkdir -p "$LOG_DIR"

log() { printf '[monitor] %s %s\n' "$(date -Is)" "$*" | tee -a "$DBG" >/dev/null; }
set_kv() {
  local k="$1" v="$2"
  if [ -f "$STATE" ] && grep -qE "^${k}=" "$STATE" 2>/dev/null; then
    local tmp; tmp="$(mktemp)"
    awk -v K="$k" -v V="$v" 'BEGIN{q="""} { if ($0 ~ "^"K"=") print K"="q V q; else print }' "$STATE" > "$tmp" && mv "$tmp" "$STATE"
  else
    echo "${k}="${v}"" >> "$STATE"
  fi
}
ensure_state(){ [ -f "$STATE" ] || echo 'status="nos - initializing"' > "$STATE"; }

get_idle_cmd(){
  local raw=""
  if [ -s "$RAW_EXTRA" ]; then
    raw="$(cat "$RAW_EXTRA")"
  elif [ -s "$MINER_DIR/nosana.conf" ]; then
    raw="$(sed 's/^VERBOSE=//' "$MINER_DIR/nosana.conf")"
  fi
  local cmd args
  cmd="$(echo "$raw" | sed -n 's/.*"idleSettings"[^{]*{[^}]*"command"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | tail -n1)"
  args="$(echo "$raw" | sed -n 's/.*"idleSettings"[^{]*{[^}]*"arguments"[[:space:]]*":[[:space:]]*"\([^"]*\)".*/\1/p' | tail -n1)"
  echo "$cmd|$args"
}

idle_start(){
  local pair cmd args
  pair="$(get_idle_cmd)"
  cmd="${pair%%|*}"; args="${pair#*|}"
  if [ -z "$cmd" ]; then
    log "idle_start: no idleSettings.command found"
    return 0
  fi
  if ! screen -ls | grep -q "\.nosana-idle"; then
    echo "[nosana] idle start: $cmd $args" >> "$IDLE_LOG"
    log "starting idle screen: $cmd $args"
    date +%s > "$IDLE_START"
    screen -S nosana-idle -dm bash -lc "$cmd $args >> \"$IDLE_LOG\" 2>&1"
    set_kv idle_enabled "1"
  fi
}

idle_stop(){
  if screen -ls | grep -q "\.nosana-idle"; then
    log "stopping idle screen"
    screen -S nosana-idle -X quit || true
    echo "[nosana] idle stop" >> "$IDLE_LOG"
  fi
  rm -f "$IDLE_START"
  set_kv idle_enabled "0"
}

update_state_from_line(){
  local L="$1" w s n q
  if echo "$L" | grep -Eq 'Wallet:[[:space:]]+[A-Za-z0-9]{32,64}'; then
    w="$(echo "$L" | sed -n 's/.*Wallet:[[:space:]]*\([A-Za-z0-9]\{32,64\}\).*/\1/p')"
    [ -n "$w" ] && set_kv wallet "$w"
  fi
  if echo "$L" | grep -Eq 'SOL balance:[[:space:]]*[0-9]'; then
    s="$(echo "$L" | sed -n 's/.*SOL balance:[[:space:]]*\([0-9.]*\).*/\1/p')"
    [ -n "$s" ] && set_kv sol "$s"
  fi
  if echo "$L" | grep -Eq 'NOS balance:[[:space:]]*[0-9]'; then
    n="$(echo "$L" | sed -n 's/.*NOS balance:[[:space:]]*\([0-9.]*\).*/\1/p')"
    [ -n "$n" ] && set_kv nos "$n"
  fi
  if echo "$L" | grep -Eq 'QUEUED.*position[[:space:]][0-9]+/[0-9]+'; then
    q="$(echo "$L" | sed -n 's/.*position[[:space:]]\([0-9]\+\/[0-9]\+\).*/\1/p' | tail -n1)"
    if [ -n "$q" ]; then
      set_kv queue "$q"
      set_kv status "nos - queued $q"
      idle_start
      rm -f "$JOB_START"
    fi
  fi
  if echo "$L" | grep -Eiq 'claimed job|started successfully|is resuming|resumed|is running|Running container '; then
    set_kv status "nos - job"
    date +%s > "$JOB_START"
    idle_stop
  fi
  if echo "$L" | grep -Eq 'finished successfully|RESTARTING'; then
    set_kv status "nos - initializing"
  fi
}

bootstrap_from_log(){
  if [ -s "$NOSLOG" ]; then
    stdbuf -oL -eL tail -n 1000 "$NOSLOG" | while IFS= read -r line; do
      update_state_from_line "$line"
    done
  fi
}

main(){
  ensure_state
  log "monitor started pid=$$"
  bootstrap_from_log
  stdbuf -oL -eL tail -n0 -F "$NOSLOG" 2>/dev/null | while IFS= read -r line; do
    update_state_from_line "$line"
  done
}
main &
echo $$ > /var/run/nosana_monitor.pid
wait
