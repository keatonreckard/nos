#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
LOG_DIR="/var/log/miner/nosana"
CUSTOM_LOG="/var/log/miner/custom/custom.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
PIDFILE="$RUN_DIR/nosana.idlewatch.pid"
mkdir -p "$RUN_DIR" "$LOG_DIR" "$(dirname "$CUSTOM_LOG")"
touch "$NOSANA_LOG" "$IDLE_LOG" "$CUSTOM_LOG"
echo "[idle-queue] watcher online" | tee -a "$CUSTOM_LOG" >/dev/null
start_idle(){ echo "[idle-queue] starting idle via EXTRA config" | tee -a "$IDLE_LOG" "$CUSTOM_LOG" >/dev/null; ( bash -lc "$MINER_DIR/idle-run.sh" ) >>"$IDLE_LOG" 2>&1 || true; }
stop_idle(){ echo "[idle-queue] stopping idle" | tee -a "$IDLE_LOG" "$CUSTOM_LOG" >/dev/null; bash "$MINER_DIR/idle-stop.sh" >>"$IDLE_LOG" 2>&1 || true; }
detect_state(){
  local L CLEAN
  L="$(podman logs --tail 400 nosana-node 2>/dev/null || docker logs --tail 400 nosana-node 2>/dev/null || true)"
  [[ -z "$L" && -s "$NOSANA_LOG" ]] && L="$(tail -n 400 "$NOSANA_LOG" 2>/dev/null)"
  [[ -z "$L" ]] && { echo init; return 0; }
  CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"
  if printf "%s\n" "$CLEAN" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* (started|running)|Flow .* (started|running)'; then echo job; return 0; fi
  if printf "%s\n" "$CLEAN" | grep -Eqi '(^|[[:space:]])QUEUED([[:space:]]|$)|position[[:space:]]+[0-9]+/[0-9]+|\[nosana\][[:space:]]+queued'; then echo queued; return 0; fi
  echo init
}
if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE" 2>/dev/null)" 2>/dev/null; then exit 0; fi
echo $$ > "$PIDFILE"
trap 'rm -f "$PIDFILE"; exit 0' INT TERM EXIT
last=""
while true; do
  state="$(detect_state)"
  if [[ "$state" != "$last" ]]; then
    case "$state" in
      job)    stop_idle ;;
      queued) start_idle ;;
      *)      : ;;
    esac
    last="$state"
  fi
  sleep 8
done
