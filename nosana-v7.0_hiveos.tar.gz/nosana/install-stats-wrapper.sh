#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Preserve original once
if [ -f "$DIR/h-stats.sh" ] && [ ! -f "$DIR/h-stats.orig" ]; then
  cp -f "$DIR/h-stats.sh" "$DIR/h-stats.orig"
fi

# Install wrapper as the active h-stats.sh
cp -f "$DIR/h-stats-wrapper.sh" "$DIR/h-stats.sh"
chmod 0755 "$DIR/h-stats.sh"

echo "Installed stats wrapper. Original saved as h-stats.orig"
