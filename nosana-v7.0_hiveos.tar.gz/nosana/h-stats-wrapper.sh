#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Run the original h-stats.sh to produce base JSON
BASE_JSON="$("$DIR/h-stats.sh" 2>/dev/null || true)"

# If the base script failed or returned empty, fail gracefully
if [ -z "$BASE_JSON" ]; then
  echo '{"hs":[0],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"S:0.0000 N:0.0000 W:N/A","ar":[0,0],"algo":"nos"}'
  exit 0
fi

# Pull status from nosana.state (e.g., "queued 48/48" or "job" / "running")
STATE_FILE="/var/run/nosana.state"
status_raw=""
if [ -f "$STATE_FILE" ]; then
  # read first "status=" occurrence
  status_raw="$(grep -m1 -E '^status=' "$STATE_FILE" | sed 's/^status=//')"
fi

queue_flag=""
queue_nums=""
if echo "$status_raw" | grep -qi 'queued'; then
  queue_flag="queued"
  # Extract numbers like 48/48 from "queued 48/48"
  queue_nums="$(echo "$status_raw" | grep -oE '[0-9]+/[0-9]+' | head -n1)"
fi

# Extract existing ver and algo from JSON (very tolerant parsing; no jq dependency)
# Note: We keep all other fields intact, only rewrite the "ver" and "algo" pairs.
get_json_field () {
  # $1: field name
  # $2: JSON string (single line)
  # Returns unescaped value or empty
  awk -v k="\"$1\"" 'BEGIN{RS=","; FS=":"} {
    for(i=1;i<=NF;i++){ 
      if($i~k){ 
        # Rejoin rest from i+1.. end for safety
        v=""; for(j=i+1;j<=NF;j++){ v=v (($j&&(j==i+1))?$j:":"$j) }
        # strip quotes and possible trailing braces
        gsub(/^[[:space:]]*\"/, "", v); gsub(/\"[[:space:]]*$/, "", v);
        gsub(/^[[:space:]]*\"/, "", v); gsub(/\"[[:space:]]*[\}\]]*$/, "", v);
        print v; exit
      } 
    }
  }' <(echo "$2") 2>/dev/null
}

escape_sed () { echo "$1" | sed -e 's/[\/&]/\\&/g'; }

ver_now="$(echo "$BASE_JSON" | sed -n 's/.*"ver"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)"
algo_now="$(echo "$BASE_JSON" | sed -n 's/.*"algo"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)"

new_ver="$ver_now"
new_algo="$algo_now"

# If queued and we have X/Y numbers, ensure ver includes " Q:X/Y"
if [ -n "$queue_flag" ] && [ -n "$queue_nums" ]; then
  if ! echo "$new_ver" | grep -q 'Q:'; then
    if [ -n "$new_ver" ]; then
      new_ver="$new_ver Q:$queue_nums"
    else
      new_ver="Q:$queue_nums"
    fi
  fi
  # Force algo to "nos - queued X/Y", mirroring the original working behavior
  new_algo="nos - queued $queue_nums"
else
  # If not queued, try to reflect job/running
  if echo "$status_raw" | grep -qiE '(job|running|active)'; then
    new_algo="nos - job"
  elif [ -z "$status_raw" ]; then
    # Fall back to whatever base had; otherwise keep "nos"
    if [ -z "$new_algo" ]; then new_algo="nos"; fi
  fi
fi

# If extraction failed, keep originals
if [ -z "$new_ver" ]; then new_ver="$ver_now"; fi
if [ -z "$new_algo" ]; then new_algo="$algo_now"; fi

# Replace the fields in the JSON (only the first occurrence)
ver_esc="$(escape_sed "$ver_now")"
new_ver_esc="$(escape_sed "$new_ver")"
algo_esc="$(escape_sed "$algo_now")"
new_algo_esc="$(escape_sed "$new_algo")"

OUT="$BASE_JSON"
if echo "$OUT" | grep -q '"ver"'; then
  OUT="$(echo "$OUT" | sed "0,/\(\"ver\"[[:space:]]*:[[:space:]]*\"\)$ver_esc\(\"*\)/s//\1$new_ver_esc\2/")"
fi
if echo "$OUT" | grep -q '"algo"'; then
  OUT="$(echo "$OUT" | sed "0,/\(\"algo\"[[:space:]]*:[[:space:]]*\"\)$algo_esc\(\"*\)/s//\1$new_algo_esc\2/")"
fi

echo "$OUT"
