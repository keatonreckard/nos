Nosana wrapper v3.1.16: relaxed parsing for Wallet/SOL/NOS; robust algo & version.
