#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"

mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""; idle_enabled=0
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

L=""; [[ -f "$NOSANA_LOG" ]] && L="$(tail -n 2000 "$NOSANA_LOG" | tr -d '\r')"

# Wallet (take token after 'Wallet:')
if [[ -z "${wallet:-}" && -n "$L" ]]; then
  wallet="$(printf "%s\n" "$L" | grep -E 'Wallet:[[:space:]]*[A-Za-z0-9]+' | tail -n1 | sed -E 's/.*Wallet:[[:space:]]*([^[:space:]]+).*/\1/')"
fi

# Balances (numbers after 'SOL balance:' / 'NOS balance:')
if [[ -z "${sol:-}" && -n "$L" ]]; then
  sol="$(printf "%s\n" "$L" | grep -E 'SOL balance:[[:space:]]*[0-9]' | tail -n1 | sed -E 's/.*SOL balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/')"
fi
if [[ -z "${nos:-}" && -n "$L" ]]; then
  nos="$(printf "%s\n" "$L" | grep -E 'NOS balance:[[:space:]]*[0-9]' | tail -n1 | sed -E 's/.*NOS balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/')"
fi

# Determine status
if [[ -n "$L" ]]; then
  if printf "%s\n" "$L" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
    status="nos - job"; queue=""
  else
    pos="$(printf "%s\n" "$L" | grep -Eo 'position[[:space:]]+[0-9]+/[0-9]+' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/')"
    if [[ -n "${pos:-}" ]]; then
      status="nos - queued ${pos}"; queue="${pos}"
    elif printf "%s\n" "$L" | grep -Eqi 'QUEUED'; then
      status="nos - queued"
    fi
  fi
fi

# Uptime
now=$(date +%s)
if [[ -f "$MINER_DIR/job.start.time" ]]; then start_time=$(cat "$MINER_DIR/job.start.time")
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then start_time=$(cat "$MINER_DIR/idle.start.time")
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then start_time=$(cat "$MINER_DIR/nosana.start.time")
else read -r up _ < /proc/uptime; start_time=$(( now - ${up%.*} )); fi
uptime=$((now - start_time)); ((uptime<0)) && uptime=0

# Idle passthrough
parse_idle_stats() {
  [[ -s "$IDLE_LOG" ]] || { echo "0|0|0"; return; }
  local L2 hs_val hs_unit khs="0" acc="0" rej="0"
  L2="$(tail -n 400 "$IDLE_LOG")"
  local line="$(echo "$L2" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1)"
  hs_val="$(printf "%s\n" "$line" | sed -E 's/^([0-9]+(\.[0-9]+)?).*/\1/')"
  hs_unit="$(printf "%s\n" "$line" | sed -E 's/^[0-9]+(\.[0-9]+)?[[:space:]]*([A-Za-z]+).*/\2/I' | tr '[:lower:]' '[:upper:]' | sed 's/S$//')"
  case "$hs_unit" in
    H)  khs=$(python3 - <<PY
v="$hs_val"
try:
    print(f"{float(v)/1000:.6f}")
except Exception:
    print("0")
PY
);;
    KH) khs="$hs_val";;
    MH) khs=$(python3 - <<PY
v="$hs_val"
try:
    print(f"{float(v)*1000:.6f}")
except Exception:
    print("0")
PY
);;
    GH) khs=$(python3 - <<PY
v="$hs_val"
try:
    print(f"{float(v)*1000*1000:.6f}")
except Exception:
    print("0")
PY
);;
  esac

  # Shares (best-effort)
  if echo "$L2" | grep -Eiq '([0-9]+/[0-9]+|A:[0-9]+)'; then
    if echo "$L2" | grep -Eio '([0-9]+)\/([0-9]+)'; then
      acc=$(echo "$L2" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f1)
      rej=$(echo "$L2" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f2)
    else
      acc=$(echo "$L2" | grep -Eio 'A:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)
      rej=$(echo "$L2" | grep -Eio 'R:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)
    fi
  fi
  echo "${khs}|${acc}|${rej}"
}

algo="${status:-nos}"
khs="0"; ar_acc="0"; ar_rej="0"
if echo "$algo" | grep -qi 'queued'; then
  IFS='|' read -r khs ar_acc ar_rej <<<"$(parse_idle_stats)"
  [[ -z "$khs" || "$khs" == "0" ]] && khs="999"
fi

# Build version string
ver=""
if [[ -n "${sol:-}" ]]; then printf -v solf "%.4f" "$(printf "%s" "$sol")"; ver+="S:${solf}"; fi
if [[ -n "${nos:-}" ]]; then printf -v nosf "%.4f" "$(printf "%s" "$nos")"; ver+="${ver:+ }N:${nosf}"; fi
if [[ -n "${wallet:-}" ]]; then ver+="${ver:+ }W:$(printf "%s" "$wallet" | cut -c1-5)"; fi

# GPU arrays (best-effort)
temp_json='[]'; fan_json='[]'; bus_json='[]'
if [[ -f /hive/bin/gpu-stats ]]; then
  source /hive/bin/gpu-stats || true
  if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [[ "${#GPU_FAN[@]:-0}" -gt 0 ]]; then  fan_json ="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
  if [[ "${#BUS_IDS[@]:-0}" -gt 0 ]]; then
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

stats=$(cat <<JSON
{"hs":[${khs}],"hs_units":"khs","temp":${temp_json},"fan":${fan_json},"uptime":${uptime},"ver":"${ver}","ar":[${ar_acc},${ar_rej}],"algo":"${algo}","bus_numbers":${bus_json}}
JSON
)
printf "[%s] h-stats: ver=%s | algo=%s | khs=%s | wallet=%s | sol=%s | nos=%s\n" "$(date -Iseconds)" "$ver" "$algo" "$khs" "$wallet" "$sol" "$nos" >> "$LOG_DIR/debug.log" || true
echo "$stats"
