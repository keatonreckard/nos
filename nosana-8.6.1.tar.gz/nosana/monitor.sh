#!/bin/bash

log_file=$1
debug_log="/hive/miners/custom/nosana/debug.log"
cd /hive/miners/custom/nosana

# Ensure debug log exists
touch "$debug_log"

# Tail the log and parse
tail -f "$log_file" | while read -r line; do
  echo "$line" >> "$debug_log"  # Append to debug for upload

  if [[ "$line" == *"SOL balance:"* ]]; then
    sol=$(echo "$line" | awk '{print $3}' | xargs -I {} bash -c 'printf "%.4f" {}')
    echo "$sol" > sol_bal
    echo "Parsed SOL balance: $sol" >> "$debug_log"
  fi

  if [[ "$line" == *"NOS balance:"* ]]; then
    nos=$(echo "$line" | awk '{print $3}' | xargs -I {} bash -c 'printf "%.4f" {}')
    echo "$nos" > nos_bal
    echo "Parsed NOS balance: $nos" >> "$debug_log"
  fi

  if [[ "$line" == *"Wallet:"* ]]; then
    wallet=$(echo "$line" | awk '{print $2}')
    echo "$wallet" > wallet.txt
    echo "Parsed Wallet: $wallet" >> "$debug_log"
  fi

  if [[ "$line" == *"QUEUED"* ]]; then
    pos=$(echo "$line" | grep -oP 'position \K\d+/\d+')
    if [[ -n "$pos" ]]; then
      echo "nos - queued $pos" > algo.state
      echo "Updated algo to nos - queued $pos" >> "$debug_log"
    fi
    # Start idle miner if not running and settings exist
    if [ ! -f idle.pid ] && [ -f idle_command ] && [ -f idle_arguments ]; then
      command=$(cat idle_command)
      arguments=$(cat idle_arguments)
      $command $arguments &
      echo $! > idle.pid
      echo "Started idle miner with PID $!" >> "$debug_log"
    fi
  fi

  if [[ "$line" == *"Node has claimed job"* ]]; then
    echo "nos - job" > algo.state
    echo "Updated algo to nos - job" >> "$debug_log"
    if [ -f idle.pid ]; then
      kill $(cat idle.pid)
      rm -f idle.pid
      echo "Killed idle miner" >> "$debug_log"
    fi
  fi
done