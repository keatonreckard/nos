#!/bin/bash

cd /hive/miners/custom/nosana

temp_json='[]'
fan_json='[]'
busid_json='[]'
if [ -f /hive/bin/gpu-stats ]; then
  source /hive/bin/gpu-stats
fi

get_cpu_temps () {
  local t_core=`cpu-temp`
  local i=0
  local l_num_cores=$1
  local l_temp=
  for (( i=0; i < ${l_num_cores}; i++ )); do
    l_temp+="$t_core "
  done
  echo ${l_temp[@]} | tr " " "\n" | jq -cs '.'
}

get_cpu_fans () {
  local t_fan=0
  local i=0
  local l_num_cores=$1
  local l_fan=
  for (( i=0; i < ${l_num_cores}; i++ )); do
    l_fan+="$t_fan "
  done
  echo ${l_fan[@]} | tr " " "\n" | jq -cs '.'
}

get_cpu_bus_numbers () {
  local i=0
  local l_num_cores=$1
  local l_numbers=
  for (( i=0; i < ${l_num_cores}; i++ )); do
    l_numbers+="null "
  done
  echo ${l_numbers[@]} | tr " " "\n" | jq -cs '.'
}

algo=$(cat algo.state 2>/dev/null || echo "nos - initializing")
sol_bal=$(cat sol_bal 2>/dev/null || echo "0.0000")
nos_bal=$(cat nos_bal 2>/dev/null || echo "0.0000")
wallet=$(cat wallet.txt 2>/dev/null || echo "unknown")

ver="nosana 8.6.1 | SOL:$sol_bal NOS:$nos_bal Wallet:$wallet"

uptime=$(awk '{print int($1)}' /proc/uptime)

if [[ $algo == "nos - queued"* ]]; then
  # Idle mode, get stats from idle miner assuming it's srbminer-like
  API_TIMEOUT=5
  stats_raw=`curl --connect-timeout 2 --max-time $API_TIMEOUT --silent --noproxy '*' http://127.0.0.1:21550`
  if [[ $? -ne 0 || -z $stats_raw ]]; then
    khs=0
    stats=null
  else
    dpkg --compare-versions "`jq -r '.miner_version' <<< \"$stats_raw\"`" "gt" "0.4.7"; [[ $? -eq "0" ]] && local ver=1 || local ver=0;

    local dev_numbers=`echo $stats_raw | jq -r '.gpu_devices[].id'`
    if [[ ! -z $dev_numbers ]]; then
      local gpu_hs=
      for i in $dev_numbers; do
        (($ver)) && local t_hs=`echo $stats_raw | jq -r '.algorithms[0].hashrate.gpu | to_entries[] | select(.key == "gpu'$i'") | .value'` ||
                    local t_hs=`echo $stats_raw | jq -r '.gpu_hashrate[] | to_entries | .['$i'].value'`
        if [[ ! -z $t_hs ]]; then
          gpu_hs+="$t_hs "
        else
          gpu_hs+="0 "
        fi
      done
      gpu_hs=`echo ${gpu_hs[@]} | jq -cs '.'`
      local gpu_fan=; local gpu_temp=
      local gpu_bus_numbers=`echo $stats_raw | jq -r '.gpu_devices[].bus_id' | jq -cs '.'`
      local all_bus_ids_array=(`echo "$gpu_detect_json" | jq -r '[ . | to_entries[] | select(.value) | .value.busid [0:2] ] | .[]'`)
      local miner_bus_ids_array=(`echo "$gpu_bus_numbers" | jq -r '.[]'`)
      for ((i = 0; i < ${#miner_bus_ids_array[@]}; i++)); do
        for ((j = 0; j < ${#all_bus_ids_array[@]}; j++)); do
          if [[ "$(( 0x${all_bus_ids_array[$j]} ))" -eq "${miner_bus_ids_array[$i]}" ]]; then
            gpu_fan+=$(jq .[$j] <<< $fan_json)" "
            gpu_temp+=$(jq .[$j] <<< $temp_json)" "
          fi
        done
      done
      gpu_fan=`echo ${gpu_fan[@]} | jq -cs '.'`
      gpu_temp=`echo ${gpu_temp[@]} | jq -cs '.'`
      local gpu_bus_numbers=`echo ${gpu_bus_numbers[@]} | jq -cs '.'`
    fi

    local ac=`echo $stats_raw | jq -r '.algorithms[0].shares.accepted'`
    local rj=`echo $stats_raw | jq -r '.algorithms[0].shares.rejected'`
    local algo=`echo $stats_raw | jq -r '.algorithms[0].name'`
    khs=`echo $stats_raw | jq -r '.algorithms[0].hashrate.now' | awk '{print $1/1000}'`
    if [[ $khs -eq 0 ]]; then
      khs=`echo $stats_raw | jq -r '.algorithms[0].hashrate."1min"' | awk '{print $1/1000}'`
    fi

    local cpu_hs=`echo $stats_raw | jq -r '.algorithms[0].hashrate.cpu | to_entries | .[]|select(.key | contains("thread")) | .value' | jq -cs '.'`
    local cpu_threads=`echo $stats_raw | jq '.algorithms[0].hashrate.cpu | to_entries[] | select(.key | contains("thread")) | .key' | wc -l`
    if [[ $cpu_threads -gt 0 ]]; then
      cpu_bus_numbers=`get_cpu_bus_numbers $cpu_threads`
      cpu_fan=`get_cpu_fans $cpu_threads`
      cpu_temp=`get_cpu_temps $cpu_threads`
      hs=`jq -sc '.[0] + .[1]' <<< "$gpu_hs $cpu_hs"`
      bus_numbers=`jq -sc '.[0] + .[1]' <<< "$gpu_bus_numbers $cpu_bus_numbers"`
      temp=`jq -sc '.[0] + .[1]' <<< "$gpu_temp $cpu_temp"`
      fan=`jq -sc '.[0] + .[1]' <<< "$gpu_fan $cpu_fan"`
    else
      hs=$gpu_hs
      bus_numbers=$gpu_bus_numbers
      temp=$gpu_temp
      fan=$gpu_fan
    fi

    stats=$(jq -nc \
      --arg total_khs "$khs" \
      --argjson hs "$hs" \
      --arg hs_units "hs" \
      --argjson temp "$temp" \
      --argjson fan "$fan" \
      --arg uptime "$uptime" \
      --arg ver "$ver" \
      --argjson ar "[$ac,$rj]" \
      --arg algo "$algo" \
      --argjson bus_numbers "$bus_numbers" \
      '{total_khs: $total_khs, hs: $hs, hs_units: $hs_units, temp: $temp, fan: $fan, uptime: $uptime, ver: $ver, ar: $ar, algo: $algo, bus_numbers: $bus_numbers}')
  else
    stats=null
    khs=0
  fi
else
  # Normal Nosana mode
  khs=0
  stats=$(jq -nc \
    --argjson hs "[]" \
    --arg hs_units "khs" \
    --argjson temp "$temp_json" \
    --argjson fan "$fan_json" \
    --arg uptime "$uptime" \
    --arg ver "$ver" \
    --argjson ar "[0,0]" \
    --arg algo "$algo" \
    --argjson bus_numbers "$busid_json" \
    '{hs: $hs, hs_units: $hs_units, temp: $temp, fan: $fan, uptime: $uptime, ver: $ver, ar: $ar, algo: $algo, bus_numbers: $bus_numbers}')
fi

echo $khs
echo $stats