#!/bin/bash

cd /hive/miners/custom/nosana

source /hive/bin/gpu-stats

khs=0

algo=$(cat algo.state 2>/dev/null || echo "nos - initializing")
sol_bal=$(cat sol_bal 2>/dev/null || echo "0.0000")
nos_bal=$(cat nos_bal 2>/dev/null || echo "0.0000")
wallet=$(cat wallet.txt 2>/dev/null || echo "unknown")

ver="nosana 1.0 | SOL:$sol_bal NOS:$nos_bal Wallet:$wallet"

uptime=$(awk '{print int($1)}' /proc/uptime)

stats=$(jq -nc \
  --argjson hs "[]" \
  --arg hs_units "khs" \
  --argjson temp "$temp_json" \
  --argjson fan "$fan_json" \
  --arg uptime "$uptime" \
  --arg ver "$ver" \
  --argjson ar "[0,0]" \
  --arg algo "$algo" \
  --argjson bus_numbers "$busid_json" \
  '{hs: $hs, hs_units: $hs_units, temp: $temp, fan: $fan, uptime: $uptime, ver: $ver, ar: $ar, algo: $algo, bus_numbers: $bus_numbers}')