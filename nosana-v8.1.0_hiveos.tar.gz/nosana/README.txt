NOSANA (HiveOS custom miner package)
-----------------------------------
Built: 2025-08-21T16:50:16

v8.1.0_hiveos:
- h-stats-wrapper.sh now *executes* your miner's h-stats.sh and echoes its stdout (no sourcing).
  This ensures the full miner_stats object (hs, hs_units, temp, fan, uptime, ver, algo, bus_numbers) is sent.
- h-stats.sh: 
  - removed "ar" at the source and sanitized at final print
  - KH/s mapping intact (init+job=>1, queued X/Y=>X), algo text untouched
  - added version cache at /var/run/nosana.ver to prevent empty "ver"
- Idle logic (monitor/idle-run/idle-kill/idle-screen/config) kept exactly as uploaded.
