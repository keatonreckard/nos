\
    #!/usr/bin/env bash
    # HiveOS custom miner stats wrapper (executes miner's h-stats.sh and echoes JSON)
    set -euo pipefail
    : "${MINER_DIR:=/hive/miners/custom}"
    if [[ -z "${CUSTOM_MINER:-}" ]]; then
      echo "CUSTOM_MINER is not defined" >&2
      exit 1
    fi
    miner_stats_path="$MINER_DIR/$CUSTOM_MINER/h-stats.sh"
    if [[ ! -x "$miner_stats_path" ]]; then
      echo "$miner_stats_path is missing or not executable" >&2
      exit 1
    fi
    # Execute and pass through the generated JSON
    out="$("$miner_stats_path")" || out=""
    [[ -n "$out" ]] && printf "%s\n" "$out"
