#!/usr/bin/env bash
set -euo pipefail
OUT="$(/hive/miners/custom/nosana/h-stats.sh 2>/dev/null | tail -n1)"
if [[ -z "$OUT" || "${OUT:0:1}" != "{" ]]; then
  OUT='{"hs":[0],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"","ar":[0,0],"algo":"nos","bus_numbers":[]}'
fi
echo "$OUT"
