#!/usr/bin/env bash
# nosana/idle-bridge.sh (v51)
# Usage: idle-bridge.sh start|stop
set -euo pipefail
LOG_DIR="/var/log/miner/nosana"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
PID_FILE="/var/run/nosana.idlebridge.pid"

mkdir -p "$LOG_DIR"

start() {
  # If already running, exit
  if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    exit 0
  fi
  # Ensure idle.log exists to follow (tail will wait if not)
  : > "$IDLE_LOG"
  # Stream idle log into nosana log with tag
  ( exec stdbuf -oL -eL tail -n0 -F "$IDLE_LOG" | sed -u 's/^/[idle-miner] /' >> "$NOSANA_LOG" ) &
  echo $! > "$PID_FILE"
}

stop() {
  if [[ -f "$PID_FILE" ]]; then
    kill "$(cat "$PID_FILE")" 2>/dev/null || true
    rm -f "$PID_FILE"
  fi
}

case "${1:-start}" in
  start) start ;;
  stop)  stop ;;
  *) echo "usage: $0 start|stop" >&2; exit 1 ;;
esac
