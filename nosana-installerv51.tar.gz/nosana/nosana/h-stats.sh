#!/usr/bin/env bash
# nosana/h-stats.sh (v51)
# Prints two lines:
# 1) total khs as a plain number
# 2) JSON with fields: hs, hs_units, temp, fan, uptime, ver, algo, bus_numbers
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

now_ts="$(date +%s)"

# Helpers
strip_ansi() { sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g'; }
jescape() { sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'; }

# Load logs
CLEAN=""
if [[ -s "$NOSANA_LOG" ]]; then
  CLEAN="$(tail -n 1500 "$NOSANA_LOG" | tr -d '\r' | strip_ansi)"
fi

# Wallet / balances for version string
wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
if [[ -z "$wallet" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
fi
sol="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
nos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"

ver=""
if [[ -n "${sol:-}" ]]; then
  printf -v solf "%.4f" "$sol"; ver+="S:${solf}"
fi
if [[ -n "${nos:-}" ]]; then
  printf -v nosf "%.4f" "$nos"; ver+="${ver:+ }N:${nosf}"
fi
if [[ -n "${wallet:-}" ]]; then
  ver+="${ver:+ }W:$(printf '%s' "$wallet" | cut -c1-5)"
fi

# Detect state
queue="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*QUEUED[[:space:]]+.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
job_running=0
if printf "%s\n" "$CLEAN" | tail -n 200 | grep -Ei 'Pulling image|Downloading \|' >/dev/null 2>&1; then
  job_running=1
fi

algo_base="nos - initializing"
if [[ "$job_running" -eq 1 ]]; then
  algo_base="nos-job"
elif [[ -n "$queue" ]]; then
  algo_base="nos - queued $queue"
fi

# Idle parsing (from idle.log)
gpu_it=0
cpu_it=0
idle_algo=""

if [[ -s "$IDLE_LOG" ]]; then
  ISTR="$(tail -n 200 "$IDLE_LOG" | tr -d '\r' | strip_ansi)"
  # XMR active?
  xmr_count="$(printf "%s\n" "$ISTR" | grep -c "\[XMR\]" || true)"
  if [[ "${xmr_count:-0}" -gt 5 ]]; then
    idle_algo="idle xmr"
    # XMR is CPU-only; take latest "avg it/s" from XMR lines
    cpu_it="$(printf "%s\n" "$ISTR" | awk '/\[XMR\].*avg it\/s/ { for (i=1;i<=NF;i++) if($i=="avg"){print $(i-1); } }' | tail -n1)"
    cpu_it="${cpu_it:-0}"
    # keep gpu_it at 0
  else
    idle_algo="idle qubic"
    # CUDA avg it/s
    gpu_it="$(printf "%s\n" "$ISTR" | awk '/\[CUDA\].*avg it\/s/ { for (i=1;i<=NF;i++) if($i=="avg"){print $(i-1); } }' | tail -n1)"
    gpu_it="${gpu_it:-0}"
    # CPU avg it/s (AVX512/AVX2/GENERIC)
    cpu_it="$(printf "%s\n" "$ISTR" | awk '/\[(AVX512|AVX2|GENERIC)\].*avg it\/s/ { for (i=1;i<=NF;i++) if($i=="avg"){print $(i-1); } }' | tail -n1)"
    cpu_it="${cpu_it:-0}"
  fi
fi

# Build outputs depending on state
hs_json="[]"
hs_units="khs"
bus_json="[]"
temp_json="[]"
fan_json="[]"

khs="1"  # default while initializing / job

if [[ "$job_running" -eq 1 ]]; then
  # nos-job: fixed 1 khs; no idle suffix
  algo="$algo_base"
elif [[ -n "$queue" ]]; then
  # queued: show idle stats (separate GPU + CPU in 'hs' as it/s)
  algo="$algo_base"
  if [[ -n "$idle_algo" ]]; then
    algo="$algo - $idle_algo"
  fi
  # numeric checks
  [[ "$gpu_it" =~ ^[0-9]+(\.[0-9]+)?$ ]] || gpu_it=0
  [[ "$cpu_it" =~ ^[0-9]+(\.[0-9]+)?$ ]] || cpu_it=0
  total_it=$(awk -v a="$gpu_it" -v b="$cpu_it" 'BEGIN{printf "%.6f", a+b}')
  khs=$(awk -v t="$total_it" 'BEGIN{printf "%.6f", t/1000}')
  hs_json=$(printf '[%s,%s]' "$gpu_it" "$cpu_it")
  hs_units="hs"
  # Try to map GPU bus number if agent provides $gpu_stats
  if [[ -n "${gpu_stats:-}" ]]; then
    # Expect JSON; extract first non-CPU busid
    busids="$(echo "$gpu_stats" | jq -r '.busids[]?')"
    brands="$(echo "$gpu_stats" | jq -r '.brand[]?')"
    bnum="null"
    idx=0
    while read -r b; do
      br="$(echo "$brands" | sed -n "$((idx+1))p")"
      if [[ "$br" != "cpu" && -n "$b" ]]; then
        # convert PCI domain like 01:00.0 -> 1
        bn="$(echo "$b" | awk -F: '{print strtonum("0x"$1)}')"
        bnum="$bn"; break
      fi
      idx=$((idx+1))
    done <<< "$busids"
    bus_json=$(printf '[%s,null]' "${bnum:-null}")
  else
    bus_json='[null,null]'
  fi
else
  algo="$algo_base"
fi

# Uptime heuristic: time since nosana.log first appeared in this boot
uptime="0"
if [[ -e "$NOSANA_LOG" ]]; then
  mtime="$(stat -c %Y "$NOSANA_LOG" 2>/dev/null || echo "$now_ts")"
  uptime="$(( now_ts - mtime ))"
fi

# JSON assemble
algo_j="$(printf '%s' "$algo" | jescape)"
ver_j="$(printf '%s' "$ver" | jescape)"

printf "%s\n" "$khs"
printf '{"hs":%s,"hs_units":"%s","temp":%s,"fan":%s,"uptime":%s,"ver":"%s","algo":"%s","bus_numbers":%s}\n' \
  "${hs_json}" "${hs_units}" "${temp_json}" "${fan_json}" "${uptime}" "${ver_j}" "${algo_j}" "${bus_json}"

exit 0
