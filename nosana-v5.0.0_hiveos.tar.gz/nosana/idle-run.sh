#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
DEBUG_LOG="$LOG_DIR/debug.log"
PARSED_DIR="$MINER_DIR/parsed"

mkdir -p "$LOG_DIR" "$PARSED_DIR"
touch "$IDLE_LOG" "$NOSANA_LOG" "$DEBUG_LOG"

IDLE_COMMAND="$(cat "$PARSED_DIR/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$PARSED_DIR/idle_args" 2>/dev/null || true)"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

if [[ -z "${IDLE_COMMAND:-}" ]]; then
  echo "[$(date -Iseconds)] idle-run: no idle command set" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  msg "NOS: idle start failed (no command)"
  exit 1
fi

# If a previous idle screen exists, nuke it
if screen -ls | grep -q "nosana-idle"; then
  screen -S nosana-idle -X quit || true
  sleep 0.5
fi

# Start idle miner in a screen, prefix output with [idle] and tee to both logs
CMDLINE="$IDLE_COMMAND $IDLE_ARGS"
{
  echo "[$(date -Iseconds)] idle-run: starting idle miner: $CMDLINE"
} | tee -a "$DEBUG_LOG" "$NOSANA_LOG"

# Launch in screen so user can attach; ensure immediate interleaving to nosana.log + idle.log
screen -dmS nosana-idle bash -lc "
  set -o pipefail
  ( $IDLE_COMMAND $IDLE_ARGS 2>&1 | awk '{print \"[idle] \"$0}' | tee -a \"$IDLE_LOG\" ) 2>&1 | tee -a \"$NOSANA_LOG\"
"

# Verify it started
sleep 0.6
if screen -ls | grep -q \"nosana-idle\"; then
  echo \"[$(date -Iseconds)] idle-run: idle miner started\" | tee -a \"$DEBUG_LOG\" \"$NOSANA_LOG\"
  msg \"NOS: idle miner started\"
  exit 0
else
  echo \"[$(date -Iseconds)] idle-run: failed to start idle miner\" | tee -a \"$DEBUG_LOG\" \"$NOSANA_LOG\"
  msg \"NOS: idle miner failed to start\"
  exit 2
fi
