#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
DEBUG_LOG="$LOG_DIR/debug.log"
PARSED_DIR="$MINER_DIR/parsed"

for d in /var/log/miner "$LOG_DIR" "$PARSED_DIR"; do mkdir -p "$d" 2>/dev/null || true; done
: > "$IDLE_LOG" || true
: > "$NOSANA_LOG" || true
: > "$DEBUG_LOG" || true

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

IDLE_COMMAND="$(cat "$PARSED_DIR/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$PARSED_DIR/idle_args" 2>/dev/null || true)"

if [[ -z "${IDLE_COMMAND:-}" ]]; then
  echo "[$(date -Iseconds)] idle-run: no idle command set" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  msg "NOS: idle start failed (no command)"; exit 1
fi

# Preflight binary checks
IDLE_DIR="$(dirname "$IDLE_COMMAND")"
IDLE_BIN="$(basename "$IDLE_COMMAND")"
if [[ ! -e "$IDLE_COMMAND" ]]; then
  echo "[$(date -Iseconds)] idle-run: binary not found: $IDLE_COMMAND" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  msg "NOS: idle start failed (binary missing)"; exit 3
fi
if [[ ! -x "$IDLE_COMMAND" ]]; then chmod +x "$IDLE_COMMAND" 2>/dev/null || true; fi

{
  echo "[$(date -Iseconds)] idle-run preflight"
  echo "  whoami=$(whoami)  pwd=$(pwd)" >> "$DEBUG_LOG" 2>&1
  echo "  idle_dir=$IDLE_DIR idle_bin=$IDLE_BIN" >> "$DEBUG_LOG" 2>&1
  ls -l "$IDLE_COMMAND" || true
  command -v screen >> "$DEBUG_LOG" 2>&1 || true || echo "screen not in PATH"
  command -v awk >> "$DEBUG_LOG" 2>&1 || true || echo "awk not in PATH"
  which bash || true
  if command -v file >/dev/null 2>&1; then file "$IDLE_COMMAND" || true; fi
} | tee -a "$DEBUG_LOG" "$NOSANA_LOG"

# Nuke previous session if present
if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then
  screen -S nosana-idle -X quit || true
  sleep 0.2
fi

# Run from the binary's directory; exec ./binary to satisfy relative lookups
screen -dmS nosana-idle bash -c '
  set -o pipefail
  cd "'"$IDLE_DIR"'"
  exec "./'"$IDLE_BIN"'" '"$IDLE_ARGS"' 2>&1 \
    | awk "{print \"[idle] \" \$0}" \
    | tee -a "'"$IDLE_LOG"'" \
    | tee -a "'"$NOSANA_LOG"'"
'

# Verify: check session and process
sleep 1
session_ok=0
proc_ok=0
if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then session_ok=1; fi
# Try to detect the process quickly
if pgrep -f -- "$IDLE_BIN" >/dev/null 2>&1; then proc_ok=1; fi

if [[ $session_ok -eq 1 || $proc_ok -eq 1 ]]; then
  echo "[$(date -Iseconds)] idle-run: idle miner started (session_ok=$session_ok proc_ok=$proc_ok)" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  msg "NOS: idle miner started"; exit 0
else
  echo "[$(date -Iseconds)] idle-run: failed to start (session_ok=$session_ok proc_ok=$proc_ok)" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  echo "Last 50 lines of idle.log:" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  tail -n 50 "$IDLE_LOG" 2>/dev/null | tee -a "$DEBUG_LOG" "$NOSANA_LOG" || true
  msg "NOS: idle miner failed to start"; exit 2
fi
