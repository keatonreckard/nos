#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
CUSTOM_DIR="/var/log/miner/custom"
mkdir -p "$LOG_DIR" "$CUSTOM_DIR" 2>/dev/null || true
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
MINER_LOG="$CUSTOM_DIR/custom.log"

touch "$NOSANA_LOG" "$IDLE_LOG" "$MINER_LOG"

msg(){ [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }
idle_running(){ screen -ls 2>/dev/null | grep -q "\.nosana-idle"; }

start_idle(){
  if ! idle_running; then
    echo "[$(date -Iseconds)] idle-watcher: starting idle miner" | tee -a "$MINER_LOG"
    bash "$MINER_DIR/idle-run.sh" >>"$IDLE_LOG" 2>&1 & disown || true
    msg "NOS: idle miner started"
  fi
}

stop_idle(){
  if idle_running; then
    echo "[$(date -Iseconds)] idle-watcher: stopping idle miner" | tee -a "$MINER_LOG"
    bash "$MINER_DIR/idle-kill.sh" >>"$IDLE_LOG" 2>&1 || true
    msg "NOS: idle miner stopped"
  fi
}

# Heuristic: watch the nosana-node log; start idle on "position X/Y" (queued), stop idle on job start/running
last_pos=""
tail -Fn0 "$NOSANA_LOG" | while read -r line; do
  # queued
  if echo "$line" | grep -Eq "position[[:space:]]+[0-9]+/[0-9]+"; then
    pos="$(echo "$line" | grep -oE '[0-9]+/[0-9]+' | head -n1)"
    if [ -n "$pos" ] && [ "$pos" != "$last_pos" ]; then
      echo "[$(date -Iseconds)] idle-watcher: detected queued $pos" | tee -a "$MINER_LOG"
      start_idle
      last_pos="$pos"
    fi
  fi

  # job started / running
  if echo "$line" | grep -Eqi 'Node is claiming job|Node has claimed job|claimed job|Job .* started|Flow .* started|is running'; then
    echo "[$(date -Iseconds)] idle-watcher: detected job start" | tee -a "$MINER_LOG"
    stop_idle
  fi

  # job finished (doesn't start idle automatically; rely on queued event)
  if echo "$line" | grep -Eq "Nosana Node finished|Job .* completed|finished successfully|Flow .* (finished|completed)"; then
    echo "[$(date -Iseconds)] idle-watcher: job finished" | tee -a "$MINER_LOG"
  fi
done
