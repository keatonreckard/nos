#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR" /var/run

# Prefer Hive's configured basename if available
MINER_LOG="${CUSTOM_LOG_BASENAME:-/var/log/miner/nosana/nosana}.log"
IDLE_LOG="$LOG_DIR/idle.log"
PID_FILE="/var/run/nosana-idle-bridge.pid"

start() {
  # Avoid duplicate tails
  if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    exit 0
  fi

  touch "$IDLE_LOG" "$MINER_LOG"

  # Wait up to 60s for the nosana-idle screen to appear, then enable logging to our path
  for _ in $(seq 1 60); do
    if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then
      # Set log file and turn logging on
      screen -S nosana-idle -X logfile "$IDLE_LOG" || true
      screen -S nosana-idle -X log on || true
      break
    fi
    sleep 1
  done

  # Start bridge (CR->NL, strip ANSI, prefix)
  ( exec stdbuf -o0 -e0 tail -F "$IDLE_LOG" \
      | stdbuf -o0 -e0 sed -u -r 's/\r/\n/g; s/\x1B\[[0-9;?]*[ -\/]*[@-~]//g' \
      | awk '{ print "[idle-miner] " $0 }' >> "$MINER_LOG" ) &

  echo $! > "$PID_FILE"
}

stop() {
  if [[ -f "$PID_FILE" ]]; then
    kill "$(cat "$PID_FILE")" 2>/dev/null || true
    rm -f "$PID_FILE"
  fi
}

case "${1:-}" in
  start) start ;;
  stop) stop ;;
  restart) stop; start ;;
  *) echo "usage: $0 {start|stop|restart}"; exit 1 ;;
esac
