
#!/usr/bin/env bash
set -euo pipefail

IDLE_SCREEN="nosana-idle"
KILL_PAT='qli-Client|qli-worker-AVX512|qli-worker-XMR|qli-worker-CUDA'
MSG=/hive/bin/message

hmsg(){ [ -x "$MSG" ] && "$MSG" info "$1" || echo "$1"; }

idle_kill(){
  screen -S "$IDLE_SCREEN" -X quit 2>/dev/null || true
  pkill -9 -f "$KILL_PAT" 2>/dev/null || true
}

idle_start(){
  # If your package has idle-run.sh, reuse it
  if [ -x /hive/miners/custom/nosana/idle-run.sh ]; then
    bash /hive/miners/custom/nosana/idle-run.sh </dev/null >/dev/null 2>&1 &
  fi
}

job_running(){
  docker exec podman podman ps --format '{{.ID}} {{.Image}} {{.Names}}' \
    | awk 'tolower($0) !~ /tunnel|frpc/ {print}' | grep -q .
}

# Watch docker logs from nosana-node for triggers
( docker logs -f nosana-node 2>&1 || true ) | \
while IFS= read -r line; do
  if echo "$line" | grep -Eqi 'Node has found job|is starting|is intializing|is initializing|Flow .* is initialized'; then
    idle_kill
    hmsg "NOSANA: idle miner killed (job event)"
  fi
done &

# Hourly scheduler: kill at :04, restart at :07 if no job
while :; do
  min=$(date +%M)
  if [ "$min" = "04" ]; then
    idle_kill
    hmsg "NOSANA: idle miner killed (:04)"
    sleep 60
  elif [ "$min" = "07" ]; then
    if ! job_running; then
      idle_start
      hmsg "NOSANA: idle miner restarted (:07, no job)"
    fi
    sleep 60
  else
    sleep 5
  fi
done
