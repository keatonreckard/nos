#!/usr/bin/env bash
# HiveOS custom miner stats wrapper — emit a single method:stats with full miner_stats
set -euo pipefail

MINER_ROOT="/hive/miners/custom"
THIS="${CUSTOM_MINER:-nosana}"
MINER_DIR="$MINER_ROOT/$THIS"
LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

# 1) Get miner JSON (single line)
RAW="$("$MINER_DIR/h-stats.sh" 2>>"$LOG_DIR/debug.log" | tr -d '\r' | head -n1 || true)"
RAW="$(printf "%s" "$RAW" | sed -E ':a;N;$!ba;s/\n/ /g')"
if ! printf "%s" "$RAW" | grep -q '^{'; then
  RAW='{"hs":[0],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"","algo":"nos - initializing","bus_numbers":[]}'
fi

have_jq=0
command -v jq >/dev/null 2>&1 && have_jq=1

# Derivers for ver/algo from nosana.log
compute_ver() {
  local L wallet sol nos v w5
  [[ -s "$LOG_DIR/nosana.log" ]] || return 1
  L="$(tail -n 3000 "$LOG_DIR/nosana.log" | tr -d '\r')"
  wallet="$(printf "%s\n" "$L" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
  [[ -z "$wallet" ]] && wallet="$(printf "%s\n" "$L" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
  sol="$(printf "%s\n" "$L" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
  nos="$(printf "%s\n" "$L" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
  [[ -z "$wallet$sol$nos" ]] && return 1
  [[ -n "$sol" ]] && printf -v sol "%.4f" "$sol"
  [[ -n "$nos" ]] && printf -v nos "%.4f" "$nos"
  w5="$(printf "%s" "$wallet" | cut -c1-5)"
  v=""; [[ -n "$sol" ]] && v+="S:${sol}"
  [[ -n "$nos" ]] && v+="${v:+ }N:${nos}"
  [[ -n "$w5" ]]  && v+="${v:+ }W:${w5}"
  printf "%s" "$v"
}

compute_algo() {
  local L pos
  [[ -s "$LOG_DIR/nosana.log" ]] || { printf "nos - initializing"; return 0; }
  L="$(tail -n 3000 "$LOG_DIR/nosana.log" | tr -d '\r')"
  if printf "%s\n" "$L" | grep -Eqi 'Node is claiming job|Node has found job|Job .* started|Flow .* running|is running'; then
    printf "nos - job"
  else
    pos="$(printf "%s\n" "$L" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
    if [[ -n "$pos" ]]; then
      printf "nos - queued %s" "$pos"
    elif printf "%s\n" "$L" | grep -Eqi 'QUEUED'; then
      printf "nos - queued"
    else
      printf "nos - initializing"
    fi
  fi
}

J="$RAW"
# Strip ar entirely, normalize arrays and hs, fill ver/algo if missing
if [[ $have_jq -eq 1 ]]; then
  nv="$(compute_ver || true)"; na="$(compute_algo)"
  # hs normalization: if value looks like "6/30" or contains '/', keep left side only
  J="$(printf "%s" "$J" | jq -c --arg v "${nv:-}" --arg a "$na" '
    . as $x
    | del(.ar)
    | (if (.temp|type)!="array" then .temp=[] else . end)
    | (if (.fan|type)!="array" then .fan=[] else . end)
    | (if (.bus_numbers|type)!="array" then .bus_numbers=[] else . end)
    | (if (.hs_units|type)!="string" or .hs_units=="" then .hs_units="khs" else . end)
    | (if (.ver|type)!="string" or .ver=="" then (if $v=="" then . else (.ver=$v) end) else . end)
    | (if (.algo|type)!="string" or .algo=="" then .algo=$a else . end)
    | (if (.hs|type)=="array" and ((.hs[0]|tostring|contains("/"))) then
         (.hs[0] = ((.hs[0]|tostring|split("/")[0])|tonumber) )
       else . end)
  ' 2>/dev/null || printf "%s" "$J")"
else
  # Non-jq fallbacks
  J="$(printf "%s" "$J" | sed -E 's/,"ar":\[[^]]*\]//g; s/"ar":\[[^]]*\],?//g')"
  # hs left of slash
  J="$(printf "%s" "$J" | sed -E 's/"hs":\[\s*([0-9.]+)\/[^]]*\]/"hs":[\1]/')"
  # ensure hs_units when absent
  echo "$J" | grep -q '"hs_units"' || J="$(printf "%s" "$J" | sed 's/^{/{\"hs_units\":\"khs\",/')" 
fi

# total_khs (sum or first element)
if [[ $have_jq -eq 1 ]]; then
  total_khs="$(printf "%s" "$J" | jq -r 'try ((.hs | map(tonumber) | add) // (.hs[0]) // 0) catch 0' 2>/dev/null || echo 0)"
else
  total_khs="$(printf "%s" "$J" | sed -nE 's/.*"hs":\[\s*([0-9.]+).*/\1/p')"; total_khs="${total_khs:-0}"
fi

# Emit a single method:stats line with full mirrored miner_stats
printf '{"method":"stats","params":{"miner":"custom","total_khs":%s,"miner_stats":%s}}\n' \
  "${total_khs:-0}" \
  "$(printf "%s" "$J")"
