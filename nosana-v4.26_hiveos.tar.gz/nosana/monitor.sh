#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
STATE_FILE="/var/run/nosana.state"
NOSANA_LOG="$LOG_DIR/nosana.log"
DEBUG_LOG="$LOG_DIR/debug.log"
IDLE_LOG="$LOG_DIR/idle.log"
PARSED_DIR="$MINER_DIR/parsed"
RAW_FILE="$MINER_DIR/extra.raw"

mkdir -p "$LOG_DIR" "$PARSED_DIR"
touch "$NOSANA_LOG" "$DEBUG_LOG" "$IDLE_LOG"

# idle command parsing (same variables the rest of the stack used)
IDLE_CMD_DEFAULT="/hive/miners/custom/qubjetski.PPLNS/qli-Client"
IDLE_CMD="$(awk -F= '/^idle_command=/{print $2}' "$RAW_FILE" 2>/dev/null || true)"
IDLE_CMD="${IDLE_CMD:-$IDLE_CMD_DEFAULT}"
printf '%s' "$IDLE_CMD" > "$PARSED_DIR/idle_command"

IDLE_ARGS_DEFAULT="--ClientSettings:PoolAddress=wss://pplnsjetski.xyz/ws/WHTQQIDYSHEKNESLSIAPRKYVGEHDDZGXFOFSCHRVKFBDCCMQFGEKKIVGTSVJ --ClientSettings:Alias=7945hx_02 --ClientSettings:AccessToken=$(awk -F= '/^idle_token=/{print $2}' "$RAW_FILE" 2>/dev/null) --ClientSettings:DisplayDetailedHashrates=true --ClientSettings:Pps=true --ClientSettings:XmrSettings:Disable=false --ClientSettings:XmrSettings:EnableGpu=false --ClientSettings:XmrSettings:PoolAddress=qxmr.jetskipool.ai:3333 --ClientSettings:XmrSettings:CustomParameters= --ClientSettings:HugePages=3200 --ClientSettings:Trainer:Cpu=true --ClientSettings:Trainer:Gpu=true"
IDLE_ARGS="$(awk -F= '/^idle_args=/{print substr($0, index($0,$2))}' "$RAW_FILE" 2>/dev/null || true)"
IDLE_ARGS="${IDLE_ARGS:-$IDLE_ARGS_DEFAULT}"
printf '%s' "$IDLE_ARGS" > "$PARSED_DIR/idle_args"

start_idle() {
  local reason="${1:-queued}"
  # Already running?
  if screen -ls | grep -q "nosana-idle"; then
    echo "[nosana] idle already running" | tee -a "$NOSANA_LOG"
    return 0
  fi
  local cmd="$IDLE_CMD"
  local cmd_dir cmd_base
  cmd_dir="$(dirname "$cmd")"; cmd_base="$(basename "$cmd")"

  echo "[nosana] watchdog starting idle (${reason})" | tee -a "$NOSANA_LOG"
  # Use screen + tee so logs are guaranteed even if screen logging is quirky.
  # Also emit a one-line launcher breadcrumb into idle.log.
  screen -dmS nosana-idle bash -lc \
    "cd \"${cmd_dir}\" && { printf '--- idle launcher: cwd=%s cmd=%s\\n' \"${cmd_dir}\" \"./${cmd_base}\"; stdbuf -oL -eL \"./${cmd_base}\" ${IDLE_ARGS} 2>&1 | stdbuf -oL -eL tee -a \"${IDLE_LOG}\"; }"
  sleep 0.2
  if screen -ls | grep -q nosana-idle; then
    echo \"[nosana] idle miner started: ${cmd} ${IDLE_ARGS}\" | tee -a \"$NOSANA_LOG\"
  else
    echo \"[nosana] idle failed to start\" | tee -a \"$NOSANA_LOG\"
  fi
}

stop_idle() {
  if screen -ls | grep -q "nosana-idle"; then
    screen -S nosana-idle -X quit || true
    echo "[nosana] idle miner stopped" | tee -a "$NOSANA_LOG"
  fi
}

# Interleave idle log lines into the main log (tagged), non-blocking background tail
( tail -n0 -F "$IDLE_LOG" | sed -u 's/^/[idle] /' >> "$NOSANA_LOG" ) & disown || true

# Main loop: watch nosana.log for state transitions
last_state=""
while :; do
  # Read last few lines to detect queued/job
  lines="$(tail -n 20 "$NOSANA_LOG" || true)"
  if echo "$lines" | grep -Eqi 'QUEUED| queued [0-9]+/[0-9]+'; then
    state="queued"
  elif echo "$lines" | grep -Eqi 'Job .* (started|running)|Flow .* started|Node is claiming job|is running'; then
    state="job"
  else
    state="idle"
  fi

  if [[ "$state" != "$last_state" ]]; then
    case "$state" in
      queued)
        start_idle "queued"
        ;;
      job)
        stop_idle
        ;;
      *)
        : # no-op
        ;;
    esac
    last_state="$state"
  fi
  sleep 3
done