#!/usr/bin/env bash
set -euo pipefail
LOG_DIR="/var/log/miner/nosana"
MINER_DIR="/hive/miners/custom/nosana"
mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

# Allow caller to provide a full command line in $IDLE_CMD, otherwise try a few defaults
IDLE_CMD="${IDLE_CMD:-}"
if [[ -z "$IDLE_CMD" ]]; then
  # Example default (adjust to your environment if needed)
  if [[ -x /hive/miners/custom/qubjetski.PPLNS/qli-Client ]]; then
    IDLE_CMD="/hive/miners/custom/qubjetski.PPLNS/qli-Client"
  elif command -v qli-Client >/dev/null 2>&1; then
    IDLE_CMD="qli-Client"
  else
    echo "[nosana] idle-run: no qli-Client found; set IDLE_CMD" >> "$LOG_DIR/nosana.log"
    exit 0
  fi
fi

# If already running, don't start another
if screen -list | grep -q "nosana-idle"; then
  echo "[nosana] idle-run: screen already active" >> "$LOG_DIR/nosana.log"
  exit 0
fi

# Stamp start time so h-stats uptime makes sense while queued
date +%s > "$MINER_DIR/idle.start.time" 2>/dev/null || true

# Start detached screen and tee output into idle.log with [idle] prefix
screen -dmS nosana-idle bash -lc \
  '('"$IDLE_CMD"') 2>&1 | sed -u "s/^/[idle]  /" | tee -a '"$LOG_DIR"'/idle.log '"

echo "[nosana] idle miner started" >> "$LOG_DIR/nosana.log" || true
