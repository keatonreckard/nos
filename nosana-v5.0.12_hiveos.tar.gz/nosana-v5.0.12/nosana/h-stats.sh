#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="${MINER_DIR:-/hive/miners/custom/nosana}"
RUN_DIR="/var/run"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
STATE_FILE="$RUN_DIR/nosana.state"

mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

# Load previous state (may set: wallet, sol, nos, status, queue, etc.)
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

# Collect latest clean logs (strip ANSI)
L=""
if [[ -s "$NOSANA_LOG" ]]; then
  L="$(tail -n 2000 "$NOSANA_LOG" | tr -d '\r')"
fi
if [[ -z "$L" ]]; then
  if command -v docker >/dev/null 2>&1; then
    C="$(docker logs --since 10m nosana-node 2>/dev/null || true)"
  else
    C=""
  fi
  [[ -n "$C" ]] && L="$(printf "%s" "$C" | tr -d '\r')"
fi
CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"

# Wallet / balances from logs (best-effort)
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
fi
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
fi
if [[ -z "${sol:-}" ]]; then
  sol="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
if [[ -z "${nos:-}" ]]; then
  nos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi

# Determine status string
status="nos - initializing"
pos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
if printf "%s\n" "$CLEAN" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
  status="nos - job"
  pos=""
else
  if [[ -n "$pos" ]]; then
    status="nos - queued ${pos}"
  elif printf "%s\n" "$CLEAN" | grep -Eqi 'QUEUED'; then
    status="nos - queued"
  fi
fi

# Uptime calculation
now=$(date +%s)
start_time=""
for f in "$MINER_DIR/job.start.time" "$MINER_DIR/idle.start.time" "$MINER_DIR/nosana.start.time"; do
  if [[ -f "$f" ]]; then start_time="$(cat "$f")"; break; fi
done
if [[ -z "$start_time" ]]; then read -r up _ < /proc/uptime; start_time=$(( now - ${up%.*} )); fi
uptime=$((now - start_time)); ((uptime<0)) && uptime=0

# Parse idle hashrate (-> KH/s) and accepted/rejected shares from idle log
parse_idle() {
  [[ -s "$IDLE_LOG" ]] || { echo "0|0|0"; return; }
  local L2 hs_val hs_unit token acc rej khs
  L2="$(tail -n 400 "$IDLE_LOG")"
  token="$(printf "%s\n" "$L2" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*([a-zA-Z]+)\/s' | tail -n1)"
  hs_val="$(printf "%s" "$token" | awk '{print $1}')"
  hs_unit="$(printf "%s" "$token" | awk '{print $2}' | tr '[:lower:]' '[:upper:]')"
  khs="0"
  case "$hs_unit" in
    IT/S|IT|I/S|I) khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.3f", v/1000)}');;
    H/S|H)         khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.3f", v/1000)}');;
    KH/S|KH)       khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.3f", v)}');;
    MH/S|MH)       khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.3f", v*1000)}');;
    GH/S|GH)       khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.3f", v*1000*1000)}');;
  esac
  acc="$(printf "%s\n" "$L2" | grep -Eio 'A:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)"
  rej="$(printf "%s\n" "$L2" | grep -Eio 'R:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)"
  if [[ -z "$acc" ]] && printf "%s\n" "$L2" | grep -Eio '([0-9]+)/([0-9]+)' >/dev/null; then
    acc="$(printf "%s\n" "$L2" | grep -Eio '([0-9]+)/([0-9]+)' | tail -n1 | cut -d/ -f1)"
    rej="$(printf "%s\n" "$L2" | grep -Eio '([0-9]+)/([0-9]+)' | tail -n1 | cut -d/ -f2)"
  fi
  echo "${khs}|${acc:-0}|${rej:-0}"
}

khs="0"; ar_a="0"; ar_r="0"
if echo "$status" | grep -qi 'queued'; then
  IFS='|' read -r khs ar_a ar_r <<<"$(parse_idle)"
  [[ -z "$khs" || "$khs" == "0" ]] && khs="0.001"
fi

# Version string
ver=""
if [[ -n "${sol:-}" ]]; then printf -v solf "%.6f" "$sol"; ver="S:${solf}"; fi
if [[ -n "${nos:-}" ]]; then printf -v nosf "%.4f" "$nos"; ver="${ver:+$ver }N:${nosf}"; fi
if [[ -n "${wallet:-}" ]]; then ver="${ver:+$ver }W:$(printf "%s" "$wallet" | cut -c1-5)"; fi

# GPU stats (optional, best-effort)
temp_json='[]'; fan_json='[]'; bus_json='[]'
if [[ -f /hive/bin/gpu-stats ]]; then
  source /hive/bin/gpu-stats || true
  if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [[ "${#GPU_FAN[@]:-0}" -gt 0 ]]; then  fan_json ="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
  if [[ "${#BUS_IDS[@]:-0}" -gt 0 ]]; then
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

# Final clean JSON to STDOUT (no redirection elsewhere)
printf '{"hs":[%s],"hs_units":"khs","temp":%s,"fan":%s,"uptime":%s,"ver":"%s","ar":[%s,%s],"algo":"%s","bus_numbers":%s}\n' \
  "$khs" "$temp_json" "$fan_json" "$uptime" "$ver" "$ar_a" "$ar_r" "$status" "$bus_json"
