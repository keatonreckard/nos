#!/usr/bin/env bash
set -euo pipefail
LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

# Kill the idle miner screen/session/process quickly and quietly
if screen -list | grep -q "nosana-idle"; then
  screen -S nosana-idle -X quit || true
fi
pkill -f "qli-Client|qubic.li|xmr-stak|xmrig" 2>/dev/null || true
echo "[nosana] idle miner killed" >> "$LOG_DIR/nosana.log" || true
