Nosana helper v5.0.12

- Fixes custom stats JSON (no invalid `hs:[7/30]` or `ar:[,]`).
- `h-stats.sh` now prints a single clean JSON line to STDOUT.
- Adds `idle-kill.sh` and `idle-run.sh`:
  * `idle-kill.sh` is safe to call on miner restart and on job start.
  * `idle-run.sh` starts a `screen` named `nosana-idle` and streams into /var/log/miner/nosana/idle.log.

Quick test after installing:
  bash /hive/miners/custom/nosana/h-stats.sh | jq -c

If the miner is QUEUED, you can launch the idle miner with:
  /hive/miners/custom/nosana/idle-run.sh

And kill it any time with:
  /hive/miners/custom/nosana/idle-kill.sh
