\
    #!/usr/bin/env bash
    # nosana h-stats.sh (v5.0.12 rules)
    # - job running -> 1 khs
    # - idle with no idle miner data -> queue position X/Y => X khs
    # - never emit slashes in JSON arrays
    # - include ver string with SOL, NOS, and short Wallet
    # - avoid 0 hashrate; fallback to 1 khs

    set -euo pipefail
    export LC_ALL=C

    MINER_DIR="${MINER_DIR:-/hive/miners/custom/nosana}"
    RUN_DIR="/var/run"
    STATE_FILE="$RUN_DIR/nosana.state"
    LOG_DIR="/var/log/miner/nosana"
    IDLE_LOG="$LOG_DIR/idle.log"
    NOSANA_LOG="$LOG_DIR/nosana.log"

    mkdir -p "$LOG_DIR"
    exec 2>>"$LOG_DIR/debug.log"

    # Pull last logs and strip ANSI
    L=""
    if [[ -s "$NOSANA_LOG" ]]; then
      L="$(tail -n 4000 "$NOSANA_LOG" | tr -d '\r')"
    fi
    if [[ -z "$L" ]]; then
      C="$(docker logs --since 10m nosana-node 2>/dev/null || true)"
      [[ -n "$C" ]] && L="$(printf "%s" "$C" | tr -d '\r')"
    fi
    CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"

    # Parse wallet, SOL, NOS
    wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
    if [[ -z "$wallet" ]]; then
      wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
    fi
    sol="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
    nos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"

    # Status and queue position
    status="nos - initializing"
    queue_pos=""
    if printf "%s\n" "$CLEAN" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
      status="nos - job"
    else
      # Extract "position X/Y"
      queue_pos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*position[[:space:]]+([0-9]+)\/([0-9]+).*/\1\/\2/p' | tail -n1)"
      if [[ -n "$queue_pos" ]]; then
        status="nos - queued ${queue_pos}"
      elif printf "%s\n" "$CLEAN" | grep -Eq 'QUEUED'; then
        status="nos - queued"
      fi
    fi

    # Uptime heuristic
    now=$(date +%s)
    if   [[ -f "$MINER_DIR/job.start.time" ]]; then start_time=$(cat "$MINER_DIR/job.start.time")
    elif [[ -f "$MINER_DIR/idle.start.time" ]]; then start_time=$(cat "$MINER_DIR/idle.start.time")
    elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then start_time=$(cat "$MINER_DIR/nosana.start.time")
    else read -r up _ < /proc/uptime; start_time=$(( now - ${up%.*} )); fi
    uptime=$((now - start_time)); ((uptime<0)) && uptime=0

    # Extract idle miner rate (KH/s equivalent)
    parse_idle_stats() {
      [[ -s "$IDLE_LOG" ]] || { echo "0 0 0"; return; }
      local L2 hs_val hs_unit khs="0" acc="0" rej="0"
      L2="$(tail -n 600 "$IDLE_LOG")"
      local line="$(echo "$L2" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(it|kh|mh|gh)/s' | tail -n1)"
      hs_val="$(printf "%s\n" "$line" | sed -nE 's/^([0-9]+(\.[0-9]+)?).*/\1/p')"
      hs_unit="$(printf "%s\n" "$line" | sed -nE 's/^[0-9]+(\.[0-9]+)?[[:space:]]*([A-Za-z]+).*/\2/p' | tr '[:lower:]' '[:upper:]')"
      if [[ -n "${hs_val:-}" && -n "${hs_unit:-}" ]]; then
        case "$hs_unit" in
          IT) khs="$(awk -v v="$hs_val" 'BEGIN{printf("%.0f", v/1000)}')" ;; # it/s -> "KH/s-ish" display
          KH) khs="$(awk -v v="$hs_val" 'BEGIN{printf("%.0f", v)}')" ;;
          MH) khs="$(awk -v v="$hs_val" 'BEGIN{printf("%.0f", v*1000)}')" ;;
          GH) khs="$(awk -v v="$hs_val" 'BEGIN{printf("%.0f", v*1000*1000)}')" ;;
          *)  khs="0" ;;
        esac
      fi
      if echo "$L2" | grep -Eiq '([0-9]+/[0-9]+|A:[0-9]+)'; then
        if echo "$L2" | grep -Eio '([0-9]+)\/([0-9]+)' >/dev/null; then
          acc=$(echo "$L2" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f1)
          rej=$(echo "$L2" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f2)
        else
          acc=$(echo "$L2" | grep -Eio 'A:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)
          rej=$(echo "$L2" | grep -Eio 'R:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)
        fi
      fi
      echo "${khs} ${acc} ${rej}"
    }

    algo="$status"
    hs_khs=1
    ar_acc=0
    ar_rej=0

    if echo "$status" | grep -qi 'job'; then
      # Job running => fixed 1 khs
      hs_khs=1
    else
      # Idle
      read -r idle_khs idle_acc idle_rej < <(parse_idle_stats)
      if [[ "${idle_khs:-0}" -gt 0 ]]; then
        hs_khs="$idle_khs"; ar_acc="$idle_acc"; ar_rej="$idle_rej"
      else
        # No idle data; try queue position -> X khs
        if [[ -n "$queue_pos" ]]; then
          qx="${queue_pos%%/*}"
          if [[ "$qx" =~ ^[0-9]+$ ]] && [[ "$qx" -gt 0 ]]; then
            hs_khs="$qx"
          else
            hs_khs=1
          fi
        else
          hs_khs=1
        fi
      fi
    fi

    # Version string: S:xx N:xx W:xxxxx
    ver=""
    if [[ -n "${sol:-}" ]]; then printf -v solf "%.6f" "$sol"; ver+="S:${solf}"; fi
    if [[ -n "${nos:-}" ]]; then printf -v nosf "%.4f" "$nos"; ver+="${ver:+ }N:${nosf}"; fi
    if [[ -n "${wallet:-}" ]]; then ver+="${ver:+ }W:$(printf "%s" "$wallet" | cut -c1-5)"; fi

    # GPU info (best effort)
    temp_json="[]"; fan_json="[]"; bus_json="[]"
    if [[ -f /hive/bin/gpu-stats ]]; then
      source /hive/bin/gpu-stats || true
      if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
      if [[ "${#GPU_FAN[@]:-0}"  -gt 0 ]]; then fan_json ="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
      if [[ "${#BUS_IDS[@]:-0}"  -gt 0 ]]; then
        bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
        bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
      fi
    fi

    # Emit a single-number hs array; never slashes
    stats=$(cat <<JSON
{"hs":[${hs_khs}],"hs_units":"khs","temp":${temp_json},"fan":${fan_json},"uptime":${uptime},"ver":"${ver}","ar":[${ar_acc},${ar_rej}],"algo":"${algo}","bus_numbers":${bus_json}}
JSON
)
    printf "[%s] h-stats: ver=%s | algo=%s | hs_khs=%s | wallet=%s | sol=%s | nos=%s\n" \
      "$(date -Iseconds)" "$ver" "$algo" "$hs_khs" "${wallet:-}" "${sol:-}" "${nos:-}" >> "$LOG_DIR/debug.log" || true

    # Final output only the JSON line
    printf "%s\n" "${stats}"
