nosana HiveOS package v5.0.12
- Job running: reports 1 khs
- Idle w/o idle miner data: reports queue position X from X/Y as X khs
- JSON has no slashes in 'hs' and fills 'ar' as [0,0] if unknown
- Version string shows SOL, NOS, short Wallet
- Idle miner is killed on miner restart to prevent duplicates

Nosana wrapper v3.1.18: ANSI-stripped sed parsing for wallet/balances; robust algo; docker logs fallback.
