\
    #!/usr/bin/env bash
    # nosana h-run.sh wrapper (v5.0.12)
    set -euo pipefail

    DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    LOG_DIR="/var/log/miner/nosana"
    mkdir -p "$LOG_DIR"

    echo "[h-run] $(date -Iseconds) cleanup any lingering idle miner" >> "$LOG_DIR/debug.log"
    # Kill idle screen & processes to avoid duplicates across miner restarts
    (screen -ls | awk '/\.idle/{print $1}' | xargs -r -n1 screen -S 2>/dev/null || true)
    pkill -f 'qli-Client' 2>/dev/null || true

    # Mark start
    date +%s > "$DIR/nosana.start.time"

    # Chain to monitor.sh (user's main launcher)
    exec bash "$DIR/monitor.sh"
