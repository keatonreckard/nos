\
    #!/usr/bin/env bash
    set -euo pipefail

    MINER_DIR="/hive/miners/custom/nosana"
    LOG_DIR="/var/log/miner/nosana"
    STATE_FILE="/var/run/nosana.state"
    NOSANA_LOG="$LOG_DIR/nosana.log"
    IDLE_LOG="$LOG_DIR/idle.log"
    DEBUG="$LOG_DIR/debug.log"
    PARSED_DIR="$MINER_DIR/parsed"
    IDLE_CMD_FILE="$PARSED_DIR/idle_command"
    IDLE_ARGS_FILE="$PARSED_DIR/idle_args"

    mkdir -p "$LOG_DIR" "$PARSED_DIR"

    echo "[nosana] monitor started" | tee -a "$NOSANA_LOG" "$DEBUG"

    idle_running=0
    last_queue=""
    status="nos - initializing"
    echo "status=\"${status}\"" > "$STATE_FILE"

    start_idle() {
      [[ -s "$IDLE_CMD_FILE" ]] || return 0
      local cmd args
      cmd="$(cat "$IDLE_CMD_FILE" 2>/dev/null || true)"
      args="$(cat "$IDLE_ARGS_FILE" 2>/dev/null || true)"
      if [[ -n "$cmd" ]]; then
        echo "[nosana] start idle: ${cmd} ${args}" | tee -a "$NOSANA_LOG" "$DEBUG"
        "$MINER_DIR/idle-screen.sh" start "$cmd" $args || true
        idle_running=1
        echo "idle_enabled=1" >> "$STATE_FILE"
      fi
    }

    stop_idle() {
      if [[ $idle_running -eq 1 ]]; then
        echo "[nosana] stop idle" | tee -a "$NOSANA_LOG" "$DEBUG"
        "$MINER_DIR/idle-screen.sh" stop || true
        idle_running=0
        echo "idle_enabled=0" >> "$STATE_FILE"
      fi
    }

    # Helper: extract and update queue + status
    update_from_line() {
      local line="$1"
      # Queue position
      if echo "$line" | grep -Eiq 'QUEUED|queued'; then
        local pos
        pos="$(echo "$line" | sed -n 's/.*position[[:space:]]\+\([0-9]\+\/[0-9]\+\).*/\1/p' | tail -n1)"
        if [[ -n "$pos" ]]; then
          status="nos - queued ${pos}"
          if [[ "$last_queue" != "$pos" ]]; then
            echo "[nosana] queued ${pos}" | tee -a "$NOSANA_LOG" "$DEBUG"
            last_queue="$pos"
          fi
        else
          status="nos - queued"
        fi
        echo "status=\"${status}\"" > "$STATE_FILE"
        # Start idle if not running
        if [[ $idle_running -eq 0 ]]; then start_idle; fi
      fi

      # Job started/claimed/running
      if echo "$line" | grep -Eqi 'claimed job|Job .* started|Flow .* running|is running'; then
        status="nos - job"
        echo "status=\"${status}\"" > "$STATE_FILE"
        stop_idle
      fi
    }

    # Periodically surface a snippet of idle log to main log
    surface_idle_snippet() {
      if [[ $idle_running -eq 1 && -s "$IDLE_LOG" ]]; then
        tail -n 1 "$IDLE_LOG" | sed 's/^/[idle] /' >> "$NOSANA_LOG" || true
      fi
    }

    # Follow the nosana log (created by h-run.sh)
    touch "$NOSANA_LOG"
    # Use tail -F to follow across log rotations
    while true; do
      tail -n 0 -F "$NOSANA_LOG" 2>/dev/null | while IFS= read -r line; do
        echo "$line" | grep -q "." || continue
        update_from_line "$line"
      done
      sleep 1
      surface_idle_snippet
    done
