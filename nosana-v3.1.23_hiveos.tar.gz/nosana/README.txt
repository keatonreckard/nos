Nosana HiveOS Custom Miner
==========================
Version: 3.1.23

What’s new (since .22):
- Preserve fixed version/algo string: ver="S:<SOL> N:<NOS> W:<WALLET5>" and algo reflects queued/job/free
- Robust wallet/SOL/NOS scraping straight from nosana log
- Safe idle-miner controller: start when QUEUED (position X/Y), stop when job starts
- Dashboard messages on state changes (node start, queued pos changes, idle start/stop)
- No early exits; monitor auto-restarts if needed

Files:
- h-run.sh         : Starts sidecar + nosana node, tails logs, keeps process alive, spawns monitor
- h-config.sh      : Parses idleSettings from nosana.conf VERBOSE to parsed/idle_command & parsed/idle_args
- h-stats.sh       : Emits JSON stats for Hive; builds version string and algo from logs/state
- monitor.sh       : Watches nosana log to manage idle miner and send events
- idle-screen.sh   : Launch/stop idle miner in a screen session, write idle.log
- nosana.conf      : Config (edit VERBOSE line to include idleSettings JSON as shown below)
- h-manifest.conf  : Miner metadata (version 3.1.23)
- README.txt       : You are here

Idle settings example in nosana.conf:
VERBOSE='{"idleSettings":{"command":"/hive/miners/custom/qubjetski.PPLNS/qli-Client","arguments":" --foo=bar ..." }}'

Logs:
- /var/log/miner/nosana/nosana.log  (nosana CLI and events)
- /var/log/miner/nosana/idle.log    (idle miner output)
- /var/log/miner/nosana/debug.log   (debug from scripts)

State:
- /var/run/nosana.state

