\
    #!/usr/bin/env bash
    set -euo pipefail

    MINER_DIR="/hive/miners/custom/nosana"
    LOG_DIR="/var/log/miner/nosana"
    RUNDIR="/var/run"
    DEBUG="$LOG_DIR/debug.log"
    NOSANA_LOG="$LOG_DIR/nosana.log"

    mkdir -p "$LOG_DIR" "$RUNDIR"

    echo "[$(date -Iseconds)] h-run: cleaning previous containers" | tee -a "$DEBUG"
    # stop/remove old containers (best-effort)
    podman rm -f nosana-node nosana-podman >/dev/null 2>&1 || true

    echo "[$(date -Iseconds)] h-run: starting podman sidecar" | tee -a "$DEBUG"
    podman run -d --privileged --pid=host --net=host --name nosana-podman nosana/podman:v1.1.0 >/dev/null

    # Start Nosana CLI container
    echo "[$(date -Iseconds)] h-run: starting nosana-node container" | tee -a "$DEBUG"
    podman run -d --name nosana-node --net=host \
      -v /root/.nosana:/root/.nosana \
      nosana/nosana-cli:latest >/dev/null

    # Tee container logs to nosana.log
    : > "$NOSANA_LOG"
    ( podman logs -f nosana-node 2>&1 | sed 's/\r$//' | tee -a "$NOSANA_LOG" ) &

    # Stamp start time
    date +%s > "$MINER_DIR/nosana.start.time"

    # Run config parser so monitor can pick up idle settings
    "$MINER_DIR/h-config.sh" || true

    # Start monitor in background, auto-restart if it dies
    ( while true; do "$MINER_DIR/monitor.sh"; sleep 1; done ) &

    # Keep miner process alive
    while true; do sleep 30; done
