\
    #!/usr/bin/env bash
    set -euo pipefail

    MINER_DIR="/hive/miners/custom/nosana"
    CONF_FILE="$MINER_DIR/nosana.conf"
    PARSED_DIR="$MINER_DIR/parsed"
    LOG_DIR="/var/log/miner/nosana"
    DEBUG="$LOG_DIR/debug.log"

    mkdir -p "$PARSED_DIR" "$LOG_DIR"

    RAW_EXTRA="$(grep -E '^VERBOSE=' "$CONF_FILE" 2>/dev/null | sed -E 's/^VERBOSE=//')"
    RAW_EXTRA="${RAW_EXTRA%\"}"; RAW_EXTRA="${RAW_EXTRA#\"}"
    echo "[$(date -Iseconds)] h-config: RAW_EXTRA length=${#RAW_EXTRA}" >> "$DEBUG"

    idle_cmd=""; idle_args=""

    if echo "$RAW_EXTRA" | grep -q '"idleSettings"'; then
      # Extract "command":"..."
      idle_cmd="$(echo "$RAW_EXTRA" | sed -n 's/.*"idleSettings"[^{]*{[^}]*"command"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)"
      # Extract "arguments":"..."
      idle_args="$(echo "$RAW_EXTRA" | sed -n 's/.*"idleSettings"[^{]*{[^}]*"arguments"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)"
    fi

    if [[ -n "$idle_cmd" ]]; then
      echo "$idle_cmd" > "$PARSED_DIR/idle_command"
      echo "$idle_args" > "$PARSED_DIR/idle_args"
      echo "[$(date -Iseconds)] h-config: parsed idle command: $idle_cmd" >> "$DEBUG"
      echo "[$(date -Iseconds)] h-config: parsed idle args: $idle_args" >> "$DEBUG"
    else
      : > "$PARSED_DIR/idle_command"
      : > "$PARSED_DIR/idle_args"
      echo "[$(date -Iseconds)] h-config: no idleSettings found" >> "$DEBUG"
    fi
