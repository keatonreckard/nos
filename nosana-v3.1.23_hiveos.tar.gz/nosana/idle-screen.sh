\
    #!/usr/bin/env bash
    set -euo pipefail

    LOG_DIR="/var/log/miner/nosana"
    mkdir -p "$LOG_DIR"
    IDLE_LOG="$LOG_DIR/idle.log"
    PIDFILE="/var/run/nosana-idle.pid"
    SCNAME="nosana-idle"

    cmd="${1:-}"
    shift || true
    args="$*"

    case "${cmd}" in
      start)
        if screen -list | grep -q "\.${SCNAME}[[:space:]]"; then
          echo "idle-screen: already running"
          exit 0
        fi
        shift || true
        # next args are command then its args
        run_cmd="${1:-}"; shift || true
        run_args="$*"
        if [[ -z "${run_cmd}" ]]; then
          echo "idle-screen: no run command"
          exit 1
        fi
        # launch in screen; ensure fresh log
        : > "$IDLE_LOG"
        # shellcheck disable=SC2086
        screen -dmS "$SCNAME" bash -lc "stdbuf -oL -eL ${run_cmd} ${run_args} 2>&1 | tee -a '$IDLE_LOG'"
        # try to capture PID of process inside screen (best-effort)
        sleep 0.4
        pgrep -f "${run_cmd} ${run_args}" | head -n1 > "$PIDFILE" || true
        echo "[idle] started: ${run_cmd} ${run_args}" | tee -a "$IDLE_LOG"
        ;;
      stop)
        if screen -list | grep -q "\.${SCNAME}[[:space:]]"; then
          screen -S "$SCNAME" -X quit || true
        fi
        if [[ -f "$PIDFILE" ]]; then
          pid="$(cat "$PIDFILE" || true)"
          if [[ -n "${pid:-}" ]]; then kill "$pid" 2>/dev/null || true; fi
          rm -f "$PIDFILE"
        fi
        echo "[idle] stopped" | tee -a "$IDLE_LOG"
        ;;
      *)
        echo "Usage: $0 start <command> [args...] | stop"
        exit 1
        ;;
    esac
