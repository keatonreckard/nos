#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
PARSED_DIR="$MINER_DIR/parsed"
STATE_FILE="/var/run/nosana.state"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
IDLE_PID_FILE="/var/run/nosana-idle.pid"

mkdir -p "$LOG_DIR" "$PARSED_DIR"

ts() { date +"[%Y-%m-%dT%H:%M:%S%z]"; }
log(){ echo "$(ts) $*" | tee -a "$LOG_DIR/debug.log" >&2; }

echo "[nosana] monitor started" | tee -a "$NOSANA_LOG" >/dev/null

idle_running() {
  [[ -f "$IDLE_PID_FILE" ]] && ps -p "$(cat "$IDLE_PID_FILE")" >/dev/null 2>&1
}

start_idle() {
  local cmd args
  cmd="$(cat "$PARSED_DIR/idle_command" 2>/dev/null || true)"
  args="$(cat "$PARSED_DIR/idle_args" 2>/dev/null || true)"
  if [[ -z "$cmd" ]]; then
    log "monitor: start_idle requested, but no idle command configured"
    return 0
  fi
  log "monitor: start_idle hook (cmd:'$cmd' args:'$args')"
  # Start idle miner; mirror its log into both idle.log and nosana.log
  ( setsid bash -c "stdbuf -oL -eL \"$cmd\" $args 2>&1 | tee -a \"$IDLE_LOG\" | sed -u 's/^/[idle] /' >> \"$NOSANA_LOG\"" ) &
  echo $! > "$IDLE_PID_FILE"
  echo "[nosana] idle miner started" | tee -a "$NOSANA_LOG" >/dev/null
}

stop_idle() {
  if idle_running; then
    kill "$(cat "$IDLE_PID_FILE")" >/dev/null 2>&1 || true
    rm -f "$IDLE_PID_FILE"
    echo "[nosana] idle miner stopped" | tee -a "$NOSANA_LOG" >/dev/null
  fi
}

last_queue_state=""
# Tail nosana log and react to state transitions
tail -n +1 -F "$NOSANA_LOG" | while IFS= read -r line; do
  # Queue detection
  if echo "$line" | grep -Eq 'QUEUED.*position[[:space:]]+[0-9]+/[0-9]+'; then
    pos="$(echo "$line" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p')"
    [[ -z "$pos" ]] && pos="queued"
    if [[ "$last_queue_state" != "$pos" ]]; then
      echo "[nosana] queued $pos" | tee -a "$NOSANA_LOG" >/dev/null
      last_queue_state="$pos"
    fi
    # Ensure idle miner runs
    if ! idle_running; then
      start_idle
    fi
  fi

  # Job start/stop detection
  if echo "$line" | grep -Eq 'Node has claimed job|Job .* started successfully|Flow .* running'; then
    stop_idle
    echo "[nosana] job started" | tee -a "$NOSANA_LOG" >/dev/null
  fi
  if echo "$line" | grep -Eq 'Job .* finished successfully|Node cleaning successfully|RESTARTING'; then
    echo "[nosana] job finished" | tee -a "$NOSANA_LOG" >/dev/null
  fi
done
