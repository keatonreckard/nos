#!/usr/bin/env bash
set -euo pipefail
LOG_DIR="/var/log/miner/nosana"
touch "$LOG_DIR/idle.log"
tail -f "$LOG_DIR/idle.log"
