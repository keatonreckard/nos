#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
LOG_DIR="/var/log/miner/nosana"
STATE_FILE="$RUN_DIR/nosana.state"
mkdir -p "$RUN_DIR" "$LOG_DIR"

ts() { date +"[%Y-%m-%dT%H:%M:%S%z]"; }
log(){ echo "$(ts) $*" | tee -a "$LOG_DIR/debug.log" >&2; }

# Pick a container runtime: podman (host), docker, or nerdctl
runtime=""
if command -v podman >/dev/null 2>&1; then
  runtime="podman"
elif command -v docker >/dev/null 2>&1; then
  runtime="docker"
elif command -v nerdctl >/dev/null 2>&1; then
  runtime="nerdctl"
else
  log "h-run: ERROR: no container runtime found (podman/docker/nerdctl)"
  exit 127
fi

# Clean any previous containers
log "h-run: cleaning previous containers"
$runtime rm -f nosana-podman >/dev/null 2>&1 || true
$runtime rm -f nosana-node >/dev/null 2>&1 || true

# Start sidecar podman-in-container if host is not podman
log "h-run: starting podman sidecar"
if [[ "$runtime" = "podman" ]]; then
  # host podman exists; ensure image present for completeness
  podman pull nosana/podman:v1.1.0 >/dev/null 2>&1 || true
  # nothing else needed; nosana cli uses provider=podman inside its own container
else
  $runtime pull nosana/podman:v1.1.0 >/dev/null 2>&1 || true
  $runtime run -d --name nosana-podman --restart unless-stopped \
    --privileged \
    -v /var/lib/nosana-podman:/var/lib/containers \
    -v /var/run/nosana-podman:/var/run/podman \
    nosana/podman:v1.1.0 >/dev/null
fi

# Start nosana cli container
log "h-run: starting nosana-node container"
$runtime pull nosana/nosana-cli:latest >/dev/null 2>&1 || true

# Create nosana log stream
NOSANA_LOG="$LOG_DIR/nosana.log"
touch "$NOSANA_LOG"
: > "$NOSANA_LOG"

# Run CLI; map sidecar podman socket if using docker/nerdctl
if [[ "$runtime" = "podman" ]]; then
  $runtime run --rm --name nosana-node \
    -v "$LOG_DIR":/logs \
    -v /root/.nosana:/root/.nosana \
    nosana/nosana-cli:latest node start provider=podman 2>&1 | tee -a "$NOSANA_LOG" &
else
  $runtime run --rm --name nosana-node \
    --privileged \
    -v "$LOG_DIR":/logs \
    -v /root/.nosana:/root/.nosana \
    -v /var/run/nosana-podman:/var/run/podman \
    -e CONTAINER_HOST=unix:///var/run/podman/podman.sock \
    nosana/nosana-cli:latest node start provider=podman 2>&1 | tee -a "$NOSANA_LOG" &
fi

echo "nosana_pid=$!" > "$STATE_FILE"

# Launch monitor (handles idle miner + status messages)
bash "$MINER_DIR/monitor.sh" &

wait
