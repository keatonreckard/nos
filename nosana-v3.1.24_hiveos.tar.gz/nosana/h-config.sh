#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
PARSED_DIR="$MINER_DIR/parsed"
LOG_DIR="/var/log/miner/nosana"
mkdir -p "$PARSED_DIR" "$LOG_DIR"

RAW="${CUSTOM_MINER_CONFIG:-}"
if [[ -z "${RAW}" && -f "$MINER_DIR/nosana.conf" ]]; then
  RAW="$(cat "$MINER_DIR/nosana.conf")"
fi

ts() { date +"[%Y-%m-%dT%H:%M:%S%z]"; }

echo "$(ts) h-config: RAW_EXTRA length=${#RAW}" >> "$LOG_DIR/debug.log"

# Extract JSON-like "idleSettings" blob if present
idle_json="$(echo "$RAW" | tr -d '\n' | sed -n 's/.*"idleSettings"\s*:\s*{\(.*\)}.*/{\1}/p' || true)"

idle_cmd=""; idle_args=""
if [[ -n "$idle_json" ]]; then
  # command
  idle_cmd="$(echo "$idle_json" | sed -E 's/\\\\"/"/g' | grep -oE '"command"\s*:\s*"[^"]+"' | sed -E 's/.*"command"\s*:\s*"([^"]+)".*/\1/' || true)"
  # arguments
  idle_args="$(echo "$idle_json" | sed -E 's/\\\\"/"/g' | grep -oE '"arguments"\s*:\s*"[^"]*"' | sed -E 's/.*"arguments"\s*:\s*"([^"]*)".*/\1/' || true)"
fi

if [[ -n "$idle_cmd" ]]; then
  echo "$idle_cmd" > "$MINER_DIR/parsed/idle_command"
  echo "$idle_args" > "$MINER_DIR/parsed/idle_args"
  echo "$(ts) h-config: parsed idle command: $idle_cmd" >> "$LOG_DIR/debug.log"
  echo "$(ts) h-config: parsed idle args: $idle_args" >> "$LOG_DIR/debug.log"
else
  : > "$MINER_DIR/parsed/idle_command"
  : > "$MINER_DIR/parsed/idle_args"
  echo "$(ts) h-config: no idleSettings found" >> "$LOG_DIR/debug.log"
fi
