Nosana custom miner for HiveOS

Version: 3.1.24
Folder layout:
  nosana/
    h-manifest.conf
    h-run.sh
    h-config.sh
    h-stats.sh
    monitor.sh
    idle-screen.sh
    nosana.conf

Highlights in 3.1.24
- Idle miner auto-starts when queued and stops when a job starts.
- Idle miner log is mirrored into miner log/motd.
- Version string now shows SOL, NOS, and wallet short, scraped from Nosana CLI output.
- Hashrate shows idle hashrate (or 999 kH/s) while queued.
- Fallback to Docker/nerdctl if host 'podman' isn't available.
