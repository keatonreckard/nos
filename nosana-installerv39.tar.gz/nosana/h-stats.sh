#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"

NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
DEBUG_LOG="$LOG_DIR/debug.log"

mkdir -p "$LOG_DIR" "$RUN_DIR"
touch "$NOSANA_LOG" "$IDLE_LOG" "$DEBUG_LOG"

# defaults
khs=0
stats=""
status="nos - initializing"
queue_pos=""
sol=""; nos=""; wallet=""; algo="nos - initializing"

# Load state if present
if [[ -f "$STATE_FILE" ]]; then
  # shellcheck disable=SC1090
  . "$STATE_FILE" || true
fi

# helpers
strip_ansi() { sed -r 's/\x1B\[[0-9;?]*[ -\/]*[@-~]//g'; }
tail_clean() { local f="$1" n="${2:-400}"; tail -n "$n" "$f" 2>/dev/null | tr -d '\r' | strip_ansi; }

# Parse nosana log for wallet/balances if missing
CLEAN_NOS="$(tail_clean "$NOSANA_LOG" 1200)"
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$CLEAN_NOS" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
  [[ -z "$wallet" ]] && wallet="$(printf "%s\n" "$CLEAN_NOS" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
fi
if [[ -z "${sol:-}" ]]; then
  sol="$(printf "%s\n" "$CLEAN_NOS" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
if [[ -z "${nos:-}" ]]; then
  nos="$(printf "%s\n" "$CLEAN_NOS" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi

# version fragment (no prefix)
ver=""
short_wallet=""
if [[ -n "$wallet" ]]; then short_wallet="$(printf "%s" "$wallet" | cut -c1-5)"; fi
if [[ -n "$sol" || -n "$nos" || -n "$short_wallet" ]]; then
  ver="$(printf 'S:%s N:%s W:%s' "${sol:-0}" "${nos:-0}" "${short_wallet:-----}")"
fi

# capture queue position (if present in status)
if printf "%s" "${status:-}" | grep -Eq 'queued[[:space:]]+[0-9]+/[0-9]+'; then
  queue_pos="$(printf "%s" "$status" | sed -nE 's/.*queued[[:space:]]+([0-9]+\/[0-9]+).*/\1/p')"
fi

# compute idle algo + rate when queued
idle_calc() {
  local cl; cl="$(tail_clean "$IDLE_LOG" 240)"
  [[ -z "$cl" ]] && return 1

  local is_xmr=0
  if printf "%s\n" "$cl" | grep -q "\[XMR\]"; then is_xmr=1; fi

  local gpu_avg=0 cpu_avg=0
  if (( is_xmr )); then
    # XMR: last "avg it/s" on XMR lines (CPU only)
    local xmr_avg; xmr_avg="$(printf "%s\n" "$cl" | grep "\[XMR\]" | grep -Eo '[0-9]+[[:space:]]+avg it/s' | tail -n1 | awk '{print $1}')"
    [[ -z "$xmr_avg" ]] && xmr_avg=0
    cpu_avg="$xmr_avg"
    if [[ -n "$queue_pos" ]]; then algo="nos - queued ${queue_pos} - idle xmr"; else algo="nos - idle xmr"; fi
  else
    # Qubic: CUDA avg + CPU (AVX*) avg
    local cuda_avg; cuda_avg="$(printf "%s\n" "$cl" | grep "\[CUDA\]" | grep -Eo '[0-9]+[[:space:]]+avg it/s' | tail -n1 | awk '{print $1}')"
    [[ -z "$cuda_avg" ]] && cuda_avg=0
    gpu_avg="$cuda_avg"
    local cpu_last; cpu_last="$(printf "%s\n" "$cl" | grep -E '\[(AVX512|AVX2|GENERIC)\]' | grep -Eo '[0-9]+[[:space:]]+avg it/s' | tail -n1 | awk '{print $1}')"
    [[ -z "$cpu_last" ]] && cpu_last=0
    cpu_avg="$cpu_last"
    if [[ -n "$queue_pos" ]]; then algo="nos - queued ${queue_pos} - idle qubic"; else algo="nos - idle qubic"; fi
  fi

  local total_it=$(( gpu_avg + cpu_avg ))
  if [[ "$total_it" =~ ^[0-9]+$ ]] && [[ "$total_it" -gt 0 ]]; then
    khs="$(awk -v it="$total_it" 'BEGIN{ printf "%.3f", it/1000.0 }')"
  else
    khs=0
  fi
  return 0
}

# Only change algo+hs while queued; otherwise leave status/khs as upstream
if printf "%s" "${status:-}" | grep -qi '^nos - queued'; then
  idle_calc || true
else
  algo="${status:-nos - initializing}"
fi

# Uptime from known timestamps
uptime=0; now="$(date +%s)"
for tfile in "$MINER_DIR/job.start.time" "$MINER_DIR/idle.start.time" "$MINER_DIR/nosana.start.time"; do
  if [[ -f "$tfile" ]]; then
    ts="$(cat "$tfile" 2>/dev/null || echo 0)"
    if [[ "$ts" =~ ^[0-9]+$ ]] && [[ "$ts" -gt 0 ]]; then
      diff=$(( now - ts ))
      [[ "$diff" -gt "$uptime" ]] && uptime="$diff"
    fi
  fi
done

# Emit JSON (single total hs element; temps/fans/bus empty as before)
stats="$(jq -nc \
  --argjson hs "$(printf '%s' "${khs:-0}" | jq -cs '.[0]')" \
  --arg hs_units "khs" \
  --arg uptime "${uptime}" \
  --arg ver "${ver}" \
  --arg algo "${algo}" \
  --argjson temp "[]" --argjson fan "[]" --argjson bus_numbers "[]" \
  '{hs:[$hs], hs_units:$hs_units, temp:$temp, fan:$fan, uptime:($uptime|tonumber), ver:$ver, algo:$algo, bus_numbers:$bus_numbers}')"

echo "${khs}"
echo "${stats}"
