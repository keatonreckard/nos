#!/bin/bash
# Setup runtime dirs and log files for nosana custom miner

set -e

LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/run/hive"
MINER1="${RUN_DIR}/miner.1"
MINER2="${RUN_DIR}/miner.2"
STATUS2="${RUN_DIR}/miner_status.2"
STATE_DIR="/var/run"
STATE_FILE="${STATE_DIR}/nosana.state"
START_FILE="${STATE_DIR}/nosana.start"

mkdir -p "$LOG_DIR" "$STATE_DIR"

# Ensure miner screens output files exist
touch "$MINER1" "$MINER2"

# Seed placeholder for idle output if empty
if [ ! -s "$MINER2" ]; then
  echo "waiting for node to enter queued state to start idle miner" > "$MINER2"
fi

# Default status
echo '{"status":"stopped"}' > "$STATUS2" 2>/dev/null || true

# Clear phase state on config
echo "initializing" > "$STATE_FILE" 2>/dev/null || true
date +%s > "$START_FILE" 2>/dev/null || true

exit 0
