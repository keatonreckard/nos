# Nosana HiveOS Wrapper Changelog

## 825v52
- Removed `.PADDING` filler file per user request.
- No behavior changes.
- Kept full v50 flow: idle kill/clear on start, node logs -> `/run/hive/miner.1`, idle logs -> `/run/hive/miner.2`.
- Stats: initializing = `nos - initializing` with 0.01 kH; queued adds idle suffix and pulls kH from miner.2; job running fixed at 1.000 kH.
- Messages: start/kill idle miner, queue updates, container launch notices.

## 825v51
- Version bump from v50, no behavior changes.

## 825v50
- Revert baseline to working flow and restore full script set and permissions.
- Added monitor-driven idle start on queued, and strict log routing to miner.1 / miner.2.
