#!/bin/bash
# Emit Hive stats JSON regularly. Keep logic simple and robust.

set -e

RUN_DIR="/run/hive"
MINER1="${RUN_DIR}/miner.1"
MINER2="${RUN_DIR}/miner.2"
STATE_DIR="/var/run"
STATE_FILE="${STATE_DIR}/nosana.state"
START_FILE="${STATE_DIR}/nosana.start"

# Helper: get seconds since start
since_start() {
  if [ -f "$START_FILE" ]; then
    NOW=$(date +%s)
    START=$(cat "$START_FILE" 2>/dev/null || echo 0)
    echo $((NOW-START))
  else
    echo 9999
  fi
}

# Parse queue position from miner.1 (latest occurrence)
queue_pos() {
  tac "$MINER1" 2>/dev/null | grep -m1 -E 'QUEUED.*position [0-9]+/[0-9]+'     | sed -E 's/.*position ([0-9]+\/[0-9]+).*/\1/'
}

# Detect idle algorithm & rate from miner.2 (XMR or Qubic) in it/s => kH/s
idle_khs() {
  awk 'match($0,/\[(XMR|QUBIC|Qubic)\][^|]* ([0-9]+) it\/s/,a){print a[2]; exit}' "$MINER2" 2>/dev/null |   awk '{ if($1=="") print "0"; else printf "%.3f", $1/1000 }'
}

idle_algo() {
  awk 'match($0,/\[(XMR|QUBIC|Qubic)\]/,a){print tolower(a[1]); exit}' "$MINER2" 2>/dev/null | sed 's/qubic/qubic/'
}

# Main loop
INTERVAL=10
UPTIME=0
while :; do
  sleep "$INTERVAL"
  UPTIME=$((UPTIME+INTERVAL))

  PHASE="initializing"
  if [ -f "$STATE_FILE" ]; then
    PHASE=$(cat "$STATE_FILE" 2>/dev/null || echo "initializing")
  fi

  # Fallback: after 120s without queued marker, assume job (node active)
  if [ "$PHASE" = "initializing" ]; then
    ELAPSED=$(since_start)
    if [ "$ELAPSED" -gt 120 ]; then
      PHASE="job"
    fi
  fi

  QPOS=""
  if [ "$PHASE" = "queued" ] || echo "$PHASE" | grep -q '^queued:'; then
    if echo "$PHASE" | grep -q '^queued:'; then
      QPOS="${PHASE#queued:}"
      PHASE="queued"
    else
      QPOS="$(queue_pos)"
    fi
  fi

  # Build algo + hashrate
  ALGO="nos - initializing"
  HS="0.01"
  HS_ARR="[0]"

  case "$PHASE" in
    initializing)
      ALGO="nos - initializing"
      HS="0.01"
      HS_ARR="[0]"
    ;;
    queued)
      ALGO="nos queued ${QPOS}"
      # If idle miner is running and reporting, append suffix and use its rate
      if screen -ls 2>/dev/null | grep -q "nosana-idle"; then
        KH=$(idle_khs)
        if [ "$KH" != "0" ] && [ "$KH" != "" ]; then
          ALG=$(idle_algo)
          if [ -z "$ALG" ]; then ALG="idle"; else ALG="idle ${ALG}"; fi
          ALGO="${ALGO} - ${ALG}"
          HS="$KH"
          # convert HS to integer array of khs (rounded)
          HS_INT=$(printf "%.0f" "$(echo "$KH*1000" | bc -l 2>/dev/null || echo 0)")
          HS_ARR="[$HS_INT]"
        else
          HS="0.01"
          HS_ARR="[0]"
        fi
      else
        HS="0.01"
        HS_ARR="[0]"
      fi
    ;;
    job)
      ALGO="nos - job"
      HS="1.000"
      HS_ARR="[1000]"
    ;;
    *)
      # unknown => treat as initializing
      ALGO="nos - initializing"
      HS="0.01"
      HS_ARR="[0]"
    ;;
  esac

  # Emit lightweight line for agent (matches style)
  echo "$HS"

  # Raw miner JSON (used by Hive UI parser)
  echo "{"hs":${HS_ARR},"hs_units":"khs","temp":[],"fan":[],"uptime":"$UPTIME","ver":"","algo":"$ALGO","bus_numbers":[]}"

  # Also emit the outer RPC stanza expected by the Agent
  TOTAL_KHS="$HS"
  echo "Hashrate custom ${TOTAL_KHS} kH/s"

  # Note: The actual RPC to Hive is sent by the Agent, we only print JSON blob next.
  echo "{"method":"stats","params":{"v":2,"rig_id":"$RIG_ID","passwd":"$RIG_PASS","meta":{"fs_id":$FS_ID,"custom":{"coin":"NOS"}},"temp":[0,40],"fan":[0,0],"power":[0,5],"df":"336G","mem":[30804,26850],"cputemp":[55],"cpuavg":[20,20,20],"miner":"custom","total_khs":$TOTAL_KHS,"miner_stats":{"status":"running","hs":${HS_ARR},"hs_units":"khs","temp":[],"fan":[],"uptime":$UPTIME,"ver":"","algo":"$ALGO","bus_numbers":[]}}}"
done
