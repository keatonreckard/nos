#!/bin/sh
# Stop idle miner screen and reset miner.2

RUN_DIR="/run/hive"
MINER2="${RUN_DIR}/miner.2"
STATUS2="${RUN_DIR}/miner_status.2"

if screen -ls | grep -q "nosana-idle"; then
  screen -S nosana-idle -X quit || true
fi

echo "waiting for node to enter queued state to start idle miner" > "$MINER2"
echo '{"status":"stopped"}' > "$STATUS2" 2>/dev/null || true
