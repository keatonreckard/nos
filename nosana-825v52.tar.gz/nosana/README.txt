nosana 825v50 (revert) with small fixes
- Kill idle miner and clear miner.2 on start/restart
- Initialize phase ensures no idle suffix/rate leaks during 'initializing'
- Queue detection updates algo to 'nos queued x/y' and starts idle miner
- Idle logs are written only to /run/hive/miner.2
- Node logs are appended only to /run/hive/miner.1
- Default hashrates: 0.01 kH (init/queued no idle), 1.000 kH (job)

Bumped version to 825v51. No behavioral changes.
