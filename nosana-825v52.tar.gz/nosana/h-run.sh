#!/bin/bash
# Start nosana node and manage sidecar; ensure idle miner is stopped first

# Do not use -u to avoid unbound variable issues in Hive environment
set -e

ts() { date +"[%Y-%m-%dT%H:%M:%S%z]"; }
log() { echo "$(ts) h-run: $*"; }

RUN_DIR="/run/hive"
MINER1="${RUN_DIR}/miner.1"
MINER2="${RUN_DIR}/miner.2"
STATUS2="${RUN_DIR}/miner_status.2"
STATE_DIR="/var/run"
STATE_FILE="${STATE_DIR}/nosana.state"
START_FILE="${STATE_DIR}/nosana.start"

# Kill any residual idle miner and clear its screen/log before anything else
if screen -ls | grep -q "nosana-idle"; then
  echo "$(ts) NOS: idle miner killed" | tee -a "$MINER1" >/dev/null
  screen -S nosana-idle -X quit || true
fi
# Reset miner.2 & status
echo "waiting for node to enter queued state to start idle miner" > "$MINER2"
echo '{"status":"stopped"}' > "$STATUS2" 2>/dev/null || true

# Phase -> initializing
echo "initializing" > "$STATE_FILE"
date +%s > "$START_FILE"

# Clean old containers (best effort)
log "cleaning previous containers"
docker rm --force podman nosana-node >/dev/null 2>&1 || true

# Start podman sidecar (container flavor, works on Hive)
log "starting podman sidecar (container)"
if ! docker volume ls | grep -q podman-cache; then docker volume create podman-cache >/dev/null 2>&1; fi
if ! docker volume ls | grep -q podman-socket; then docker volume create podman-socket >/dev/null 2>&1; fi

PODMAN_ID=$(docker run -d --pull=always --gpus=all --name podman --device /dev/fuse   --mount source=podman-cache,target=/var/lib/containers   --volume podman-socket:/podman   --privileged -e ENABLE_GPU=true nosana/podman:v1.1.0 unix:/podman/podman.sock 2>/dev/null || true)

sleep 2
if docker ps | grep -q "podman"; then
  log "podman socket is up"
fi

# Start nosana-node container (provider=podman via volume)
log "starting nosana-node (podman provider via volume)"
echo "NOS: node starting" | tee -a "$MINER1" >/dev/null

NODE_ID=$(docker run -d --pull=always --name nosana-node --network host -t   --volume ~/.nosana/:/root/.nosana/   --volume podman-socket:/root/.nosana/podman:ro   nosana/nosana-cli:latest node start --network mainnet 2>/dev/null || true)

# Stream node logs to miner.1 (append-only). Run in background.
# Use stdbuf to force line-buffered output to avoid partial overwrites.
stdbuf -oL -eL docker logs -f nosana-node >> "$MINER1" 2>&1 &

echo "$(ts) NOS: node container launched" | tee -a "$MINER1" >/dev/null

# Fire up monitor (non-fatal if it dies)
if [ -x "$(dirname "$0")/monitor.sh" ]; then
  "$(dirname "$0")/monitor.sh" >> "$MINER1" 2>&1 &
  echo "$(ts) NOS: monitor started" | tee -a "$MINER1" >/dev/null
fi

# Keep foreground alive to satisfy Hive custom miner
# Tail the node log file to keep process attached
tail -F "$MINER1"
