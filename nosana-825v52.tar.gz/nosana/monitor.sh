#!/bin/sh
# Minimal monitor: watch miner.1 for queue lines, start/stop idle miner accordingly
# Avoid bash-isms; run with /bin/sh for portability

RUN_DIR="/run/hive"
MINER1="${RUN_DIR}/miner.1"
MINER2="${RUN_DIR}/miner.2"
STATUS2="${RUN_DIR}/miner_status.2"
STATE_DIR="/var/run"
STATE_FILE="${STATE_DIR}/nosana.state"

echo "NOS: monitor started"

idle_running() {
  screen -ls 2>/dev/null | grep -q "nosana-idle"
}

start_idle() {
  if idle_running; then
    return
  fi
  if [ -x "$(dirname "$0")/idle-run.sh" ]; then
    echo "NOS: starting idle miner"
    sh "$(dirname "$0")/idle-run.sh" &
    echo '{"status":"running"}' > "$STATUS2" 2>/dev/null || true
  fi
}

stop_idle() {
  if idle_running; then
    echo "NOS: idle miner killed"
    sh "$(dirname "$0")/idle-kill.sh" >/dev/null 2>&1 || true
  fi
  echo '{"status":"stopped"}' > "$STATUS2" 2>/dev/null || true
}

# When starting up, set initializing
echo "initializing" > "$STATE_FILE"

# Follow miner.1 and react to queue updates
tail -n0 -F "$MINER1" 2>/dev/null | while IFS= read -r line; do
  # Detect queued with position x/y
  case "$line" in
    *"QUEUED"*position*/*)
      QPOS=$(echo "$line" | sed -n 's/.*position \([0-9]\+\/\([0-9]\+\)\).*/\1/p' | head -n1)
      if [ -z "$QPOS" ]; then
        # fallback simple parse
        QPOS=$(echo "$line" | awk '{for(i=1;i<=NF;i++){if($i=="position"){print $(i+1)}}}' | tr -d ' ')
      fi
      if [ -n "$QPOS" ]; then
        echo "queued:$QPOS" > "$STATE_FILE"
        echo "NOS: queued $QPOS"
        start_idle
      fi
    ;;
    *"Health check completed"*)
      # shortly before queued; keep initializing
      echo "initializing" > "$STATE_FILE"
    ;;
    *"Shutting down node"*|*"Starting job"*|*"RUNNING job"*|*"RUNNING task"*)
      echo "job" > "$STATE_FILE"
      echo "NOS: job started"
      stop_idle
    ;;
  esac
done
