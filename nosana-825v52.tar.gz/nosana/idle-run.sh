#!/bin/sh
# Start idle miner in a dedicated screen; log only to miner.2

RUN_DIR="/run/hive"
MINER2="${RUN_DIR}/miner.2"
STATUS2="${RUN_DIR}/miner_status.2"
CMD_FILE="/hive/miners/custom/nosana/idle.cmd"

# Determine command
if [ -s "$CMD_FILE" ]; then
  CMD=$(cat "$CMD_FILE")
elif [ -n "$IDLE_COMMAND" ]; then
  CMD="$IDLE_COMMAND"
else
  echo "NOS: idle miner not configured (no idle.cmd or IDLE_COMMAND)"
  exit 0
fi

# Clear miner.2 and set status running
: > "$MINER2"
echo '{"status":"running"}' > "$STATUS2" 2>/dev/null || true

# Launch inside screen; pipe stdout/stderr to miner.2
# Use exec sh -c to ensure command expansion is respected
screen -S nosana-idle -dm sh -c "$CMD >> "$MINER2" 2>&1"
echo "NOS: idle miner started (cmd: $CMD)"
