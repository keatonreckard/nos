#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

# ---- paths ----
MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
NOSANA_LOG="/run/hive/miner.1"
IDLE_LOG="/run/hive/miner.2"

mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

# Fallbacks
khs=0
stats=""
status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""; idle_enabled=0
# Load previous state if present (to avoid losing version string between phases)
if [[ -f "$STATE_FILE" ]]; then
  # shellcheck disable=SC1090
  source "$STATE_FILE" || true
fi


# ---- Current state helpers ----
job_active=0

normalize_to_khs() {
  # $1 = numeric rate, $2 = unit (uppercase); echo kH/s value or 0
  local rate="$1" unit="$2"
  case "$unit" in
    IT/S) echo "$(echo "scale=6; ${rate}/1000" | bc)";;
    H/S)  echo "$(echo "scale=6; ${rate}/1000" | bc)";;
    KH/S|KHS) echo "${rate}";;
    MH/S) echo "$(echo "scale=6; ${rate}*1000" | bc)";;
    *) echo "0";;
  esac
}
if [[ "${status:-}" =~ ^nos[[:space:]]-[[:space:]]job$ ]]; then
  job_active=1
fi
# Read & clean logs (strip ANSI)
clean_log() {
  local file="$1"
  [[ -s "$file" ]] || return 1
  # read last slice and strip carriage returns + ANSI
  tail -n 4000 "$file" 2>/dev/null | tr -d '\r' | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g'
  return 0
}

NOS_CLEAN="$(clean_log "$NOSANA_LOG" || true)"
IDLE_CLEAN="$(clean_log "
# --- sanitize a view of idle log (strip ANSI + CR) ---
SANITIZED_IDLE="/tmp/nosana_idle_sanitized.$$"
if [ -f "$SANITIZED_IDLE" ]; then
  sed -u -E $'s/\x1B\[[0-9;?]*[ -\\/]*[@-~]//g' "$SANITIZED_IDLE" | tr -d '\r' > "$SANITIZED_IDLE" 2>/dev/null || cp "$SANITIZED_IDLE" "$SANITIZED_IDLE" 2>/dev/null
else
  : > "$SANITIZED_IDLE"
fi
$SANITIZED_IDLE" || true)"

# ---- Parse wallet / balances from nosana log ----
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
fi
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
fi

if [[ -z "${sol:-}" ]]; then
  sol="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
if [[ -z "${nos:-}" ]]; then
  nos="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi

# Build version string (keep previous if data not found)
ver_build=""
if [[ -n "${sol:-}" || -n "${nos:-}" || -n "${wallet:-}" ]]; then
  shortw=""
  if [[ -n "${wallet:-}" ]]; then shortw="$(printf "%s" "$wallet" | cut -c1-5)"; fi
  ver_build="S:${sol:-0} N:${nos:-0} W:${shortw:-?????}"
fi
# If version string wasn't derivable now, keep old one if present
ver="${ver_build:-${ver:-}}"

# ---- Parse queue position ----
queue_txt="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*QUEUED.*position[[:space:]]*([0-9]+)\/([0-9]+).*/\1\/\2/p' | tail -n1)"
if [[ -z "$queue_txt" ]]; then
  queue_txt="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*queued[[:space:]]*([0-9]+)\/([0-9]+).*/\1\/\2/p' | tail -n1)"
fi

# ---- Determine idle mode (qubic vs xmr) ----
idle_mode=""
if [[ -n "${IDLE_CLEAN:-}" ]]; then
  # consider XMR mode if there are sufficiently many XMR lines recently
  xmr_count="$(printf "%s\n" "$IDLE_CLEAN" | tail -n 120 | grep -c '\[XMR\]' || true)"
  if [[ "${xmr_count:-0}" -ge 3 ]]; then
    idle_mode="xmr"
  else
    # default qubic if we see AVX/GENERIC or CUDA signatures
    if printf "%s\n" "$IDLE_CLEAN" | grep -Eq '\[(AVX512|AVX2|GENERIC|CUDA)\]'; then
      idle_mode="qubic"
    fi
  fi
fi

# ---- Extract idle hashrates (instant or avg it/s) ----
extract_avg() { # $1: pattern e.g. '\[CUDA\]'
  printf "%s\n" "${IDLE_CLEAN:-}" | grep -E "$1" | grep -E 'avg it/s' | tail -n1 | sed -nE 's/.*\|\s*([0-9]+)[[:space:]]+avg it\/s.*/\1/p'
}
extract_inst_gpu() {
  printf "%s\n" "${IDLE_CLEAN:-}" | grep -E '\[GPU\][[:space:]]+Trainer:[[:space:]]+GPU #[0-9]+:' | tail -n1 | sed -nE 's/.*GPU #[0-9]+:[[:space:]]*([0-9]+)[[:space:]]+it\/s.*/\1/p'
}

cpu_hs=""; gpu_hs=""
if [[ "$idle_mode" == "xmr" ]]; then
  cpu_hs="$(extract_avg '\[XMR\]')"
  [[ -z "${cpu_hs}" ]] && cpu_hs="0"
elif [[ "$idle_mode" == "qubic" ]]; then
  total_line="$(printf "%s
" "${IDLE_CLEAN:-}" | grep -E -i 'Total speed:|Total:' | tail -n1)"
  token="$(printf "%s
" "$total_line" | grep -E -oi '(""" + token_regex + r""")' | tail -n1)"
  if [[ -z "$token" ]]; then
    token="$(printf "%s
" "${IDLE_CLEAN:-}" | grep -E -oi '(""" + token_regex + r""")' | tail -n1)"
  fi
  rate="$(printf "%s
" "$token" | awk '{print $1}')" || rate=""
  unit="$(printf "%s
" "$token" | awk '{print toupper($2)}')" || unit=""
  if [[ -n "$rate" && -n "$unit" ]]; then
    khs="$(normalize_to_khs "$rate" "$unit")"
  else
    khs="0"
  fi
  hs_json="[]"
else
  khs=0
  hs_json="[]"
fi
# ---- Uptime heuristic ----
uptime=0
if [[ -f "$NOSANA_LOG" ]]; then
  now="$(date +%s)"
  mt="$(stat --format='%Y' "$NOSANA_LOG" || echo "$now")"
  delta=$(( now - mt ))
  if (( delta < 86400 )); then uptime=$(( 120 + (86400 - delta) % 300 )); fi
fi

# ---- Emit stats ----
# temp / fan left empty; bus_numbers left empty (nulls) per current wrapper
stats="$(jq -nc \
  --argjson hs "${hs_json}" \
  --arg hs_units "${hs_units}" \
  --argjson temp '[]' \
  --argjson fan '[]' \
  --arg uptime "${uptime}" \
  --arg ver "${ver:-}" \
  --arg algo "${algo}" \
  --argjson bus_numbers '[]' \
  '{ $hs, $hs_units, $temp, $fan, $uptime, $ver, $algo, $bus_numbers }'
)"

# Output for Hive agent
echo "${khs:-0}"
echo "${stats}"

rm -f "$SANITIZED_IDLE" 2>/dev/null || true
