nosana hiveos wrapper (v4.30)

- Starts a monitor that watches the node logs for QUEUED vs JOB.
- Launches the idle miner with nohup when queued; mirrors idle.log into nosana.log with [idle] prefix.
- Emits valid JSON for the HiveOS agent; restores algo display (queued X/Y, job, or initializing).

Files:
  h-config.sh, h-manifest.conf, h-run.sh, h-stats.sh, monitor.sh, idle-screen.sh, README.txt
