#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
NOSLOG="$LOG_DIR/nosana.log"
IDLELOG="$LOG_DIR/idle.log"
PARSED="$ROOT/parsed"
STATE_FILE="$PARSED/state"
IDLE_PID_FILE="/var/run/nosana-idle.pid"
TAIL_PID_FILE="/var/run/nosana-idle-tailer.pid"

mkdir -p "$LOG_DIR" "$PARSED"
: > "$STATE_FILE"
touch "$NOSLOG" "$IDLELOG"

ts() { date +"[%Y-%m-%dT%H:%M:%S%z]"; }

# path to idle miner (kept exactly as provided by user env)
IDLE_BIN=$(cat "$PARSED/idle_command" 2>/dev/null || echo "/hive/miners/custom/qubjetski.PPLNS/qli-Client")
IDLE_DIR=$(dirname "$IDLE_BIN")
IDLE_EXE=$(basename "$IDLE_BIN")

# extra args (kept from parsed)
IDLE_ARGS=$(cat "$PARSED/idle_args" 2>/dev/null || echo "")

is_running_pid() { local p="$1"; [ -n "$p" ] && kill -0 "$p" 2>/dev/null; }
idle_running() { pgrep -af "[.]/${IDLE_EXE}|${IDLE_EXE} " >/dev/null 2>&1 || is_running_pid "$(cat "$IDLE_PID_FILE" 2>/dev/null || true)"; }
tailer_running() { is_running_pid "$(cat "$TAIL_PID_FILE" 2>/dev/null || true)"; }

start_tailer() {
  tailer_running && return 0
  # prefix lines with [idle] and append to noslog; ignore if empty
  nohup bash -lc "exec tail -F \"$IDLELOG\" | sed -u 's/^/[idle] /' >> \"$NOSLOG\"" >/dev/null 2>&1 &
  echo $! > "$TAIL_PID_FILE"
}

stop_tailer() {
  if tailer_running; then
    kill "$(cat "$TAIL_PID_FILE")" 2>/dev/null || true
    rm -f "$TAIL_PID_FILE"
  fi
}

start_idle() {
  idle_running && return 0
  mkdir -p "$IDLE_DIR"
  cd "$IDLE_DIR" || true
  echo "[nosana] idle miner starting: $IDLE_BIN $IDLE_ARGS" | tee -a "$NOSLOG"
  # zero idle log to make fresh detection easy
  : > "$IDLELOG"
  # Use nohup + setsid to avoid screen complexities
  nohup bash -lc "exec setsid stdbuf -oL -eL ./\"$IDLE_EXE\" $IDLE_ARGS" >> "$IDLELOG" 2>&1 &
  echo $! > "$IDLE_PID_FILE"
  start_tailer
  echo "[nosana] idle miner started (pid=$(cat "$IDLE_PID_FILE"))" | tee -a "$NOSLOG"
}

stop_idle() {
  if idle_running; then
    echo "[nosana] idle miner stopping" | tee -a "$NOSLOG"
    pkill -f "[.]${IDLE_EXE}" 2>/dev/null || true
    if [ -s "$IDLE_PID_FILE" ]; then
      kill "$(cat "$IDLE_PID_FILE")" 2>/dev/null || true
    fi
    rm -f "$IDLE_PID_FILE"
  fi
  stop_tailer
  echo "[nosana] idle miner stopped" | tee -a "$NOSLOG"
}

# state detection helpers
set_state() {
  local new="$1" extra="${2:-}"
  echo "$new" > "$STATE_FILE"
  if [ "$new" = "queued" ]; then
    echo "[nosana] set_state detected queued ${extra} -> start_idle" | tee -a "$NOSLOG"
    start_idle
  elif [ "$new" = "job" ]; then
    echo "[nosana] set_state detected job -> stop_idle" | tee -a "$NOSLOG"
    stop_idle
  fi
}

# bootstrap: make sure tailer exists even before first transition
start_tailer

# main loop: watch nosana.log for transitions
# We ignore lines we ourselves inject which start with [idle]
tail -n0 -F "$NOSLOG" | while IFS= read -r line; do
  [[ "$line" == "[idle] "* ]] && continue

  # Detect QUEUED patterns
  if echo "$line" | grep -qE 'QUEUED|queued [0-9]+/[0-9]+'; then
    # extract X/Y if present
    pos=$(echo "$line" | grep -oE '[0-9]+/[0-9]+' | tail -n1 || true)
    set_state "queued" "$pos"
    continue
  fi

  # Detect "job started/accepted" patterns
  if echo "$line" | grep -qiE 'job (started|accepted|running)|RUNNING JOB|Starting job'; then
    set_state "job"
    continue
  fi

  # Detect job finished to go back to queued (idle)
  if echo "$line" | grep -qiE 'job finished|JOB FINISHED|No job available'; then
    set_state "queued"
    continue
  fi
done
