#!/usr/bin/env bash
set -euo pipefail

log_dir="/var/log/miner/nosana"
mkdir -p "$log_dir"
chmod 755 "$log_dir"
noslog="$log_dir/nosana.log"

ts() { date +"[%Y-%m-%dT%H:%M:%S%z]"; }

echo "$(ts) h-run: cleaning previous containers" | tee -a "$noslog"
# Keep original behavior (do not alter how the node runs)
# Sidecar & node start are assumed to be handled in external scripts/config
# This wrapper only ensures the monitor is running.

# Start monitor (idempotent)
if ! pgrep -af "/hive/miners/custom/nosana/monitor.sh" >/dev/null 2>&1; then
  echo "[nosana] monitor started" | tee -a "$noslog"
  nohup /hive/miners/custom/nosana/monitor.sh >>"$noslog" 2>&1 & disown || true
else
  echo "[nosana] monitor already running" | tee -a "$noslog"
fi

# Hand control back to HiveOS init; nothing else major here by request.
exit 0
