#!/usr/bin/env bash
set -Eeuo pipefail
LOG_DIR="/var/log/miner/nosana"
NOSLOG="$LOG_DIR/nosana.log"
DBG="$LOG_DIR/debug.log"
PARSED="/hive/miners/custom/nosana/parsed"

mkdir -p "$LOG_DIR" "$PARSED"
touch "$NOSLOG" "$DBG"

# Extract balances & wallet like the user wants (keep formatting)
SOL=$(grep -oE 'SOL balance:\s+[0-9.]+ SOL' "$NOSLOG" | tail -n1 | awk '{print $3}' 2>/dev/null || echo "")
NOS=$(grep -oE 'NOS balance:\s+[0-9.]+ NOS' "$NOSLOG" | tail -n1 | awk '{print $3}' 2>/dev/null || echo "")
WAL=$(grep -oE 'Wallet:\s+[A-Za-z0-9]+' "$NOSLOG" | tail -n1 | awk '{print $2}' 2>/dev/null || echo "")

VER_STR=""
if [ -n "$SOL" ] || [ -n "$NOS" ] || [ -n "$WAL" ]; then
  WSHORT=$(echo "$WAL" | cut -c1-5)
  VER_STR="S:${SOL:-} N:${NOS:-} W:${WSHORT:-}"
fi

# Algo detection: prefer latest queued with X/Y, else job, else initializing
algo="nos - initializing"
if grep -qE 'queued [0-9]+/[0-9]+' "$NOSLOG"; then
  q=$(grep -E 'queued [0-9]+/[0-9]+' "$NOSLOG" | tail -n1 | grep -oE '[0-9]+/[0-9]+' || true)
  [ -n "$q" ] && algo="nos - queued $q"
fi
# If we have a clear job state more recent than queued, prefer job
jq_line=$(grep -nE 'job (started|accepted|running)|RUNNING JOB|Starting job' "$NOSLOG" | tail -n1 | cut -d: -f1 || echo 0)
qq_line=$(grep -nE 'queued [0-9]+/[0-9]+' "$NOSLOG" | tail -n1 | cut -d: -f1 || echo 0)
if [ "${jq_line:-0}" -gt "${qq_line:-0}" ] && [ "$jq_line" != "0" ]; then
  algo="nos - job"
fi

# Emit a fixed, clean JSON line for the agent
printf '{"hs":[%s],"hs_units":"khs","temp":[],"fan":[],"uptime":%d,"ver":"%s","ar":[0,0],"algo":"%s","bus_numbers":[]}\n' \
  "0" "$(cut -d. -f1 /proc/uptime)" "$VER_STR" "$algo" | tee -a "$DBG" >/dev/null

# Also print an easy-to-read debug line
echo "$(date +'%F %T') h-stats: ver=$VER_STR | algo=$algo | khs=0 | wallet=$WAL | sol=$SOL | nos=$NOS" >> "$DBG"
