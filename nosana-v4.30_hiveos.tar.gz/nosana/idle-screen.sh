#!/usr/bin/env bash
set -euo pipefail
log="/var/log/miner/nosana/idle.log"
mkdir -p /var/log/miner/nosana
if [ ! -s "$log" ]; then
  : > "$log"
fi
cat <<'HDR' >> "$log"

H $(/hive/bin/hive-version 2>/dev/null || echo "?") · K $(uname -r) · D $(. /etc/os-release 2>/dev/null; echo "${VERSION_ID:-?}") · N $(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null | head -n1 || echo "-") · up $(uptime -p | sed 's/up //')

$(hostname) · ID $(cat /var/run/hive.id 2>/dev/null || echo "?") · LA $(cut -d ' ' -f1-3 /proc/loadavg) · RAM $(free -m | awk '/Mem:/ {print $2"G  available " ($7/1024)"G (" int($7/$2*100) "%)"}')

HDR
