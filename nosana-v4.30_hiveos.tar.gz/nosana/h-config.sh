#!/usr/bin/env bash
# h-config.sh - placeholder (kept minimal per user request)
# Load env if present
[ -f /hive/miners/custom/nosana/.env ] && source /hive/miners/custom/nosana/.env
