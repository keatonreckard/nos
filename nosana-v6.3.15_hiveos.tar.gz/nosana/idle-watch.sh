#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
LOG_DIR="/var/log/miner/nosana"
CUSTOM_LOG="/var/log/miner/custom/custom.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
PIDFILE="$RUN_DIR/nosana.idlewatch.pid"
mkdir -p "$RUN_DIR" "$LOG_DIR" "$(dirname "$CUSTOM_LOG")"
touch "$NOSANA_LOG" "$IDLE_LOG" "$CUSTOM_LOG"

idle_running(){ screen -ls 2>/dev/null | grep -q "\.nosana-idle"; }

start_idle(){
  if ! idle_running; then
    echo "idle-screen: starting idle miner screen: $MINER_DIR/idle-screen.sh" | tee -a "$IDLE_LOG" "$NOSANA_LOG" "$CUSTOM_LOG" >/dev/null
    ( bash -lc "$MINER_DIR/idle-run.sh" ) >>"$IDLE_LOG" 2>&1 &
  fi
}
stop_idle(){
  if idle_running; then
    echo "[idle-queue] stopping idle miner" | tee -a "$IDLE_LOG" "$NOSANA_LOG" "$CUSTOM_LOG" >/dev/null
    bash "$MINER_DIR/idle-kill.sh" >>"$IDLE_LOG" 2>&1 || true
  fi
}

detect_and_toggle(){
  # Prefer container logs
  L="$(podman logs --since 10s nosana-node 2>/dev/null || docker logs --since 10s nosana-node 2>/dev/null || true)"
  if [[ -z "${L:-}" && -s "$NOSANA_LOG" ]]; then
    L="$(tail -n 400 "$NOSANA_LOG" 2>/dev/null)"
  fi
  [[ -z "${L:-}" ]] && return 0
  CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"
  job_ln=$(printf "%s\n" "$CLEAN" | awk '/Node is claiming job|Node has found job|claimed job|Job .* (started|running)|Flow .* (started|running)/{ln=NR}END{print ln+0}')
  queue_ln=$(printf "%s\n" "$CLEAN" | awk '/(^|[[:space:]])QUEUED([[:space:]]|$)|position[[:space:]]+[0-9]+\/[0-9]+|\[nosana\][[:space:]]+queued/{ln=NR}END{print ln+0}')
  if (( queue_ln > job_ln && queue_ln > 0 )); then
    start_idle
  else
    stop_idle
  fi
}

# single instance
if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE" 2>/dev/null)" 2>/dev/null; then
  exit 0
fi
echo $$ > "$PIDFILE"
echo "[idle-queue] watcher online" >>"$CUSTOM_LOG"
trap 'rm -f "$PIDFILE"; exit 0' INT TERM EXIT
while true; do
  detect_and_toggle
  sleep 7
done
