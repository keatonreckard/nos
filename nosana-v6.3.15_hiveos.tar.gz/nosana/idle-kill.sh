#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
mkdir -p "$LOG_DIR"; touch "$IDLE_LOG"
echo "[$(date -Iseconds)] idle-kill: idle miner killed" | tee -a "$IDLE_LOG"
screen -S nosana-idle -X quit >/dev/null 2>&1 || true
exit 0
