#!/usr/bin/env bash
set -euo pipefail
source /hive/miners/custom/nosana/h-config.sh
# Stop screen session if used (name: nosana-idle) and bridge
screen -S nosana-idle -X quit 2>/dev/null || true
/hive/miners/custom/nosana/idle-bridge.sh stop || true
echo "[idle-kill] invoked at $(date)" >> "$NOSANA_LOG"
