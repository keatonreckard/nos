#!/usr/bin/env bash
# Emits two lines: <khs>\n<json>
set -euo pipefail
export LC_ALL=C
source /hive/miners/custom/nosana/h-config.sh

jq_bin="$(command -v jq || true)"
bc_bin="$(command -v bc || true)"
[[ -z "$jq_bin" ]] && echo "0" && echo '{}' && exit 0

# helpers
clean_log() { sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g' | tr -d '\r'; }
numfmt_safe() {
  # $1=float, $2=decimals
  awk -v x="${1:-0}" -v d="${2:-0}" 'BEGIN{ printf("%.*f", d, (x+0)) }'
}

# read state
status=""; queue=""; sol=""; nos=""; wallet=""
if [[ -s "$STATE_FILE" ]]; then
  # shellcheck disable=SC1090
  source "$STATE_FILE" || true
fi

# gather recent nosana log
L="$(tail -n 3000 "$NOSANA_LOG" | clean_log)"
# update wallet/sol/nos if missing
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$L" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
fi
if [[ -z "${sol:-}" ]]; then
  sol="$(printf "%s\n" "$L" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
if [[ -z "${nos:-}" ]]; then
  nos="$(printf "%s\n" "$L" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi

# format version string (persist even when queued)
sol_fmt=""; nos_fmt=""; wal_short=""
[[ -n "${sol:-}" ]] && sol_fmt="$(numfmt_safe "$sol" 4)"
[[ -n "${nos:-}" ]] && nos_fmt="$(numfmt_safe "$nos" 3)"
if [[ -n "${wallet:-}" ]]; then wal_short="$(printf "%s" "$wallet" | cut -c1-5)"; fi
ver=""; if [[ -n "$sol_fmt$nos_fmt$wal_short" ]]; then ver="S:${sol_fmt} N:${nos_fmt} W:${wal_short}"; fi

# detect queue (position a/b)
if [[ -z "${queue:-}" ]]; then
  q="$(printf "%s\n" "$L" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
  [[ -z "$q" ]] && q="$(printf "%s\n" "$L" | sed -nE 's/.*\[nosana\][[:space:]]+queued[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
  queue="$q"
fi

# detect idle mode + hashrates from idle.log
IDLE="$(tail -n 200 "$IDLE_LOG" | clean_log)"
is_xmr=0
xmr_avg=0
gpu_it=0
cpu_it=0

if printf "%s\n" "$IDLE" | grep -q "\[XMR\].*avg it/s"; then
  is_xmr=1
  xmr_avg="$(printf "%s\n" "$IDLE" | awk '/\[XMR\].*avg it\/s/ {last=$0} END{ if(last){ if (match(last,/([0-9]+)[[:space:]]+avg it\/s/,m)) print m[1]; else print 0 } }')"
else
  # Qubic: parse CUDA and CPU
  gpu_it="$(printf "%s\n" "$IDLE" | awk '/\[CUDA\].*avg it\/s/ {last=$0} END{ if(last){ if (match(last,/([0-9]+)[[:space:]]+avg it\/s/,m)) print m[1]; else print 0 } }')"
  cpu_it="$(printf "%s\n" "$IDLE" | awk '/\[(AVX512|AVX2|GENERIC)\].*avg it\/s/ {last=$0} END{ if(last){ if (match(last,/([0-9]+)[[:space:]]+avg it\/s/,m)) print m[1]; else print 0 } }')"
fi

algo="nos"
hs_units="hs"
declare -a hs temp fan bus_numbers
khs="0"

now_epoch="$(date +%s)"
recent_cli="$(printf "%s\n" "$L" | awk -v now="$now_epoch" '
  match($0, /\[([0-9:-T+]+)\]/) { }')"

# Decide mode
# Prefer explicit state.status if available
mode="${status:-}"
if [[ "$mode" == "job" ]]; then
  algo="nos - job"
  hs=(1000)
  khs="1"
elif [[ "$mode" == "initializing" ]]; then
  algo="nos - initializing"
  hs=(1000)
  khs="1"
else
  # queued?
  if [[ -n "${queue:-}" ]]; then
    if [[ $is_xmr -eq 1 ]]; then
      algo="nos - queued ${queue} - idle xmr"
      hs=("$xmr_avg")
    else
      algo="nos - queued ${queue} - idle qubic"
      if [[ -n "$gpu_it" && -n "$cpu_it" ]]; then
        hs=("$gpu_it" "$cpu_it")
      elif [[ -n "$gpu_it" ]]; then
        hs=("$gpu_it")
      else
        hs=("$cpu_it")
      fi
    fi
    # total khs from sum(it/s)/1000
    sum=0
    for h in "${hs[@]}"; do
      [[ -n "$h" ]] && sum=$((sum + h))
    done
    if [[ "$sum" -gt 0 ]]; then
      if [[ -n "$bc_bin" ]]; then
        khs="$(echo "scale=6; $sum/1000" | bc)"
      else
        khs="$((sum/1000))"
      fi
    fi
  else
    # fallback: if no known state, show initializing with 1 kH/s to avoid idle suffix bleed
    algo="nos - initializing"
    hs=(1000)
    khs="1"
  fi
fi

# emit JSON
hs_json="$(printf '%s\n' "${hs[@]}" | jq -cs '.|map(tonumber)')"
temp_json="[]"; fan_json="[]"; bus_json="[]"

stats=$(jq -nc \
  --argjson hs "$hs_json" \
  --arg hs_units "$hs_units" \
  --argjson temp "$temp_json" \
  --argjson fan "$fan_json" \
  --arg uptime "60" \
  --arg ver "$ver" \
  --arg algo "$algo" \
  --argjson bus_numbers "$bus_json" \
  '{$hs,$hs_units,$temp,$fan,$uptime,$ver,$algo,$bus_numbers}')

echo "$khs"
echo "$stats"
