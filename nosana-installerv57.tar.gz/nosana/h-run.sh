#!/usr/bin/env bash
set -euo pipefail
source /hive/miners/custom/nosana/h-config.sh

# Timestamp separator instead of truncation
printf -- "-- custom nosana -- %s --\n" "$(date)" >> "$NOSANA_LOG"

# Start monitor (single instance)
if ! pgrep -afq "/hive/miners/custom/nosana/monitor.sh"; then
  nohup /hive/miners/custom/nosana/monitor.sh start >>"$NOSANA_LOG" 2>&1 & disown || true
fi

echo "[nosana] monitor started"
