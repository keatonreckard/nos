#!/usr/bin/env bash
set -euo pipefail
install -m 755 /hive/miners/custom/nosana/h-stats-wrapper.sh /hive/bin/custom-stats
echo "[nosana] custom-stats installed"
