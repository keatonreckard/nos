#!/usr/bin/env bash
# Placeholder that documents how the idle miner is launched in your env.
# The actual binary/args are configured elsewhere. We only ensure logs exist.
set -euo pipefail
source /hive/miners/custom/nosana/h-config.sh
touch "$IDLE_LOG"
echo "[idle-run] invoked at $(date)" >> "$NOSANA_LOG"
