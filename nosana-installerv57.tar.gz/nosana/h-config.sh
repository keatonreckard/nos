#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
LOG_DIR="/var/log/miner/nosana"
STATE_FILE="$RUN_DIR/nosana.state"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR"
touch "$NOSANA_LOG" "$IDLE_LOG" "$STATE_FILE"
chmod 664 "$NOSANA_LOG" "$IDLE_LOG" || true
# Keep state file readable/writable
chmod 664 "$STATE_FILE" || true

# Export for children
export MINER_DIR RUN_DIR LOG_DIR STATE_FILE NOSANA_LOG IDLE_LOG
