#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
source /hive/miners/custom/nosana/h-config.sh

PIDFILE="$RUN_DIR/nosana.idle-bridge.pid"

start_tail() {
  # avoid duplicates
  if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    exit 0
  fi
  # Follow IDLE_LOG and prefix, append to miner log
  ( exec bash -c 'tail -n0 -F "$IDLE_LOG" 2>/dev/null | sed -u "s/^/[idle] /" >> "$NOSANA_LOG"' ) &
  echo $! > "$PIDFILE"
}

case "${1:-start}" in
  start) start_tail ;;
  stop)
    if [[ -f "$PIDFILE" ]]; then
      kill "$(cat "$PIDFILE")" 2>/dev/null || true
      rm -f "$PIDFILE"
    fi
    ;;
  *) echo "Usage: $0 {start|stop}" ; exit 1 ;;
esac
