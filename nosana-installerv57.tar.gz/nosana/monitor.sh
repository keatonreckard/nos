#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
source /hive/miners/custom/nosana/h-config.sh

cmd="${1:-start}"

case "$cmd" in
  start)
    # ensure idle bridge running (single instance)
    /hive/miners/custom/nosana/idle-bridge.sh start || true

    # lightweight tailer to update state (status/queue/balances/wallet) without 'msg'
    (
      shopt -s pipefail
      tail -n0 -F "$NOSANA_LOG" 2>/dev/null | while IFS= read -r line; do
        # queue position
        if [[ "$line" =~ position[[:space:]]+([0-9]+)/([0-9]+) ]]; then
          a="${BASH_REMATCH[1]}"; b="${BASH_REMATCH[2]}"
          awk -v s="queued" -v q="$a/$b" 'BEGIN{printf("status=%q\nqueue=%q\n",s,q)}' >> "$STATE_FILE".tmp
          cat "$STATE_FILE".tmp >> "$STATE_FILE" && rm -f "$STATE_FILE".tmp || true
        fi
        if [[ "$line" =~ \[nosana\][[:space:]]+queued[[:space:]]+([0-9]+)/([0-9]+) ]]; then
          a="${BASH_REMATCH[1]}"; b="${BASH_REMATCH[2]}"
          awk -v s="queued" -v q="$a/$b" 'BEGIN{printf("status=%q\nqueue=%q\n",s,q)}' >> "$STATE_FILE".tmp
          cat "$STATE_FILE".tmp >> "$STATE_FILE" && rm -f "$STATE_FILE".tmp || true
        fi
        # initializing signal
        if [[ "$line" =~ Installing[[:space:]]@nosana/cli|Starting\ Nosana\ CLI|Node\ api\ \(https\ \&\ ws\)\ running ]]; then
          awk -v s="initializing" 'BEGIN{printf("status=%q\n",s)}' >> "$STATE_FILE".tmp
          cat "$STATE_FILE".tmp >> "$STATE_FILE" && rm -f "$STATE_FILE".tmp || true
        fi
        # crude job detection
        if [[ "$line" =~ "Running health check" ]]; then
          : # ignore
        fi
        if [[ "$line" =~ "starting\ container"|"Starting job"|"Executing flow"|"Job ".*" started" ]]; then
          awk -v s="job" 'BEGIN{printf("status=%q\n",s)}' >> "$STATE_FILE".tmp
          cat "$STATE_FILE".tmp >> "$STATE_FILE" && rm -f "$STATE_FILE".tmp || true
        fi
        if [[ "$line" =~ "Nosana Node finished"|"Job ".*" completed"|"finished successfully"|"Flow ".*"(finished|completed)" ]]; then
          awk -v s="idle" 'BEGIN{printf("status=%q\n",s)}' >> "$STATE_FILE".tmp
          cat "$STATE_FILE".tmp >> "$STATE_FILE" && rm -f "$STATE_FILE".tmp || true
        fi
        # wallet & balances
        if [[ "$line" =~ Wallet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}) ]]; then
          w="${BASH_REMATCH[1]}"
          awk -v v="$w" 'BEGIN{printf("wallet=%q\n",v)}' >> "$STATE_FILE".tmp
          cat "$STATE_FILE".tmp >> "$STATE_FILE" && rm -f "$STATE_FILE".tmp || true
        fi
        if [[ "$line" =~ SOL\ balance:[[:space:]]*([0-9]+(\.[0-9]+)?) ]]; then
          s="${BASH_REMATCH[1]}"
          awk -v v="$s" 'BEGIN{printf("sol=%q\n",v)}' >> "$STATE_FILE".tmp
          cat "$STATE_FILE".tmp >> "$STATE_FILE" && rm -f "$STATE_FILE".tmp || true
        fi
        if [[ "$line" =~ NOS\ balance:[[:space:]]*([0-9]+(\.[0-9]+)?) ]]; then
          n="${BASH_REMATCH[1]}"
          awk -v v="$n" 'BEGIN{printf("nos=%q\n",v)}' >> "$STATE_FILE".tmp
          cat "$STATE_FILE".tmp >> "$STATE_FILE" && rm -f "$STATE_FILE".tmp || true
        fi
      done
    ) & disown
    ;;
  *)
    echo "Usage: $0 start"
    ;;
esac
