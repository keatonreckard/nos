#!/usr/bin/env bash
set -euo pipefail
# Attach to the idle screen session if present
exec screen -r nosana-idle
