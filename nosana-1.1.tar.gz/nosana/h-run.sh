#!/bin/bash

log=$CUSTOM_LOG_BASENAME.log
debug_log=/var/log/miner/nosana/debug.log
echo "Starting Nosana miner at $(date)" > "$log"
echo "Debug log started at $(date)" > "$debug_log"

# Check and install dependencies only if missing
echo "Checking dependencies..." | tee -a "$log" "$debug_log"
apt-get update -y >> "$debug_log" 2>&1
if ! command -v gpg >/dev/null 2>&1; then
  echo "Installing gnupg..." | tee -a "$log" "$debug_log"
  apt-get install -y gnupg >> "$debug_log" 2>&1 || { echo "Failed to install gnupg" | tee -a "$log" "$debug_log"; exit 1; }
fi
if ! command -v docker >/dev/null 2>&1; then
  echo "Installing docker.io..." | tee -a "$log" "$debug_log"
  apt-get install -y docker.io >> "$debug_log" 2>&1 || { echo "Failed to install docker.io" | tee -a "$log" "$debug_log"; exit 1; }
  usermod -aG docker root >> "$debug_log" 2>&1 || { echo "Failed to add root to docker group" | tee -a "$log" "$debug_log"; exit 1; }
  systemctl restart docker >> "$debug_log" 2>&1 || { echo "Failed to restart docker" | tee -a "$log" "$debug_log"; exit 1; }
fi
if ! command -v nvidia-ctk >/dev/null 2>&1; then
  echo "Installing NVIDIA Container Toolkit..." | tee -a "$log" "$debug_log"
  distribution=ubuntu$(lsb_release -rs)
  curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg >> "$debug_log" 2>&1 || { echo "Failed to fetch NVIDIA GPG key" | tee -a "$log" "$debug_log"; exit 1; }
  curl -s -L https://nvidia.github.io/libnvidia-container/${distribution}/libnvidia-container.list | \
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
    tee /etc/apt/sources.list.d/nvidia-container-toolkit.list >> "$debug_log" 2>&1 || { echo "Failed to configure NVIDIA repo" | tee -a "$log" "$debug_log"; exit 1; }
  apt-get update -y >> "$debug_log" 2>&1 || { echo "Failed to update apt after NVIDIA repo" | tee -a "$log" "$debug_log"; exit 1; }
  apt-get install -y nvidia-container-toolkit >> "$debug_log" 2>&1 || { echo "Failed to install NVIDIA Container Toolkit" | tee -a "$log" "$debug_log"; exit 1; }
  nvidia-ctk runtime configure --runtime=docker >> "$debug_log" 2>&1 || { echo "Failed to configure NVIDIA runtime" | tee -a "$log" "$debug_log"; exit 1; }
  systemctl restart docker >> "$debug_log" 2>&1 || { echo "Failed to restart docker after NVIDIA config" | tee -a "$log" "$debug_log"; exit 1; }
fi

# Verify Docker is running
if ! systemctl is-active --quiet docker; then
  echo "Docker service is not running" | tee -a "$log" "$debug_log"
  systemctl status docker >> "$debug_log" 2>&1
  exit 1
fi

# Read verbose flag
verbose=$(cat /hive/miners/custom/nosana/verbose.flag)
if [ "$verbose" = "true" ]; then
  OPTS="--verbose"
else
  OPTS=""
fi

# Download and verify Nosana start script
echo "Fetching Nosana start script..." | tee -a "$log" "$debug_log"
wget -qO /tmp/nosana_start.sh https://nosana.com/start.sh >> "$debug_log" 2>&1
if [ $? -ne 0 ]; then
  echo "Failed to download Nosana start script" | tee -a "$log" "$debug_log"
  exit 1
fi

# Start the Nosana node
echo "Starting Nosana node..." | tee -a "$log" "$debug_log"
bash /tmp/nosana_start.sh $OPTS >> "$log" 2>&1 &
pid=$!
echo $pid > /tmp/nosana.pid

# Start monitor in background
/hive/miners/custom/nosana/monitor.sh &

# Wait on the main process
wait $pid
