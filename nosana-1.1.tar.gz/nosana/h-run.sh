#!/bin/bash
cd /hive/miners/custom/nosana
./nosana-miner.sh $CUSTOM_USER_CONFIG
