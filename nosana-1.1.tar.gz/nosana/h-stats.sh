#!/bin/bash

algo_file=/tmp/nosana_algo
ver_file=/tmp/nosana_ver

algo=$(cat "$algo_file" 2>/dev/null || echo "nos - initializing")
ver=$(cat "$ver_file" 2>/dev/null || echo "")
uptime=$(ps -p $(cat /tmp/nosana.pid 2>/dev/null) -o etimes= 2>/dev/null | tr -d ' ' || echo 0)

# Assume NVIDIA for temps, fans, buses
temps_str=$(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader 2>/dev/null)
fans_str=$(nvidia-smi --query-gpu=fan.speed --format=csv,noheader 2>/dev/null | sed 's/ %//g')
buses_str=$(nvidia-smi --query-gpu=pci.bus_id --format=csv,noheader 2>/dev/null | awk -F: '{print strtonum("0x"$1)}')

IFS=$'\n'
temps=($temps_str)
fans=($fans_str)
buses=($buses_str)
unset IFS

hs_arr=()
for _ in "${temps[@]}"; do
  hs_arr+=("0")
done
hs_json=$(IFS=','; echo "${hs_arr[*]}")

khs=0
stats=$(jq -nc --argjson hs "[$hs_json]" --arg hs_units "khs" --argjson temp "[${temps[*]}]" --argjson fan "[${fans[*]}]" --arg uptime "$uptime" --arg ver "$ver" --arg algo "$algo" --argjson bus_numbers "[${buses[*]}]" '{hs: $hs, hs_units: $hs_units, temp: $temp, fan: $fan, uptime: $uptime|tonumber, ver: $ver, algo: $algo, bus_numbers: $bus_numbers}')
