#!/bin/bash

# Nosana miner stats for HiveOS

# Initialize variables
khs="0"
stats=""

# Get stats from /run/hive/miner.1 if available
if [ -f /run/hive/miner.1 ]; then
  # Extract and clean wallet address (first 5 characters)
  wallet_raw=$(grep -oP "Wallet:\s*\S+" /run/hive/miner.1 | head -n 1 | awk '{print $2}')
  wallet=$(echo "$wallet_raw" | sed 's/\x1B\[[0-9;]*[mK]//g; s/[\x00-\x1F]//g' | cut -c1-5 || echo "None")
  echo "Raw wallet: $wallet_raw" >> /tmp/nosana-stats-debug.log
  echo "Cleaned wallet: $wallet" >> /tmp/nosana-stats-debug.log
  # Extract and clean SOL balance
  sol_balance_raw=$(grep -oP "SOL balance:\s*\S+" /run/hive/miner.1 | head -n 1 | awk '{print $3}')
  sol_balance=$(echo "$sol_balance_raw" | sed 's/\x1B\[[0-9;]*[mK]//g; s/[\x00-\x1F]//g' | cut -d'.' -f1-6 || echo "0.0")
  echo "Raw sol_balance: $sol_balance_raw" >> /tmp/nosana-stats-debug.log
  echo "Cleaned sol_balance: $sol_balance" >> /tmp/nosana-stats-debug.log
  # Extract and clean NOS balance
  nos_balance_raw=$(grep -oP "NOS balance:\s*\S+" /run/hive/miner.1 | head -n 1 | awk '{print $3}')
  nos_balance=$(echo "$nos_balance_raw" | sed 's/\x1B\[[0-9;]*[mK]//g; s/[\x00-\x1F]//g' | cut -d'.' -f1-6 || echo "0.0")
  echo "Raw nos_balance: $nos_balance_raw" >> /tmp/nosana-stats-debug.log
  echo "Cleaned nos_balance: $nos_balance" >> /tmp/nosana-stats-debug.log
  # Extract queue position
  queue_position_raw=$(grep -oP "QUEUED.*at position \K[0-9]+/[0-9]+" /run/hive/miner.1 | head -n 1)
  queue_position=$(echo "$queue_position_raw" | sed 's/\x1B\[[0-9;]*[mK]//g; s/[\x00-\x1F]//g' || echo "0/0")
  echo "Raw queue_position: $queue_position_raw" >> /tmp/nosana-stats-debug.log
  echo "Cleaned queue_position: $queue_position" >> /tmp/nosana-stats-debug.log
  [ "$queue_position" != "null" ] && [[ "$queue_position" =~ [0-9]+/[0-9]+ ]] && khs="$queue_position" || khs="0"
  # Check for job running (simplified detection)
  if grep -q "Node has found job" /run/hive/miner.1; then
    algo_status="nosana - job running"
  else
    algo_status="nosana - queued $queue_position"
  fi
else
  wallet="None"
  sol_balance="0.0"
  nos_balance="0.0"
  queue_position="0/0"
  khs="0"
  algo_status="nosana - queued 0/0"
fi

# Default values
[ -z "$wallet" ] && wallet="None"
[ -z "$sol_balance" ] && sol_balance="0.0"
[ -z "$nos_balance" ] && nos_balance="0.0"

# Gather system GPU stats using nvidia-smi (if available)
temp=()
fan=()
bus_numbers=()
if command -v nvidia-smi >/dev/null 2>&1; then
  mapfile -t temp < <(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader 2>/dev/null)
  [ ${#temp[@]} -eq 0 ] && temp=([0]) || temp=("[${temp[*]}]")
  mapfile -t fan < <(nvidia-smi --query-gpu=fan.speed --format=csv,noheader 2>/dev/null | sed 's/ %//g')
  [ ${#fan[@]} -eq 0 ] && fan=([0]) || fan=("[${fan[*]}]")
  mapfile -t bus_ids < <(nvidia-smi --query-gpu=pci.bus_id --format=csv,noheader 2>/dev/null | cut -d':' -f2 | cut -d'.' -f1)
  [ ${#bus_ids[@]} -eq 0 ] && bus_numbers=([0]) || bus_numbers=("[${bus_ids[*]}]")
fi

# Use default array if nvidia-smi fails or no data
[ ${#temp[@]} -eq 0 ] && temp=([0])
[ ${#fan[@]} -eq 0 ] && fan=([0])
[ ${#bus_numbers[@]} -eq 0 ] && bus_numbers=([0])

# Construct JSON stats with explicit array formatting, escaping special characters
ver="v1.0, W:$wallet, Sol:$sol_balance, Nos:$nos_balance"
ver=$(echo "$ver" | sed 's/\x1B\[[0-9;]*[mK]//g; s/[\x00-\x1F]/ /g')
stats=$(cat <<EOF
{
  "hs": ["$khs"],
  "hs_units": "hs",
  "temp": ${temp[*]},
  "fan": ${fan[*]},
  "uptime": 0,
  "ver": "$ver",
  "algo": "$algo_status",
  "bus_numbers": ${bus_numbers[*]}
}
EOF
)

# Output for debugging (included in agent scope)
echo "khs=$khs"
echo "stats=$stats"
