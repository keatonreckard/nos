#!/bin/bash

# Nosana Miner Wrapper for HiveOS - Full Setup for Virgin Ubuntu Machine

# Logging functions
log_std() { printf "\033[1;36m==> \033[1;38;5;231m%s\033[0m\n" "$1"; }
log_err() { printf "\033[1;91m==> \033[1;38;5;231m%s\033[0m\n" "$1"; }

# Default values
VERBOSE=false
PRE_RELEASE=""
DOCKER_IMAGE="nosana/nosana-cli:latest"
PODMAN_IMAGE="nosana/podman:v1.1.0"
LOG_FILE="/run/hive/miner.1"
NOSANA_HOME="/root/.nosana"
CONF_FILE="/hive/miners/custom/nosana/config.json"
RUNNING_FLAG="/tmp/nosana-running.lock"

# Parse command-line parameters, ignoring --network
while [ $# -gt 0 ]; do
  case "$1" in
    --verbose) VERBOSE=true ;;
    --pre-release) PRE_RELEASE="next" ;;
    --network=*) log_err "Ignoring --network argument to prevent override" ;;
    *) log_err "Unknown parameter: $1" ;;
  esac
  shift
done

# Log environment for debugging
log_std "Using NOSANA_HOME: $NOSANA_HOME"
log_std "Using network: mainnet (hardcoded)"
current_user=${USER:-$(whoami)}
echo "USER=$current_user" > /tmp/nosana-env-debug.log
echo "HOME=$HOME" >> /tmp/nosana-env-debug.log
echo "Command-line args: $@" >> /tmp/nosana-env-debug.log
echo "Execution instance: $RANDOM" >> /tmp/nosana-env-debug.log

# Check and handle existing instances
if [ -f "$RUNNING_FLAG" ]; then
  if ps -p $(cat "$RUNNING_FLAG" 2>/dev/null) > /dev/null 2>&1; then
    log_std "Existing instance detected, killing old containers..."
    docker rm -f podman nosana-node >/dev/null 2>&1
    rm -f "$RUNNING_FLAG"
    log_std "Old containers stopped, proceeding with new instance."
  else
    log_std "Stale lock file detected, removing it."
    rm -f "$RUNNING_FLAG"
  fi
fi
echo $$ > "$RUNNING_FLAG"  # Store PID in lock file
echo "Lock file created with PID: $$" >> /tmp/nosana-env-debug.log

# Trap to clean up lock file on script termination
trap 'rm -f "$RUNNING_FLAG"; echo "Lock file removed on exit" >> /tmp/nosana-env-debug.log' EXIT

# Check Ubuntu version
if ! lsb_release -a 2>/dev/null | grep -q "Ubuntu 20.04\|Ubuntu 22.04\|Ubuntu 24.04"; then
  log_err "This script requires Ubuntu 20.04, 22.04, or 24.04. Please update your system."
  exit 1
fi
log_std "✅ Ubuntu version is compatible."

# Install basic tools
log_std "Installing basic tools..."
apt update && apt install -y curl wget gnupg lsb-release

# Install Docker
log_std "Installing Docker..."
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com -o get-docker.sh
  sh get-docker.sh
  usermod -aG docker "$current_user"
  sleep 2
  if ! groups "$current_user" | grep -q docker; then
    log_err "Failed to add $current_user to docker group."
    exit 1
  fi
  systemctl enable docker
  systemctl start docker
fi
log_std "✅ Docker installed and configured."

# Install NVIDIA drivers
log_std "Installing NVIDIA drivers..."
if ! command -v nvidia-smi >/dev/null 2>&1; then
  ubuntu_version=$(lsb_release -rs)
  wget https://us.download.nvidia.com/XFree86/Linux-x86_64/$(curl -s https://www.nvidia.com/Download/API/lastestdriver.aspx | grep -oP 'version=\K[\d\.]+' | head -n 1)/NVIDIA-Linux-x86_64-$(curl -s https://www.nvidia.com/Download/API/lastestdriver.aspx | grep -oP 'version=\K[\d\.]+' | head -n 1).run -O NVIDIA.run
  chmod +x NVIDIA.run
  ./NVIDIA.run --silent --no-questions
  if [ $? -ne 0 ]; then
    log_err "NVIDIA driver installation failed. Check logs."
    exit 1
  fi
  if ! command -v nvidia-smi >/dev/null 2>&1; then
    log_err "NVIDIA driver installation verification failed."
    exit 1
  fi
fi
log_std "✅ NVIDIA drivers installed."

# Install NVIDIA Container Toolkit
log_std "Installing NVIDIA Container Toolkit..."
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg \
  && curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
    sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list \
  && \
    sudo apt-get update
sudo apt-get install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker
log_std "✅ NVIDIA Container Toolkit installed and configured."

# Create Docker volumes for Podman
if ! docker volume ls | grep -q podman-cache; then
  docker volume create podman-cache >/dev/null 2>&1
fi
if ! docker volume ls | grep -q podman-socket; then
  docker volume create podman-socket >/dev/null 2>&1
fi

# Stop and remove existing containers
log_std "Stopping any existing containers..."
docker rm -f podman nosana-node >/dev/null 2>&1

# Start Podman container
log_std "🔥 Starting podman..."
docker run -d \
  --pull=always \
  --gpus=all \
  --name podman \
  --device /dev/fuse \
  --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman \
  --privileged \
  -e ENABLE_GPU=true \
  "$PODMAN_IMAGE" unix:/podman/podman.sock >/tmp/podman-start.log 2>&1
if [ $? -eq 0 ]; then
  log_std "Podman started successfully."
else
  log_err "Failed to start Podman. Check logs:"
  cat /tmp/podman-start.log
  exit 1
fi
sleep 5

# Register and run Nosana Grid
log_std "🔥 Registering and starting Nosana Grid..."
bash <(wget -qO- https://nosana.com/start.sh) >> "$LOG_FILE" 2>&1
if [ $? -ne 0 ]; then
  log_err "Nosana Grid registration failed. Check $LOG_FILE."
  exit 1
fi
log_std "✅ Nosana Grid registration completed."

# Test Nosana node interactively once
log_std "🔥 Testing Nosana node interactively..."
DOCKER_ARGS=(--rm --network host --volume "$NOSANA_HOME:/root/.nosana" --volume podman-socket:/root/.nosana/podman:ro -e CLI_VERSION="$PRE_RELEASE")
NOSANA_ARGS=(node start --network mainnet)
[ "$VERBOSE" = true ] && NOSANA_ARGS+=(--log trace) && log_std "🔥 Testing with verbose logging..."

docker run "${DOCKER_ARGS[@]}" "$DOCKER_IMAGE" "${NOSANA_ARGS[@]}" > >(tee -a "$LOG_FILE" /tmp/nosana-test.log) 2> >(tee -a "$LOG_FILE" /tmp/nosana-test.log >&2)
EXIT_CODE=$?
if [ $EXIT_CODE -ne 0 ]; then
  log_err "Interactive test failed. Exit code: $EXIT_CODE. Check /tmp/nosana-test.log and $LOG_FILE"
  cat /tmp/nosana-test.log
  exit 1
fi
log_std "Interactive test passed. Starting Nosana node in detached mode..."

# Start Nosana node in detached mode once
log_std "🔥 Starting Nosana node..."
DOCKER_ARGS=(--pull=always --name nosana-node --network host --volume "$NOSANA_HOME:/root/.nosana" --volume podman-socket:/root/.nosana/podman:ro -e CLI_VERSION="$PRE_RELEASE")
NOSANA_ARGS=(node start --network mainnet)
[ "$VERBOSE" = true ] && NOSANA_ARGS+=(--log trace) && log_std "🔥 Starting Nosana node with verbose logging..."

docker run -d "${DOCKER_ARGS[@]}" "$DOCKER_IMAGE" "${NOSANA_ARGS[@]}" > /tmp/nosana-start.log 2>&1
EXIT_CODE=$?
if [ $EXIT_CODE -eq 0 ]; then
  log_std "Nosana node started successfully."
  for i in {1..10}; do
    sleep 0.2
    docker logs nosana-node 2>/dev/null | sed 's/\x1B\[[0-9;]*[a-zA-Z]//g' >> "$LOG_FILE"
  done
else
  log_err "Failed to start Nosana node. Exit code: $EXIT_CODE"
  cat /tmp/nosana-start.log
  docker logs nosana-node 2>/dev/null | sed 's/\x1B\[[0-9;]*[a-zA-Z]//g' >> "$LOG_FILE"
  exit 1
fi

# Keep script running
wait
