#!/usr/bin/env bash
# nosana h-stats.sh — v5.0.11
# - Job running: default hs:[1]
# - Queued: use idle kH/s if available; otherwise use queue position (X/Y -> X)
# - Never output slashes in hashrate; no zeros for hs if avoidable
# - ver string includes S:<sol> N:<nos> W:<first5> when available
# - ar is always numeric [A,R]
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"

mkdir -p "$LOG_DIR"
touch "$LOG_DIR/debug.log"

# Read persisted state (wallet/queue/etc) if any
status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

# Helper: strip ANSI
strip_ansi() { sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g'; }

# Collect recent logs
L=""
if [[ -s "$NOSANA_LOG" ]]; then
  L="$(tail -n 3000 "$NOSANA_LOG" | tr -d '\r' | strip_ansi)"
fi
if [[ -z "$L" ]]; then
  # Fallback to container logs if present
  C="$(docker logs --since 10m nosana-node 2>/dev/null || true)"
  [[ -n "$C" ]] && L="$(printf "%s" "$C" | tr -d '\r' | strip_ansi)"
fi

# Extract wallet/SOL/NOS from logs if not already in state
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$L" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
fi
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$L" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
fi

if [[ -z "${sol:-}" ]]; then
  sol="$(printf "%s\n" "$L" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
if [[ -z "${nos:-}" ]]; then
  nos="$(printf "%s\n" "$L" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi

# Determine status and queue from logs
if printf "%s\n" "$L" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
  status="nos - job"; queue=""
else
  pos="$(printf "%s\n" "$L" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
  if [[ -n "${pos:-}" ]]; then
    status="nos - queued ${pos}"; queue="${pos}"
  elif printf "%s\n" "$L" | grep -Eqi 'QUEUED'; then
    status="nos - queued"
  fi
fi

# Uptime heuristic: prefer job/idle timestamps, else rig uptime
now=$(date +%s || echo 0)
if [[ -f "$MINER_DIR/job.start.time" ]]; then start_time=$(cat "$MINER_DIR/job.start.time")
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then start_time=$(cat "$MINER_DIR/idle.start.time")
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then start_time=$(cat "$MINER_DIR/nosana.start.time")
else read -r up _ < /proc/uptime; start_time=$(( now - ${up%.*} )); fi
uptime=$((now - start_time)); ((uptime<0)) && uptime=0

# Parse idle miner hashrate from idle.log
parse_idle_stats() {
  [[ -s "$IDLE_LOG" ]] || { echo "0|0|0"; return; }
  local L2 hs_val hs_unit khs="0" acc="0" rej="0"
  L2="$(tail -n 600 "$IDLE_LOG")"

  # Try patterns: "<num> it/s", "<num> KH/s", "<num> MH/s", etc
  local line="$(echo "$L2" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(it|kh|mh|gh)/s' | tail -n1)"
  hs_val="$(printf "%s\n" "$line" | sed -nE 's/^([0-9]+(\.[0-9]+)?).*/\1/p')"
  hs_unit="$(printf "%s\n" "$line" | sed -nE 's/^[0-9]+(\.[0-9]+)?[[:space:]]*([A-Za-z]+).*/\2/p' | tr '[:lower:]' '[:upper:]')"

  if [[ -n "${hs_val:-}" && -n "${hs_unit:-}" ]]; then
    case "$hs_unit" in
      IT) khs="$hs_val" ;;                         # treat it/s as kH/s surrogate
      KH) khs="$hs_val" ;;
      MH) khs="$(awk -v v="$hs_val" 'BEGIN{printf("%.0f", v*1000)}')" ;;
      GH) khs="$(awk -v v="$hs_val" 'BEGIN{printf("%.0f", v*1000*1000)}')" ;;
      *)  khs="$hs_val" ;;
    esac
  fi

  # Shares (best-effort)
  if echo "$L2" | grep -Eiq '([0-9]+/[0-9]+|A:[0-9]+)'; then
    if echo "$L2" | grep -Eio '([0-9]+)\/([0-9]+)'; then
      acc=$(echo "$L2" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f1)
      rej=$(echo "$L2" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f2)
    else
      acc=$(echo "$L2" | grep -Eio 'A:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)
      rej=$(echo "$L2" | grep -Eio 'R:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)
    fi
  fi
  echo "${khs:-0}|${acc:-0}|${rej:-0}"
}

# Decide hashrate
algo="${status:-nos}"
khs="0"; ar_acc="0"; ar_rej="0"

# Pull idle metrics if queued
if echo "$algo" | grep -qi 'queued'; then
  IFS='|' read -r khs ar_acc ar_rej <<<"$(parse_idle_stats)"
  # If idle provided nothing or 0, try the queue position X/Y -> X
  if [[ -z "$khs" || "$khs" == "0" || "$khs" == "0.0" ]]; then
    if [[ -n "${queue:-}" ]] && echo "$queue" | grep -qE '^[0-9]+/[0-9]+$'; then
      khs="$(echo "$queue" | cut -d'/' -f1)"
      [[ -z "$khs" || "$khs" == "0" ]] && khs="1"
    else
      khs="1"
    fi
  fi
else
  # Job running but we do not report real speed here: default to 1 kH/s
  khs="1"
fi

# Ensure integers for hs, ar
khs_int="$(printf "%s" "$khs" | sed -E 's/\..*$//' )"
[[ -z "$khs_int" || "$khs_int" = "0" ]] && khs_int="1"
[[ -z "${ar_acc:-}" ]] && ar_acc="0"
[[ -z "${ar_rej:-}" ]] && ar_rej="0"

# Build version string
ver=""
if [[ -n "${sol:-}" ]]; then printf -v solf "%.4f" "$sol"; ver+="S:${solf}"; fi
if [[ -n "${nos:-}" ]]; then printf -v nosf "%.4f" "$nos"; ver+="${ver:+ }N:${nosf}"; fi
if [[ -n "${wallet:-}" ]]; then ver+="${ver:+ }W:$(printf "%s" "$wallet" | cut -c1-5)"; fi

# GPU arrays (best-effort; keep empty arrays if none)
temp_json='[]'; fan_json='[]'; bus_json='[]'
if [[ -f /hive/bin/gpu-stats ]]; then
  source /hive/bin/gpu-stats || true
  if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [[ "${#GPU_FAN[@]:-0}"  -gt 0 ]]; then  fan_json="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
  if [[ "${#BUS_IDS[@]:-0}" -gt 0 ]]; then
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

# Emit stats JSON (NO slashes in hs; numeric ar)
printf '{"hs":[%s],"hs_units":"khs","temp":%s,"fan":%s,"uptime":%s,"ver":"%s","ar":[%s,%s],"algo":"%s","bus_numbers":%s}\n'       "$khs_int" "$temp_json" "$fan_json" "$uptime" "$ver" "$ar_acc" "$ar_rej" "$algo" "$bus_json"

# Debug trace
printf "[%s] h-stats v5.0.11: algo=%s khs=%s ver=%s queue=%s\n" "$(date -Iseconds)" "$algo" "$khs_int" "$ver" "${queue:-}" >> "$LOG_DIR/debug.log" || true
