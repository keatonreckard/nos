nosana custom miner package — v5.0.11

Files:
- h-stats.sh       (755): HiveOS stats script with requested behavior
- idle-stop.sh     (755): Kills idle miner screen/processes (called on restart)
- idle-run.sh      (755): Placeholder helper to start idle miner
- VERSION          (644): 5.0.11

Key behaviors (per your requests):
- During jobs: reports hs:[1] (never 0)
- Queued: uses idle kH/s if present; else uses queue position X from X/Y
- Never prints slashes in hs; ar is always numeric [A,R]
- ver includes SOL, NOS, and Wallet prefix when available
- Safe logging to /var/log/miner/nosana

Install (on the rig):
  scp nosana-5.0.11.tar.gz <rig>:/hive/miners/custom/
  ssh <rig>
  cd /hive/miners/custom && tar -xzf nosana-5.0.11.tar.gz
  miner restart

Note: h-run.sh is NOT included to avoid disrupting your existing start logic.
      If you want me to include a run script that also invokes idle-stop.sh
      automatically on restarts, say the word and I'll bundle it.
