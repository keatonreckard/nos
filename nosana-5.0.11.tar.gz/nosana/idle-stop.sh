#!/usr/bin/env bash
set -euo pipefail
LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR"
{
  echo "[$(date -Iseconds)] idle-stop: stopping idle miner"
  # Kill screen sessions commonly used for idle
  for s in nosana-idle idle-noss idle; do
    screen -S "$s" -X quit 2>/dev/null || true
  done
  # Kill known processes
  pkill -f 'qli-Client' 2>/dev/null || true
  pkill -f 'xmrig' 2>/dev/null || true
  # Remove idle timestamp
  rm -f /hive/miners/custom/nosana/idle.start.time || true
  echo "[$(date -Iseconds)] idle-stop: done"
} >> "$LOG_DIR/debug.log" 2>&1
