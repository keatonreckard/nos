#!/usr/bin/env bash
set -euo pipefail
LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR"
echo "[$(date -Iseconds)] idle-run: starting idle (placeholder)" >> "$LOG_DIR/debug.log"
# This is a placeholder. Your environment-specific idle command can be placed here.
# Example:
# screen -dmS nosana-idle bash -lc '/hive/miners/custom/qubjetski.PPLNS/qli-Client ... >> /var/log/miner/nosana/idle.log 2>&1'
touch /hive/miners/custom/nosana/idle.start.time || true
