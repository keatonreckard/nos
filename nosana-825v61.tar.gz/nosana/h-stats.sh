#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

# ---- config ----
INIT_GRACE=45   # seconds to display "nos - initializing" after (re)start

# ---- paths ----
MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
NOSANA_LOG="/run/hive/miner.1"   # node logs
IDLE_LOG="/run/hive/miner.2"     # idle logs
IDLE_STATUS="/run/hive/miner_status.2"
START_STAMP="$MINER_DIR/nosana.start.time"
JOB_STAMP="$MINER_DIR/job.start.time"
IDLE_STAMP="$MINER_DIR/idle.start.time"

# ---- helpers ----
read_kv_state() { [[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true; }

calc_uptime() {
  local stamp="$1" now ts
  now="$(date +%s)"
  if [[ -f "$stamp" ]]; then
    ts="$(cat "$stamp" 2>/dev/null || echo "$now")"
    if [[ "$ts" =~ ^[0-9]+$ ]] && (( now >= ts )); then
      echo $(( now - ts)); return
    fi
  fi
  echo 0
}

sanitize() {
  sed -u -e 's/\r/\n/g' -E -e 's/\x1B\[[0-9;?]*[ -\/]*[@-~]//g'
}

# Parse queue position "position X/Y" from node log
queue_pos() {
  local line
  line="$(tail -n 2000 "$NOSANA_LOG" 2>/dev/null | sanitize | grep -Eo 'position[[:space:]]+[0-9]+/[0-9]+' | tail -n 1 || true)"
  if [[ "$line" =~ position[[:space:]]+([0-9]+)/([0-9]+) ]]; then
    echo "${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
  else
    echo ""
  fi
}

idle_screen_up() {
  screen -ls 2>/dev/null | grep -qE '\.nosana-idle' && return 0 || return 1
}
idle_proc_up() {
  pgrep -f -a 'qli-Client|xmrig' >/dev/null 2>&1 && return 0 || return 1
}

# Returns algo label "idle xmr"/"idle qubic"/"idle" and sets IDLE_KHS (kH/s string)
IDLE_KHS="0.00"
parse_idle_khs() {
  local block algo match its unit
  block="$(tail -n 500 "$IDLE_LOG" 2>/dev/null | sanitize)"
  # algo hint
  if grep -q '\[XMR\]' <<<"$block"; then
    algo="idle xmr"
  elif grep -qi 'qubic\|qli' <<<"$block"; then
    algo="idle qubic"
  else
    algo="idle"
  fi
  match="$(grep -Eo '([0-9]+([.][0-9]+)?)\s*(avg\s*)?(it/s|its|kH/s|KH/s|kh/s)' <<<"$block" | tail -n 1 || true)"
  if [[ -n "$match" ]]; then
    its="${match%% *}"; unit="${match##* }"
    case "$unit" in
      it/s|its) IDLE_KHS="$(awk -v n="$its" 'BEGIN{ printf "%.2f", n/1000.0 }')" ;;
      kH/s|KH/s|kh/s) IDLE_KHS="$(awk -v n="$its" 'BEGIN{ printf "%.2f", n }')" ;;
      *) IDLE_KHS="0.00" ;;
    esac
  else
    IDLE_KHS="0.00"
  fi
  # Fallback parse if still zero: be more permissive and grab the last numeric before it/s or kH/s (including "avg it/s")
  if [[ "$IDLE_KHS" == "0.00" ]]; then
    last="$(awk '
      {
        for (i=1;i<=NF;i++){
          tl=tolower($i);
          if ($i ~ /^[0-9]+(\.[0-9]+)?$/ && (i+1)<=NF && ($(i+1)=="it/s" || $(i+1)=="its")) val=$i;
          if ($i ~ /^[0-9]+(\.[0-9]+)?$/ && (i+1)<=NF && tolower($(i+1)) ~ /^k[hH]\/s$/) val_k=$i;
          if (tl=="avg" && (i+1)<=NF && ($(i+1) ~ /^(it\/s|its|k[hH]\/s)$/) && (i-1)>=1 && $(i-1) ~ /^[0-9]+(\.[0-9]+)?$/){ val_avg=$(i-1); unit_avg=$(i+1); }
        }
      }
      END{
        if (unit_avg!="") print val_avg " " unit_avg; else if (val_k!="") print val_k " kH/s"; else if (val!="") print val " it/s";
      }' <<<"$block")"
    if [[ -n "$last" ]]; then
      its="${last%% *}"; unit="${last##* }"
      case "$unit" in
        it/s|its) IDLE_KHS="$(awk -v n="$its" 'BEGIN{ printf "%.2f", n/1000.0 }')" ;;
        kH/s|KH/s|kh/s) IDLE_KHS="$(awk -v n="$its" 'BEGIN{ printf "%.2f", n }')" ;;
      esac
    fi
  fi
  echo "$algo"
}

# ---- main ----
read_kv_state
status="${status:-nos - initializing}"

# Grace window to force initializing
start_age="$(calc_uptime "$START_STAMP")"
if (( start_age < INIT_GRACE )); then
  uptime="$start_age"
  algo="nos - initializing"
  total_khs="0.00"
  hs_units="khs"
  # numbers should be numeric in JSON
  hs_json="$(jq -nc --argjson k "$(printf '%.2f' "$total_khs" | sed 's/^0*//;s/^\./0./')" '[($k)]' 2>/dev/null || echo '[0]')"
  # uptime numeric
  stats="$(jq -nc --argjson hs "${hs_json}" --arg hs_units "${hs_units}" \
      --argjson temp '[]' --argjson fan '[]' --argjson uptime "$uptime" \
      --arg ver "" --arg algo "${algo}" --argjson bus_numbers '[]' \
      '{ $hs, $hs_units, $temp, $fan, $uptime, $ver, $algo, $bus_numbers }' 2>/dev/null || echo '{"hs":[0],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"","algo":"nos - initializing","bus_numbers":[]}')"
  printf "%s\n" "${total_khs}"
  printf "%s\n" "${stats}"
  exit 0
fi

# Detect idle activity via multiple signals
idle_active=false
if grep -q '"running"' "$IDLE_STATUS" 2>/dev/null; then idle_active=true; fi
if tail -n 200 "$IDLE_LOG" 2>/dev/null | sanitize | grep -qE '([0-9]+(\.[0-9]+)?)\s*(it/s|its|kH/s|KH/s|kh/s)'; then idle_active=true; fi
if idle_screen_up; then idle_active=true; fi
if idle_proc_up; then idle_active=true; fi

# If we see a queue position in node log, treat as queued (unless job)
qpos="$(queue_pos)"
if [[ "$status" != "nos - job" && -n "$qpos" ]]; then
  status="nos - queued"
fi

algo="nos - initializing"
total_khs="0.00"
hs_units="khs"

if [[ "$status" == "nos - job" ]]; then
  uptime="$(calc_uptime "$JOB_STAMP")"
  algo="nos - job running"
  total_khs="1.00"
elif [[ "$status" == "nos - queued" ]]; then
  uptime="$(calc_uptime "$IDLE_STAMP")"
  if [[ "$idle_active" == true ]]; then
    idle_algo="$(parse_idle_khs)"
    algo="nos queued ${qpos:-?/?} - ${idle_algo}"
    total_khs="$IDLE_KHS"
    printf '{"status":"running"}\n' > "$IDLE_STATUS"
  else
    algo="nos queued ${qpos:-?/?}"
  fi
else
  uptime="$(calc_uptime "$START_STAMP")"
  algo="nos - initializing"
fi

# Build hs array (numeric)
knum="$(printf '%.2f' "$total_khs" 2>/dev/null || echo 0)"
hs_json="$(jq -nc --argjson k "${knum/./.}" '[($k)]' 2>/dev/null || echo '[0]')"

# Emit miner_stats
stats="$(jq -nc \
  --argjson hs "${hs_json}" \
  --arg hs_units "${hs_units}" \
  --argjson temp '[]' \
  --argjson fan '[]' \
  --argjson uptime "$uptime" \
  --arg ver "" \
  --arg algo "${algo}" \
  --argjson bus_numbers '[]' \
  '{ $hs, $hs_units, $temp, $fan, $uptime, $ver, $algo, $bus_numbers }' 2>/dev/null || \
  echo '{"hs":[0],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"","algo":"nos - initializing","bus_numbers":[]}')"

printf "%s\n" "${total_khs}"
printf "%s\n" "${stats}"
