#!/usr/bin/env bash

# ---- idle-when-queued watcher (robust) ----
# Safe defaults
: "${MINER_DIR:=/hive/miners/custom/nosana}"
: "${RUN_DIR:=/var/run}"
: "${LOG_DIR:=/var/log/miner/nosana}"
: "${CUSTOM_DIR:=/var/log/miner/custom}"
mkdir -p "$LOG_DIR" "$RUN_DIR" "$CUSTOM_DIR" 2>/dev/null || true
: "${NOSANA_LOG:=$LOG_DIR/nosana.log}"
: "${IDLE_LOG:=$LOG_DIR/idle.log}"
: "${CUSTOM_LOG:=$CUSTOM_DIR/custom.log}"
touch "$NOSANA_LOG" "$IDLE_LOG" "$CUSTOM_LOG"

idle_running(){ screen -ls 2>/dev/null | grep -q "\.nosana-idle"; }

start_idle(){
  if ! idle_running; then
    echo "idle-run: starting idle miner: $MINER_DIR/idle-run.sh" | tee -a "$IDLE_LOG" "$NOSANA_LOG" "$CUSTOM_LOG" >/dev/null
    if [[ -x "$MINER_DIR/idle-run.sh" ]]; then
      ( bash -lc "$MINER_DIR/idle-run.sh" ) >>"$IDLE_LOG" 2>&1 &
    fi
  fi
}

stop_idle(){
  if idle_running; then
    echo "[idle-queue] stopping idle miner" | tee -a "$IDLE_LOG" "$NOSANA_LOG" "$CUSTOM_LOG" >/dev/null
    if [[ -x "$MINER_DIR/idle-kill.sh" ]]; then
      "$MINER_DIR/idle-kill.sh" >>"$IDLE_LOG" 2>&1 || true
    else
      screen -S nosana-idle -X quit >/dev/null 2>&1 || true
    fi
  fi
}

detect_and_toggle_idle(){
  # Prefer container logs to avoid dependency on local nosana.log
  L="$(podman logs --since 5m nosana-node 2>/dev/null || docker logs --since 5m nosana-node 2>/dev/null || true)"
  if [[ -z "$L" && -s "$NOSANA_LOG" ]]; then
    L="$(tail -n 2000 "$NOSANA_LOG" | tr -d '\r')"
  fi
  [[ -z "$L" ]] && return 0

  CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"

  # Find the latest "job" and "queued" markers by line number
  job_ln=$(printf "%s\n" "$CLEAN" | awk '/Node is claiming job|Node has found job|claimed job|Job .* (started|running)|Flow .* (started|running)/ {ln=NR} END{print ln+0}')
  queue_ln=$(printf "%s\n" "$CLEAN" | awk '/(^|[[:space:]])QUEUED([[:space:]]|$)|position[[:space:]]+[0-9]+\/[0-9]+|\[nosana\][[:space:]]+queued/ {ln=NR} END{print ln+0}')

  if (( queue_ln > job_ln && queue_ln > 0 )); then
    if ! idle_running; then echo "[idle-queue] detected queued (ln=" "$queue_ln" "), starting idle" >>"$CUSTOM_LOG"; fi
    start_idle
  else
    if idle_running; then echo "[idle-queue] detected job/newer non-queue (job ln=" "$job_ln" "), stopping idle" >>"$CUSTOM_LOG"; fi
    stop_idle
  fi
}

# Launch watcher in background (single instance)
if [[ ! -f "$RUN_DIR/nosana.idlewatch.pid" ]] || ! kill -0 "$(cat "$RUN_DIR/nosana.idlewatch.pid" 2>/dev/null)" 2>/dev/null; then
  ( while true; do detect_and_toggle_idle; sleep 7; done ) & echo $! > "$RUN_DIR/nosana.idlewatch.pid"
fi
# ---------------------------------------------

set -uo pipefail
export LC_ALL=C
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
DEBUG_LOG="$LOG_DIR/debug.log"
MINER_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
mkdir -p "$LOG_DIR" "$RUN_DIR"; touch "$MINER_LOG" "$DEBUG_LOG" "$IDLE_LOG"

IDLE_COMMAND="$(cat "$MINER_DIR/parsed/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$MINER_DIR/parsed/idle_args" 2>/dev/null || true)"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

set_state() {
  local key="$1" val="$2"
  local vesc="${val//\\/\\\\}"; vesc="${vesc//\"/\\\"}"
  mkdir -p "$(dirname "$STATE_FILE")"; touch "$STATE_FILE"
  awk -v k="$key" -v v="$vesc" '
    BEGIN{done=0}
    $0 ~ ("^"k"=") { print k"=\""v"\""; done=1; next }
    { print }
    END{ if(!done) print k"=\""v"\"" }
  ' "$STATE_FILE" > "$STATE_FILE.tmp" && mv "$STATE_FILE.tmp" "$STATE_FILE"
}

date +%s > "$MINER_DIR/nosana.start.time"
set_state status "nos - initializing"
echo "[nosana] monitor started" | tee -a "$MINER_LOG"; msg "NOS: monitor started"

bootstrap() {
  local bootlog
  bootlog="$(docker logs --since 60m nosana-node 2>&1 || true)"
  [[ -n "$bootlog" ]] && printf "%s\n" "$bootlog" | tee -a "$MINER_LOG"
  if printf '%s\n' "$bootlog" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
    set_state status "nos - queued"; msg "NOS: queued"
    date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
  elif printf '%s\n' "$bootlog" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
    set_state status "nos - job"; msg "NOS: job"; date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
  fi
}
bootstrap

last_pos=""
while true; do
  logchunk="$(docker logs --since 10s nosana-node 2>&1 || true)"
  if [[ -n "$logchunk" ]]; then
    printf "%s\n" "$logchunk" | tee -a "$MINER_LOG"
    if echo "$logchunk" | grep -Eq "position [0-9]+/[0-9]+"; then
      pos="$(echo "$logchunk" | grep -E 'position [0-9]+/[0-9]+' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/')"
      [[ -n "$pos" && "$pos" != "$last_pos" ]] && { echo "[nosana] queued ${pos}" | tee -a "$MINER_LOG"; msg "NOS: queued ${pos}"; last_pos="$pos"; }
      set_state status "nos - queued ${pos}"; date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
    fi
    if echo "$logchunk" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
      set_state status "nos - job"; date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"; msg "NOS: job started"
    fi
    if echo "$logchunk" | grep -Eq "Nosana Node finished|Job .* completed|finished successfully|Flow .* (finished|completed)"; then
      echo "[nosana] job finished" | tee -a "$MINER_LOG"; msg "NOS: job finished"
    fi
  fi
  sleep 5
done
