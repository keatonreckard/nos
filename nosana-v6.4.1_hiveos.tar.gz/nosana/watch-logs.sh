#!/usr/bin/env bash
set -euo pipefail
LOG_DIR="/var/log/miner/nosana"
CUSTOM_DIR="/var/log/miner/custom"
OUT="$CUSTOM_DIR/custom.log"
NOS="$LOG_DIR/nosana.log"
IDL="$LOG_DIR/idle.log"
mkdir -p "$LOG_DIR" "$CUSTOM_DIR"
touch "$NOS" "$IDL" "$OUT"
stdbuf -oL tail -F -n 0 "$NOS" | sed -u 's/^/[NOS] /' >> "$OUT" & echo $! > /var/run/nosana.watch.tail1.pid
stdbuf -oL tail -F -n 0 "$IDL" | sed -u 's/^/[IDLE] /' >> "$OUT" & echo $! > /var/run/nosana.watch.tail2.pid
wait
