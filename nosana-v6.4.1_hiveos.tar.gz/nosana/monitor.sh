#!/usr/bin/env bash
set -euo pipefail

# Safe defaults & dirs
: "${MINER_DIR:=/hive/miners/custom/nosana}"
: "${RUN_DIR:=/var/run}"
: "${LOG_DIR:=/var/log/miner/nosana}"
: "${CUSTOM_DIR:=/var/log/miner/custom}"
mkdir -p "$LOG_DIR" "$RUN_DIR" "$CUSTOM_DIR" 2>/dev/null || true

# Logs (must exist even under set -u)
: "${NOSANA_LOG:=$LOG_DIR/nosana.log}"
: "${IDLE_LOG:=$LOG_DIR/idle.log}"
: "${CUSTOM_LOG:=$CUSTOM_DIR/custom.log}"
touch "$NOSANA_LOG" "$IDLE_LOG" "$CUSTOM_LOG"

# Helpers
msg(){ [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || echo "$1"; }
idle_running(){ screen -ls 2>/dev/null | grep -q "\.nosana-idle"; }
start_watch(){
  if [[ ! -f "$RUN_DIR/nosana.watch.pid" ]] || ! kill -0 "$(cat "$RUN_DIR/nosana.watch.pid" 2>/dev/null)" 2>/dev/null; then
    nohup "$MINER_DIR/watch-logs.sh" >/dev/null 2>&1 &
    echo $! > "$RUN_DIR/nosana.watch.pid"
  fi
}
start_idle(){
  if ! idle_running; then
    local cmd="$MINER_DIR/idle-run.sh"
    echo "idle-run: starting idle miner: $cmd" | tee -a "$IDLE_LOG" "$NOSANA_LOG" "$CUSTOM_LOG" >/dev/null
    msg "[IDLE] starting"
    if [[ -x "$cmd" ]]; then
      ( "$cmd" 2>&1 | tee -a "$IDLE_LOG" "$NOSANA_LOG" "$CUSTOM_LOG" >/dev/null ) &
    fi
  fi
}
stop_idle(){
  if idle_running; then
    msg "[IDLE] stopping"
    if [[ -x "$MINER_DIR/idle-kill.sh" ]]; then
      "$MINER_DIR/idle-kill.sh" >>"$IDLE_LOG" 2>&1 || true
    else
      screen -S nosana-idle -X quit >/dev/null 2>&1 || true
    fi
  fi
}

# Main loop
while true; do
  start_watch
  # Read recent node logs (strip ANSI)
  L=""
  [[ -s "$NOSANA_LOG" ]] && L="$(tail -n 3000 "$NOSANA_LOG" | tr -d '\r')"
  if [[ -z "$L" ]]; then
    C="$(podman logs --since 10m nosana-node 2>/dev/null || docker logs --since 10m nosana-node 2>/dev/null || true)"
    [[ -n "$C" ]] && L="$(printf "%s" "$C" | tr -d '\r')"
  fi
  CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"

  # Latest-line logic
  job_ln=$(printf "%s\n" "$CLEAN" | awk '/Node is claiming job|Node has found job|claimed job|Job .* (started|running)|Flow .* (started|running)/ {ln=NR} END{print ln+0}')
  queue_ln=$(printf "%s\n" "$CLEAN" | awk '/position[[:space:]]+[0-9]+\/[0-9]+|QUEUED/ {ln=NR} END{print ln+0}')

  if (( queue_ln > job_ln && queue_ln > 0 )); then
    start_idle
  else
    stop_idle
  fi

  sleep 5
done
