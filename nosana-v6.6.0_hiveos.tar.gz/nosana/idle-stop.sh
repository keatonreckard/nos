\
    #!/usr/bin/env bash
    set -euo pipefail
    LOG_DIR="/var/log/miner/nosana"
    echo "[idle-stop] $(date -Iseconds) requested stop" >> "$LOG_DIR/agent.log"
    if command -v screen >/dev/null 2>&1; then
      screen -ls | awk '/\t[0-9]+\.(idle|idle-run|qli|qubic)/{print $1}' | while read -r sid; do
        screen -S "$sid" -X quit || true
      done
    fi
    pkill -f 'qli-Client'    >/dev/null 2>&1 || true
    pkill -f 'qubic.li'      >/dev/null 2>&1 || true
    pkill -f 'pplns.*jetski' >/dev/null 2>&1 || true
    exit 0
