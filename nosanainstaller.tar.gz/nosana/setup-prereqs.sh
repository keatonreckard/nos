#!/usr/bin/env bash
set -euo pipefail

LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR"
log(){ echo "[$(date -Iseconds)] $*" | tee -a "$LOG_DIR/debug.log"; }

# 1) Docker via user's HiveOS-friendly script
if ! command -v docker >/dev/null 2>&1; then
  log "Docker not found. Installing via HiveOS docker script..."
  if [[ -x "./install_docker_slave.sh" ]]; then
    bash ./install_docker_slave.sh | tee -a "$LOG_DIR/debug.log"
  else
    wget -qO ./install_docker_slave.sh "https://github.com/filthz/fact-worker-public/releases/download/base_files/install_docker_slave.sh"
    chmod 0755 ./install_docker_slave.sh
    bash ./install_docker_slave.sh | tee -a "$LOG_DIR/debug.log"
  fi
else
  log "Docker already present."
fi

# Ensure docker service is up
if ! systemctl is-active --quiet docker; then
  log "Starting docker service..."
  systemctl start docker || true
fi

# 2) NVIDIA Container Toolkit (per Nosana docs)
if ! command -v nvidia-ctk >/dev/null 2>&1; then
  log "Installing NVIDIA Container Toolkit..."
  set +e
  curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
  curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
    sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list >/dev/null
  sudo apt-get update -y
  sudo apt-get install -y nvidia-container-toolkit
  set -e
else
  log "nvidia-ctk already installed."
fi

log "Configuring docker runtime for NVIDIA..."
sudo nvidia-ctk runtime configure --runtime=docker || true
sudo systemctl restart docker || true

# Non-fatal sanity check
if docker run --rm --gpus all nvidia/cuda:11.0.3-base-ubuntu18.04 nvidia-smi >/dev/null 2>&1; then
  log "NVIDIA toolkit OK inside container."
else
  log "WARNING: nvidia-smi check in container failed (continuing)."
fi

exit 0
