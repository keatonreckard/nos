#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
DEBUG_LOG="$LOG_DIR/debug.log"
MINER_LOG="$LOG_DIR/nosana.log"

IDLE_PID_FILE="$RUN_DIR/nosana_idle.pid"
LOCK_FILE="$RUN_DIR/nosana_monitor.lock"

IDLE_COMMAND="$(cat "$MINER_DIR/parsed/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$MINER_DIR/parsed/idle_args" 2>/dev/null || true)"

[[ -f "$LOCK_FILE" ]] && { echo "[$(date -Iseconds)] monitor: lock exists, exiting" >> "$DEBUG_LOG"; exit 0; }
echo $$ > "$LOCK_FILE"
trap 'rm -f "$LOCK_FILE"' EXIT

# Safe setter: write key="value" (quoted) to avoid 'source' errors
set_state() {
  local key="$1" val="$2"
  local esc
  esc=$(printf '%s' "$val" | sed -e 's/[\\/&]/\\&/g' -e 's/"/\\"/g')
  touch "$STATE_FILE"
  if grep -q "^${key}=" "$STATE_FILE"; then
    sed -i -E "s#^(${key}=).*#\\1\"${esc}\"#g" "$STATE_FILE"
  else
    echo "${key}=\"${val}\"" >> "$STATE_FILE"
  fi
}

msg() {
  if [[ -x /hive/bin/message ]]; then
    /hive/bin/message info "$1" || true
  fi
}

start_idle() {
  [[ -z "$IDLE_COMMAND" ]] && return 0
  if [[ -f "$IDLE_PID_FILE" ]] && kill -0 "$(cat "$IDLE_PID_FILE")" 2>/dev/null; then
    return 0
  fi
  local args="${IDLE_ARGS//%WORKER_NAME%/${WORKER_NAME:-worker}}"
  echo "[$(date -Iseconds)] monitor: starting idle miner: $IDLE_COMMAND $args" >> "$DEBUG_LOG"
  date +%s > "$MINER_DIR/idle.start.time"
  rm -f "$MINER_DIR/job.start.time"
  nohup bash -lc "$IDLE_COMMAND $args" >> "$LOG_DIR/idle.log" 2>&1 &
  echo $! > "$IDLE_PID_FILE"
  msg "NOS: queued → started idle miner"
}

stop_idle() {
  if [[ -f "$IDLE_PID_FILE" ]]; then
    local pid=$(cat "$IDLE_PID_FILE")
    if kill -0 "$pid" 2>/dev/null; then
      echo "[$(date -Iseconds)] monitor: stopping idle miner pid=$pid" >> "$DEBUG_LOG"
      kill "$pid" 2>/dev/null || true
      sleep 1
      kill -9 "$pid" 2>/dev/null || true
    fi
    rm -f "$IDLE_PID_FILE"
  fi
}

bootstrap_state() {
  local SINCE="${1:-30m}"
  echo "[$(date -Iseconds)] monitor: bootstrapping state from recent logs" >> "$DEBUG_LOG"
  local bootlog
  bootlog="$(docker logs --since "$SINCE" nosana-node 2>&1 || true)"
  if [[ -z "$bootlog" ]]; then
    set_state status "nos - initializing"
    return 0
  fi
  local w sb nb
  w="$(echo "$bootlog" | grep -E '^Wallet:\s+[A-Za-z0-9]{32,48}' | tail -n1 | awk '{print $2}')"
  [[ -n "$w" ]] && set_state wallet "$w"
  sb="$(echo "$bootlog" | grep -E 'SOL balance:\s+[0-9]+\.[0-9]+' | tail -n1 | awk '{print $3}')"
  nb="$(echo "$bootlog" | grep -E 'NOS balance:\s+[0-9]+\.[0-9]+' | tail -n1 | awk '{print $3}')"
  [[ -n "$sb" ]] && set_state sol "$sb"
  [[ -n "$nb" ]] && set_state nos "$nb"

  if echo "$bootlog" | grep -Eqi 'claimed job|Job .* started|Flow .* started'; then
    set_state status "nos - job"
    set_state queue ""
    date +%s > "$MINER_DIR/job.start.time"
    rm -f "$MINER_DIR/idle.start.time"
    stop_idle
    msg "NOS: detected running job on restart"
  elif echo "$bootlog" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
    local pos
    pos="$(echo "$bootlog" | grep -E 'position [0-9]+/[0-9]+' | tail -n1 | sed -n 's/.*position \([0-9]\+\/[0-9]\+\).*/\1/p')"
    if [[ -n "$pos" ]]; then
      set_state status "nos - queued ${pos}"
      set_state queue "${pos}"
    else
      set_state status "nos - queued"
    fi
    date +%s > "$MINER_DIR/idle.start.time"
    rm -f "$MINER_DIR/job.start.time"
    start_idle
    msg "NOS: detected queued state on restart"
  else
    set_state status "nos - initializing"
  fi
}

# Stamp wrapper start time (fallback uptime)
date +%s > "$MINER_DIR/nosana.start.time"

set_state status "nos - initializing"
msg "NOS: node initializing"
bootstrap_state "45m"

: "${SINCE:=5m}"
touch "$MINER_LOG"

docker logs --since "$SINCE" -f nosana-node 2>&1 | tee -a "$MINER_LOG" | while IFS= read -r line; do
  echo "$line"
  if [[ "$line" =~ ^Wallet:\ +([A-Za-z0-9]{32,48}) ]]; then
    set_state wallet "${BASH_REMATCH[1]}"
  fi
  if [[ "$line" =~ SOL\ balance:\ +([0-9]+\.[0-9]+) ]]; then
    set_state sol "${BASH_REMATCH[1]}"
  fi
  if [[ "$line" =~ NOS\ balance:\ +([0-9]+\.[0-9]+) ]]; then
    set_state nos "${BASH_REMATCH[1]}"
  fi
  if [[ "$line" =~ \ position\ ([0-9]+)\/([0-9]+) ]]; then
    pos="${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
    set_state status "nos - queued ${pos}"
    set_state queue "${pos}"
    date +%s > "$MINER_DIR/idle.start.time"
    rm -f "$MINER_DIR/job.start.time"
    start_idle
  elif [[ "$line" =~ ^.*QUEUED.*position\ ([0-9]+)\/([0-9]+) ]]; then
    pos="${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
    set_state status "nos - queued ${pos}"
    set_state queue "${pos}"
    date +%s > "$MINER_DIR/idle.start.time"
    rm -f "$MINER_DIR/job.start.time"
    start_idle
  fi
  if echo "$line" | grep -Eqi 'claimed job|Job .* started|Flow .* started'; then
    set_state status "nos - job"
    set_state queue ""
    date +%s > "$MINER_DIR/job.start.time"
    rm -f "$MINER_DIR/idle.start.time"
    msg "NOS: job started — stopping idle miner"
    stop_idle
  fi
  if echo "$line" | grep -q "Nosana Node finished"; then
    set_state status "nos - initializing"
  fi
done
