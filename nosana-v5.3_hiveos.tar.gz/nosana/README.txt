Nosana wrapper v3.1.18: ANSI-stripped sed parsing for wallet/balances; robust algo; docker logs fallback.


v5.3 changes:
- If parsed/idle_command is missing, fall back to parsing idleSettings.command/args from nosana.conf.
- Refresh idle config every 10s so late config writes are picked up without restart.
- No changes to run flow, stats, balances, or message behavior.
