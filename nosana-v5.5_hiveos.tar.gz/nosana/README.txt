Nosana wrapper v3.1.18: ANSI-stripped sed parsing for wallet/balances; robust algo; docker logs fallback.


v5.5 changes:
- Adds a background QUEUED watcher that prints clear breadcrumbs and calls start_idle() immediately when QUEUED is seen.
- Breadcrumbs go to debug.log, nosana.log, and HiveOS dashboard.
- No changes to run flow, stats/version strings, node startup, or dashboard wording otherwise.
