#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"

# Hive live logs
MINER1="/run/hive/miner.1"   # nosana-node (CLI) logs
MINER2="/run/hive/miner.2"   # idle miner logs
MINER_STATUS1="/run/hive/miner_status.1"
MINER_STATUS2="/run/hive/miner_status.2"

mkdir -p "$RUN_DIR" "/run/hive"
touch "$MINER1" "$MINER2" "$MINER_STATUS1" "$MINER_STATUS2" "$STATE_FILE"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }
log() { echo "[$(date -Iseconds)] $*" >> "$MINER1"; }

set_state() {
  local key="$1" val="$2"
  local vesc="${val//\\/\\\\}"; vesc="${vesc//\"/\\\"}"
  awk -v k="$key" -v v="$vesc" '
    BEGIN{done=0}
    $0 ~ ("^"k"=") { print k"=""v"""; done=1; next }
    { print }
    END{ if(!done) print k"=""v""" }
  ' "$STATE_FILE" > "$STATE_FILE.tmp" && mv "$STATE_FILE.tmp" "$STATE_FILE"
}

idle_running() { screen -ls 2>/dev/null | grep -q "\.nosana-idle"; }

# Read parsed idle configs
PARSED_DIR="$MINER_DIR/parsed"
IDLE_COMMAND="$(cat "$PARSED_DIR/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$PARSED_DIR/idle_args" 2>/dev/null || true)"

start_idle() {
  if [[ -z "${IDLE_COMMAND:-}" ]]; then
    log "NOS: idle miner NOT started (no IDLE_COMMAND configured)"
    return 0
  fi
  if idle_running; then
    log "NOS: idle miner already running"
    return 0
  fi
  # Run idle miner in its own screen, log to miner.2
  screen -DmS nosana-idle -L -Logfile "${MINER2}" ${IDLE_COMMAND} ${IDLE_ARGS}
  echo '{"status":"running"}' > "${MINER_STATUS2}"
  msg "NOS: idle miner started"
  log "NOS: idle miner started (cmd: ${IDLE_COMMAND} ${IDLE_ARGS})"
}

kill_idle() {
  if idle_running; then
    screen -S nosana-idle -X quit || true
    # wait briefly for screen to exit
    for _i in 1 2 3 4 5; do
      screen -ls 2>/dev/null | grep -q "\.nosana-idle" || break
      sleep 1
    done
  fi
  if [[ -n "${IDLE_COMMAND:-}" ]]; then
    pkill -f -- "$IDLE_COMMAND" 2>/dev/null || true
  fi
  echo '{"status":"stopped"}' > "${MINER_STATUS2}"
  log "NOS: idle miner killed"
}

# Proactively kill any previous idle miner to avoid overlap
if idle_running; then
  log "NOS: found existing idle screen; terminating"
  screen -S nosana-idle -X quit || true
  for _i in 1 2 3 4 5; do
    screen -ls 2>/dev/null | grep -q "\.nosana-idle" || break
    sleep 1
  done
fi
if [[ -n "${IDLE_COMMAND:-}" ]]; then
  pkill -f -- "$IDLE_COMMAND" 2>/dev/null || true
fi
echo '{"status":"stopped"}' > "$MINER_STATUS2"
log "NOS: cleared previous idle miner (if any)"

# Clean previous containers
log "h-run: cleaning previous containers"
docker rm -f nosana-node podman >/dev/null 2>&1 || true
docker container prune -f >/dev/null 2>&1 || true

# Ensure volumes for podman-in-docker sidecar
docker volume inspect podman-cache >/dev/null 2>&1 || docker volume create podman-cache >/dev/null
docker volume inspect podman-socket >/dev/null 2>&1 || docker volume create podman-socket >/dev/null

# Start Podman sidecar
log "h-run: starting podman sidecar (container)"
docker run -d   --pull=always   --gpus=all   --name podman   --device /dev/fuse   --mount source=podman-cache,target=/var/lib/containers   --volume podman-socket:/podman   --privileged   -e ENABLE_GPU=true   nosana/podman:v1.1.0 unix:/podman/podman.sock >> "$MINER1" 2>&1 || true

# Wait until socket is created in the shared volume (max 30s)
i=0
while [ $i -lt 30 ]; do
  if docker exec podman sh -c 'test -S /podman/podman.sock' >/dev/null 2>&1; then
    log "h-run: podman socket is up"
    break
  fi
  i=$((i+1))
  sleep 1
done

# Start Nosana-Node CLI using the podman-socket volume mapped to /root/.nosana/podman
SOL_NET_ENV="${SOL_NET_ENV:=mainnet}"
log "h-run: starting nosana-node (podman provider via volume)"
msg "NOS: node starting"
docker rm -f nosana-node >/dev/null 2>&1 || true
docker run -d   --pull=always   --name nosana-node   --network host   --gpus=all   --volume /root/.nosana/:/root/.nosana/   --volume podman-socket:/root/.nosana/podman:ro   -e CLI_VERSION=   nosana/nosana-cli:latest     node start --network "${SOL_NET_ENV}" >> "$MINER1" 2>&1 || true

# Follow logs only to miner.1 (sanitize CR/ANSI/backspace)
( docker logs -f nosana-node 2>&1   | stdbuf -oL sed -u -e 's/\r/\n/g'   | stdbuf -oL sed -u -E 's/\x1B\[[0-9;?]*[ -\/]*[@-~]//g'   | stdbuf -oL sed -u 's/\x08//g'   >> "$MINER1" ) &
LOG_FOLLOW_PID=$!

sleep 2
msg "NOS: node container launched"
echo '{"status":"running"}' > "$MINER_STATUS1"

# Initialize state
date +%s > "$MINER_DIR/nosana.start.time"
set_state status "nos - initializing"
msg "NOS: monitor started"

# Bootstrap
bootlog="$(docker logs --since 60m nosana-node 2>&1 || true)"
if printf '%s\n' "$bootlog" | grep -Eqi 'Node is claiming job|claimed job|Job .* started|Flow .* started|is running'; then
  set_state status "nos - job"
  kill_idle
  date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
  msg "NOS: job"
elif printf '%s\n' "$bootlog" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
  set_state status "nos - queued"
  date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
  start_idle
  msg "NOS: queued"
fi

# Monitor loop (5s polling)
while :; do
  logchunk="$(docker logs --since 10s nosana-node 2>&1 || true)"
  if [[ -n "$logchunk" ]]; then
    if echo "$logchunk" | grep -Eqi 'Node is claiming job|claimed job|Job .* started|Flow .* started|is running'; then
      set_state status "nos - job"
      kill_idle
      date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
      msg "NOS: job started"
    elif echo "$logchunk" | grep -Eqi 'Nosana Node finished|Job .* (completed|finished)|Flow .* (finished|completed)'; then
      msg "NOS: job finished"
    fi

    if echo "$logchunk" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
      set_state status "nos - queued"
      date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
      start_idle
      echo '{"status":"running"}' > "${MINER_STATUS2}"
      msg "NOS: queued"
    fi
  fi
  # Heartbeat: reflect actual idle screen state into miner_status.2
  if idle_running; then
    echo '{"status":"running"}' > "$MINER_STATUS2"
  else
    echo '{"status":"stopped"}' > "$MINER_STATUS2"
  fi
  sleep 5
done
