#!/usr/bin/env bash
/hive/miners/custom/nosana/h-stats.sh "$@"
