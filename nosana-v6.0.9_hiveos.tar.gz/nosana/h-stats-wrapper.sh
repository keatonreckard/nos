#!/usr/bin/env bash
# HiveOS custom miner stats wrapper (fixed)
set -euo pipefail
: "${MINER_DIR:=/hive/miners/custom}"
if [[ -z "${CUSTOM_MINER:-}" ]]; then
  echo -e "${RED}\$CUSTOM_MINER is not defined${NOCOLOR}"
  exit 1
fi
if [[ ! -f "$MINER_DIR/$CUSTOM_MINER/h-stats.sh" ]]; then
  echo "${RED}$MINER_DIR/$CUSTOM_MINER/h-stats.sh is not implemented${NOCOLOR}"
  exit 1
fi
out="$("$MINER_DIR/$CUSTOM_MINER/h-stats.sh")""
echo "$out"
stats="$out"
export stats
