Nosana wrapper v3.1.17: base58 wallet parsing + docker logs fallback; algo/version stabilized.
