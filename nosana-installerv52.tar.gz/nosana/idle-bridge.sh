#!/usr/bin/env bash
# Tail idle miner log and mirror into main nosana miner log with a prefix
set +e
export LC_ALL=C

LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
MINER_LOG="$LOG_DIR/nosana.log"
PIDFILE="/var/run/nosana.idle_tail.pid"

start_tail() {
  mkdir -p "$LOG_DIR"
  # Avoid duplicates
  if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    exit 0
  fi
  # Start a background tail with prefix
  ( tail -n0 -F "$IDLE_LOG" 2>/dev/null | awk '{print "[idle-miner] " $0}' >> "$MINER_LOG" ) &
  echo $! > "$PIDFILE"
}

stop_tail() {
  if [ -f "$PIDFILE" ]; then
    kill "$(cat "$PIDFILE")" >/dev/null 2>&1 || true
    rm -f "$PIDFILE"
  fi
}

case "${1:-start}" in
  start) start_tail ;;
  stop)  stop_tail  ;;
  restart) stop_tail; start_tail ;;
  status) if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then echo "running"; else echo "stopped"; fi ;;
  *) start_tail ;;
esac
