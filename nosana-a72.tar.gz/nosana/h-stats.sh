#!/usr/bin/env bash
set -euo pipefail
ORIG="/hive/miners/custom/nosana/h-stats-orig.sh"
JOB_RUNNING(){
  docker exec podman sh -lc 'podman ps --format "{{.ImageName}}" 2>/dev/null' 2>/dev/null \
    | grep -E -q "^nosana/(nn|comfy):"
}
RAW="$("$ORIG" 2>/dev/null || true)"
if [ -z "$RAW" ]; then
  RAW='{"method":"stats","params":{"v":2,"miner":"custom","total_khs":0,"miner_stats":{"status":"running","hs":[],"hs_units":"hs","algo":"nos - initializing"}}}'
fi
if JOB_RUNNING; then
  echo "$RAW" | sed -E \
    -e 's/"algo":"[^"]*"/"algo":"nos - job"/' \
    -e 's/"total_khs":[0-9.]+/"total_khs":0/' \
    -e 's/"hs":\[[^]]*\]/"hs":[]/'
else
  printf "%s\n" "$RAW"
fi
