#!/usr/bin/env bash
set -euo pipefail

IDLE_SCREEN="nosana-idle"
KILL_PAT='qli-Client|qli-worker-AVX512|qli-worker-XMR|qli-worker-CUDA'

kill_idle() {
  screen -S "$IDLE_SCREEN" -X quit 2>/dev/null || true
  pkill -9 -f "$KILL_PAT" 2>/dev/null || true
}

msg() {
  if [ -x /hive/bin/message ]; then
    /hive/bin/message info "$1" || true
  else
    echo "$1"
  fi
}

job_event_watch() {
  # kill idle as soon as job logs appear
  ( docker logs -f nosana-node 2>/dev/null | grep -E --line-buffered 'Node has found job|Node is claiming job|Job .* is starting|Flow .* is starting|Resolving job definition|Validating job definition|Starting container ' | while read -r _line; do
      kill_idle
      msg "NOSANA: idle miner killed (job event)"
      # Only need to kill once per run; continue watching though
    done ) &
}

schedule_guard() {
  # every minute: :04 kill, :07 restart (if idle not running)
  while :; do
    m=$(date +%M)
    if [ "$m" = "04" ]; then
      kill_idle
      msg "NOSANA: idle miner killed at :04 (scheduled)"
      sleep 60
    elif [ "$m" = "07" ]; then
      # if idle not running, try restart via existing idle-run.sh
      if ! screen -ls | grep -q "$IDLE_SCREEN"; then
        if [ -x /hive/miners/custom/nosana/idle-run.sh ]; then
          /hive/miners/custom/nosana/idle-run.sh >/dev/null 2>&1 || true
          msg "NOSANA: idle miner restart attempt at :07 (scheduled)"
        fi
      fi
      sleep 60
    else
      sleep 10
    fi
  done
}

if [[ ${1:-} == "--daemon" ]]; then
  job_event_watch
  schedule_guard
else
  echo "usage: $0 --daemon"
  exit 0
fi
