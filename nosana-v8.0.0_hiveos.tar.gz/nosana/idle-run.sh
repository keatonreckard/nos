#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="${MINER_DIR:-/hive/miners/custom/nosana}"
LOG_DIR="${LOG_DIR:-/var/log/miner/nosana}"
RUN_DIR="${RUN_DIR:-/var/run}"
PARSED_DIR="${PARSED_DIR:-$MINER_DIR/parsed}"
STATE_FILE="${STATE_FILE:-$RUN_DIR/nosana.state}"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
mkdir -p "$LOG_DIR" "$PARSED_DIR"

idle_enabled=0
[[ -f "$STATE_FILE" ]] && . "$STATE_FILE" || true
if [[ "${idle_enabled:-0}" != "1" ]]; then
  echo "idle-run: idle not enabled; exiting" | tee -a "$IDLE_LOG" "$NOSANA_LOG" >/dev/null
  exit 0
fi

cmd="$(tr -d '\r' < "$PARSED_DIR/idle_command" 2>/dev/null || true)"
args="$(tr -d '\r' < "$PARSED_DIR/idle_args" 2>/dev/null || true)"
if [[ -z "${cmd// }" ]]; then
  echo "idle-run: no command configured (PARSED_DIR/idle_command empty); exiting" | tee -a "$IDLE_LOG" "$NOSANA_LOG" >/dev/null
  exit 0
fi

if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then
  echo "idle-run: nosana-idle already running; nothing to do" | tee -a "$IDLE_LOG" "$NOSANA_LOG" >/dev/null
  exit 0
fi

launcher="$MINER_DIR/.idle_exec.sh"
cat > "$launcher" <<'LAUNCH'
#!/usr/bin/env bash
set -euo pipefail
exec bash -lc "$NOSANA_IDLE_CMD $NOSANA_IDLE_ARGS"
LAUNCH
chmod 755 "$launcher"
export NOSANA_IDLE_CMD="$cmd"
export NOSANA_IDLE_ARGS="$args"

echo "idle-run: launching: $cmd $args" | tee -a "$IDLE_LOG" "$NOSANA_LOG" >/dev/null
screen -dmS nosana-idle env -i HOME="$HOME" PATH="$PATH" SHELL="/bin/bash" TERM=xterm-256color   MINER_DIR="$MINER_DIR" LOG_DIR="$LOG_DIR" "$launcher" >>"$IDLE_LOG" 2>&1 || true

exit 0
