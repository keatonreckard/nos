NOSANA (HiveOS custom miner package)
-----------------------------------
Built: 2025-08-21T15:31:38
Top-level dir: nosana

Changes in v8.0.0_hiveos:
- h-stats: report 1 kH/s while status is "nos - initializing".
- Idle mining: when logs show "queued", monitor starts a detached screen ("nosana-idle")
  using command/args from Extra Config JSON key idleSettings:
    {"idleSettings": {"command": "kawpowminer", "arguments": "-S pool:port -O wallet.worker"}}
  When a job starts, the idle session is stopped. Algo/hashrate stats unchanged.
