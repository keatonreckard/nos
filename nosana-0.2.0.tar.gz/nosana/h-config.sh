#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
CONF_FILE="$MINER_DIR/nosana.conf"
RAW_EXTRA_FILE="$MINER_DIR/extra.raw"
PARSED_DIR="$MINER_DIR/parsed"
KEY_FILE="/root/.nosana/nosana_key.json"

mkdir -p "$MINER_DIR" "$LOG_DIR" "$PARSED_DIR"
chmod 755 "$MINER_DIR"
touch "$LOG_DIR/nosana.log" "$LOG_DIR/debug.log"

: "${CUSTOM_USER_CONFIG:=}"

echo "[$(date -Iseconds)] h-config: writing nosana.conf and saving extra config" >> "$LOG_DIR/debug.log"

{
  echo -n "VERBOSE="
  echo "$CUSTOM_USER_CONFIG"
} > "$CONF_FILE"

echo "$CUSTOM_USER_CONFIG" > "$RAW_EXTRA_FILE"

KEYPAIR_JSON=""
if grep -q '"keypair"' "$RAW_EXTRA_FILE"; then
  KEYPAIR_JSON=$(sed -n 's/.*"keypair"[[:space:]]*:[[:space:]]*\(\[[^]]*\]\).*/\1/p' "$RAW_EXTRA_FILE" | head -n1)
fi

IDLE_COMMAND=""
IDLE_ARGS=""
if grep -q '"idleSettings"' "$RAW_EXTRA_FILE"; then
  IDLE_COMMAND=$(sed -n 's/.*"idleSettings".*"command"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$RAW_EXTRA_FILE" | head -n1)
  IDLE_ARGS=$(sed -n 's/.*"idleSettings".*"arguments"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$RAW_EXTRA_FILE" | head -n1)
fi

echo "$KEYPAIR_JSON" > "$PARSED_DIR/keypair.json"
echo "$IDLE_COMMAND" > "$PARSED_DIR/idle_command"
echo "$IDLE_ARGS"    > "$PARSED_DIR/idle_args"

mkdir -p /root/.nosana
chmod 700 /root/.nosana

if [[ -n "${KEYPAIR_JSON}" ]]; then
  if [[ ! -f "$KEY_FILE" ]]; then
    echo "$KEYPAIR_JSON" > "$KEY_FILE"
    chmod 600 "$KEY_FILE"
    echo "[$(date -Iseconds)] h-config: wrote new keypair to $KEY_FILE" >> "$LOG_DIR/debug.log"
  else
    echo "[$(date -Iseconds)] h-config: keypair present, key exists; leaving as-is" >> "$LOG_DIR/debug.log"
  fi
else
  echo "[$(date -Iseconds)] h-config: no keypair provided" >> "$LOG_DIR/debug.log"
fi

cat > "$STATE_FILE" <<EOF
status=nos\ -\ initializing
queue=
sol=
nos=
wallet=
idle_enabled=$( [[ -n "$IDLE_COMMAND" ]] && echo 1 || echo 0 )
EOF
chmod 664 "$STATE_FILE"

exit 0
