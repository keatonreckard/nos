nosana HiveOS wrapper
---------------------
Files:
  - h-manifest.conf
  - h-config.sh
  - h-run.sh
  - h-stats.sh
  - monitor.sh

Install:
  1) Copy/untar into /hive/miners/custom so you have /hive/miners/custom/nosana/*
  2) chmod +x /hive/miners/custom/nosana/*.sh
  3) In your Flight Sheet, set Custom miner to "nosana".
  4) Put your Extra config. It will be passed to nosana.conf as `VERBOSE=...`.
     If you include a keypair, it will initialize /root/.nosana/nosana_key.json once.
     Example snippet:
     "keypair": "[1,2,3,...]"
     "idleSettings":{"command":"/hive/miners/srbminer/2.6.9/SRBMiner-MULTI","arguments":"--algorithm verushash --pool ... --wallet WAL.%WORKER_NAME% --disable-gpu"}

Behavior:
  - Installs gpg if missing; installs Docker using the provided Hive-friendly script if missing.
  - Starts podman sidecar and nosana-node containers without -it (TTY) flags.
  - Streams docker logs to /var/log/miner/nosana/nosana.log and stdout (visible in `motd watch`).
  - Parses balances, wallet, queue position from logs to update algo string and version.
  - When queued and idleSettings exists, starts the idle miner; kills it when a job starts.
  - Container name is exactly `nosana-node`.
  - A debug log is at /var/log/miner/nosana/debug.log.
