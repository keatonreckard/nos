#!/usr/bin/env bash
set -Eeuo pipefail
# This is a very thin wrapper; actual idle process is spawned by monitor.sh
exit 0
