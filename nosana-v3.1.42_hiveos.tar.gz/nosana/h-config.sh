#!/usr/bin/env bash
set -Eeuo pipefail

DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
. "$DIR/nosana.conf"

TS(){ date +"[%Y-%m-%dT%H:%M:%S%z]"; }
DBG="$LOG_DIR/debug.log"
STATE="/var/run/nosana"
IDLE_ENV="$STATE/idle.env"
mkdir -p "$LOG_DIR" "$STATE"

parse_json_field(){ # file key -> prints value
  local file="$1" key="$2"
  # very tolerant grep/sed (no jq dependency)
  sed -nE "s/.*\"$key\"[[:space:]]*:[[:space:]]*\"([^\"]*)\".*/\1/p" "$file" | head -n1
}

src=""
for f in /run/hive/custom/extra.json /run/hive/custom.json; do
  [[ -s "$f" ]] && src="$f" && break
done

if [[ -n "$src" ]]; then
  cmd="$(parse_json_field "$src" "command")"
  args="$(parse_json_field "$src" "arguments")"
  if [[ -n "$cmd" ]]; then
    echo "$(TS) h-config: parsed idle command: $cmd" | tee -a "$DBG" >/dev/null
    echo "IDLE_CMD=\"$cmd\"" > "$IDLE_ENV"
    echo "IDLE_ARGS=\"$args\"" >> "$IDLE_ENV"
  else
    # Preserve previous env if exists
    if [[ -n "${IDLE_CMD:-}" ]]; then
      echo "IDLE_CMD=\"$IDLE_CMD\"" > "$IDLE_ENV"
      echo "IDLE_ARGS=\"${IDLE_ARGS:-}\"" >> "$IDLE_ENV"
    fi
  fi
else
  # No JSON; keep existing or env-provided values
  if [[ -n "${IDLE_CMD:-}" ]]; then
    echo "IDLE_CMD=\"$IDLE_CMD\"" > "$IDLE_ENV"
    echo "IDLE_ARGS=\"${IDLE_ARGS:-}\"" >> "$IDLE_ENV"
  fi
fi
