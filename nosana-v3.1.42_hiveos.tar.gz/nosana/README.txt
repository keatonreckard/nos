Nosana custom miner (rollback behavior to v3.1.18) for HiveOS
Version: 3.1.42 (behavior matches .18; only bugfixes)

What changed (only actual fixes):
- Default $CUSTOM_LOG_BASENAME=nosana if undefined (prevents errors)
- Podman sidecar kept as before; if its socket doesn't appear within 20s, auto-fallback to docker (no other behavior change)
- Idle miner start/stop logic restored (queued -> start idle; running -> stop idle)
- Version string parsing made robust (Wallet/SOL/NOS + queue position) without awk/sed pitfalls
- Naming scheme, paths, and screen usage unchanged

Install:
  wget -O nosana-v3.1.42_hiveos.tar.gz "sandbox:/mnt/data/nosana-v3.1.42_hiveos.tar.gz"
  miner stop && miner start

Files:
  nosana/h-manifest.conf
  nosana/nosana.conf
  nosana/h-run.sh
  nosana/monitor.sh
  nosana/h-stats.sh
  nosana/h-config.sh
  nosana/idle-screen.sh
  nosana/README.txt
