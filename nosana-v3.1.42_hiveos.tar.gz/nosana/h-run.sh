#!/usr/bin/env bash
set -Eeuo pipefail

DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
. "$DIR/nosana.conf"

TS(){ date +"[%Y-%m-%dT%H:%M:%S%z]"; }
DBG="$LOG_DIR/debug.log"
LOG_BASE="${CUSTOM_LOG_BASENAME:-nosana}"
mkdir -p "$LOG_DIR" "$NOSANA_HOME"

dlog(){ echo "$(TS) $*" | tee -a "$DBG" >/dev/null; }

clean_containers(){
  docker rm -f nos-podman nosana-node >/dev/null 2>&1 || true
}

start_podman(){
  dlog "h-run: starting podman sidecar"
  # Mount the same $NOSANA_HOME so the sock path is on host at $PODMAN_SOCK
  docker run -d --name nos-podman --restart=unless-stopped \
    -v "$NOSANA_HOME:$NOSANA_HOME" "$PODMAN_IMAGE" >/dev/null
  # Wait for the socket to appear
  for i in $(seq 1 "$IDLE_WAIT_SECS"); do
    [[ -S "$PODMAN_SOCK" ]] && { dlog "h-run: podman.sock detected at $PODMAN_SOCK"; return 0; }
    sleep 1
  done
  dlog "ERROR: podman.sock not created at $PODMAN_SOCK"
  return 1
}

start_node(){
  local prov="$1"
  dlog "h-run: starting nosana-node container (provider=$prov)"
  # Always have docker socket for docker provider jobs
  local d_sock=( -v /var/run/docker.sock:/var/run/docker.sock )
  docker run -d --name nosana-node --restart=unless-stopped \
    "${d_sock[@]}" \
    -v "$NOSANA_HOME:$NOSANA_HOME" \
    "$CLI_IMAGE" \
      nosana node run --provider "$prov" --log debug >/dev/null
}

main(){
  mkdir -p "$LOG_DIR"
  dlog "h-run: cleaning previous containers"
  clean_containers || true

  # Provider decision: keep original podman-first behavior; fallback only if needed
  local prov="podman"
  if [[ "${PROVIDER}" == "docker" ]]; then
    prov="docker"
  elif [[ "${PROVIDER}" == "podman" || "${PROVIDER}" == "auto" ]]; then
    if ! start_podman; then
      if [[ "${PROVIDER}" == "auto" ]]; then
        dlog "h-run: falling back to docker provider"
        prov="docker"
      else
        exit 1
      fi
    fi
  fi

  start_node "$prov"
}

main "$@"
