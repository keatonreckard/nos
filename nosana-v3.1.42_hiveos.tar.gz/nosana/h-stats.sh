#!/usr/bin/env bash
set -Eeuo pipefail

DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
. "$DIR/nosana.conf"

TS(){ date +"[%Y-%m-%dT%H:%M:%S%z]"; }
LOG_BASE="${CUSTOM_LOG_BASENAME:-nosana}"
DBG="$LOG_DIR/debug.log"
NOSLOG="$LOG_DIR/${LOG_BASE}.log"
mkdir -p "$LOG_DIR"
touch "$DBG" "$NOSLOG"

# Extract last-seen values in a robust way from the nosana log
last_wallet="$(tac "$NOSLOG" 2>/dev/null | grep -m1 -E 'Wallet:' | sed -nE 's/.*Wallet:[[:space:]]+([A-Za-z0-9]+).*/\1/p')"
last_sol="$(tac "$NOSLOG" 2>/dev/null | grep -m1 -E 'SOL balance:' | sed -nE 's/.*SOL balance:[[:space:]]+([0-9.]+).*/\1/p')"
last_nos="$(tac "$NOSLOG" 2>/dev/null | grep -m1 -E 'NOS balance:' | sed -nE 's/.*NOS balance:[[:space:]]+([0-9.]+).*/\1/p')"

short_wallet="${last_wallet:0:5}"
sol_disp="${last_sol:-N/A}"
nos_disp="${last_nos:-N/A}"

# Queue position (if any)
pos="$(tac "$NOSLOG" 2>/dev/null | grep -m1 -E 'position[[:space:]]+[0-9]+/[0-9]+' | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p')"

# Simple khs heuristic to match previous behavior: 999 when queued, else 0
if [[ -n "${pos}" ]]; then
  khs=999
  status="queued ${pos}"
else
  # Detect running signals
  if tac "$NOSLOG" | grep -m1 -qE 'started successfully|Running container|Flow .* is running'; then
    khs=0
    status="running"
  else
    khs=0
    status="initializing"
  fi
fi

ver_str="S:${sol_disp} N:${nos_disp} W:${short_wallet:-N/A}"
echo "$(TS) h-stats: ver=${ver_str} | algo=nos - ${status} | khs=${khs} | wallet=${last_wallet:-} | sol=${last_sol:-} | nos=${last_nos:-}" >> "$DBG"

# Output a minimal, stable JSON that Hive agent is happy to consume
# Keep it simple; do not alter naming scheme.
cat <<JSON
{
  "hs": [${khs}],
  "hs_units": "khs",
  "algo": "nos",
  "ver": "${ver_str}",
  "miner_stats": { "status": "${status}" }
}
JSON
