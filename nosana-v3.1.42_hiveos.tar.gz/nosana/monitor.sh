#!/usr/bin/env bash
set -Eeuo pipefail

DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
. "$DIR/nosana.conf"

TS(){ date +"[%Y-%m-%dT%H:%M:%S%z]"; }

LOG_BASE="${CUSTOM_LOG_BASENAME:-nosana}"
DBG="$LOG_DIR/debug.log"
NOSLOG="$LOG_DIR/${LOG_BASE}.log"
IDLELOG="$LOG_DIR/idle.log"
STATE="/var/run/nosana"
IDLE_ENV="$STATE/idle.env"
mkdir -p "$LOG_DIR" "$STATE"

dlog(){ echo "$(TS) $*" | tee -a "$DBG" >/dev/null; }

# Ensure idle config exists
"$DIR/h-config.sh" || true

idle_running(){
  pgrep -f "__NOS_IDLE_MARKER__" >/dev/null 2>&1
}

idle_start(){
  # Load parsed config
  [[ -f "$IDLE_ENV" ]] && . "$IDLE_ENV"
  local cmd="${IDLE_CMD:-$IDLE_CMD}"
  local args="${IDLE_ARGS:-$IDLE_ARGS}"
  if [[ -z "${cmd}" ]]; then
    dlog "idle: no command configured; skipping"
    return 0
  fi
  if idle_running; then
    return 0
  fi
  dlog "idle: starting -> ${cmd} ${args}"
  nohup bash -lc "exec ${cmd} ${args} # __NOS_IDLE_MARKER__" >>"$IDLELOG" 2>&1 & disown
}

idle_stop(){
  if idle_running; then
    dlog "idle: stopping"
    pkill -f "__NOS_IDLE_MARKER__" || true
  fi
}

# Kick off core runner (kept separate for readability)
"$DIR/h-run.sh" || true

dlog "[nosana] monitor started"
touch "$NOSLOG"

# Tail logs from nosana-node if present; retry if not up yet
attempts=0
while :; do
  if docker ps --format '{{.Names}}' | grep -q '^nosana-node$'; then
    # stream logs; also tee into our logfile
    docker logs -f --since 1s nosana-node 2>&1 | tee -a "$NOSLOG" | while read -r line; do
      # Lightweight parsing for status signals
      if [[ "$line" =~ "Wallet:" ]]; then
        w=$(echo "$line" | sed -nE 's/.*Wallet:[[:space:]]+([A-Za-z0-9]+).*/\1/p' | tail -n1)
        [[ -n "$w" ]] && echo "$(TS) h-stats: wallet=$w" >> "$DBG"
      fi
      if [[ "$line" =~ "SOL balance:" ]]; then
        sol=$(echo "$line" | sed -nE 's/.*SOL balance:[[:space:]]+([0-9.]+).*/\1/p' | tail -n1)
        [[ -n "$sol" ]] && echo "$(TS) h-stats: sol=$sol" >> "$DBG"
      fi
      if [[ "$line" =~ "NOS balance:" ]]; then
        nos=$(echo "$line" | sed -nE 's/.*NOS balance:[[:space:]]+([0-9.]+).*/\1/p' | tail -n1)
        [[ -n "$nos" ]] && echo "$(TS) h-stats: nos=$nos" >> "$DBG"
      fi
      if echo "$line" | grep -qE 'position[[:space:]]+[0-9]+/[0-9]+'; then
        pos=$(echo "$line" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)
        echo "$(TS) h-stats: queued=$pos" >> "$DBG"
        idle_start || true
      fi
      if echo "$line" | grep -qE 'started successfully|Running container|Flow .* is running'; then
        echo "$(TS) h-stats: running" >> "$DBG"
        idle_stop || true
      fi
      if echo "$line" | grep -qE 'RESTARTING|Node has restarted successfully'; then
        echo "$(TS) h-stats: restarting" >> "$DBG"
      fi
    done
    # if docker logs exits, fall through and retry
  else
    (( attempts++ ))
    if (( attempts % 10 == 1 )); then
      dlog "monitor: waiting for nosana-node container to appear..."
    fi
    sleep 2
  fi
done
