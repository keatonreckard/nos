NOSANA (HiveOS custom miner package)
-----------------------------------
Built: 2025-08-21T17:39:42

v8.1.5_hiveos:
- Reverted idle-run.sh to your original behavior (no command/arg reformatting).
- Kept stable stats fixes: no "ar", final JSON sanitizer, KH/s mapping, version cache.
- Wrapper passes through miner JSON and strips any stray "ar".
- All other files unchanged from your uploads.
