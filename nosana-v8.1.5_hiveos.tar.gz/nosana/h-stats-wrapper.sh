\
    #!/usr/bin/env bash
    set -euo pipefail
    : "${CUSTOM_MINER:=nosana}"
    miner="/hive/miners/custom/${CUSTOM_MINER}/h-stats.sh"
    if [[ ! -x "$miner" ]]; then
      miner="/hive/miners/custom/nosana/h-stats.sh"
    fi
    out="$("$miner")" || out=""
    out="$(printf "%s" "$out" | tr -d '\r' | sed -E 's/,"ar":\[[^]]*\]//g; s/"ar":\[[^]]*\],?//g')"
    printf "%s\n" "$out"
