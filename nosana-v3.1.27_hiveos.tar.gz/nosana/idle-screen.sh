#!/usr/bin/env bash
set -euo pipefail
CUSTOM_LOG_BASENAME="${CUSTOM_LOG_BASENAME:-nosana}"
LOG_DIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
tail -n 200 -f "${LOG_DIR}/idle.log"
