#!/usr/bin/env bash
set -euo pipefail

CUSTOM_LOG_BASENAME="${CUSTOM_LOG_BASENAME:-nosana}"
MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="${RUN_DIR}/nosana.state"
LOG_DIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
IDLE_LOG="${LOG_DIR}/idle.log"
NOSANA_LOG="${LOG_DIR}/nosana.log"

status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""; idle_enabled=0
[[ -f "${STATE_FILE}" ]] && source "${STATE_FILE}" || true

# Scrape wallet/balances from nosana.log (last occurrences)
if [[ -s "${NOSANA_LOG}" ]]; then
  if [[ -z "${wallet:-}" ]]; then
    wallet="$(grep -E '^(Wallet|Address|Public[[:space:]]*Key|Pubkey):[[:space:]]*[A-Za-z0-9]+' "${NOSANA_LOG}" | tail -n1 | awk '{print $2}' || true)"
  fi
  if [[ -z "${sol:-}" ]]; then
    sol="$(grep -E 'SOL balance:[[:space:]]*[0-9]+(\.[0-9]+)?' "${NOSANA_LOG}" | tail -n1 | awk '{print $3}' || true)"
  fi
  if [[ -z "${nos:-}" ]]; then
    nos="$(grep -E 'NOS balance:[[:space:]]*[0-9]+(\.[0-9]+)?' "${NOSANA_LOG}" | tail -n1 | awk '{print $3}' || true)"
  fi
  # Status fallbacks
  if grep -Eq 'Job .* started|Flow .* running' "${NOSANA_LOG}"; then
    status="nos - job"
  elif grep -Eq '\bQUEUED\b' "${NOSANA_LOG}"; then
    # Try to include position A/B
    pos="$(grep -E 'position[[:space:]]+[0-9]+/[0-9]+' "${NOSANA_LOG}" | tail -n1 | sed -n 's/.*position[[:space:]]\+\([0-9]\+\/[0-9]\+\).*/\1/p')"
    if [[ -n "${pos:-}" ]]; then status="nos - queued ${pos}"; else status="nos - queued"; fi
  fi
fi

fmt4() { awk -v n="${1:-}" 'BEGIN{ if (n=="" || n=="N/A") { printf("N/A"); } else { printf("%.4f", n+0); } }'; }

# Build version string
sol4="$( [[ -n "${sol:-}" ]] && fmt4 "$sol" || echo "N/A")"
nos4="$( [[ -n "${nos:-}" ]] && fmt4 "$nos" || echo "N/A")"
wallet_short="$( [[ -n "${wallet:-}" ]] && printf '%s' "$wallet" | cut -c1-5 || echo "N/A")"
ver="S:${sol4} N:${nos4} W:${wallet_short}"

# Hashrate and shares from idle when queued
khs="0"; ar_acc="0"; ar_rej="0"
if echo "${status}" | grep -qi 'queued'; then
  if [[ -s "${IDLE_LOG}" ]]; then
    line="$(grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' "${IDLE_LOG}" | tail -n1 || true)"
    if [[ -n "${line}" ]]; then
      val="$(echo "${line}" | awk '{print $1}')"
      unit="$(echo "${line}" | awk '{print $2}' | tr '[:lower:]' '[:upper:]' | tr -d '/S')"
      case "${unit}" in
        H)  khs="$(awk -v v="${val}" 'BEGIN{printf("%.6f", v/1000)}')" ;;
        KH) khs="$(awk -v v="${val}" 'BEGIN{printf("%.6f", v)}')" ;;
        MH) khs="$(awk -v v="${val}" 'BEGIN{printf("%.6f", v*1000)}')" ;;
        GH) khs="$(awk -v v="${val}" 'BEGIN{printf("%.6f", v*1000*1000)}')" ;;
      esac
    fi
  fi
  [[ -z "${khs}" || "${khs}" == "0" ]] && khs="999"
fi

# Uptime
now=$(date +%s)
if [[ -f "${MINER_DIR}/job.start.time" ]]; then
  start_time=$(cat "${MINER_DIR}/job.start.time")
elif [[ -f "${MINER_DIR}/idle.start.time" ]]; then
  start_time=$(cat "${MINER_DIR}/idle.start.time")
elif [[ -f "${MINER_DIR}/nosana.start.time" ]]; then
  start_time=$(cat "${MINER_DIR}/nosana.start.time")
else
  start_time=$((now - $(awk '{print int($1)}' /proc/uptime)))
fi
uptime=$((now - start_time)); ((uptime<0)) && uptime=0

# GPU metrics (best-effort via HiveOS gpu-stats)
temp_json='[]'; fan_json='[]'; bus_json='[]'
if [[ -f /hive/bin/gpu-stats ]]; then
  # shellcheck disable=SC1091
  source /hive/bin/gpu-stats || true
  if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [[ "${#GPU_FAN[@]:-0}"  -gt 0 ]]; then fan_json ="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
  if [[ "${#BUS_IDS[@]:-0}"  -gt 0 ]]; then
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

stats=$(cat <<JSON
{"hs":[${khs}],"hs_units":"khs","temp":${temp_json},"fan":${fan_json},"uptime":${uptime},"ver":"${ver}","ar":[${ar_acc},${ar_rej}],"algo":"${status}","bus_numbers":${bus_json}}
JSON
)

printf "[%s] h-stats: ver=%s | algo=%s | khs=%s | wallet=%s | sol=%s | nos=%s\n" "$(date -Iseconds)" "${ver}" "${status}" "${khs}" "${wallet}" "${sol}" "${nos}" >> "${LOG_DIR}/debug.log" || true

echo "${stats}"
