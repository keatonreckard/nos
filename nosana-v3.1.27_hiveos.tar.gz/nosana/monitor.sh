#!/usr/bin/env bash
set -euo pipefail

CUSTOM_LOG_BASENAME="${CUSTOM_LOG_BASENAME:-nosana}"
LOG_DIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
MINER_DIR="/hive/miners/custom/nosana"
PARSED_DIR="${MINER_DIR}/parsed"
RUN_DIR="/var/run"

NOSANA_LOG="${LOG_DIR}/nosana.log"
IDLE_LOG="${LOG_DIR}/idle.log"
STATE_FILE="${RUN_DIR}/nosana.state"

mkdir -p "${LOG_DIR}" "${PARSED_DIR}"

debug() { printf "[%s] %s\n" "$(date -Iseconds)" "$*" >> "${LOG_DIR}/debug.log"; }

idle_running() { pgrep -f -a "screen -S nosana-idle" >/dev/null 2>&1 || pgrep -f "$(cat "${PARSED_DIR}/idle_command" 2>/dev/null)" >/dev/null 2>&1; }

idle_start() {
  local cmd args
  cmd="$(cat "${PARSED_DIR}/idle_command" 2>/dev/null || true)"
  args="$(cat "${PARSED_DIR}/idle_args" 2>/dev/null || true)"
  if [[ -z "${cmd}" ]]; then
    debug "idle_start: no idle_command parsed; skipping"
    return
  fi
  if idle_running; then
    debug "idle_start: already running"
    return
  fi
  debug "attempting to start idle (cmd:'${cmd}' args:'${args}')"
  # Start in screen and pipe output to idle.log
  screen -dmS nosana-idle bash -lc "stdbuf -oL -eL '${cmd}' ${args} 2>&1 | tee -a '${IDLE_LOG}'"
  echo 1 > "${RUN_DIR}/nosana.idle_enabled"
}

idle_stop() {
  if idle_running; then
    debug "stopping idle miner"
    screen -S nosana-idle -X quit >/dev/null 2>&1 || true
    pkill -f "$(cat "${PARSED_DIR}/idle_command" 2>/dev/null)" >/dev/null 2>&1 || true
  fi
  : > "${RUN_DIR}/nosana.idle_enabled" || true
}

# Initialize
echo "status='nos - initializing'" > "${STATE_FILE}"
debug "monitor started"

# Tail the nosana log and react to state changes
touch "${NOSANA_LOG}"
tail -Fn0 "${NOSANA_LOG}" | \
while IFS= read -r line; do
  # Queue detection
  if echo "$line" | grep -Eq '\bQUEUED\b'; then
    if echo "$line" | grep -Eq 'position[[:space:]]+[0-9]+/[0-9]+'; then
      pos="$(echo "$line" | sed -n 's/.*position[[:space:]]\+([0-9]\+\/[0-9]\+).*/\1/p')"
      status="nos - queued ${pos:-}"
    else
      status="nos - queued"
    end_if=true
    fi
    idle_start
    printf "status='%s'\n" "$status" > "${STATE_FILE}"
    continue
  fi

  # Job start / running
  if echo "$line" | grep -Eq 'Job .* started|Flow .* running'; then
    status="nos - job"
    idle_stop
    printf "status='%s'\n" "$status" > "${STATE_FILE}"
    continue
  fi

  # Job finished -> queued again (some logs)
  if echo "$line" | grep -Eq 'has restarted successfully|QUEUED'; then
    status="nos - queued"
    idle_start
    printf "status='%s'\n" "$status" > "${STATE_FILE}"
    continue
  fi
done
