#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
PARSED_DIR="${MINER_DIR}/parsed"
LOG_DIR="/var/log/miner/${CUSTOM_LOG_BASENAME:-nosana}"
mkdir -p "$PARSED_DIR" "$LOG_DIR"

RAW="${CUSTOM_USER_CONFIG:-${RAW_EXTRA:-}}"
printf "[%s] h-config: RAW_EXTRA length=%s\n" "$(date -Iseconds)" "${#RAW}" >> "${LOG_DIR}/debug.log"

# Extract idle command and args from RAW; keep previous behavior/format
# Expecting lines like:
# idle_command=/path/to/miner
# idle_args=--flag1=... --flag2=...
idle_cmd="$(echo "$RAW" | sed -n 's/.*idle_command[[:space:]]*=[[:space:]]*\([^[:space:]]\+\).*/\1/p' | tail -n1)"
idle_args="$(echo "$RAW" | sed -n 's/.*idle_args[[:space:]]*=[[:space:]]*\(.*\)$/\1/p' | tail -n1)"

# Backward compatibility: if not provided, try to parse legacy JSON-ish CLIENT settings
if [[ -z "${idle_cmd:-}" ]]; then
  idle_cmd="$(echo "$RAW" | grep -Eo '(/hive/miners/custom/[^[:space:]]+)' | head -n1 || true)"
fi
if [[ -z "${idle_args:-}" ]]; then
  idle_args="$(echo "$RAW" | sed -n 's/.*args:\(.*\)$/\1/p' | tail -n1 || true)"
fi

if [[ -n "${idle_cmd:-}" ]]; then
  echo "$idle_cmd" > "${PARSED_DIR}/idle_command"
  printf "[%s] h-config: parsed idle command: %s\n" "$(date -Iseconds)" "$idle_cmd" >> "${LOG_DIR}/debug.log"
fi
if [[ -n "${idle_args:-}" ]]; then
  echo "$idle_args" > "${PARSED_DIR}/idle_args"
  printf "[%s] h-config: parsed idle args: %s\n" "$(date -Iseconds)" "$idle_args" >> "${LOG_DIR}/debug.log"
fi
