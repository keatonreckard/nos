Nosana HiveOS custom miner package (v3.1.27)

What changed:
- Defaults $CUSTOM_LOG_BASENAME to "nosana" when not set.
- Switches to Docker provider by default (no podman sidecar needed).
- Robust wallet/SOL/NOS parsing from nosana.log; updates version string.
- Idle miner auto-start while queued and auto-stop on job start.
- Preserves existing file names and log locations:
  - Logs: /var/log/miner/$CUSTOM_LOG_BASENAME/{nosana.log, idle.log, debug.log}
  - Parsed idle files: /hive/miners/custom/nosana/parsed/{idle_command,idle_args}

Usage:
1) Upload tarball.
2) HiveOS "Custom miner" -> Miner name "nosana" (or your choice).
3) Miner start will call h-config.sh, h-run.sh, monitor.sh, and h-stats.sh.
