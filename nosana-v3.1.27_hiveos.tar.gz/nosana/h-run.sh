#!/usr/bin/env bash
set -euo pipefail

CUSTOM_LOG_BASENAME="${CUSTOM_LOG_BASENAME:-nosana}"
LOG_DIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
RUN_DIR="/var/run"
MINER_DIR="/hive/miners/custom/nosana"
STATE_FILE="${RUN_DIR}/nosana.state"
mkdir -p "$LOG_DIR" "$RUN_DIR"

source "${MINER_DIR}/nosana.conf" 2>/dev/null || true

debug() { printf "[%s] %s\n" "$(date -Iseconds)" "$*" >> "${LOG_DIR}/debug.log"; }

# Choose provider: prefer docker if available
if command -v docker >/dev/null 2>&1; then
  export NOSANA_PROVIDER="docker"
  debug "Using provider: docker"
else
  # Fallback to podman if available on host
  if command -v podman >/dev/null 2>&1; then
    export NOSANA_PROVIDER="podman"
    export CONTAINER_HOST="unix:///run/podman/podman.sock"
    debug "Using provider: podman (host)"
  else
    # Last resort: fail with clear error instead of trying sidecar
    echo "[ERROR] Neither docker nor podman is available on host." | tee -a "${LOG_DIR}/debug.log"
    exit 127
  fi
fi

# Clean any previous run log marker
: > "${LOG_DIR}/nosana.log"
echo "$$" > "${RUN_DIR}/nosana.pid"
date +%s > "${MINER_DIR}/nosana.start.time"
debug "starting nosana-node container"

# Common docker run args
DOCKER_RUN=(docker run --pull always --rm -i
  -e NOSANA_PROVIDER="${NOSANA_PROVIDER}"
  -v /root/.nosana:/root/.nosana
  -v /var/run/docker.sock:/var/run/docker.sock
  "${NOSANA_CLI_IMAGE:-nosana/nosana-cli:latest}"
)

# Start CLI and tee output to nosana.log (foreground)
# Keep process in foreground so HiveOS can manage lifecycle.
set +e
"${DOCKER_RUN[@]}" 2>&1 | tee -a "${LOG_DIR}/nosana.log"
rc=${PIPESTATUS[0]}
set -e

debug "nosana-cli exited rc=${rc}"
exit "${rc}"
