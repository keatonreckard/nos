\
    #!/usr/bin/env bash
    set -euo pipefail
    # Hive agent reads STDOUT of this script into "miner_stats"
    : "${CUSTOM_MINER:=nosana}"
    miner="/hive/miners/custom/${CUSTOM_MINER}/h-stats.sh"
    if [[ ! -x "$miner" ]]; then
      miner="/hive/miners/custom/nosana/h-stats.sh"
    fi
    exec "$miner"
