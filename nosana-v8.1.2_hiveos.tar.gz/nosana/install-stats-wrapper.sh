\
    #!/usr/bin/env bash
    set -euo pipefail
    MINER_DIR="/hive/miners/custom/nosana"
    TARGET="/hive/miners/custom/h-stats.sh"
    install -m 0755 -D "$MINER_DIR/h-stats-wrapper.sh" "$TARGET"
    echo "installed: $TARGET"
