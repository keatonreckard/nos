NOSANA (HiveOS custom miner package)
-----------------------------------
Built: 2025-08-21T17:06:01

v8.1.2_hiveos:
- Fix for truncated miner_stats: global wrapper now EXECs your miner's h-stats.sh and prints JSON to STDOUT.
- h-stats.sh: stdout is ONLY the JSON; debug routed to debug.log via stderr. No "ar" field anywhere.
- KH/s mapping preserved (init+job=>1, queued X/Y=>X); version cache retains S:/N:/W: between log updates.
- Idle logic unchanged from your uploaded files.
