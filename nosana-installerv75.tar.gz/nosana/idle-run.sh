#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
DEBUG_LOG="$LOG_DIR/debug.log"
PARSED_DIR="$MINER_DIR/parsed"
RUN_DIR="/run/hive"
MOTD_MINER2="$RUN_DIR/miner.2"
MOTD_STATUS2="$RUN_DIR/miner_status.2"
CUR_MINER="$RUN_DIR/cur_miner"
CUR_MINER_BAK="$RUN_DIR/cur_miner.nosana.bak"

ensure_motd_window_2() {
  mkdir -p "$RUN_DIR" 2>/dev/null || true
  printf '{"status":"running"}\n' > "$MOTD_STATUS2" 2>/dev/null || true

  # Ensure cur_miner has a 2nd line label for the MOTD header
  if [ -f "$CUR_MINER" ] && [ ! -f "$CUR_MINER_BAK" ]; then cp -f "$CUR_MINER" "$CUR_MINER_BAK" 2>/dev/null || true; fi
  if [ -f "$CUR_MINER" ]; then
    awk 'NR==1{print;next} NR==2{print "idle-miner"; next} {print}' "$CUR_MINER" > "${CUR_MINER}.tmp" 2>/dev/null && mv -f "${CUR_MINER}.tmp" "$CUR_MINER" || true
  else
    printf "custom\nidle-miner\n" > "$CUR_MINER" 2>/dev/null || true
  fi

  # Background tail to populate /run/hive/miner.2 (strip ANSI)
  # Stop any previous tailers we might have started
  if [ -f "$RUN_DIR/.nosana_idle_to_motd.pid" ]; then
    kill "$(cat "$RUN_DIR/.nosana_idle_to_motd.pid" 2>/dev/null)" >/dev/null 2>&1 || true
    rm -f "$RUN_DIR/.nosana_idle_to_motd.pid"
  fi
  pkill -f "tail -n .* -F .*idle.log.*nosana_to_motd" >/dev/null 2>&1 || true

  ( stdbuf -oL tail -n 200 -F "$IDLE_LOG" | sed -u "s/\x1B\[[0-9;]*[A-Za-z]//g" > "$MOTD_MINER2" ) >/dev/null 2>&1 & echo $! > "$RUN_DIR/.nosana_idle_to_motd.pid"
}

for d in /var/log/miner "$LOG_DIR" "$PARSED_DIR"; do mkdir -p "$d" 2>/dev/null || true; done
: > "$IDLE_LOG" || true
mkdir -p "/var/log/miner/miner2" 2>/dev/null || true
ln -sf "$IDLE_LOG" "/var/log/miner/miner2/miner.log" 2>/dev/null || true

: > "$NOSANA_LOG" || true
: > "$DEBUG_LOG" || true

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

IDLE_COMMAND="$(cat "$PARSED_DIR/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$PARSED_DIR/idle_args" 2>/dev/null || true)"

if [[ -z "${IDLE_COMMAND:-}" ]]; then
  echo "[$(date -Iseconds)] idle-run: no idle command set" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  msg "NOS: idle start failed (no command)"; exit 1
fi

# Preflight binary checks
IDLE_DIR="$(dirname "$IDLE_COMMAND")"
IDLE_BIN="$(basename "$IDLE_COMMAND")"
if [[ ! -e "$IDLE_COMMAND" ]]; then
  echo "[$(date -Iseconds)] idle-run: binary not found: $IDLE_COMMAND" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  msg "NOS: idle start failed (binary missing)"; exit 3
fi
if [[ ! -x "$IDLE_COMMAND" ]]; then chmod +x "$IDLE_COMMAND" 2>/dev/null || true; fi

{
  echo "[$(date -Iseconds)] idle-run preflight"
  echo "  whoami=$(whoami)  pwd=$(pwd)"
  echo "  idle_dir=$IDLE_DIR idle_bin=$IDLE_BIN"
  ls -l "$IDLE_COMMAND" || true
  command -v screen || echo "screen not in PATH"
  command -v awk || echo "awk not in PATH"
  which bash || true
  if command -v file >/dev/null 2>&1; then file "$IDLE_COMMAND" || true; fi
} | tee -a "$DEBUG_LOG" "$NOSANA_LOG"

# Nuke previous session if present
if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then
  screen -S nosana-idle -X quit || true
  sleep 0.2
fi

echo "[$(date -Iseconds)] idle-run: starting idle miner: $IDLE_COMMAND $IDLE_ARGS" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"

# Run from the binary's directory; exec ./binary to satisfy relative lookups
screen -dmS nosana-idle bash -c '
  set -o pipefail
  cd "'"$IDLE_DIR"'"
  exec "./'"$IDLE_BIN"'" '"$IDLE_ARGS"' 2>&1 \
    | awk "{print \"[idle] \" \$0}" \
    | tee -a "'"$IDLE_LOG"'" \
    | tee -a "'"$NOSANA_LOG"'"
'

# Verify: check session and process
sleep 1
session_ok=0
proc_ok=0
if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then session_ok=1; fi
# Try to detect the process quickly
if pgrep -f -- "$IDLE_BIN" >/dev/null 2>&1; then proc_ok=1; fi

if [[ $session_ok -eq 1 || $proc_ok -eq 1 ]]; then
  echo "[$(date -Iseconds)] idle-run: idle miner started (session_ok=$session_ok proc_ok=$proc_ok)" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
ensure_motd_window_2
  msg "NOS: idle miner started"; exit 0
else
  echo "[$(date -Iseconds)] idle-run: failed to start (session_ok=$session_ok proc_ok=$proc_ok)" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  echo "Last 50 lines of idle.log:" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  tail -n 50 "$IDLE_LOG" 2>/dev/null | tee -a "$DEBUG_LOG" "$NOSANA_LOG" || true
  msg "NOS: idle miner failed to start"; exit 2
fi
