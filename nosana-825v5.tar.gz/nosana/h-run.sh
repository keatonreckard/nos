#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"

# Hive "live" log files:
MINER1="/run/hive/miner.1"   # docker node logs (Nosana)
MINER2="/run/hive/miner.2"   # idle miner logs

mkdir -p "$RUN_DIR" "/run/hive"
touch "$STATE_FILE" "$MINER1" "$MINER2"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

set_state() {
  local key="$1" val="$2"
  local vesc="${val//\\/\\\\}"; vesc="${vesc//\"/\\\"}"
  awk -v k="$key" -v v="$vesc" '
    BEGIN{done=0}
    $0 ~ ("^"k"=") { print k"=\""v"\""; done=1; next }
    { print }
    END{ if(!done) print k"=\""v"\"" }
  ' "$STATE_FILE" > "$STATE_FILE.tmp" && mv "$STATE_FILE.tmp" "$STATE_FILE"
}

idle_running() { screen -ls 2>/dev/null | grep -q "\.nosana-idle"; }

# Read parsed idle command/args if present
PARSED_DIR="$MINER_DIR/parsed"
IDLE_COMMAND="$(cat "$PARSED_DIR/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$PARSED_DIR/idle_args" 2>/dev/null || true)"

start_idle() {
  [[ -z "${IDLE_COMMAND:-}" ]] && return 0
  if ! idle_running; then
    screen -dmS nosana-idle bash -lc "exec stdbuf -oL -eL ${IDLE_COMMAND} ${IDLE_ARGS} >> ${MINER2} 2>&1"
    msg "NOS: idle miner started"
  fi
}

kill_idle() {
  if idle_running; then
    screen -S nosana-idle -X quit || true
  fi
  # Try harder in case process survived
  if [[ -n "${IDLE_COMMAND:-}" ]]; then
    pkill -f -- "$IDLE_COMMAND" || true
  fi
  msg "NOS: idle miner killed"
}

echo "[$(date -Iseconds)] h-run: cleaning previous containers" >> "$MINER1"
docker rm -f nosana-node podman >/dev/null 2>&1 || true
pkill -9 -f "podman system service" 2>/dev/null || true

echo "[$(date -Iseconds)] h-run: starting podman sidecar" >> "$MINER1"
(nohup podman system service -t 0 unix:///var/run/podman.sock >/dev/null 2>&1 &) || true
sleep 5

echo "[$(date -Iseconds)] h-run: starting nosana-node container" >> "$MINER1"
# Expect image preconfigured elsewhere; keep as before
docker run -d --restart=unless-stopped --name nosana-node --pull=always nosana/node:latest >/dev/null 2>&1 || true

# Stream docker logs *only* to miner.1
( docker logs --since 0s -f nosana-node 2>&1 >> "$MINER1" ) &
DOCKER_FOLLOW_PID=$!

# Initialize state
date +%s > "$MINER_DIR/nosana.start.time"
set_state status "nos - initializing"
msg "NOS: monitor started"

# Bootstrap: short peek at recent logs to set initial state quickly
bootlog="$(docker logs --since 60m nosana-node 2>&1 || true)"
if printf '%s\n' "$bootlog" | grep -Eqi 'Node is claiming job|claimed job|Job .* started|Flow .* started|is running'; then
  set_state status "nos - job"
  kill_idle
  msg "NOS: job"
elif printf '%s\n' "$bootlog" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
  set_state status "nos - queued"
  start_idle
  msg "NOS: queued"
fi

# Main monitor loop: check transitions every 5s (no extra file output)
while :; do
  logchunk="$(docker logs --since 10s nosana-node 2>&1 || true)"
  if [[ -n "$logchunk" ]]; then
    if echo "$logchunk" | grep -Eqi 'Node is claiming job|claimed job|Job .* started|Flow .* started|is running'; then
      set_state status "nos - job"
      kill_idle
      date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
      msg "NOS: job started"
    elif echo "$logchunk" | grep -Eqi 'Nosana Node finished|Job .* (completed|finished)|Flow .* (finished|completed)'; then
      msg "NOS: job finished"
    fi

    if echo "$logchunk" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
      set_state status "nos - queued"
      date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
      start_idle
      msg "NOS: queued"
    fi
  fi
  sleep 5
done
