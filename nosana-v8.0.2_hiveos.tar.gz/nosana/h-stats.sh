#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"

mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""; idle_enabled=0
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

# Assemble + clean logs, strip ANSI
L=""; [[ -s "$NOSANA_LOG" ]] && L="$(tail -n 3000 "$NOSANA_LOG" | tr -d '\r')"
if [[ -z "$L" ]]; then
  C="$(docker logs --since 10m nosana-node 2>/dev/null || true)"
  [[ -n "$C" ]] && L="$(printf "%s" "$C" | tr -d '\r')"
fi
CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"

# Wallet from explicit labels
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
fi
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*(Public[[:space:]]*Key|Pubkey|Address)[[:space:]]*:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\2/p' | tail -n1)"
fi
# Wallet from node URL
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
fi

# Balances
if [[ -z "${sol:-}" ]]; then
  sol="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
if [[ -z "${nos:-}" ]]; then
  nos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi

# Determine status
if printf "%s\n" "$CLEAN" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
  status="nos - job"; queue=""
else
  pos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
  if [[ -n "${pos:-}" ]]; then
    status="nos - queued ${pos}"; queue="${pos}"
  elif printf "%s\n" "$CLEAN" | grep -Eqi 'QUEUED'; then
    status="nos - queued"
  fi
fi

# Uptime
now=$(date +%s)
if [[ -f "$MINER_DIR/job.start.time" ]]; then start_time=$(cat "$MINER_DIR/job.start.time")
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then start_time=$(cat "$MINER_DIR/idle.start.time")
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then start_time=$(cat "$MINER_DIR/nosana.start.time")
else read -r up _ < /proc/uptime; start_time=$(( now - ${up%.*} )); fi
uptime=$((now - start_time)); ((uptime<0)) && uptime=0

# Idle passthrough (guard awk when empty)
parse_idle_stats() {
  [[ -s "$IDLE_LOG" ]] || { echo "0|0|0"; return; }
  local L2 hs_val hs_unit khs="0" acc="0" rej="0"
  L2="$(tail -n 400 "$IDLE_LOG")"
  local line="$(echo "$L2" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1)"
  hs_val="$(printf "%s\n" "$line" | sed -nE 's/^([0-9]+(\.[0-9]+)?).*/\1/p')"
  hs_unit="$(printf "%s\n" "$line" | sed -nE 's/^[0-9]+(\.[0-9]+)?[[:space:]]*([A-Za-z]+).*/\2/p' | tr '[:lower:]' '[:upper:]' | sed 's/S$//')"
  if [[ -n "${hs_val:-}" && -n "${hs_unit:-}" ]]; then
    case "$hs_unit" in
      H)  khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v/1000)}');;
      KH) khs="$hs_val";;
      MH) khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v*1000)}');;
      GH) khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v*1000*1000)}');;
    esac
  fi
  if echo "$L2" | grep -Eiq '([0-9]+/[0-9]+|A:[0-9]+)'; then
    if echo "$L2" | grep -Eio '([0-9]+)\/([0-9]+)'; then
      acc=$(echo "$L2" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f1)
      rej=$(echo "$L2" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f2)
    else
      acc=$(echo "$L2" | grep -Eio 'A:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)
      rej=$(echo "$L2" | grep -Eio 'R:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)
    fi
  fi
  echo "${khs}|${acc}|${rej}"
}

algo="${status:-nos}"
khs="0"; ar_acc="0"; ar_rej="0"
if echo "$algo" | grep -qi 'queued'; then
  IFS='|' read -r khs ar_acc ar_rej <<<"$(parse_idle_stats)"
  [[ -z "$khs" || "$khs" == "0" ]] && khs="999"
fi

# Version string: only include known fields
ver=""
if [[ -n "${sol:-}" ]]; then printf -v solf "%.4f" "$sol"; ver+="S:${solf}"; fi
if [[ -n "${nos:-}" ]]; then printf -v nosf "%.4f" "$nos"; ver+="${ver:+ }N:${nosf}"; fi
if [[ -n "${wallet:-}" ]]; then ver+="${ver:+ }W:$(printf "%s" "$wallet" | cut -c1-5)"; fi

# GPU arrays (best-effort)
temp_json='[]'; fan_json='[]'; bus_json='[]'
if [[ -f /hive/bin/gpu-stats ]]; then
  source /hive/bin/gpu-stats || true
  if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [[ "${#GPU_FAN[@]:-0}" -gt 0 ]]; then  fan_json ="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
  if [[ "${#BUS_IDS[@]:-0}" -gt 0 ]]; then
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

# ---- classic tweak: set KH/s and algo cleanly ----
# Expect $status set to one of: "nos - job", "nos - queued X/Y", "nos - initializing", etc.
algo="${status:-${algo:-nos}}"

# If algo includes queued, extract first number of X/Y
qfirst="$(printf "%s\n" "$algo" | sed -nE 's/.*queued[[:space:]]+([0-9]+)\/[0-9]+.*/\1/p')"

khs="${khs:-0}"
if printf "%s" "$algo" | grep -qi 'nos - job'; then
  khs="1"
elif printf "%s" "$algo" | grep -qi 'nos - queued' && [[ -n "${qfirst:-}" ]]; then
  khs="$qfirst"
else
  khs="${khs:-0}"
fi

# sanitize (remove slashes/anything non-numeric/period)
khs="$(printf "%s" "$khs" | sed 's|/.*||; s/[^0-9.]//g')"
[[ -z "$khs" ]] && khs="0"

# standardize algo field (no slash replacements here; dashboard handles plain "queued X/Y")
algo="$algo"
# -----------------------------------------------

# --- KH/s mapping + sanitize (classic, non-invasive) ---
algo="${algo:-${status:-nos}}"
# queued first number X from X/Y
qfirst="$(printf "%s\n" "$algo" | sed -nE 's/.*queued[[:space:]]+([0-9]+)\/[0-9]+.*/\1/p')"

if printf "%s" "$algo" | grep -qi 'nos - job'; then
  khs="1"
elif printf "%s" "$algo" | grep -qi 'nos - queued' && [[ -n "${qfirst:-}" ]]; then
  khs="$qfirst"
else
  khs="${khs:-0}"
fi

# strip slashes & non-numeric to keep JSON healthy
khs="$(printf "%s" "$khs" | sed 's|/.*||; s/[^0-9.]//g')"
[[ -z "$khs" ]] && khs="0"
# -------------------------------------------------------

stats=$(cat <<JSON
{"hs":[${khs}],"hs_units":"khs","temp":${temp_json},"fan":${fan_json},"uptime":${uptime},"ver":"${ver}","ar":[${ar_acc},${ar_rej}],"algo":"${algo}","bus_numbers":${bus_json}}
JSON
)
printf "[%s] h-stats: ver=%s | algo=%s | khs=%s | wallet=%s | sol=%s | nos=%s\n" "$(date -Iseconds)" "$ver" "$algo" "$khs" "$wallet" "$sol" "$nos" >> "$LOG_DIR/debug.log" || true
echo "$stats"
