#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
DEBUG_LOG="$LOG_DIR/debug.log"
mkdir -p "$LOG_DIR"; touch "$LOG_DIR/nosana.log" "$DEBUG_LOG"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

# Kill any prior idle
bash "$MINER_DIR/idle-kill.sh" || true
echo "[$(date -Iseconds)] NOS: cleared previous idle miner - if any" | tee -a "$DEBUG_LOG"

echo "[$(date -Iseconds)] h-run: cleaning previous containers" | tee -a "$DEBUG_LOG"
docker rm -f podman nosana-node >/dev/null 2>&1 || true

echo "[$(date -Iseconds)] h-run: starting podman sidecar - container" | tee -a "$DEBUG_LOG"
# Ensure volumes exist
docker volume create podman-cache >/dev/null 2>&1 || true
docker volume create podman-socket >/dev/null 2>&1 || true

docker run -d --pull=always --gpus=all --name podman \
  --device /dev/fuse --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman --privileged -e ENABLE_GPU=true \
  nosana/podman:v1.1.0 unix:/podman/podman.sock >> "$DEBUG_LOG" 2>&1 || true

# Wait for podman socket to appear in the volume container
for i in {1..20}; do
  if docker exec podman test -S /podman/podman.sock 2>/dev/null; then
    echo "[$(date -Iseconds)] h-run: podman socket is up" | tee -a "$DEBUG_LOG"
    break
  fi
  sleep 1
done

echo "[$(date -Iseconds)] h-run: starting nosana-node - podman provider via volume" | tee -a "$DEBUG_LOG"
msg "NOS: node starting"
docker run -d --pull=always --name nosana-node --network host --gpus=all \
  --volume /root/.nosana/:/root/.nosana/ \
  --volume podman-socket:/root/.nosana/podman:ro \
  -e CLI_VERSION= \
  nosana/nosana-cli:latest \
  node start --network "${SOL_NET_ENV:=mainnet}" >> "$DEBUG_LOG" 2>&1 || true
sleep 2
msg "NOS: node container launched"

# Clear miner.1 and pipe container logs to it
: > /run/hive/miner.1 || true
# background log follower
(docker logs -f nosana-node 2>&1 | sed -u "s/\r/\n/g" >> /run/hive/miner.1) &
echo $! > /var/run/nosana.logs.pid

# Start monitor loop (never returns)
exec bash "$MINER_DIR/monitor.sh"
