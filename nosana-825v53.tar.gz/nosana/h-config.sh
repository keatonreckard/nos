#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C


MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
CONF_FILE="$MINER_DIR/nosana.conf"
IDLE_CMD_FILE="$MINER_DIR/idle.cmd"

mkdir -p "$MINER_DIR" "$LOG_DIR" "$RUN_DIR" /root/.nosana
chmod 755 "$MINER_DIR"
touch "$LOG_DIR/nosana.log" "$LOG_DIR/debug.log" "$LOG_DIR/idle.log"
chmod 664 "$LOG_DIR/"*.log || true

# Helper: write key=value to state
set_state() {
  local k="$1" v="$2"
  grep -v -E "^${k}=" "$STATE_FILE" 2>/dev/null > "${STATE_FILE}.tmp" || true
  printf "%s=%s\n" "$k" "$v" >> "${STATE_FILE}.tmp"
  mv -f "${STATE_FILE}.tmp" "$STATE_FILE"
}

# Determine idle miner command (priority: env IDLE_COMMAND, file idle.cmd, nosana.conf line IDLE_COMMAND=...)
IDLE_COMMAND="${IDLE_COMMAND:-}"
if [[ -z "${IDLE_COMMAND}" && -s "$IDLE_CMD_FILE" ]]; then
  IDLE_COMMAND="$(cat "$IDLE_CMD_FILE")"
fi
if [[ -z "${IDLE_COMMAND}" && -s "$CONF_FILE" ]]; then
  IDLE_COMMAND="$(grep -E '^IDLE_COMMAND=' "$CONF_FILE" | sed 's/^IDLE_COMMAND=//; s/^"//; s/"$//')"
fi

# Export for children
export IDLE_COMMAND

# Flag for idle mining
if [[ -n "${IDLE_COMMAND}" ]]; then
  set_state idle_enabled 1
else
  set_state idle_enabled 0
fi

# Initial state on config
set_state phase initializing
set_state algo "nos - initializing"
set_state queued_pos ""
set_state queued_total ""
set_state idle_algo ""
set_state idle_hash_khs ""
# default 0.01 for display on init
set_state khs "0.01"

# Touch status files so Hive dashboard has them
: > /run/hive/miner.1 || true
printf "waiting for node to enter queued state to start idle miner\n" > /run/hive/miner.2 || true
echo "stopped" > /run/hive/miner_status.2 || true

exit 0
