#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
# Kill screen & any child process
if screen -ls 2>/dev/null | grep -q "nosana-idle"; then
  # Terminate screen session
  screen -S nosana-idle -X quit || true
fi
# Kill by name if any stragglers
pkill -f 'nosana-idle|qli-Client|xmr|qubic|idle' 2>/dev/null || true
# Mark status and clear miner.2
echo "stopped" > /run/hive/miner_status.2 || true
: > /run/hive/miner.2 || true
