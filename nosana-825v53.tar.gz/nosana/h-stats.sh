#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

STATE_FILE="/var/run/nosana.state"

read_state() { awk -F= -v K="$1" '$1==K{print substr($0, index($0,$2))}' "$STATE_FILE" 2>/dev/null | tail -n1; }

algo="$(read_state algo)"
phase="$(read_state phase)"
khs="$(read_state khs)"
pos="$(read_state queued_pos)"
tot="$(read_state queued_total)"

# When queued and idle miner is running, compute hashrate from /run/hive/miner.2
if [[ "$phase" == "queued" ]]; then
  if screen -ls 2>/dev/null | grep -q "nosana-idle"; then
    # Parse latest it/s and convert to kH (21188 it/s => 21.188 kH)
    rate_it=$(tac /run/hive/miner.2 2>/dev/null | grep -m1 -E '([0-9]+)\.?([0-9]*) it/s' | sed -E 's/.* ([0-9]+(\.[0-9]*)?) it\/s.*/\1/')
    if [[ -n "${rate_it:-}" ]]; then
      # bc might not exist; do shell arithmetic: divide by 1000 with 3 decimals
      int=${rate_it%.*}; frac=${rate_it#*.}; [[ "$int" = "$rate_it" ]] && frac=0
      khs=$(python3 - <<PY
rate=float("$rate_it")
print(f"{rate/1000:.3f}")
PY
)
    fi
  else
    khs="${khs:-0.01}"
  fi
fi

# If initializing, force khs=0.01 and do not include idle suffix
if echo "$algo" | grep -q "initializing"; then
  khs="0.01"
fi

# If job running, force khs=1.000
if echo "$algo" | grep -q "nos - job"; then
  khs="1"
fi

# Emit Hive JSON
cat <<JSON
{"hs":[${khs:-0.01}],"hs_units":"khs","temp":[],"fan":[],"uptime":"$(($(cut -d. -f1 /proc/uptime)))","ver":"","algo":"${algo}","bus_numbers":[]}
JSON
