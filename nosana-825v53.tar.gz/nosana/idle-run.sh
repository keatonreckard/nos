#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
DEBUG_LOG="$LOG_DIR/debug.log"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

if [[ -z "${IDLE_COMMAND:-}" ]]; then
  echo "[$(date -Iseconds)] idle-run: no IDLE_COMMAND configured; not starting idle miner" | tee -a "$DEBUG_LOG"
  exit 1
fi

# Clear previous status/log
echo "running" > /run/hive/miner_status.2 || true
# Don't wipe miner.2 here; keep prior "waiting..." until first output

# Start in a detached screen. Use stdbuf to force line-buffered output; translate CR to NL for MOTD.
CMD="${IDLE_COMMAND}"
echo "[$(date -Iseconds)] NOS: idle miner started (cmd: ${CMD})" | tee -a "$DEBUG_LOG" "$LOG_DIR/nosana.log"
msg "NOS: idle miner started"

# Start screen running bash -lc to resolve env and path
screen -S nosana-idle -dm bash -lc 'stdbuf -oL -eL '"$CMD"' 2>&1 | sed -u "s/\r/\n/g" | tee -a /run/hive/miner.2'
