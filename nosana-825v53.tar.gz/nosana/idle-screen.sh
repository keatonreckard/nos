#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

screen -r nosana-idle || true
