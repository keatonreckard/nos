#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
exec bash "/hive/miners/custom/nosana/h-stats.sh"
