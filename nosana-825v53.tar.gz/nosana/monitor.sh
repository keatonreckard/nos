#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
DEBUG_LOG="$LOG_DIR/debug.log"
STATE_FILE="/var/run/nosana.state"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

set_state() {
  local k="$1" v="$2"
  tmp="${STATE_FILE}.tmp"
  grep -v -E "^${k}=" "$STATE_FILE" 2>/dev/null > "$tmp" || true
  printf "%s=%s\n" "$k" "$v" >> "$tmp"
  mv -f "$tmp" "$STATE_FILE"
}

get_state() {
  local k="$1"; awk -F= -v K="$k" '$1==K{print substr($0, index($0,$2))}' "$STATE_FILE" 2>/dev/null | tail -n1
}

idle_running() { screen -ls 2>/dev/null | grep -q "nosana-idle"; }

# Ensure initial algo and small hashrate
set_state algo "nos - initializing"
set_state khs "0.01"

# Tail logs
touch /run/hive/miner.1
# Keep last seen queue to reduce spam
LAST_Q=""
while true; do
  # Read the last 2000 bytes for parsing (covers multiple lines without needing tail -f)
  logchunk="$(tail -c 20000 /run/hive/miner.1 2>/dev/null || true)"
  if [[ -z "$logchunk" ]]; then
    sleep 3; continue
  fi

  # Detect queued position
  if echo "$logchunk" | grep -E "QUEUED" -qi; then
    # Extract pos and total if present
    pos="$(echo "$logchunk" | awk 'tolower($0) ~ /queued/ && match($0, /position[[:space:]]*([0-9]+)\/([0-9]+)/, a){print a[1]}' | tail -n1)"
    tot="$(echo "$logchunk" | awk 'tolower($0) ~ /queued/ && match($0, /position[[:space:]]*([0-9]+)\/([0-9]+)/, a){print a[2]}' | tail -n1)"
    if [[ -n "${pos:-}" && -n "${tot:-}" ]]; then
      set_state phase "queued"
      set_state queued_pos "$pos"
      set_state queued_total "$tot"
      # Update algo string
      if idle_running; then
        # Determine idle algo by inspecting miner.2 recent lines
        idle_algo="idle"
        if grep -qi '\[XMR\]' /run/hive/miner.2 2>/dev/null; then idle_algo="idle xmr"; fi
        if grep -qi 'QUBIC' /run/hive/miner.2 2>/dev/null; then idle_algo="idle qubic"; fi
        set_state algo "nos queued ${pos}/${tot} - ${idle_algo}"
      else
        set_state algo "nos queued ${pos}/${tot}"
      fi
      # Inform agent if changed
      QNOW="${pos}/${tot}"
      if [[ "$QNOW" != "$LAST_Q" ]]; then
        LAST_Q="$QNOW"
        if idle_running; then
          msg "NOS: queued ${QNOW} (idle running)"
        else
          msg "NOS: queued ${QNOW}"
        end if
      fi
      # Start idle if enabled and not running
      idle_enabled="$(get_state idle_enabled)"
      if [[ "${idle_enabled:-0}" = "1" ]] && ! idle_running; then
        bash "$MINER_DIR/idle-run.sh" || true
      fi
    fi
  fi

  # Detect job start
  if echo "$logchunk" | grep -Eqi 'claimed job|Job .* started|is running|Flow .* started'; then
    set_state phase "job"
    set_state algo "nos - job"
    # Force job hashrate to 1 kH as per requirement
    set_state khs "1"
    # Kill idle immediately
    if idle_running; then
      bash "$MINER_DIR/idle-kill.sh" || true
      msg "NOS: idle miner killed (job start)"
    fi
    msg "NOS: job started"
  fi

  # Detect finished job -> go back to queued (will be picked on next loop)
  if echo "$logchunk" | grep -Eqi 'finished|completed|Nosana Node finished'; then
    msg "NOS: job finished"
  fi

  sleep 5
done
