#!/usr/bin/env bash
set -e
# This will be downloaded from GitHub at runtime if missing.
echo 'install_docker_slave placeholder'
