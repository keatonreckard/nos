#!/usr/bin/env bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR"
log(){ echo "[$(date -Iseconds)] $*" | tee -a "$LOG_DIR/debug.log"; }

log "Installing base tools (gpg, gnupg, ca-certificates, curl, lsb-release, apt-transport-https, bsdutils)"
apt-get update -y || true
apt-get install -y --no-install-recommends --allow-downgrades gpg gnupg ca-certificates curl lsb-release apt-transport-https bsdutils || true

# Docker via HiveOS script if missing
if ! command -v docker >/dev/null 2>&1; then
  log "Docker not found. Installing via HiveOS script..."
  if [[ -x "./install_docker_slave.sh" ]]; then
    bash ./install_docker_slave.sh | tee -a "$LOG_DIR/debug.log"
  else
    wget -qO ./install_docker_slave.sh "https://github.com/filthz/fact-worker-public/releases/download/base_files/install_docker_slave.sh"
    chmod 0755 ./install_docker_slave.sh
    bash ./install_docker_slave.sh | tee -a "$LOG_DIR/debug.log"
  fi
else
  log "Docker already present."
fi

# Ensure docker service is up
systemctl start docker 2>/dev/null || true
systemctl enable docker 2>/dev/null || true

# Quiet the nosana start.sh non-root group check without patching start.sh
groupadd docker 2>/dev/null || true
usermod -aG docker user 2>/dev/null || true

# NVIDIA Container Toolkit repo & install (robust, non-interactive)
KEYRING="/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg"
install -m 0755 -d /usr/share/keyrings
rm -f "$KEYRING"
log "Installing NVIDIA repo keyring..."
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | gpg --batch --yes --dearmor -o "$KEYRING"
chmod 0644 "$KEYRING"

# Remove old NVIDIA sources to avoid duplicates
find /etc/apt/sources.list.d -maxdepth 1 -type f -name "*nvidia*.list" -exec rm -f {} \; || true
sed -i '/nvidia\.github\.io/d' /etc/apt/sources.list 2>/dev/null || true

CODENAME="$(lsb_release -cs 2>/dev/null || echo jammy)"
ARCH="$(dpkg --print-architecture)"
case "$CODENAME" in
  jammy) UBUNTU_NUM="ubuntu22.04" ;;
  focal) UBUNTU_NUM="ubuntu20.04" ;;
  bionic) UBUNTU_NUM="ubuntu18.04" ;;
  *)     UBUNTU_NUM="ubuntu22.04" ;;
esac
log "Detected: codename=$CODENAME arch=$ARCH mapped=$UBUNTU_NUM"

LIST_TMP="/tmp/nvidia-container-toolkit.list"
CANDIDATES=(
  "https://nvidia.github.io/libnvidia-container/stable/${UBUNTU_NUM}/${ARCH}/nvidia-container-toolkit.list"
  "https://nvidia.github.io/libnvidia-container/stable/${UBUNTU_NUM}/nvidia-container-toolkit.list"
  "https://nvidia.github.io/libnvidia-container/stable/${ARCH}/nvidia-container-toolkit.list"
  "https://nvidia.github.io/libnvidia-container/stable/nvidia-container-toolkit.list"
)
GOT=""
for url in "${CANDIDATES[@]}"; do
  if curl -fsSL "$url" -o "$LIST_TMP"; then
    GOT="$url"
    break
  fi
done
if [[ -n "$GOT" ]]; then
  log "Using NVIDIA repo list: $GOT"
  sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' "$LIST_TMP" > /etc/apt/sources.list.d/nvidia-container-toolkit.list
else
  log "WARNING: Could not fetch NVIDIA repo list from any candidate URL."
fi

# Reset apt cache and update
apt-get clean
rm -rf /var/lib/apt/lists/*
apt-get update -o Acquire::https::Verify-Peer=true -o Acquire::https::Verify-Host=true -y || true

# Try toolkit; fallback to runtime packages
if ! apt-get install -y --allow-downgrades nvidia-container-toolkit; then
  log "nvidia-container-toolkit not found; trying fallbacks (nvidia-container-runtime, nvidia-docker2)..."
  apt-get install -y --allow-downgrades nvidia-container-runtime || true
  apt-get install -y --allow-downgrades nvidia-docker2 || true
fi

# Configure docker runtime if nvidia-ctk exists
if command -v nvidia-ctk >/dev/null 2>&1; then
  log "Configuring docker runtime for NVIDIA via nvidia-ctk..."
  nvidia-ctk runtime configure --runtime=docker || true
  systemctl restart docker || true
else
  log "WARNING: nvidia-ctk not found; skipping runtime configure."
fi

# Non-fatal sanity check
if docker run --rm --gpus all nvidia/cuda:11.0.3-base-ubuntu18.04 nvidia-smi >/dev/null 2>&1; then
  log "NVIDIA toolkit OK inside container."
else
  log "WARNING: nvidia-smi check in container failed (continuing)."
fi

exit 0
