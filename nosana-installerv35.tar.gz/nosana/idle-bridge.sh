#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR" /var/run
DEBUG_LOG="$LOG_DIR/debug.log"

# Resolve miner log file
resolve_miner_log() {
  local ml
  if [[ -n "${CUSTOM_LOG_BASENAME:-}" ]]; then
    ml="${CUSTOM_LOG_BASENAME}.log"
  elif [[ -f "/hive/miners/custom/nosana/h-manifest.conf" ]]; then
    ml="$(grep -E '^\s*CUSTOM_LOG_BASENAME=' /hive/miners/custom/nosana/h-manifest.conf | head -n1 | cut -d= -f2-)"
    ml="${ml:-/var/log/miner/nosana/nosana}"
    ml="${ml}.log"
  else
    ml="/var/log/miner/nosana/nosana.log"
  fi
  printf "%s" "$ml"
}

# Periodically (re)enable screen logging
reassert_logging() {
  if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then
    screen -S nosana-idle -X logfile "$IDLE_LOG" || true
    screen -S nosana-idle -X logfile flush 1 || true
    screen -S nosana-idle -X log on || true
  fi
}

start() {
  MINER_LOG="$(resolve_miner_log)"
  IDLE_LOG="$LOG_DIR/idle.log"
  PID_FILE="/var/run/idle-bridge.pid"

  echo "[$(date -Iseconds)] idle-bridge starting; MINER_LOG=$MINER_LOG IDLE_LOG=$IDLE_LOG" | tee -a "$DEBUG_LOG"

  # If already running, reassert logging and exit
  if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    echo "[$(date -Iseconds)] idle-bridge already running (pid=$(cat "$PID_FILE"))" >> "$DEBUG_LOG"
    reassert_logging
    exit 0
  fi

  # Ensure screen logging is enabled
  reassert_logging

  # Start rotation-safe forwarding: reopen MINER_LOG on each line
  (
    stdbuf -o0 -e0 tail -n0 -F "$IDLE_LOG"         | stdbuf -o0 -e0 tr '\r' '\n'         | stdbuf -o0 -e0 sed -u -r 's/\x1B\[[0-9;?]*[ -\/]*[@-~]//g'         | while IFS= read -r line; do
        [[ -n "$line" ]] && printf '[idle-miner] %s\n' "$line" >> "$(resolve_miner_log)"
      done
  ) &
  echo $! > "$PID_FILE"
  echo "[$(date -Iseconds)] idle-bridge tail started (pid=$(cat "$PID_FILE"))" >> "$DEBUG_LOG"

  # Background: keep reasserting every 20s
  ( while true; do reassert_logging; sleep 20; done ) >/dev/null 2>&1 &
}

stop() {
  local PID_FILE="/var/run/idle-bridge.pid"
  if [[ -f "$PID_FILE" ]]; then
    kill "$(cat "$PID_FILE")" 2>/dev/null || true
    rm -f "$PID_FILE"
    echo "[$(date -Iseconds)] idle-bridge stopped" >> "$DEBUG_LOG"
  fi
}

case "${1:-}" in
  start) start ;;
  stop) stop ;;
  restart) stop; start ;;
  *) echo "usage: $0 {start|stop|restart}"; exit 1 ;;
esac
