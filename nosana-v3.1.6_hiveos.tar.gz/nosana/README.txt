Nosana wrapper v3.1.5 (HiveOS custom miner)
------------------------------------------------
Key features:
- Idle miner log spliced into /var/log/miner/nosana/nosana.log every ~20s (prefixed [idle]) for MOTD watch.
- Robust parsing for SOL/NOS balances and wallet; shown in stats 'ver' string as S:<sol> N:<nos> W:<first5>.
- If queued: hashrate passes through from idle miner; if not available, shows sentinel 999 kH/s.
- Dashboard messages: node start, monitor start, queued position changes, job start/finish, idle miner start/stop.
- Idle start robustness: run from binary dir, chmod +x, screen verification, watchdog to re-start when queued.
- Aggressive nosana.log scraping in h-stats.sh for wallet/SOL/NOS; h-stats echoes JSON and logs the computed ver.

Files:
- h-config.sh, h-manifest.conf, h-run.sh, h-stats.sh, monitor.sh, idle-screen.sh, nosana.conf

Install:
- Upload tar.gz via HiveOS custom miner. Provide EXTRA CONFIG as either full JSON or just `"idleSettings":{...}`.
