#!/usr/bin/env bash
set -uo pipefail
export LC_ALL=C
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
DEBUG_LOG="$LOG_DIR/debug.log"
MINER_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
mkdir -p "$LOG_DIR" "$RUN_DIR"; touch "$MINER_LOG" "$DEBUG_LOG" "$IDLE_LOG"
msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" >/dev/null 2>&1 || true; }
# Prefix node logs and filter noise (POSIX awk; dedupe within invocation)
node_log_filter() {
  awk '
    BEGIN { }
    function strip_ansi(s){ gsub(/\033\[[0-9;]*[A-Za-z]/, "", s); gsub(/\r/, "", s); return s }
    function trim(s){ sub(/^[[:space:]]+/, "", s); sub(/[[:space:]]+$/, "", s); return s }
    function drop_line(s){
      if (s=="" || s ~ /^[-=_]{3,}$/ || s ~ /^[|\/\\_[:space:]]{5,}$/) return 1
      if (s ~ /^(Network:|Wallet:|SOL balance:|NOS balance:|Provider:)/) return 1
      if (s ~ /^- Installing @nosana\/cli/) return 1
      if (s ~ /^Grid is recommending market/) return 1
      if (s ~ /^Grid recommended /) return 1
      if (s ~ /^Fetching market required resources/) return 1
      if (s ~ /^- Running health check$/) return 1
      if (s ~ /^✔ Health check completed$/) return 1
      if (s ~ /^- Checking if provider is healthy/) return 1
      if (s ~ /^-  Checking Specs/) return 1
      return 0
    }
    {
      s=trim(strip_ansi($0)); if (drop_line(s)) next
      if (s ~ /^✔ Provider is healthy/) s="Provider healthy"
      if (s ~ /^✔ Node specs check completed successfully/) s="Specs OK"
      # Normalize queued -> QUEUED X/Y (market <id>)
      if (index(s,"QUEUED") && index(s,"position")){
        pos=s; sub(/^.*position[[:space:]]+/, "", pos); sub(/[[:space:]].*$/, "", pos)
        id=s;  sub(/^.*market[[:space:]]+/, "", id);   sub(/[[:space:]].*$/, "", id)
        if (pos!="" && id!="") s="QUEUED " pos " (market " id ")"
      }
      if (!seen[s]++) { print "[nosana-node] " s }
    }'
}
# Ensure no leftover idle miner from previous run
if screen -ls 2>/dev/null | grep -q "${IDLE_SCREEN:-idle-miner}"; then
  bash "$MINER_DIR/idle-kill.sh" || true
  echo "[nosana] cleared idle on restart" | tee -a "$MINER_LOG"
  msg "NOS: idle miner cleared on restart"
fi


IDLE_COMMAND="$(cat "$MINER_DIR/parsed/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$MINER_DIR/parsed/idle_args" 2>/dev/null || true)"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

set_state() {
  local key="$1" val="$2"
  local vesc="${val//\\/\\\\}"; vesc="${vesc//\"/\\\"}"
  mkdir -p "$(dirname "$STATE_FILE")"; touch "$STATE_FILE"
  awk -v k="$key" -v v="$vesc" '
    BEGIN{done=0}
    $0 ~ ("^"k"=") { print k"=\""v"\""; done=1; next }
    { print }
    END{ if(!done) print k"=\""v"\"" }
  ' "$STATE_FILE" > "$STATE_FILE.tmp" && mv "$STATE_FILE.tmp" "$STATE_FILE"
}

# helper to know if idle is running
idle_running() { screen -ls 2>/dev/null | grep -q "${IDLE_SCREEN:-idle-miner}"; }

date +%s > "$MINER_DIR/nosana.start.time"
set_state status "nos - initializing"
echo "[nosana] monitor started" | tee -a "$MINER_LOG"; msg "NOS: monitor started"

bootstrap() {
  local bootlog
  bootlog="$(docker logs --since 60m nosana-node 2>&1 || true)"
  [[ -n "$bootlog" ]] && printf "%s
" "$bootlog" | node_log_filter | tee -a "$MINER_LOG"

  if printf '%s\n' "$bootlog" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
    set_state status "nos - job"
    date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
    # Kill idle immediately if running
    if idle_running; then bash "$MINER_DIR/idle-kill.sh" || true; fi
    msg "NOS: job"
  elif printf '%s\n' "$bootlog" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
    set_state status "nos - queued"
    date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
    # Start idle if not running
    if [[ -n "$IDLE_COMMAND" ]] && ! idle_running; then
      if bash "$MINER_DIR/idle-run.sh"; then :; else echo "[$(date -Iseconds)] monitor: idle start attempt failed" | tee -a "$DEBUG_LOG" "$MINER_LOG"; fi
    fi
    msg "NOS: queued"
  fi
}
bootstrap

last_pos=""
while true; do
  logchunk="$(docker logs --since 10s nosana-node 2>&1 || true)"
  if [[ -n "$logchunk" ]]; then
    printf "%s
" "$logchunk" | node_log_filter | tee -a "$MINER_LOG"
    if echo "$logchunk" | grep -Eq "position [0-9]+/[0-9]+"; then
      pos="$(echo "$logchunk" | grep -E 'position [0-9]+/[0-9]+' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/')"
      if [[ -n "$pos" && "$pos" != "$last_pos" ]]; then
        echo "[nosana] queued ${pos}" | tee -a "$MINER_LOG"; msg "NOS: queued ${pos}"
        last_pos="$pos"
      fi
      set_state status "nos - queued ${pos}"
      date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
      # Simple rule: if queued => idle must be running
      if [[ -n "$IDLE_COMMAND" ]] && ! idle_running; then
        if bash "$MINER_DIR/idle-run.sh"; then :; else echo "[$(date -Iseconds)] monitor: idle start attempt failed" | tee -a "$DEBUG_LOG" "$MINER_LOG"; msg "NOS: idle failed"; fi
      fi
    fi

    if echo "$logchunk" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
      set_state status "nos - job"
      date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
      # Kill idle immediately (no graceful shutdown)
      if idle_running; then
        bash "$MINER_DIR/idle-kill.sh" || true
      fi
      msg "NOS: job started"
    fi

    if echo "$logchunk" | grep -Eq "Nosana Node finished|Job .* completed|finished successfully|Flow .* (finished|completed)"; then
      echo "[nosana] job finished" | tee -a "$MINER_LOG"; msg "NOS: job finished"
    fi
  fi
  sleep 5





# --- EXACT docker logs mirror to miner.1 (no extras) ---
DOCKER_MIRROR_PID_FILE="/var/run/nosana.dockermirror.pid"
DOCKER_LOG_PID_FILE="/var/run/nosana.dockerlogfile.pid"
MOTD_RUN_DIR="/run/hive"
MOTD_MINER1="$MOTD_RUN_DIR/miner.1"
MOTD_STATUS1="$MOTD_RUN_DIR/miner_status.1"
ensure_exact_mirror() {
  mkdir -p "$MOTD_RUN_DIR"
  echo '{"status":"running"}' > "$MOTD_STATUS1" 2>/dev/null || true
  touch "$MOTD_RUN_DIR/MINER_RUN" 2>/dev/null || true
  # Kill any prior relays so we don't duplicate
    [[ -f "$DOCKER_MIRROR_PID_FILE" ]] && kill "$(cat "$DOCKER_MIRROR_PID_FILE")" 2>/dev/null || true
  [[ -f "$DOCKER_LOG_PID_FILE" ]] && kill "$(cat "$DOCKER_LOG_PID_FILE")" 2>/dev/null || true
  : > "$MOTD_MINER1"
  # Start a pure mirror to miner.1 (no tee/awk/headers)
  (
    command -v docker >/dev/null 2>&1 && docker logs -f nosana-node 2>&1 \
      | stdbuf -oL -eL awk '{ gsub(//,"
"); gsub(/\[[0-9;?]*[ -/]*[@-~]/,""); print; fflush(); }' \
      > "$MOTD_MINER1"
  ) &
  echo $! > "$DOCKER_MIRROR_PID_FILE"
  # Independently append the same docker logs to nosana.log (does NOT feed miner.1)
  ( command -v docker >/dev/null 2>&1 && docker logs -t -f nosana-node >> "$MINER_LOG" 2>&1 ) &
  echo $! > "$DOCKER_LOG_PID_FILE"
}
ensure_exact_mirror

# --- idle queue/job watcher ---
WATCHER_PID_FILE="/var/run/nosana.queuewatch.pid"
IDLE_SCREEN="${IDLE_SCREEN:-idle-miner}"

idle_running() {
  screen -ls 2>/dev/null | grep -q "\.${IDLE_SCREEN}"
}

start_queue_watcher() {
  # Avoid duplicates
  if [[ -f "$WATCHER_PID_FILE" ]] && kill -0 "$(cat "$WATCHER_PID_FILE")" 2>/dev/null; then
    return 0
  fi
  (
    command -v docker >/dev/null 2>&1 || exit 0
    docker logs -f nosana-node 2>&1 | while IFS= read -r line; do
      # When queued, start idle
      if echo "$line" | grep -Eiq 'QUEUED|position [0-9]+/[0-9]+'; then
        if [[ -x "$MINER_DIR/idle-run.sh" ]]; then
          if ! idle_running; then
            echo "[$(date -Iseconds)] monitor: queue detected → starting idle" >> "$DEBUG_LOG"
            bash "$MINER_DIR/idle-run.sh" >> "$DEBUG_LOG" 2>&1 || true
          fi
        fi
      fi
      # When job starts, kill idle
      if echo "$line" | grep -Eiq 'claiming job|claimed job|Job .* started|is running'; then
        if [[ -x "$MINER_DIR/idle-kill.sh" ]]; then
          if idle_running; then
            echo "[$(date -Iseconds)] monitor: job detected → killing idle" >> "$DEBUG_LOG"
            bash "$MINER_DIR/idle-kill.sh" >> "$DEBUG_LOG" 2>&1 || true
          fi
        fi
      fi
    done
  ) &
  echo $! > "$WATCHER_PID_FILE"
  echo "[$(date -Iseconds)] monitor: queue watcher started (pid=$(cat "$WATCHER_PID_FILE"))" >> "$DEBUG_LOG"
}
start_queue_watcher
# --- end watcher ---

# --- end EXACT docker logs mirror ---

done