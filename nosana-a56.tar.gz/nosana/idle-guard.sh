#!/usr/bin/env bash
set -euo pipefail
LOG_CONT="${1:-nosana-node}"
IDLE_RUN="/hive/miners/custom/nosana/idle-run.sh"
mkdir -p /var/log/miner/nosana /run/hive

send_msg(){
  local msg="$1"
  if command -v message >/dev/null 2>&1; then
    message "$msg" >/dev/null 2>&1 || true
  elif [ -x /hive/bin/message ]; then
    /hive/bin/message "$msg" >/dev/null 2>&1 || true
  else
    echo "[nosana] MESSAGE: $msg"
  fi
}

KILL_IDLE(){
  screen -S idle -X quit >/dev/null 2>&1 || true
  pkill -9 -f "qli-Client|qli-worker-AVX512|qli-worker-XMR|qli-worker-CUDA" >/dev/null 2>&1 || true
}

IDLE_RUNNING(){
  screen -ls | grep -q "\.idle\s" && return 0
  pgrep -f "qli-Client|qli-worker-AVX512|qli-worker-XMR|qli-worker-CUDA" >/dev/null 2>&1 && return 0
  return 1
}

JOB_RUNNING(){
  # returns 0 if any nosana job container is running inside the sidecar
  docker exec podman sh -lc 'podman ps --format "{{.ImageName}}" 2>/dev/null' 2>/dev/null \
    | grep -E -q "^nosana/(nn|comfy):" && return 0 || return 1
}

START_IDLE(){
  if [ -x "$IDLE_RUN" ]; then
    bash "$IDLE_RUN" >> /var/log/miner/nosana/idle-run.log 2>&1 || true
  fi
}

# immediate pre-kill (avoid tainted stats on first job line)
KILL_IDLE

# background watcher: kill on job log lines
{
  echo "[idle-guard] watching docker logs of ${LOG_CONT}"
  docker logs -f --tail=0 "${LOG_CONT}" 2>&1 \
  | stdbuf -oL -eL grep -E --line-buffered "Node has found job|Node is claiming job|Job .* is starting|Flow .* initialized|Running action container/run" \
  | while read -r line; do
      KILL_IDLE
      # no message here to avoid spam
    done
} >> /var/log/miner/nosana/idle-guard.log 2>&1 &
echo $! > /run/hive/nosana.idle-guard.pid

# scheduler: :04 kill + message, :07 restart idle if no job running
{
  echo "[idle-guard] starting :04/:07 scheduler"
  last_kill_hour=""
  last_restart_hour=""
  while :; do
    m="$(date +%M)"
    h="$(date +%H)"
    if [ "$m" = "04" ] && [ "$h" != "$last_kill_hour" ]; then
      KILL_IDLE
      send_msg "NOSANA: idle miner killed by schedule at :04 (hour ${h})"
      last_kill_hour="$h"
    fi
    if [ "$m" = "07" ] && [ "$h" != "$last_restart_hour" ]; then
      if ! JOB_RUNNING; then
        if ! IDLE_RUNNING; then
          START_IDLE
          send_msg "NOSANA: idle miner (re)started at :07 (no job running)"
        else
          # Already running; optional message omitted to reduce noise
          :
        fi
      fi
      last_restart_hour="$h"
    fi
    sleep 15
  done
} >> /var/log/miner/nosana/idle-guard.log 2>&1 &
echo $! > /run/hive/nosana.idle-guard-sched.pid
