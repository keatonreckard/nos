#!/usr/bin/env bash
# nosana monitor (v8.1.20_hiveos) — start idle miner on QUEUED, stop on JOB
set -euo pipefail
LOG_DIR="/var/log/miner/nosana"; mkdir -p "$LOG_DIR"
NOSANA_LOG="$LOG_DIR/nosana.log"
DEBUG_LOG="$LOG_DIR/debug.log"
LOCK="/var/run/nosana.monitor.lock"

exec >>"$DEBUG_LOG" 2>&1
echo "[$(date -Iseconds)] monitor: start"

# single instance
exec 9>"$LOCK"
if ! flock -n 9; then
  echo "[$(date -Iseconds)] monitor: another instance running, exit"
  exit 0
fi

start_idle() {
  if screen -ls | grep -q nosana-idle; then
    echo "[$(date -Iseconds)] monitor: idle already running"
    return 0
  fi
  echo "[$(date -Iseconds)] monitor: starting idle"
  /hive/miners/custom/nosana/idle-run.sh || echo "[$(date -Iseconds)] monitor: idle-run failed"
}

stop_idle() {
  if screen -ls | grep -q nosana-idle; then
    echo "[$(date -Iseconds)] monitor: stopping idle"
    /hive/miners/custom/nosana/idle-kill.sh || true
  fi
}

touch "$NOSANA_LOG"
# on startup, decide from last state
if grep -Eiq 'queued [0-9]+/[0-9]+| QUEUED ' "$NOSANA_LOG"; then
  start_idle
else
  stop_idle
fi

# follow log for transitions
tail -Fn0 "$NOSANA_LOG" | while read -r line; do
  l="${line%$'\r'}"
  if echo "$l" | grep -Eiq 'queued [0-9]+/[0-9]+| QUEUED '; then
    start_idle
  elif echo "$l" | grep -Eiq 'Node is claiming job|has found job|Job .* started|Flow .* running|is running|job .* started'; then
    stop_idle
  elif echo "$l" | grep -Eiq 'job .* finished|RESTARTING'; then
    # next loop will see QUEUED and start idle again
    stop_idle
  fi
done
