#!/usr/bin/env bash
# nosana h-stats.sh (v8.1.20_hiveos) — define $khs and $stats for Hive agent (no stdout)
# Keep changes minimal; DO NOT print to stdout here; agent sources this.
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"

mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

# Clean up & assemble nosana logs (strip CR and ANSI)
L=""; [[ -s "$NOSANA_LOG" ]] && L="$(tail -n 3000 "$NOSANA_LOG" | tr -d '\r')"
if [[ -z "$L" ]]; then
  C="$(docker logs --since 10m nosana-node 2>/dev/null || true)"
  [[ -n "$C" ]] && L="$(printf "%s" "$C" | tr -d '\r')"
fi
CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"

# Wallet (best-effort)
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
fi
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
fi

# Balances (optional)
if [[ -z "${sol:-}" ]]; then
  sol="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
if [[ -z "${nos:-}" ]]; then
  nos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi

# Determine status
if printf "%s\n" "$CLEAN" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* running|is running'; then
  status="nos - job"; queue=""
else
  pos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
  if [[ -n "${pos:-}" ]]; then
    status="nos - queued ${pos}"; queue="${pos}"
  elif printf "%s\n" "$CLEAN" | grep -Eqi '\bQUEUED\b'; then
    status="nos - queued"
  fi
fi

# Uptime
now=$(date +%s)
if [[ -f "$MINER_DIR/job.start.time" ]]; then start_time=$(cat "$MINER_DIR/job.start.time")
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then start_time=$(cat "$MINER_DIR/idle.start.time")
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then start_time=$(cat "$MINER_DIR/nosana.start.time")
else read -r up _ < /proc/uptime; start_time=$(( now - ${up%.*} )); fi
uptime=$((now - start_time)); ((uptime<0)) && uptime=0

# KH/s mapping
khs="0"
algo="${status:-nos}"
qfirst="$(printf "%s\n" "$algo" | sed -nE 's/.*queued[[:space:]]+([0-9]+)\/[0-9]+.*/\1/p')"
if printf "%s" "$algo" | grep -qi 'nos - job'; then
  khs="1"
elif printf "%s" "$algo" | grep -qi 'nos - initializing'; then
  khs="1"
elif printf "%s" "$algo" | grep -qi 'nos - queued' && [[ -n "${qfirst:-}" ]]; then
  khs="$qfirst"
else
  # still queued but no X/Y parsed? use small non-zero to show alive
  khs="1"
fi
khs="$(printf "%s" "$khs" | sed 's|/.*||; s/[^0-9.]//g')"; [[ -z "$khs" ]] && khs="0"

# Version string (concise)
ver=""
if [[ -n "${sol:-}" ]]; then printf -v solf "%.4f" "$sol"; ver+="S:${solf}"; fi
if [[ -n "${nos:-}" ]]; then printf -v nosf "%.4f" "$nos"; ver+="${ver:+ }N:${nosf}"; fi
if [[ -n "${wallet:-}" ]]; then ver+="${ver:+ }W:$(printf "%s" "$wallet" | cut -c1-5)"; fi

# GPU/system arrays (best-effort)
temp_json='[]'; fan_json='[]'; bus_json='[]'
if [[ -f /hive/bin/gpu-stats ]]; then
  # shellcheck disable=SC1091
  source /hive/bin/gpu-stats || true
  if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [[ "${#GPU_FAN[@]:-0}" -gt 0 ]]; then  fan_json ="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
  if [[ "${#BUS_IDS[@]:-0}" -gt 0 ]]; then
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

# JSON escaping
j_escape() { sed 's/\\/\\\\/g; s/"/\\"/g'; }
algo_json="$(printf "%s" "$algo" | j_escape)"
ver_json="$(printf "%s" "$ver"  | j_escape)"

# Build JSON (NO stdout; agent reads $stats)
stats_json="{\"hs\":[${khs}],\"hs_units\":\"khs\",\"temp\":${temp_json},\"fan\":${fan_json},\"uptime\":${uptime},\"ver\":\"${ver_json}\",\"algo\":\"${algo_json}\",\"bus_numbers\":${bus_json}}"

printf "[%s] h-stats(set vars): ver=%s | algo=%s | khs=%s | wallet=%s | sol=%s | nos=%s\n" \
  "$(date -Iseconds)" "$ver" "$algo" "$khs" "${wallet:-}" "${sol:-}" "${nos:-}" >> "$LOG_DIR/debug.log" || true

# REQUIRED by Hive agent:
khs="${khs}"
stats="${stats_json}"
# (no echo here)
