Nosana wrapper v3.1.18: ANSI-stripped sed parsing for wallet/balances; robust algo; docker logs fallback.
