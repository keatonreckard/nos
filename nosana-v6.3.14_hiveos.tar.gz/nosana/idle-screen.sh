#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
mkdir -p "$LOG_DIR"; touch "$IDLE_LOG"
# If not running, start via idle-run, then attach
if ! screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then
  bash "$MINER_DIR/idle-run.sh" || true
fi
exec screen -r nosana-idle
