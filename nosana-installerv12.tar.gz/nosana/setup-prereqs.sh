#!/usr/bin/env bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR"
log(){ echo "[$(date -Iseconds)] $*" | tee -a "$LOG_DIR/debug.log"; }

# ---------- 0) Base tools (non-interactive) ----------
log "Installing base tools (gpg, gnupg, ca-certificates, curl, lsb-release, apt-transport-https)..."
apt-get update -y || true
apt-get install -y --no-install-recommends --allow-downgrades gpg gnupg ca-certificates curl lsb-release apt-transport-https || true

# ---------- 1) Docker via HiveOS script (only if missing) ----------
if ! command -v docker >/dev/null 2>&1; then
  log "Docker not found. Installing via HiveOS docker script..."
  if [[ -x "./install_docker_slave.sh" ]]; then
    bash ./install_docker_slave.sh | tee -a "$LOG_DIR/debug.log"
  else
    wget -qO ./install_docker_slave.sh "https://github.com/filthz/fact-worker-public/releases/download/base_files/install_docker_slave.sh"
    chmod 0755 ./install_docker_slave.sh
    bash ./install_docker_slave.sh | tee -a "$LOG_DIR/debug.log"
  fi
else
  log "Docker already present."
fi

# Ensure docker service is up
if ! systemctl is-active --quiet docker; then
  log "Starting docker service..."
  systemctl start docker || true
fi

# Add user to docker group to satisfy start.sh group checks (non-fatal on HiveOS)
groupadd docker 2>/dev/null || true
usermod -aG docker user 2>/dev/null || true

# ---------- 2) NVIDIA Container Toolkit repos & install ----------
KEYRING="/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg"
install -m 0755 -d /usr/share/keyrings
log "Installing NVIDIA repo keyring..."
rm -f "$KEYRING"; curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | gpg --batch --yes --dearmor -o "$KEYRING"
chmod 0644 "$KEYRING"

# Remove any old NVIDIA sources to avoid duplicates/mis-signed entries
find /etc/apt/sources.list.d -maxdepth 1 -type f -name "*nvidia*.list" -exec rm -f {} \; || true
# Also strip any inline nvidia entries from the main sources.list (paranoid but safe)
sed -i '/nvidia\.github\.io/d' /etc/apt/sources.list 2>/dev/null || true

# Map codename to NVIDIA's ubuntuXX.XX dir
CODENAME="$(lsb_release -cs 2>/dev/null || echo jammy)"
ARCH="$(dpkg --print-architecture)"
case "$CODENAME" in
  jammy) UBUNTU_NUM="ubuntu22.04" ;;
  focal) UBUNTU_NUM="ubuntu20.04" ;;
  bionic) UBUNTU_NUM="ubuntu18.04" ;;
  *)     UBUNTU_NUM="ubuntu22.04" ;;
esac
log "Detected: codename=$CODENAME arch=$ARCH mapped=$UBUNTU_NUM"

LIST_TMP="/tmp/nvidia-container-toolkit.list"
CANDIDATES=(
  "https://nvidia.github.io/libnvidia-container/stable/${UBUNTU_NUM}/${ARCH}/nvidia-container-toolkit.list"
  "https://nvidia.github.io/libnvidia-container/stable/${UBUNTU_NUM}/nvidia-container-toolkit.list"
  "https://nvidia.github.io/libnvidia-container/stable/${ARCH}/nvidia-container-toolkit.list"
  "https://nvidia.github.io/libnvidia-container/stable/nvidia-container-toolkit.list"
)
GOT=""
for url in "${CANDIDATES[@]}"; do
  if curl -fsSL "$url" -o "$LIST_TMP"; then
    GOT="$url"
    break
  fi
done
if [[ -n "$GOT" ]]; then
  log "Using NVIDIA repo list: $GOT"
  sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' "$LIST_TMP" > /etc/apt/sources.list.d/nvidia-container-toolkit.list
else
  log "WARNING: Could not fetch NVIDIA repo list from any candidate URL."
fi

# Reset apt cache to avoid stale index & signature issues
apt-get clean
rm -rf /var/lib/apt/lists/*
apt-get update -y || true

# Install toolkit if present; otherwise fall back to runtime packages
if ! apt-get install -y --allow-downgrades nvidia-container-toolkit; then
  log "nvidia-container-toolkit not found; trying fallbacks (nvidia-container-runtime, nvidia-docker2)..."
  apt-get install -y --allow-downgrades nvidia-container-runtime || true
  apt-get install -y --allow-downgrades nvidia-docker2 || true
fi

# Configure docker runtime if nvidia-ctk exists
if command -v nvidia-ctk >/dev/null 2>&1; then
  log "Configuring docker runtime for NVIDIA via nvidia-ctk..."
  nvidia-ctk runtime configure --runtime=docker || true
  systemctl restart docker || true
else
  log "WARNING: nvidia-ctk not found; skipping runtime configure."
fi

# Non-fatal sanity check
if docker run --rm --gpus all nvidia/cuda:11.0.3-base-ubuntu18.04 nvidia-smi >/dev/null 2>&1; then
  log "NVIDIA toolkit OK inside container."
else
  log "WARNING: nvidia-smi check in container failed (continuing)."
fi

exit 0
