#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
LOG_DIR="/var/log/miner/nosana"
DEBUG_LOG="$LOG_DIR/debug.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
mkdir -p "$LOG_DIR"; touch "$DEBUG_LOG" "$NOSANA_LOG"
msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

rc=0
RUN_DIR="/run/hive"
MOTD_MINER2="$RUN_DIR/miner.2"
MOTD_STATUS2="$RUN_DIR/miner_status.2"
CUR_MINER="$RUN_DIR/cur_miner"
CUR_MINER_BAK="$RUN_DIR/cur_miner.nosana.bak"
if screen -ls 2>/dev/null | grep -q "nosana-idle"; then
  screen -S "${IDLE_SCREEN:-idle-miner}" -X quit || true
fi

# Also SIGKILL any leftover idle process by screen child (best effort)
pkill -9 -f "\[idle\]" 2>/dev/null || rc=$?

# Stop motd tailer and clean files
if [ -f "$RUN_DIR/.idle_to_motd.pid" ]; then kill "$(cat "$RUN_DIR/.idle_to_motd.pid" 2>/dev/null)" 2>/dev/null || true; rm -f "$RUN_DIR/.idle_to_motd.pid"; fi
rm -f "$MOTD_MINER2" "$MOTD_STATUS2" 2>/dev/null || true
# Restore cur_miner if we backed it up
if [ -f "$CUR_MINER_BAK" ]; then mv -f "$CUR_MINER_BAK" "$CUR_MINER" 2>/dev/null || true; fi
echo "[$(date -Iseconds)] idle-kill: idle miner killed" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
msg "NOS: idle miner killed"
exit 0

# Stop MOTD relay if running
if [[ -f /var/run/idle.motd.pid ]]; then
  pid="$(cat /var/run/idle.motd.pid 2>/dev/null)"
  [[ -n "$pid" ]] && kill "$pid" 2>/dev/null || true
  rm -f /var/run/idle.motd.pid
fi
echo '{"status":"stopped"}' > /run/hive/miner_status.2 2>/dev/null || true
printf "\r\nIdle miner stopped.\r\n" > /run/hive/miner.2 2>/dev/null || true
