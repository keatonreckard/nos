#!/usr/bin/env bash
# nosana/h-stats.sh (v41)
# Prints two lines:
#   1) total khs (float)
#   2) JSON with fields: hs, hs_units, temp, fan, uptime, ver, algo, bus_numbers
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

# ---- helpers ----
strip_ansi() { sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g'; }

now() { date +%s; }

safe_tail() {
  local n="$1" f="$2"
  [[ -s "$f" ]] && tail -n "$n" "$f" || true
}

json_arr_from_space_list() {
  # input: space-separated items
  awk 'BEGIN{printf "["} {for(i=1;i<=NF;i++){if(i>1)printf ","; printf $i}} END{printf "]"}'
}

# ---- load cached state (if any) ----
status=""; queue=""; sol=""; nos=""; wallet=""
if [[ -f "$STATE_FILE" ]]; then
  # shellcheck disable=SC1090
  source "$STATE_FILE" || true
fi

# ---- gather & clean logs ----
L=""
if [[ -s "$NOSANA_LOG" ]]; then
  L="$(safe_tail 3000 "$NOSANA_LOG" | tr -d '\r' | strip_ansi)"
fi
IL=""
if [[ -s "$IDLE_LOG" ]]; then
  IL="$(safe_tail 200 "$IDLE_LOG" | tr -d '\r' | strip_ansi)"
fi

# ---- extract wallet / balances (preserve last known when missing) ----
w2="$(printf "%s\n" "$L" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
[[ -z "$w2" ]] && w2="$(printf "%s\n" "$L" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
[[ -n "$w2" ]] && wallet="$w2"

s2="$(printf "%s\n" "$L" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
[[ -n "$s2" ]] && sol="$s2"

n2="$(printf "%s\n" "$L" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
[[ -n "$n2" ]] && nos="$n2"

# persist back (best-effort)
{
  echo "wallet=${wallet}"
  echo "sol=${sol}"
  echo "nos=${nos}"
  [[ -n "${queue:-}" ]] && echo "queue=${queue}" || true
} > "$STATE_FILE.tmp" 2>/dev/null || true
mv -f "$STATE_FILE.tmp" "$STATE_FILE" 2>/dev/null || true

# ---- build version string ----
ver=""
if [[ -n "${sol:-}" ]]; then printf -v sf "%.4f" "$sol"; ver+="S:${sf}"; fi
if [[ -n "${nos:-}" ]]; then printf -v nf "%.4f" "$nos"; ver+="${ver:+ }N:${nf}"; fi
if [[ -n "${wallet:-}" ]]; then ver+="${ver:+ }W:$(printf '%s' "$wallet" | cut -c1-5)"; fi

# ---- queue status & algo base ----
qpos="$(printf "%s\n" "$L" | sed -nE 's/.*QUEUED.*position[[:space:]]*([0-9]+)\/([0-9]+).*/\1\/\2/p' | tail -n1)"
algo_base="nos - initializing"
if [[ -n "$qpos" ]]; then
  queue="$qpos"
  algo_base="nos - queued $qpos"
fi

# ---- detect idle mode & extract hashrates ----
mode="qubic"
cpu_hs=0
gpu_hs=0

if printf "%s\n" "$IL" | grep -q "\[XMR\]"; then
  # XMR active (CPU only)
  mode="xmr"
  # Prefer avg it/s on XMR lines
  cpu_hs="$(printf "%s\n" "$IL" | awk '/\[XMR\]/ && /avg it\/s/{for(i=1;i<=NF;i++) if($i=="avg" && $(i+1)=="it/s"){print $(i-1)} }' | tail -n1)"
  [[ -z "$cpu_hs" ]] && cpu_hs="$(printf "%s\n" "$IL" | sed -nE 's/.*\[XMR\].* ([0-9]+) it\/s.*/\1/p' | tail -n1)"
  [[ -z "$cpu_hs" ]] && cpu_hs=0
else
  # Qubic: CPU + GPU
  # CPU from AVX* avg it/s
  cpu_hs="$(printf "%s\n" "$IL" | sed -nE 's/.*\[(AVX512|AVX2|GENERIC)\].* ([0-9]+) avg it\/s.*/\2/p' | tail -n1)"
  [[ -z "$cpu_hs" ]] && cpu_hs="$(printf "%s\n" "$IL" | sed -nE 's/.*\[(AVX512|AVX2|GENERIC)\].* ([0-9]+) it\/s.*/\2/p' | tail -n1)"
  [[ -z "$cpu_hs" ]] && cpu_hs=0
  # GPU from CUDA avg it/s
  gpu_hs="$(printf "%s\n" "$IL" | sed -nE 's/.*\[CUDA\].* ([0-9]+) avg it\/s.*/\1/p' | tail -n1)"
  [[ -z "$gpu_hs" ]] && gpu_hs="$(printf "%s\n" "$IL" | sed -nE 's/.*\[GPU\][^:]*: GPU #[0-9]+: ([0-9]+) it\/s.*/\1/p' | tail -n1)"
  [[ -z "$gpu_hs" ]] && gpu_hs=0
fi

# form hs array (units = hs)
hs_list=""
if [[ "$mode" == "xmr" ]]; then
  hs_list="$cpu_hs"
else
  # separate entries: [gpu, cpu]
  hs_list="$gpu_hs $cpu_hs"
fi
# compute total kh/s
sum_hs=0
for v in $hs_list; do
  if [[ "$v" =~ ^[0-9]+$ ]]; then
    sum_hs=$((sum_hs + v))
  fi
done
khs="$(python3 - <<'PY'\nimport sys\nv=int(sys.argv[1]);print(f\"{v/1000:.6f}\")\nPY\n$sum_hs)"

# uptime heuristic: seconds since last write of whichever log is newer
u1=0; u2=0; now_ts="$(now)"
[[ -f "$NOSANA_LOG" ]] && u1=$(( now_ts - $(stat -c %Y "$NOSANA_LOG") ))
[[ -f "$IDLE_LOG"   ]] && u2=$(( now_ts - $(stat -c %Y "$IDLE_LOG")   ))
uptime=$(( now_ts - (now_ts - (u1 if u1>u2 else u2)) )) # dummy keep; fallback below
# more sensible: try state file timestamp if present
if [[ -f "$STATE_FILE" ]]; then
  uptime=$(( now_ts - $(stat -c %Y "$STATE_FILE") ))
else
  # fallback to newer of logs
  if [[ -f "$NOSANA_LOG" && -f "$IDLE_LOG" ]]; then
    lt=$(stat -c %Y "$NOSANA_LOG"); rt=$(stat -c %Y "$IDLE_LOG")
    base=$(( lt>rt ? lt : rt ))
    uptime=$(( now_ts - base ))
  elif [[ -f "$NOSANA_LOG" ]]; then
    base=$(stat -c %Y "$NOSANA_LOG"); uptime=$(( now_ts - base ))
  elif [[ -f "$IDLE_LOG" ]]; then
    base=$(stat -c %Y "$IDLE_LOG"); uptime=$(( now_ts - base ))
  else
    uptime=0
  fi
fi

# finalize algo string
algo="${algo_base} - idle ${mode}"

# ---- build JSON ----
# hs array
hs_json="$(printf "%s\n" "$hs_list" | json_arr_from_space_list)"
temp_json="[]"
fan_json="[]"
bus_json="[]"

# echo results
echo "$khs"
printf '{"hs":%s,"hs_units":"hs","temp":%s,"fan":%s,"uptime":%d,"ver":"%s","algo":"%s","bus_numbers":%s}\n' \
  "$hs_json" "$temp_json" "$fan_json" "$uptime" \
  "$(printf "%s" "$ver")" "$(printf "%s" "$algo")" "$bus_json"
