#!/usr/bin/env bash
set -euo pipefail
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

cmd="${1:-start}"
if [[ "$cmd" == "start" ]]; then
  # stream idle log into nosana log with prefix
  ( tail -n0 -F "$IDLE_LOG" | while IFS= read -r line; do
      printf '[idle-miner] %s\n' "$line" >> "$NOSANA_LOG"
    done ) &
  echo $! > "$LOG_DIR/idle-bridge.pid"
elif [[ "$cmd" == "stop" ]]; then
  [[ -f "$LOG_DIR/idle-bridge.pid" ]] && kill "$(cat "$LOG_DIR/idle-bridge.pid")" 2>/dev/null || true
fi
