#!/usr/bin/env bash
# Reports Hive stats JSON for the wrapper, passing through idle miner stats (agnostic).
set -euo pipefail

RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
IDLE_PID_FILE="$RUN_DIR/nosana_idle.pid"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"

status="nos - initializing"
queue=""
sol=""
nos=""
wallet=""
idle_enabled=0

if [[ -f "$STATE_FILE" ]]; then
  # shellcheck disable=SC1090
  source "$STATE_FILE"
fi

format4() {
  local x="${1:-}"
  if [[ -z "$x" ]]; then printf ""; return; fi
  awk -v n="$x" 'BEGIN{printf("%.4f", n+0)}'
}

parse_idle_stats() {
  local tail_lines=400
  local hs_val="" hs_unit="" khs="0" acc="" rej=""
  local L
  if [[ ! -s "$IDLE_LOG" ]]; then echo "0|0|0"; return; fi
  L="$(tail -n "$tail_lines" "$IDLE_LOG")"

  if echo "$L" | grep -Eiq 'Total( |_)Speed:|Total Hashrate:|Total speed:|speed .* H/s|hashrate' ; then
    hs_val=$(echo "$L" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1 | awk '{print $1}')
    hs_unit=$(echo "$L" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1 | awk '{print $2}' | sed 's#/s##I')
  fi

  if [[ -n "$hs_val" && -n "$hs_unit" ]]; then
    case "${hs_unit^^}" in
      H)   khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v/1000)}') ;;
      KH)  khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v)}') ;;
      MH)  khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v*1000)}') ;;
      GH)  khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v*1000*1000)}') ;;
      *)   khs="0" ;;
    esac
  fi

  if echo "$L" | grep -Eiq 'Shares:|accepted|A:[0-9]+' ; then
    if echo "$L" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 >/dev/null 2>&1 ; then
      acc=$(echo "$L" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f1)
      rej=$(echo "$L" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f2)
    elif echo "$L" | grep -Eio 'A:[0-9]+' | tail -n1 >/dev/null 2>&1 ; then
      acc=$(echo "$L" | grep -Eio 'A:[0-9]+' | tail -n1 | cut -d: -f2)
      rej=$(echo "$L" | grep -Eio 'R:[0-9]+' | tail -n1 | cut -d: -f2)
    fi
  fi

  [[ -z "$acc" ]] && acc="0"
  [[ -z "$rej" ]] && rej="0"
  echo "${khs}|${acc}|${rej}"
}

idle_running=0
if [[ -f "$IDLE_PID_FILE" ]]; then
  pid="$(cat "$IDLE_PID_FILE" 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]] && kill -0 "$pid" 2>/dev/null; then
    idle_running=1
  fi
fi

sol4="$(format4 "${sol:-}")"
nos4="$(format4 "${nos:-}")"
ver="SOL:${sol4:-N/A} NOS:${nos4:-N/A} WALLET:${wallet:-N/A}"

algo="${status:-nos}"
khs="0"
ar_acc="0"
ar_rej="0"

if echo "$status" | grep -qi 'queued' && [[ "$idle_running" -eq 1 ]]; then
  IFS='|' read -r khs ar_acc ar_rej <<<"$(parse_idle_stats)"
fi

stats=$(cat <<JSON
{"hs":[${khs}],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"$ver","ar":[${ar_acc},${ar_rej}],"algo":"$algo"}
JSON
)

echo "${khs}"
echo "${stats}"
