Nosana HiveOS wrapper v0.3.6
Shows 'nosana-job' in algo when queued or running.
