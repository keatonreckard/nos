#!/usr/bin/env bash
# tolerant h-stats: never exit non-zero; always print two lines
set +e

NOSLOG="/var/log/miner/nosana/nosana.log"

status="nos - initializing"
algo="nos - initializing"
wallet=""
sol=""
nos=""
queue=""

if [ -s "$NOSLOG" ]; then
  cleaned=$(tr -d '\r' < "$NOSLOG")
  # balances/wallet
  w=$(echo "$cleaned" | grep -E '^Wallet:\s+[A-Za-z0-9]{32,64}' | tail -n1 | awk '{print $2}')
  s=$(echo "$cleaned" | grep -E 'SOL balance:\s+[0-9]+(\.[0-9]+)?' | tail -n1 | sed -n 's/.*SOL balance:\s*\([0-9.]\+\).*/\1/p')
  n=$(echo "$cleaned" | grep -E 'NOS balance:\s+[0-9]+(\.[0-9]+)?' | tail -n1 | sed -n 's/.*NOS balance:\s*\([0-9.]\+\).*/\1/p')
  [ -n "$w" ] && wallet="$w"
  [ -n "$s" ] && sol="$s"
  [ -n "$n" ] && nos="$n"

  # detect job/queue
  if echo "$cleaned" | grep -Eiq 'claimed job|Job .* starting|started successfully|is resuming|resumed|is running'; then
    status="nos - job"
  else
    qp=$(echo "$cleaned" | grep -E 'QUEUED.*position [0-9]+/[0-9]+' | tail -n1 | sed -n 's/.*position \([0-9]\+\/[0-9]\+\).*/\1/p')
    if [ -n "$qp" ]; then
      status="nos - queued $qp"
      queue="$qp"
    fi
  fi
fi

# Per your request: map both queued and job states to 'nosana-job' so overview shows it
if echo "$status" | grep -Eq 'queued|job'; then
  algo="nosana-job"
else
  algo="$status"
fi

# GPU temps/fans via nvidia-smi or use Hive gpu-stats if available
temp_json='[]'; fan_json='[]'; bus_json='[]'

if [ -f /hive/bin/gpu-stats ]; then
  # shellcheck disable=SC1091
  . /hive/bin/gpu-stats 2>/dev/null
  if [ "${#GPU_TEMP[@]}" -gt 0 ] 2>/dev/null; then
    temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"
  fi
  if [ "${#GPU_FAN[@]}" -gt 0 ] 2>/dev/null; then
    fan_json="["$(printf "%s," "${GPU_FAN[@]}" | sed 's/,$//')"]"
  fi
  if [ "${#BUS_IDS[@]}" -gt 0 ] 2>/dev/null; then
    buses=()
    for b in "${BUS_IDS[@]}"; do
      d=$((16#${b%%:*}))
      buses+=("$d")
    done
    bus_json="["$(printf "%s," "${buses[@]}" | sed 's/,$//')"]"
  fi
fi

if [ "$temp_json" = "[]" ] || [ "$fan_json" = "[]" ]; then
  if command -v nvidia-smi >/dev/null 2>&1; then
    mapfile -t LINES < <(nvidia-smi --query-gpu=temperature.gpu,fan.speed --format=csv,noheader,nounits 2>/dev/null | sed 's/ N\/A/ -1/g')
    temps=(); fans=()
    for l in "${LINES[@]}"; do
      t=$(echo "$l" | cut -d',' -f1 | tr -d ' ')
      f=$(echo "$l" | cut -d',' -f2 | tr -d ' ')
      [ -n "$t" ] && temps+=("$t")
      [ -n "$f" ] && fans+=("$f")
    done
    if [ "${#temps[@]}" -gt 0 ]; then
      temp_json="["$(printf "%s," "${temps[@]}" | sed 's/,$//')"]"
    fi
    if [ "${#fans[@]}" -gt 0 ]; then
      fan_json="["$(printf "%s," "${fans[@]}" | sed 's/,$//')"]"
    fi
  fi
fi

format4() { awk -v n="${1:-0}" 'BEGIN{printf("%.4f", n+0)}'; }
sol4="N/A"; [ -n "$sol" ] && sol4="$(format4 "$sol")"
nos4="N/A"; [ -n "$nos" ] && nos4="$(format4 "$nos")"
wal5="N/A"; [ -n "$wallet" ] && wal5="$(printf '%s' "$wallet" | cut -c1-5)"
ver="S:${sol4} N:${nos4} W:${wal5}"

# Idle hashrate passthrough not required for algo mapping; report 0 for hs
khs="0"
ar_acc="0"; ar_rej="0"
uptime=$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 0)

stats=$(cat <<JSON
{"hs":[${khs}],"hs_units":"khs","temp":${temp_json},"fan":${fan_json},"uptime":${uptime},"ver":"${ver}","ar":[${ar_acc},${ar_rej}],"algo":"${algo}","bus_numbers":${bus_json}}
JSON
)

# Hive requires: first line khs, second line JSON
echo "$khs"
echo "$stats"
exit 0
