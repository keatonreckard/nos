#!/usr/bin/env bash
set -euo pipefail
# This is a thin wrapper used by monitor.sh. It is kept for compatibility if you want to start it manually.
exec /hive/miners/custom/nosana/monitor.sh start_idle manual
