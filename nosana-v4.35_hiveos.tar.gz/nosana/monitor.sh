#!/usr/bin/env bash
set -euo pipefail
LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
PARSED_DIR="/hive/miners/custom/nosana/parsed"
IDLE_CMD_FILE="$PARSED_DIR/idle_command"
IDLE_ARGS_FILE="$PARSED_DIR/idle_args"

log(){ echo "[nosana] $*" | tee -a "$NOSANA_LOG" >/dev/null; }

is_idle_running(){
  screen -ls | grep -q "[[:space:]]nosana-idle[[:space:]]" || pgrep -f "SCREEN.*nosana-idle" >/dev/null 2>&1
}

start_idle(){
  local reason="${1:-manual}"
  if is_idle_running; then
    return 0
  fi
  local CMD=""
  local ARGS=""
  [[ -f "$IDLE_CMD_FILE" ]] && CMD="$(tr -d '\r' < "$IDLE_CMD_FILE")" || CMD="${NOSANA_IDLE_CMD:-}"
  [[ -f "$IDLE_ARGS_FILE" ]] && ARGS="$(tr -d '\r' < "$IDLE_ARGS_FILE")" || ARGS="${NOSANA_IDLE_ARGS:-}"
  if [[ -z "$CMD" ]]; then
    log "idle command not set; skipping start"
    return 1
  fi
  if [[ ! -x "$CMD" ]]; then
    # Try to chmod if present
    [[ -f "$CMD" ]] && chmod +x "$CMD" || true
  fi
  local CWD="/"
  if [[ "$CMD" == */* ]]; then
    CWD="$(dirname "$CMD")"
    CMD="$(basename "$CMD")"
  fi
  log "start_idle(reason=$reason)"
  # Use screen with -L to ensure logs go to idle.log without extra pipes that might swallow output
  screen -L -Logfile "$IDLE_LOG" -dmS nosana-idle bash -lc "cd \"$CWD\" && exec stdbuf -oL -eL \"./$CMD\" $ARGS"
  sleep 0.4
  if is_idle_running; then
    log "idle miner started: ${CWD}/${CMD} ${ARGS}"
  else
    log "idle miner failed to start"
  fi
}

stop_idle(){
  local reason="${1:-unknown}"
  if is_idle_running; then
    screen -S nosana-idle -X quit || true
    pkill -f "SCREEN.*nosana-idle" || true
    log "idle miner stopped ($reason)"
  fi
}

# Emit a marker so we know monitor is active
log "monitor started"

# Startup sweep: if we boot into queued state already in the last 200 lines, start idle
if grep -Eiq -- "-[[:space:]]+QUEUED|\\[nosana\\][[:space:]]+queued" "$NOSANA_LOG" 2>/dev/null; then
  # but only if no RUNNING seen after last QUEUED
  if [[ -z "$(tac "$NOSANA_LOG" | sed -n '1,200p' | grep -m1 -Eo '(QUEUED|RUNNING)')" || "$(tac "$NOSANA_LOG" | sed -n '1,200p' | grep -m1 -Eo '(QUEUED|RUNNING)')" == "QUEUED" ]]; then
    start_idle "boot-queued"
  fi
fi

# Stream logs and react to state transitions
tail -n0 -F "$NOSANA_LOG" 2>/dev/null | while IFS= read -r line; do
  # Normalize
  lower="$(tr '[:upper:]' '[:lower:]' <<<"$line")"
  if grep -q "queued" <<<"$lower"; then
    start_idle "queued"
  elif grep -q -E " running |job started|starting job|picked up job" <<<"$lower"; then
    stop_idle "job-start"
  elif grep -q -E "job finished|completed" <<<"$lower"; then
    # after job finishes, node usually re-enters queue shortly; we don't auto-start here,
    # monitor will catch the next QUEUED line
    :
  fi
done
