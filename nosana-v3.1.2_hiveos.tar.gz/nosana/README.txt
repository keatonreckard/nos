Nosana wrapper v3.1.2.2 (HiveOS custom miner)
------------------------------------------------
Changes in 3.1.1:
- Idle miner log is spliced into /var/log/miner/nosana/nosana.log every ~20s (prefixed with [idle]) for MOTD watch.
- Robust parsing for SOL/NOS balances and wallet; shown in stats 'ver' string as S:<sol> N:<nos> W:<first5>.
- If queued: hashrate passes through from idle miner; if not available, shows sentinel 999 kH/s so the main dashboard indicates activity.
- Dashboard messages: node start, monitor start, queued position changes, job start/finish, idle miner start/stop.
- Version bumped to 3.0.

Files:
- h-config.sh, h-manifest.conf, h-run.sh, h-stats.sh, monitor.sh, idle-screen.sh, nosana.conf

Install:
- Upload tar.gz via HiveOS custom miner. This package expects docker, screen and nosana CLI will be handled automatically.

Patch notes: Improve idle start resilience (unconditional on queued) + watchdog.

Patch notes (3.1.2): nosana.conf now stores RAW extra config (no VERBOSE= prefix). Parsing is robust for bare idleSettings snippets.
