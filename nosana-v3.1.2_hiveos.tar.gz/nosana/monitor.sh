#!/usr/bin/env bash
set -uo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
DEBUG_LOG="$LOG_DIR/debug.log"
MINER_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

IDLE_PID_FILE="$RUN_DIR/nosana_idle.pid"
LOCK_FILE="$RUN_DIR/nosana_monitor.lock"
IDLE_SCREEN="nosana-idle"

IDLE_COMMAND="$(cat "$MINER_DIR/parsed/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$MINER_DIR/parsed/idle_args" 2>/dev/null || true)"

[[ -f "$LOCK_FILE" ]] && { echo "[$(date -Iseconds)] monitor: removing stale lock" >> "$DEBUG_LOG"; rm -f "$LOCK_FILE"; }
echo $$ > "$LOCK_FILE"
trap 'rm -f "$LOCK_FILE"' EXIT

set_state() {
  local key="$1" val="$2"
  local esc
  esc=$(printf '%s' "$val" | sed -e 's/[\\/&]/\\&/g' -e 's/"/\\"/g')
  touch "$STATE_FILE"
  if grep -q "^${key}=" "$STATE_FILE"; then
    sed -i -E "s#^(${key}=).*#\\1\"${esc}\"#g" "$STATE_FILE"
  else
    echo "${key}=\"${val}\"" >> "$STATE_FILE"
  fi
}

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

start_idle() {
  echo "[$(date -Iseconds)] monitor: start_idle hook (cmd:'$IDLE_COMMAND' args:'$IDLE_ARGS')" >> "$DEBUG_LOG"
  echo "[$(date -Iseconds)] monitor: attempting to start idle (cmd:'$IDLE_COMMAND' args:'$IDLE_ARGS')" >> "$DEBUG_LOG"
  if [[ -z "$IDLE_COMMAND" ]]; then echo "[$(date -Iseconds)] monitor: no IDLE_COMMAND configured; not starting idle" >> "$DEBUG_LOG"; return 0; fi
  if screen -ls | grep -q "[.]${IDLE_SCREEN}[[:space:]]"; then
    # already running
    return 0
  fi
  local args="${IDLE_ARGS//%WORKER_NAME%/${WORKER_NAME:-worker}}"
  date +%s > "$MINER_DIR/idle.start.time"
  rm -f "$MINER_DIR/job.start.time"
  # start in dedicated screen session and tee to idle.log
  screen -dmS "$IDLE_SCREEN" bash -lc "$IDLE_COMMAND $args 2>&1 | tee -a '$IDLE_LOG'"
  # best-effort pid discovery
  sleep 0.5
  pid="$(screen -ls | awk '/\.'"$IDLE_SCREEN"'\t/ {print $1}' | sed 's/\..*//')"
  [[ -n "$pid" ]] && echo "$pid" > "$IDLE_PID_FILE" || true
  echo "[nosana] queued → idle miner started" | tee -a "$MINER_LOG"
  msg "NOS: queued → started idle miner"
}

stop_idle() {
  # kill by screen name if present
  if screen -ls | grep -q "[.]${IDLE_SCREEN}[[:space:]]"; then
    screen -S "$IDLE_SCREEN" -X quit || true
  fi
  # fallback by pid
  if [[ -f "$IDLE_PID_FILE" ]]; then
    local pid=$(cat "$IDLE_PID_FILE")
    if kill -0 "$pid" 2>/dev/null; then
      kill "$pid" 2>/dev/null || true
      sleep 1
      kill -9 "$pid" 2>/dev/null || true
    fi
    rm -f "$IDLE_PID_FILE"
  fi
  echo "[nosana] idle miner stopped" | tee -a "$MINER_LOG"
  msg "NOS: stopped idle miner"
}

bootstrap_state_once() {
  local SINCE="${1:-60m}"
  local bootlog
  bootlog="$(docker logs --since "$SINCE" nosana-node 2>&1 || true)"
  if [[ -z "$bootlog" ]]; then
    set_state status "nos - initializing"
    echo "[nosana] initializing" | tee -a "$MINER_LOG"
    return 0
  fi
  local w sb nb
  w="$(echo "$bootlog" | grep -E '^Wallet:\s+[A-Za-z0-9]{32,48}' | tail -n1 | awk '{print $2}' 2>/dev/null || true)"
  [[ -n "${w:-}" ]] && set_state wallet "$w"
  sb="$(echo "$bootlog" | grep -E 'SOL balance:\s*[0-9]+([.][0-9]+)?' | tail -n1 | awk '{print $3}' 2>/dev/null || true)"
  nb="$(echo "$bootlog" | grep -E 'NOS balance:\s*[0-9]+([.][0-9]+)?' | tail -n1 | awk '{print $3}' 2>/dev/null || true)"
  [[ -n "${sb:-}" ]] && set_state sol "$sb"
  [[ -n "${nb:-}" ]] && set_state nos "$nb"

  if echo "$bootlog" | grep -Eqi 'claimed job|Job .* started|Flow .* started'; then
    set_state status "nos - job"; set_state queue ""
    date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
    stop_idle
    msg "NOS: job started"
  elif echo "$bootlog" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
    local pos
    pos="$(echo "$bootlog" | grep -E 'position [0-9]+/[0-9]+' | tail -n1 | sed -n 's/.*position \([0-9]\+\/[0-9]\+\).*/\1/p' 2>/dev/null || true)"
    if [[ -n "${pos:-}" ]]; then
      set_state status "nos - queued ${pos}"; set_state queue "${pos}"
      msg "NOS: queued ${pos}"
    else
      set_state status "nos - queued"
      msg "NOS: queued"
    fi
    date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
    start_idle
  else
    set_state status "nos - initializing"
  fi
}

date +%s > "$MINER_DIR/nosana.start.time"
set_state status "nos - initializing"
echo "[nosana] monitor started" | tee -a "$MINER_LOG"
msg "NOS: monitor started"

bootstrap_state_once "60m"
last_hb=$(date +%s)
last_idle_flush=0
last_pos=""

# Try to initialize last_pos from state
if [[ -f "$STATE_FILE" ]]; then
  . "$STATE_FILE"
  last_pos="${queue:-}"
fi

while true; do
  { 
    logchunk="$(docker logs --since 10s nosana-node 2>&1 || true)"
    if [[ -n "$logchunk" ]]; then
      printf "%s\n" "$logchunk" | tee -a "$MINER_LOG"
      while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        if [[ "$line" =~ ^Wallet:\ +([A-Za-z0-9]{32,48}) ]]; then set_state wallet "${BASH_REMATCH[1]}"; fi
        if [[ "$line" =~ SOL\ balance:\ +([0-9]+([.][0-9]+)?) ]]; then set_state sol "${BASH_REMATCH[1]}"; fi
        if [[ "$line" =~ NOS\ balance:\ +([0-9]+([.][0-9]+)?) ]]; then set_state nos "${BASH_REMATCH[1]}"; fi

        if [[ "$line" =~ \ position\ ([0-9]+)\/([0-9]+) ]] || [[ "$line" =~ ^.*QUEUED.*position\ ([0-9]+)\/([0-9]+) ]]; then
          pos="${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
          set_state status "nos - queued ${pos}"; set_state queue "${pos}"
          if [[ "$pos" != "$last_pos" ]]; then
            echo "[nosana] queued ${pos}" | tee -a "$MINER_LOG"
            msg "NOS: queued ${pos}"
            last_pos="$pos"
          fi
          date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
          start_idle
        fi

        if echo "$line" | grep -Eqi 'claimed job|Job .* started|Flow .* started'; then
          set_state status "nos - job"; set_state queue ""
          echo "[nosana] job started" | tee -a "$MINER_LOG"
          msg "NOS: job started"
          date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
          stop_idle
        fi

        if echo "$line" | grep -Eq "Nosana Node finished|Job .* completed|Flow .* (finished|completed)"; then
          echo "[nosana] job finished" | tee -a "$MINER_LOG"
          msg "NOS: job finished"
          bootstrap_state_once "10m"
        fi
      done <<< "$logchunk"
    fi

    # periodically splice last few idle lines into main miner log for motd
    now=$(date +%s)
    if (( now - last_idle_flush >= 20 )) && [[ -s "$IDLE_LOG" ]]; then
      tail -n 5 "$IDLE_LOG" | sed 's/^/[idle] /' >> "$MINER_LOG"
      last_idle_flush=$now
    fi
  } || true

  now=$(date +%s)
  if (( now - last_hb >= 30 )); then
    echo "[nosana] hb $(date -Iseconds)" | tee -a "$MINER_LOG"
    last_hb=$now
  fi

    # Idle miner watchdog: if queued and idle screen not running for >20s, start it
    queued_now=""
    if [[ -f "$STATE_FILE" ]]; then . "$STATE_FILE"; fi
    if echo "${status:-}" | grep -qi "queued"; then
      if ! screen -ls | grep -q "[.]"${IDLE_SCREEN}"[[:space:]]"; then
        if (( now - last_idle_flush >= 20 )); then
          echo "[$(date -Iseconds)] monitor: watchdog starting idle (status=$status)" >> "$DEBUG_LOG"
          start_idle
        fi
      fi
    fi
  sleep 5
done
