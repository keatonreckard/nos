NOSANA (HiveOS custom miner package)
-----------------------------------
Built: 2025-08-21T16:30:52

v8.0.8_hiveos:
- Guarantees **no "ar"** in the output JSON: we sanitize the final JSON string right before printing.
- Keeps your new idle logic files as uploaded.
- Preserves stats behavior: algo/version untouched; KH/s = 1 for init+job, X for queued X/Y.
