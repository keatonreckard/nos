\
    #!/usr/bin/env bash
/hive/miners/custom/nosana/install-stats-wrapper.sh || true
    set -euo pipefail

    MINER_DIR="/hive/miners/custom/nosana"
    LOG_DIR="/var/log/miner/nosana"
    mkdir -p "$LOG_DIR"

    echo "[h-run] $(date -Iseconds) starting nosana v$(cat "$MINER_DIR/VERSION" 2>/dev/null || echo '5.0.11')" >> "$LOG_DIR/agent.log"

    # Kill any lingering idle miner first
    kill_idle() {
      # Kill screen sessions that look like idle/qli/qubic
      if command -v screen >/dev/null 2>&1; then
        screen -ls | awk '/\t[0-9]+\.(idle|idle-run|qli|qubic)/{print $1}' | while read -r sid; do
          screen -S "$sid" -X quit || true
        done
      fi
      # Kill known idle miner binaries if running
      pkill -f 'qli-Client'    >/dev/null 2>&1 || true
      pkill -f 'qubic.li'      >/dev/null 2>&1 || true
      pkill -f 'pplns.*jetski' >/dev/null 2>&1 || true
      # Drop idle start marker
      rm -f "$MINER_DIR/idle.start.time" || true
      echo "[h-run] $(date -Iseconds) ensured idle miner is not running" >> "$LOG_DIR/agent.log"
    }
    kill_idle

    # Mark start time for uptime calculations in h-stats.sh
    date +%s > "$MINER_DIR/nosana.start.time"

    # Start/ensure Nosana CLI is running. We run it in background and keep this script alive.
    # You can replace this block with your own start command if you already run nosana via service.
    if ! pgrep -f "@nosana/cli" >/dev/null 2>&1; then
      ( 
        echo "[h-run] $(date -Iseconds) launching nosana cli via npx" >> "$LOG_DIR/agent.log"
        # Using npx keeps your CLI fresh; logs go to nosana.log
        npx -y @nosana/cli node run >> "$LOG_DIR/nosana.log" 2>&1
      ) &
    else
      echo "[h-run] $(date -Iseconds) nosana cli already running" >> "$LOG_DIR/agent.log"
    fi

    # Keep process around so HiveOS considers miner running
    # Tail logs to stderr to avoid polluting h-stats stdout
nohup /hive/miners/custom/nosana/idle-watch.sh >/dev/null 2>&1 &
    exec tail -F "$LOG_DIR/nosana.log" >> "$LOG_DIR/agent.log" 2>&1
