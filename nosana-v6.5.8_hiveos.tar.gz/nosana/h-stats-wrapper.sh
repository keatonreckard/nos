#!/usr/bin/env bash
# Minimal wrapper: always call nosana's stats script directly.
set -euo pipefail
exec /hive/miners/custom/nosana/h-stats.sh
