#!/usr/bin/env bash
set -euo pipefail
WRAP_SRC="/hive/miners/custom/nosana/h-stats-wrapper.sh"
WRAP_DST="/hive/miners/custom/h-stats.sh"
install -m 0755 "$WRAP_SRC" "$WRAP_DST"
echo "[nosana] installed stats wrapper to $WRAP_DST"
