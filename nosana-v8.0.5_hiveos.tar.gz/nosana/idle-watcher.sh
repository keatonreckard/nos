#!/usr/bin/env bash
set -Eeuo pipefail
export LC_ALL=C

MINER_DIR="${MINER_DIR:-/hive/miners/custom/nosana}"
RUN_DIR="${RUN_DIR:-/var/run}"
LOG_DIR="${LOG_DIR:-/var/log/miner/nosana}"
STATE_FILE="${STATE_FILE:-$RUN_DIR/nosana.state}"
IDLE_LOG="$LOG_DIR/idle.log"
WATCH_LOG="$LOG_DIR/idle_watcher.log"
CONTAINER_NAME="${CONTAINER_NAME:-nosana-node}"

mkdir -p "$LOG_DIR" "$RUN_DIR"

write_kv() {
  local k="$1" v="$2" tmp="$STATE_FILE.tmp"
  { [[ -f "$STATE_FILE" ]] && sed -E "s|^${k}=.*$||" "$STATE_FILE" || true; echo "${k}=\"${v}\"" ; } > "$tmp"
  mv -f "$tmp" "$STATE_FILE"
}

start_idle() {
  if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then
    echo "[$(date -Iseconds)] idle-watcher: idle already running" >> "$WATCH_LOG"
    return 0
  fi
  if [[ -x "$MINER_DIR/idle-run.sh" ]]; then
    echo "[$(date -Iseconds)] idle-watcher: starting idle-run.sh" >> "$WATCH_LOG"
    bash "$MINER_DIR/idle-run.sh" >>"$IDLE_LOG" 2>&1 || true
  elif [[ -x "$MINER_DIR/idle-screen.sh" ]]; then
    echo "[$(date -Iseconds)] idle-watcher: starting idle-screen.sh" >> "$WATCH_LOG"
    bash "$MINER_DIR/idle-screen.sh" >>"$IDLE_LOG" 2>&1 || true
  fi
}

stop_idle() {
  echo "[$(date -Iseconds)] idle-watcher: stopping idle screen if any" >> "$WATCH_LOG"
  screen -S nosana-idle -X quit >/dev/null 2>&1 || true
}

# seed state
write_kv status "nos - initializing"
write_kv queue ""

# Choose log source:
# 1) $LOG_DIR/nosana.log if exists
# 2) docker logs -f CONTAINER
# 3) podman logs -f CONTAINER
log_source=""
if [[ -s "$LOG_DIR/nosana.log" ]]; then
  echo "[$(date -Iseconds)] idle-watcher: tailing $LOG_DIR/nosana.log" >> "$WATCH_LOG"
  log_source="file"
elif command -v docker >/dev/null 2>&1 && docker ps >/dev/null 2>&1; then
  echo "[$(date -Iseconds)] idle-watcher: using docker logs -f $CONTAINER_NAME" >> "$WATCH_LOG"
  log_source="docker"
elif command -v podman >/dev/null 2>&1 && podman ps >/dev/null 2>&1; then
  echo "[$(date -Iseconds)] idle-watcher: using podman logs -f $CONTAINER_NAME" >> "$WATCH_LOG"
  log_source="podman"
else
  echo "[$(date -Iseconds)] idle-watcher: no log source available; idle start may not trigger" >> "$WATCH_LOG"
  log_source="none"
fi

consume_line() {
  local line="$1"
  printf '%s
' "$line" >> "$WATCH_LOG"

  # Job start/running
  if echo "$line" | grep -q -E "Job .* started|Flow .* is running|is running$"; then
    write_kv status "nos - job"
    write_kv queue ""
    stop_idle
    return
  fi

  # Job finished / restarting transitions
  if echo "$line" | grep -q -E "Job .* finished|RESTARTING|Node has restarted"; then
    write_kv status "nos - initializing"
    write_kv queue ""
    return
  fi

  # Queued with position
  if echo "$line" | grep -q -E "QUEUED.*position"; then
    qpos="$(echo "$line" | sed -n 's/.*position[[:space:]]*\([0-9]\+\/[0-9]\+\).*/\1/p')"
    [[ -z "$qpos" ]] && qpos=""
    if [[ -n "$qpos" ]]; then
      write_kv status "nos - queued $qpos"
      write_kv queue "$qpos"
    else
      write_kv status "nos - queued"
      write_kv queue ""
    fi
    start_idle
    return
  fi

  # Generic "QUEUED" without position
  if echo "$line" | grep -q -E "\bQUEUED\b"; then
    write_kv status "nos - queued"
    start_idle
    return
  fi
}

if [[ "$log_source" == "file" ]]; then
  tail -n 500 -F "$LOG_DIR/nosana.log" 2>/dev/null | while IFS= read -r L; do consume_line "$L"; done
elif [[ "$log_source" == "docker" ]]; then
  docker logs -f --tail=200 "$CONTAINER_NAME" 2>&1 | while IFS= read -r L; do consume_line "$L"; done
elif [[ "$log_source" == "podman" ]]; then
  podman logs -f --tail=200 "$CONTAINER_NAME" 2>&1 | while IFS= read -r L; do consume_line "$L"; done
else
  # Polling fallback: periodically check for a queued line in nosana.log
  while true; do
    if [[ -s "$LOG_DIR/nosana.log" ]]; then
      tail -n 200 "$LOG_DIR/nosana.log" | while IFS= read -r L; do consume_line "$L"; done
    fi
    sleep 10
  done
fi
