NOSANA (HiveOS custom miner package)
-----------------------------------
Built: 2025-08-21T16:07:07
Top-level dir: nosana

Changes in v8.0.5_hiveos:
- Idle miner now starts reliably:
  - Watcher tails /var/log/miner/nosana/nosana.log (preferred), else docker logs, else podman logs.
  - Removed idle_enabled gating; it starts if an idle command is configured.
  - Starts on QUEUED; stops on job start; sets initializing on job finish/restart.
- Stats JSON: removed "ar" entirely (no shares for this node). Initializing & job => 1 kH/s; queued => X from X/Y.

Extra Config (unchanged):
{
  "idleSettings": {
    "command": "kawpowminer",
    "arguments": "-S pool:4444 -O WALLET.WORKER"
  }
}
