#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="${MINER_DIR:-/hive/miners/custom/nosana}"
LOG_DIR="${LOG_DIR:-/var/log/miner/nosana}"
RUN_DIR="${RUN_DIR:-/var/run}"
PARSED_DIR="${PARSED_DIR:-$MINER_DIR/parsed}"
STATE_FILE="${STATE_FILE:-$RUN_DIR/nosana.state}"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
mkdir -p "$LOG_DIR" "$PARSED_DIR"

# Read command & args parsed by h-config.sh
cmd="$(tr -d '\r' < "$PARSED_DIR/idle_command" 2>/dev/null || true)"
args="$(tr -d '\r' < "$PARSED_DIR/idle_args" 2>/dev/null || true)"

if [[ -z "${cmd// }" ]]; then
  echo "idle-run: no command configured; exiting" | tee -a "$IDLE_LOG" "$NOSANA_LOG" >/dev/null
  exit 0
fi

# Prevent duplicate sessions
if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then
  echo "idle-run: nosana-idle already running; skip" | tee -a "$IDLE_LOG" "$NOSANA_LOG" >/dev/null
  exit 0
fi

launcher="$MINER_DIR/.idle_exec.sh"
cat > "$launcher" <<'LAUNCH'
#!/usr/bin/env bash
set -euo pipefail
exec bash -lc "$NOSANA_IDLE_CMD $NOSANA_IDLE_ARGS"
LAUNCH
chmod 755 "$launcher"
export NOSANA_IDLE_CMD="$cmd"
export NOSANA_IDLE_ARGS="$args"

echo "idle-run: launching: $cmd $args" | tee -a "$IDLE_LOG" "$NOSANA_LOG" >/dev/null
screen -dmS nosana-idle env -i HOME="$HOME" PATH="$PATH" SHELL="/bin/bash" TERM=xterm-256color   MINER_DIR="$MINER_DIR" LOG_DIR="$LOG_DIR" "$launcher" >>"$IDLE_LOG" 2>&1 || true

exit 0
