#!/usr/bin/env bash
set -euo pipefail

# Config
IDLE_SCREEN="nosana-idle"
IDLE_KILL_PATTERN='qli-Client|qli-worker-AVX512|qli-worker-XMR|qli-worker-CUDA'
MESSAGE_BIN="/hive/bin/message"

msg(){ echo "[idle-guard] $*"; }
notify(){ if [ -x "$MESSAGE_BIN" ]; then "$MESSAGE_BIN" info "$*"; fi; }

kill_idle(){
  # Try screen first so the app can exit cleanly, then hard kill leftovers
  screen -S "$IDLE_SCREEN" -X quit 2>/dev/null || true
  pkill -9 -f "$IDLE_KILL_PATTERN" 2>/dev/null || true
}

# daemon mode
if [[ "${1:-}" == "--daemon" ]]; then
  msg "starting daemon"
  # Hourly :04 kill, :07 restart request via idle-run (if not in job)
  while true; do
    min=$(date +%M)
    case "$min" in
      04)
        kill_idle
        notify "NOSANA: idle miner killed (scheduled :04)"
        sleep 60
        ;;
      07)
        # restart only if not running a job (heuristic: nosana-node logs do not contain 'is running' in last 60s)
        if docker logs --since 60s nosana-node 2>/dev/null | grep -qiE 'Job .* (is starting|is running|started successfully)'; then
          :
        else
          /hive/miners/custom/nosana/idle-run.sh >/dev/null 2>&1 || true
          notify "NOSANA: idle miner restart requested (:07)"
        fi
        sleep 60
        ;;
      *)
        sleep 5
        ;;
    esac
  done
fi

# one-shot kill by log trigger
kill_idle
notify "NOSANA: idle miner killed (job event)"
