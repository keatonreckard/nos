#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
DEBUG_LOG="$LOG_DIR/debug.log"
mkdir -p "$LOG_DIR"

CMD="${1:-}"; ARGS="${2:-}"
echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')] idle-run preflight" | tee -a "$DEBUG_LOG"
echo "  whoami=$(whoami)  pwd=$PWD" | tee -a "$DEBUG_LOG"
echo "  idle_cmd=$CMD" | tee -a "$DEBUG_LOG"

if [[ -z "$CMD" ]]; then
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')] idle-run: no command provided; skipping" | tee -a "$DEBUG_LOG"
  exit 0
fi

# ensure screen exists
command -v screen >/dev/null 2>&1 || (apt-get update -y && apt-get install -y screen)

# kill any previous session
screen -S idle -X quit >/dev/null 2>&1 || true

# truncate idle log
: > "$IDLE_LOG"

echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')] idle-run: starting idle miner: $CMD $ARGS" | tee -a "$DEBUG_LOG"
# start detached screen with logging enabled (-L writes to screenlog.N, but we tail process output into IDLE_LOG)
screen -dmS idle bash -lc "$CMD $ARGS 2>&1 | stdbuf -oL -eL sed -u 's/^/[idle] /' | tee -a '$IDLE_LOG'"

sleep 1
echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')] idle-run: idle miner started" | tee -a "$DEBUG_LOG"
