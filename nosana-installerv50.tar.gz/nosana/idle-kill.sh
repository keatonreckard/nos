#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
screen -S idle -X quit >/dev/null 2>&1 || true
pkill -f "screen .* -S idle" >/dev/null 2>&1 || true
