#!/usr/bin/env bash
# Outputs:
# 1st line: total khs (number)
# 2nd line: JSON stats
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

# defaults
status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

# Build clean log text
CLEAN=""
if [[ -s "$NOSANA_LOG" ]]; then
  CLEAN="$(tail -n 400 "$NOSANA_LOG" | tr -d '\r' | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"
fi

# Extract wallet/sol/nos if not set by monitor
[[ -z "${wallet:-}" ]] && wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
[[ -z "${sol:-}" ]] && sol="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
[[ -z "${nos:-}" ]] && nos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"

short_wallet=""
if [[ -n "${wallet:-}" ]]; then
  short_wallet="$(printf "%s" "$wallet" | cut -c1-5)"
fi
ver=""
if [[ -n "${sol:-}" || -n "${nos:-}" || -n "$short_wallet" ]]; then
  ver="S:${sol:-0} N:${nos:-0} W:${short_wallet:-}"
fi

# Figure queue pos from log if missing
if [[ -z "${queue:-}" ]]; then
  queue="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*QUEUED[[:space:]]+.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
fi

# Detect if job running
job_running=0
if printf "%s" "$CLEAN" | grep -Eq "Starting job|Job .* started|Running job|Starting flow|Running flow|Assigned job|Executing task"; then
  job_running=1
fi

# Idle algo detect
idle_algo=""
if [[ -s "$IDLE_LOG" ]]; then
  if tail -n 80 "$IDLE_LOG" | grep -q "\[XMR\]"; then
    idle_algo="idle xmr"
  else
    idle_algo="idle qubic"
  fi
fi

# If initializing, mask idle suffix
algo_base="${status:-nos - initializing}"
algo="$algo_base"
if [[ $job_running -eq 0 ]]; then
  # Append queue + idle when not job and status not pure initializing
  if echo "$algo_base" | grep -q "queued" ; then
    [[ -n "$idle_algo" ]] && algo="$algo_base - $idle_algo"
  fi
else
  algo="nos-job"
fi

# Hashrate parsing from idle.log
get_cpu_hs(){
  # prefer avg it/s
  local line
  line="$(tail -n 100 "$IDLE_LOG" | grep -E "\[(AVX512|AVX2|GENERIC|XMR)\]" | grep -E "avg it/s" | tail -n1 || true)"
  if [[ -n "$line" ]]; then
    echo "$line" | grep -oE "[0-9]+ avg it/s" | awk '{print $1}'
  else
    echo 0
  fi
}
get_gpu_hs(){
  local line
  line="$(tail -n 100 "$IDLE_LOG" | { grep "\[CUDA\].*avg it/s" || true; } | tail -n1)"
  if [[ -n "$line" ]]; then
    echo "$line" | grep -oE "[0-9]+ avg it/s" | awk '{print $1}'
    return
  fi
  # fallback to GPU Trainer line
  line="$(tail -n 200 "$IDLE_LOG" | grep -E "\[GPU\] Trainer: GPU #0: [0-9]+ it/s" | tail -n1 || true)"
  if [[ -n "$line" ]]; then
    echo "$line" | grep -oE "GPU #0: [0-9]+" | awk '{print $3}'
    return
  fi
  echo 0
}

cpu_hs=0; gpu_hs=0
if [[ $job_running -eq 0 ]]; then
  [[ -s "$IDLE_LOG" ]] && cpu_hs="$(get_cpu_hs)" || true
  [[ -s "$IDLE_LOG" ]] && gpu_hs="$(get_gpu_hs)" || true
fi

# Build per-device hs array:
# Map GPU to first slot, and append CPU as second slot (null bus)
hs_json="[]"; temp_json="[]"; fan_json="[]"; bus_json="[]"
gpu_bus=""
if command -v gpu-stats >/dev/null 2>&1; then
  g="$(gpu-stats | tail -n1)"
  # busids as array e.g. ["05:00.0","01:00.0"], brand ["cpu","nvidia"]
  busids="$(printf "%s" "$g" | sed -nE 's/.*"busids":\[(.*)\].*/\1/p')"
  brand="$(printf "%s" "$g" | sed -nE 's/.*"brand":\[(.*)\].*/\1/p')"
  # find index of first non-cpu brand
  idx=0; gpu_index=-1
  IFS=',' read -r -a brands <<< "$brand"
  for b in "${brands[@]}"; do
    bb="$(echo "$b" | tr -d ' "')" 
    if [[ "$bb" != "cpu" && $gpu_index -lt 0 ]]; then gpu_index=$idx; fi
    idx=$((idx+1))
  done
  # extract bus id at gpu_index
  if [[ $gpu_index -ge 0 ]]; then
    bid="$(printf "%s" "$busids" | awk -F',' -v i="$((gpu_index+1))" '{print $i}' | tr -d ' "[]')"
    # convert "01:00.0" -> 1
    gpu_bus=$(echo "$bid" | awk -F: '{ printf "%d\n",("0x"$1) }')
  fi
fi

# Compose arrays
if [[ $job_running -eq 0 && $init -eq 0 ]]; then
  # GPU first if present
  hs_json="$(printf '[%s,%s]\n' "${gpu_hs:-0}" "${cpu_hs:-0}")"
  # bus numbers
  if [[ -n "$gpu_bus" ]]; then
    bus_json="$(printf '[%s,null]\n' "$gpu_bus")"
  else
    bus_json='[null,null]'
  fi
else
  # no per-device while on job
  hs_json="[]"; bus_json="[]"
fi

# Total khs
khs=0
init=0; echo "$algo_base" | grep -q 'initializing' && init=1
if [[ $job_running -eq 1 || $init -eq 1 ]]; then
  khs=1
else
  total_it=$(echo "${gpu_hs:-0} + ${cpu_hs:-0}" | bc)
  khs=$(echo "scale=6; $total_it / 1000" | bc)
fi

# finalize
stats=$(jq -nc \
  --argjson hs "$hs_json" \
  --arg hs_units "hs" \
  --argjson temp "$temp_json" \
  --argjson fan "$fan_json" \
  --arg uptime "$(($(date +%s)-$(stat -c %Y "$NOSANA_LOG" 2>/dev/null || echo $(date +%s))))" \
  --arg ver "$ver" \
  --arg algo "$algo" \
  --argjson bus_numbers "$bus_json" \
  '{$hs, $hs_units, $temp, $fan, $uptime, $ver, $algo, $bus_numbers}')

echo "$khs"
echo "$stats"
