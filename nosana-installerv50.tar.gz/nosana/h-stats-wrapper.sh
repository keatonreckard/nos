#!/usr/bin/env bash
exec /hive/miners/custom/nosana/h-stats.sh
