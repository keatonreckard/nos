#!/usr/bin/env bash
# helper to attach to idle screen
exec screen -r idle
