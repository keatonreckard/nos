#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

# shim msg if not provided by Hive
if ! command -v msg >/dev/null 2>&1; then
  msg(){ echo "[nosana] $*"; }
fi

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
MINER_LOG="$LOG_DIR/nosana.log"
mkdir -p "$LOG_DIR" "$RUN_DIR"
touch "$MINER_LOG" "$STATE_FILE"

# Ensure state has defaults
if ! grep -q '^status=' "$STATE_FILE" 2>/dev/null; then
  {
    echo 'status="nos - initializing"'
    echo 'queue=""'
  } > "$STATE_FILE"
fi

get_clean_chunk(){
  # grab last 400 lines and strip ANSI
  tail -n 400 "$MINER_LOG" 2>/dev/null | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g'
}

while true; do
  CHUNK="$(get_clean_chunk)"
  if [[ -n "$CHUNK" ]]; then
    # Wallet/SOL/NOS
    wallet="$(printf "%s\n" "$CHUNK" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
    sol="$(printf "%s\n" "$CHUNK" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
    nos="$(printf "%s\n" "$CHUNK" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"

    qpos="$(printf "%s\n" "$CHUNK" | sed -nE 's/.*QUEUED[[:space:]]+.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"

    status="nos - initializing"
    if [[ -n "$qpos" ]]; then
      status="nos - queued $qpos"
    fi
    # If signs of job running
    if printf "%s" "$CHUNK" | grep -Eq "Starting job|Job .* started|Running job|Starting flow|Running flow|Assigned job|Pulling image docker.io"; then
      status="nos - job"
      # kill idle aggressively if still around
      bash "$MINER_DIR/idle-kill.sh" || true
    fi

    tmp="$STATE_FILE.tmp"
    {
      printf 'status="%s"\n' "$status"
      printf 'queue="%s"\n' "${qpos:-}"
      [[ -n "${wallet:-}" ]] && printf 'wallet="%s"\n' "$wallet" || true
      [[ -n "${sol:-}" ]] && printf 'sol="%s"\n' "$sol" || true
      [[ -n "${nos:-}" ]] && printf 'nos="%s"\n' "$nos" || true
    } > "$tmp"
    mv -f "$tmp" "$STATE_FILE"
  fi
  sleep 5
done
