#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

stamp(){ date +"[%Y-%m-%dT%H:%M:%S%z]"; }

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
MINER_LOG="$LOG_DIR/nosana.log"
DEBUG_LOG="$LOG_DIR/debug.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR" "$RUN_DIR"
touch "$MINER_LOG" "$DEBUG_LOG" "$IDLE_LOG"

# Source state for idle settings
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

echo "$(stamp) h-run: cleaning previous containers" | tee -a "$DEBUG_LOG"
docker rm -f podman nosana-node >/dev/null 2>&1 || true
killall -9 podman >/dev/null 2>&1 || true

# Ensure gpg for NVIDIA repo setup
if ! command -v gpg >/dev/null 2>&1; then
  echo "$(stamp) Installing GPG..." | tee -a "$DEBUG_LOG"
  apt-get update -y || true
  DEBIAN_FRONTEND=noninteractive apt-get install -y --allow-downgrades apt-transport-https ca-certificates curl gnupg gpg gpgv || true
fi

# Install NVIDIA Container Toolkit if nvidia-ctk missing (best effort)
if ! command -v nvidia-ctk >/dev/null 2>&1; then
  echo "$(stamp) Installing NVIDIA repo keyring..." | tee -a "$DEBUG_LOG"
  curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg || true
  dist="ubuntu$(. /etc/os-release && echo ${VERSION_ID//./})"
  curl -s -L https://nvidia.github.io/libnvidia-container/${dist}/libnvidia-container.list \
    | sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' \
    | tee /etc/apt/sources.list.d/nvidia-container-toolkit.list >/dev/null || true
  apt-get update -y || true
  DEBIAN_FRONTEND=noninteractive apt-get install -y nvidia-container-toolkit || true
  if command -v nvidia-ctk >/dev/null 2>&1; then
    echo "$(stamp) Configuring docker runtime for NVIDIA..." | tee -a "$DEBUG_LOG"
    nvidia-ctk runtime configure --runtime=docker || true
    systemctl restart docker || true
  else
    echo "$(stamp) WARNING: nvidia-ctk not found; skipping runtime configure." | tee -a "$DEBUG_LOG"
  fi
fi

echo "$(stamp) h-run: starting podman sidecar" | tee -a "$DEBUG_LOG"
docker rm -f podman >/dev/null 2>&1 || true
docker run -d --restart=unless-stopped --name podman --privileged \
  -v /var/lib/containers:/var/lib/containers \
  nosana/podman:v1.1.0 >/dev/null 2>&1 || true

echo "$(stamp) h-run: starting nosana-node container" | tee -a "$DEBUG_LOG"
docker rm -f nosana-node >/dev/null 2>&1 || true
# Run CLI; mount key if exists
KEY_PATH="/root/.nosana/nosana_key.json"
docker run -d --restart=unless-stopped --name nosana-node \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v /root/.nosana:/root/.nosana \
  -e NOSANA_PROVIDER="podman" \
  nosana/nosana-cli:latest >/dev/null 2>&1 || true

# Start monitor (once)
if ! pgrep -af "monitor.sh" | grep -q "$MINER_DIR/monitor.sh"; then
  bash "$MINER_DIR/monitor.sh" >>"$DEBUG_LOG" 2>&1 &
fi

# Start idle miner if idle settings exist
if [[ -n "${idle_cmd:-}" ]]; then
  bash "$MINER_DIR/idle-run.sh" "$idle_cmd" "$idle_args" >>"$DEBUG_LOG" 2>&1 || true
fi

# Start idle bridge (tail idle.log into nosana.log) - idempotent
bash "$MINER_DIR/idle-bridge.sh" start >>"$DEBUG_LOG" 2>&1 || true

# Keep foreground attached to CLI logs for motd watch
# but ensure we don't block miner stop: tail nosana-node logs to miner log
( docker logs -f nosana-node 2>&1 | sed -u $'s/\r//g' | stdbuf -oL -eL tee -a "$MINER_LOG" ) &
wait
