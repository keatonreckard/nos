#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
MINER_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
PID_FILE="/var/run/idle-bridge.pid"

usage(){ echo "usage: $0 {start|stop|status}"; }

start(){
  if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    exit 0
  fi
  ( stdbuf -oL -eL tail -n0 -F "$IDLE_LOG" | sed -u 's/^/[idle-miner] /' | stdbuf -oL -eL tee -a "$MINER_LOG" ) &
  echo $! > "$PID_FILE"
}
stop(){
  if [[ -f "$PID_FILE" ]]; then
    kill "$(cat "$PID_FILE")" >/dev/null 2>&1 || true
    rm -f "$PID_FILE"
  fi
}
status(){
  if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    echo "running"
  else
    echo "stopped"
  fi
}

case "${1:-start}" in
  start) start ;;
  stop) stop ;;
  status) status ;;
  *) usage; exit 1;;
esac
