\
#!/usr/bin/env bash
# nosana/h-stats.sh — define khs and stats for Hive agent (no stdout)
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
NOSANA_LOG="$LOG_DIR/nosana.log"

escape_json () { printf "%s" "$1" | sed 's/\\\\/\\\\\\\\/g; s/"/\\\\"/g'; }

status="nos - initializing"; queue=""
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true
if [[ -z "${queue:-}" && -s "$NOSANA_LOG" ]]; then
  q=$(tail -n 400 "$NOSANA_LOG" 2>/dev/null | sed -nE 's/.*position[[:space:]]+([0-9]+\\/[0-9]+).*/\\1/p' | tail -n1)
  [[ -n "$q" ]] && queue="$q"
fi

algo="${status:-nos}"
[[ -n "${queue:-}" ]] && algo="nos - queued ${queue}"

khs_val="1"
if [[ "$algo" =~ queued && "${queue:-}" =~ ^([0-9]+)/[0-9]+$ ]]; then
  khs_val="${BASH_REMATCH[1]}"
fi

now=$(date +%s)
if   [[ -f "$MINER_DIR/job.start.time"  ]]; then start_time=$(cat "$MINER_DIR/job.start.time")
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then start_time=$(cat "$MINER_DIR/idle.start.time")
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then start_time=$(cat "$MINER_DIR/nosana.start.time")
else read -r up _ < /proc/uptime; start_time=$(( now - ${up%.*} )); fi
uptime=$((now - start_time)); ((uptime<0)) && uptime=0

ver_parts=()
[[ -n "${sol:-}"    ]] && { printf -v solf "%.4f" "$sol";  ver_parts+=("S:${solf}"); }
[[ -n "${nos:-}"    ]] && { printf -v nosf "%.4f" "$nos";  ver_parts+=("N:${nosf}"); }
[[ -n "${wallet:-}" ]] && ver_parts+=("W:$(printf "%s" "$wallet" | cut -c1-5)")
ver="$(IFS=' '; echo "${ver_parts[*]-}")"

temp_json='[]'; fan_json='[]'; bus_json='[]'
if [[ -f /hive/bin/gpu-stats ]]; then
  source /hive/bin/gpu-stats || true
  [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]] && temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"
  [[ "${#GPU_FAN[@]:-0}"  -gt 0 ]] &&  fan_json="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"
  if [[ "${#BUS_IDS[@]:-0}"  -gt 0 ]]; then
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

khs="${khs_val}"
algo_json="$(escape_json "$algo")"; ver_json="$(escape_json "$ver")"
stats="{\"hs\":[${khs}],\"hs_units\":\"khs\",\"temp\":${temp_json},\"fan\":${fan_json},\"uptime\":${uptime:-0},\"ver\":\"${ver_json}\",\"algo\":\"${algo_json}\",\"bus_numbers\":${bus_json}}"
