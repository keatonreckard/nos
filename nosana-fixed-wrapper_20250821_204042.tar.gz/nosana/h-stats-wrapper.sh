\
#!/usr/bin/env bash
set -euo pipefail
# shellcheck disable=SC1091
source /hive/miners/custom/nosana/h-stats.sh
