\
    #!/usr/bin/env bash
    # Emits a single JSON line for HiveOS agent
    set -euo pipefail
    export LC_ALL=C

    MINER_DIR="/hive/miners/custom/nosana"
    RUN_DIR="/var/run"
    STATE_FILE="$RUN_DIR/nosana.state"
    LOG_DIR="/var/log/miner/nosana"
    IDLE_LOG="$LOG_DIR/idle.log"
    NOSANA_LOG="$LOG_DIR/nosana.log"

    mkdir -p "$LOG_DIR"
    exec 2>>"$LOG_DIR/debug.log"  # keep stdout clean

    status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""
    [[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

    # Collect recent logs and strip ANSI
    L=""; [[ -s "$NOSANA_LOG" ]] && L="$(tail -n 4000 "$NOSANA_LOG" | tr -d '\r')"
    if [[ -z "$L" ]]; then
      # Try container logs if present
      if command -v docker >/dev/null 2>&1; then
        C="$(docker logs --since 10m nosana-node 2>/dev/null || true)"; [[ -n "$C" ]] && L="$(printf "%s" "$C" | tr -d '\r')"
      elif command -v podman >/dev/null 2>&1; then
        C="$(podman logs --since 10m nosana-node 2>/dev/null || true)"; [[ -n "$C" ]] && L="$(printf "%s" "$C" | tr -d '\r')"
      fi
    fi
    CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"

    # Extract wallet/balances
    if [[ -z "${wallet:-}" ]]; then
      wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
      [[ -z "$wallet" ]] && wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
    fi
    if [[ -z "${sol:-}" ]]; then
      sol="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
    fi
    if [[ -z "${nos:-}" ]]; then
      nos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
    fi

    # Determine status and queue pos
    queue_pos=""; queue_x=""
    if echo "$CLEAN" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
      status="nos - job"
    else
      # look for 'position X/Y'
      if [[ "$CLEAN" =~ position[[:space:]]+([0-9]+)\/([0-9]+) ]]; then
        queue_pos="${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
        queue_x="${BASH_REMATCH[1]}"
      else
        # generic QUEUED
        if echo "$CLEAN" | grep -Eq 'QUEUED'; then
          status="nos - queued"
        fi
      fi
      if [[ -n "$queue_pos" ]]; then
        status="nos - queued ${queue_pos}"
      fi
    fi

    # Uptime
    now=$(date +%s)
    if [[ -f "$MINER_DIR/job.start.time" ]]; then start_time=$(cat "$MINER_DIR/job.start.time")
    elif [[ -f "$MINER_DIR/idle.start.time" ]]; then start_time=$(cat "$MINER_DIR/idle.start.time")
    elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then start_time=$(cat "$MINER_DIR/nosana.start.time")
    else read -r up _ < /proc/uptime; start_time=$(( now - ${up%.*} )); fi
    uptime=$((now - start_time)); ((uptime<0)) && uptime=0

    # Parse idle hashrate from idle.log (look for 'it/s')
    parse_idle_khs() {
      [[ -s "$IDLE_LOG" ]] || { echo ""; return; }
      local tailn line val
      tailn="$(tail -n 600 "$IDLE_LOG")"
      # Prefer lines like "GPU #0: 49 it/s" then fallback to generic "CUDA] 49 it/s"
      line="$(printf "%s\n" "$tailn" | grep -Eo 'GPU #[0-9]+: *[0-9]+(\.[0-9]+)? it/s' | tail -n1)"
      if [[ -z "$line" ]]; then
        line="$(printf "%s\n" "$tailn" | grep -Eo '\[(CUDA|AVX512)\][^0-9]*[0-9]+(\.[0-9]+)? it/s' | tail -n1)"
      fi
      val="$(printf "%s" "$line" | grep -Eo '[0-9]+(\.[0-9]+)?' | tail -n1)"
      [[ -n "$val" ]] && printf "%.0f" "$val" || echo ""
    }

    # Compute khs according to rules
    algo="$status"
    khs=""
    if echo "$status" | grep -qi 'job'; then
      khs="1"
    else
      # queued path: prefer idle, else queue_x, else 1
      idle_khs="$(parse_idle_khs || true)"
      if [[ -n "${idle_khs:-}" && "$idle_khs" != "0" ]]; then
        khs="$idle_khs"
      elif [[ -n "${queue_x:-}" ]]; then
        khs="$queue_x"
      else
        khs="1"
      fi
    fi

    # version string
    ver=""
    if [[ -n "${sol:-}" ]]; then printf -v solf "%.4f" "$sol"; ver+="S:${solf}"; fi
    if [[ -n "${nos:-}" ]]; then printf -v nosf "%.4f" "$nos"; ver+="${ver:+ }N:${nosf}"; fi
    if [[ -n "${wallet:-}" ]]; then ver+="${ver:+ }W:$(printf "%s" "$wallet" | cut -c1-5)"; fi

    # GPU arrays (best effort)
    temp_json='[]'; fan_json='[]'; bus_json='[]'
    if [[ -f /hive/bin/gpu-stats ]]; then
      source /hive/bin/gpu-stats || true
      if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
      if [[ "${#GPU_FAN[@]:-0}" -gt 0 ]]; then  fan_json ="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
      if [[ "${#BUS_IDS[@]:-0}" -gt 0 ]]; then
        bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
        bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
      fi
    fi

    # Accepted/rejected: we don't have real shares -> 0,0 (never empty)
    ar_acc=0; ar_rej=0

    # Compose JSON
    printf '{"hs":[%s],"hs_units":"khs","temp":%s,"fan":%s,"uptime":%s,"ver":"%s","ar":[%s,%s],"algo":"%s","bus_numbers":%s}\n' \
      "$khs" "$temp_json" "$fan_json" "$uptime" "$ver" "$ar_acc" "$ar_rej" "$algo" "$bus_json"
