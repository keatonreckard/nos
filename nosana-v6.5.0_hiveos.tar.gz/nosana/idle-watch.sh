#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
LOG_DIR="/var/log/miner/nosana"
CUSTOM_LOG="/var/log/miner/custom/custom.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
PIDFILE="$RUN_DIR/nosana.idlewatch.pid"

mkdir -p "$RUN_DIR" "$LOG_DIR" "$(dirname "$CUSTOM_LOG")"
touch "$NOSANA_LOG" "$IDLE_LOG" "$CUSTOM_LOG"

idle_running(){ screen -ls 2>/dev/null | grep -q "\.nosana-idle"; }

start_idle(){
  if ! idle_running; then
    echo "[idle-queue] starting idle via idle-run.sh" | tee -a "$IDLE_LOG" "$NOSANA_LOG" "$CUSTOM_LOG" >/dev/null
    ( bash -lc "$MINER_DIR/idle-run.sh" ) >>"$IDLE_LOG" 2>&1 || true
  fi
}
stop_idle(){
  if idle_running; then
    echo "[idle-queue] stopping idle via idle-stop.sh" | tee -a "$IDLE_LOG" "$NOSANA_LOG" "$CUSTOM_LOG" >/dev/null
    bash "$MINER_DIR/idle-stop.sh" >>"$IDLE_LOG" 2>&1 || true
  else
    # still call stop to allow custom cleanup
    bash "$MINER_DIR/idle-stop.sh" >>"$IDLE_LOG" 2>&1 || true
  fi
}

detect_state(){
  # Prefer container logs, fallback to nosana.log
  local L CLEAN
  if command -v podman >/dev/null 2>&1; then
    L="$(podman logs --tail 400 nosana-node 2>/dev/null || true)"
  elif command -v docker >/devnull 2>&1; then
    L="$(docker logs --tail 400 nosana-node 2>/dev/null || true)"
  else
    L=""
  fi
  if [[ -z "${L:-}" && -s "$NOSANA_LOG" ]]; then
    L="$(tail -n 400 "$NOSANA_LOG" 2>/dev/null)"
  fi
  [[ -z "${L:-}" ]] && return 1
  CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"

  # Job first
  if printf "%s\n" "$CLEAN" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* (started|running)|Flow .* (started|running)'; then
    echo "job"; return 0
  fi

  # Queue next
  if printf "%s\n" "$CLEAN" | grep -Eqi '(^|[[:space:]])QUEUED([[:space:]]|$)|position[[:space:]]+[0-9]+/[0-9]+|\[nosana\][[:space:]]+queued'; then
    echo "queued"; return 0
  fi

  # Unknown -> treat as initializing
  echo "init"; return 0
}

# Single-instance guard
if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE" 2>/dev/null)" 2>/dev/null; then
  exit 0
fi
echo $$ > "$PIDFILE"
echo "[idle-queue] watcher online" | tee -a "$CUSTOM_LOG" >/dev/null

trap 'rm -f "$PIDFILE"; exit 0' INT TERM EXIT
last=""
while true; do
  state="$(detect_state || echo init)"
  if [[ "$state" != "$last" ]]; then
    case "$state" in
      job)    stop_idle ;;
      queued) start_idle ;;
      *)      : ;;   # init: do nothing
    esac
    last="$state"
  fi
  sleep 8
done
