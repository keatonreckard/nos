\
    #!/usr/bin/env bash
    set -euo pipefail
    # Hive agent reads STDOUT of this script into "miner_stats"
    : "${CUSTOM_MINER:=nosana}"
    miner="/hive/miners/custom/${CUSTOM_MINER}/h-stats.sh"
    if [[ ! -x "$miner" ]]; then
      miner="/hive/miners/custom/nosana/h-stats.sh"
    fi
    out="$("$miner")" || out=""
    # strip any "ar":[...] fragments if present, then print exactly one line
    out="$(printf "%s" "$out" | tr -d '\r' | sed -E 's/,"ar":\[[^]]*\]//g; s/"ar":\[[^]]*\],?//g')"
    printf "%s\n" "$out"
