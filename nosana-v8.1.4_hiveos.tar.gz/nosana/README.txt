NOSANA (HiveOS custom miner package)
-----------------------------------
Built: 2025-08-21T17:33:29

v8.1.4_hiveos:
- Definitive removal of "ar" shares: stripped in miner's h-stats.sh *and* in the global wrapper as a last resort.
- Stats behavior preserved: algo text unchanged; KH/s mapping (init+job=1, queued X/Y=X); version cache retained.
- Idle logic unchanged except for earlier sanitization in idle-run.sh.
