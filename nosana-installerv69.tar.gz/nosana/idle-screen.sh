#!/usr/bin/env bash
# Attach to the existing idle miner screen session *only*.
set -euo pipefail
export LC_ALL=C
if screen -ls 2>/dev/null | grep -q "\.${IDLE_SCREEN:-xmrig-new}"; then
  exec screen -r "${IDLE_SCREEN:-xmrig-new}"
else
  echo "${IDLE_SCREEN:-xmrig-new} is not running. (No attach)"
  echo "Check logs: /var/log/miner/nosana/idle.log and nosana.log"
  exit 1
fi
