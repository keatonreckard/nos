#!/usr/bin/env bash
set -euo pipefail

LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR"
log(){ echo "[$(date -Iseconds)] $*" | tee -a "$LOG_DIR/debug.log"; }

# Ensure GPG is available before adding NVIDIA repo keys
apt-get update -y || true
apt-get install -y gpg gnupg ca-certificates curl || true


# 1) Docker via user's HiveOS-friendly script
if ! command -v docker >/dev/null 2>&1; then
  log "Docker not found. Installing via HiveOS docker script..."
  if [[ -x "./install_docker_slave.sh" ]]; then
    bash ./install_docker_slave.sh | tee -a "$LOG_DIR/debug.log"
  else
    wget -qO ./install_docker_slave.sh "https://github.com/filthz/fact-worker-public/releases/download/base_files/install_docker_slave.sh"
    chmod 0755 ./install_docker_slave.sh
    bash ./install_docker_slave.sh | tee -a "$LOG_DIR/debug.log"
  fi
else
  log "Docker already present."
fi

# Ensure docker service is up
if ! systemctl is-active --quiet docker; then
  log "Starting docker service..."
  systemctl start docker || true
fi

# 2) NVIDIA Container Toolkit (per Nosana docs) with robust repo detection
if ! command -v nvidia-ctk >/dev/null 2>&1; then
  log "Installing NVIDIA Container Toolkit..."
  set +e
  # Keyring already created by earlier gpg install step
  install -m 0755 -d /usr/share/keyrings >/dev/null 2>&1 || true
  distribution=$(. /etc/os-release; echo ${ID}${VERSION_ID} | tr '[:upper:]' '[:lower:]')
  arch=$(dpkg --print-architecture)
  TMP_LIST="/tmp/nvidia-container-toolkit.list"
  # Try several candidate URLs (order matters)
  CANDIDATES=(
    "https://nvidia.github.io/libnvidia-container/stable/${distribution}/nvidia-container-toolkit.list"
    "https://nvidia.github.io/libnvidia-container/stable/${distribution}/${arch}/nvidia-container-toolkit.list"
    "https://nvidia.github.io/libnvidia-container/stable/ubuntu22.04/nvidia-container-toolkit.list"
    "https://nvidia.github.io/libnvidia-container/stable/ubuntu22.04/${arch}/nvidia-container-toolkit.list"
    "https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list"
  )
  GOT_LIST=""
  for url in "${CANDIDATES[@]}"; do
    if curl -fsSL "$url" -o "$TMP_LIST"; then
      GOT_LIST="$url"
      break
    fi
  done
  if [[ -n "$GOT_LIST" ]]; then
    log "Using NVIDIA repo list: $GOT_LIST"

# Add NVIDIA nvidia-docker repo too (some distros serve toolkit from this index)
distribution=$(. /etc/os-release; echo ${ID}${VERSION_ID} | tr '[:upper:]' '[:lower:]')
arch=$(dpkg --print-architecture)
TMP_LIST2="/tmp/nvidia-docker.list"
CANDIDATES2=(
  "https://nvidia.github.io/nvidia-docker/${distribution}/nvidia-docker.list"
  "https://nvidia.github.io/nvidia-docker/${distribution}/${arch}/nvidia-docker.list"
  "https://nvidia.github.io/nvidia-docker/ubuntu22.04/nvidia-docker.list"
  "https://nvidia.github.io/nvidia-docker/ubuntu22.04/${arch}/nvidia-docker.list"
)
for url2 in "${CANDIDATES2[@]}"; do
  if curl -fsSL "$url2" -o "$TMP_LIST2"; then
    log "Using NVIDIA nvidia-docker repo list: $url2"
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' "$TMP_LIST2" | tee /etc/apt/sources.list.d/nvidia-docker.list >/dev/null
    break
  fi
done
apt-get update -y || true
# Try to install toolkit; if not, fallback to runtime (older path)
if ! apt-get install -y nvidia-container-toolkit; then
  log "Toolkit package not found; trying fallback packages..."
  apt-get install -y nvidia-container-runtime || true
  apt-get install -y nvidia-docker2 || true
fi
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' "$TMP_LIST" | tee /etc/apt/sources.list.d/nvidia-container-toolkit.list >/dev/null
    apt-get update -y || true
    apt-get install -y nvidia-container-toolkit || true
  else
    log "WARNING: Could not fetch NVIDIA repo list from any candidate URL."
  fi
  set -e
else
  log "nvidia-ctk already installed."
fi

log "Configuring docker runtime for NVIDIA..."
if command -v nvidia-ctk >/dev/null 2>&1; then
  nvidia-ctk runtime configure --runtime=docker || true
  systemctl restart docker || true
else
  log "WARNING: nvidia-ctk not found; skipping runtime configure."
fi

# Non-fatal sanity check
if docker run --rm --gpus all nvidia/cuda:11.0.3-base-ubuntu18.04 nvidia-smi >/dev/null 2>&1; then
  log "NVIDIA toolkit OK inside container."
else
  log "WARNING: nvidia-smi check in container failed (continuing)."
fi

exit 0