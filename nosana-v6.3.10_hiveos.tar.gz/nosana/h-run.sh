#!/usr/bin/env bash
/hive/miners/custom/nosana/install-stats-wrapper.sh || true
set -euo pipefail
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
DEBUG_LOG="$LOG_DIR/debug.log"
mkdir -p "$LOG_DIR"
touch "$LOG_DIR/nosana.log" "$DEBUG_LOG" "$LOG_DIR/idle.log"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

echo "[$(date -Iseconds)] h-run: cleaning previous containers" | tee -a "$DEBUG_LOG"
docker rm -f nosana-node podman >/dev/null 2>&1 || true
pkill -9 -f "podman system service" 2>/dev/null || true
docker container prune -f >/dev/null 2>&1 || true

docker volume inspect podman-cache >/dev/null 2>&1 || docker volume create podman-cache >/dev/null
docker volume inspect podman-socket >/dev/null 2>&1 || docker volume create podman-socket >/dev/null

echo "[$(date -Iseconds)] h-run: starting podman sidecar" | tee -a "$DEBUG_LOG"
docker run -d --pull=always --gpus=all --name podman --device /dev/fuse \
  --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman --privileged -e ENABLE_GPU=true \
  nosana/podman:v1.1.0 unix:/podman/podman.sock >> "$DEBUG_LOG" 2>&1 || true
sleep 5

echo "[$(date -Iseconds)] h-run: starting nosana-node container" | tee -a "$DEBUG_LOG"
msg "NOS: node starting"
docker run -d --pull=always --name nosana-node --network host --gpus=all \
  --volume /root/.nosana/:/root/.nosana/ \
  --volume podman-socket:/root/.nosana/podman:ro \
  -e CLI_VERSION= nosana/nosana-cli:latest \
  node start --network "${SOL_NET_ENV:=mainnet}" >> "$DEBUG_LOG" 2>&1 || true
sleep 2
msg "NOS: node container launched"

exec bash "$MINER_DIR/monitor.sh"
