#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
NOSANA_LOG="$LOG_DIR/nosana.log"

mkdir -p "$LOG_DIR" "$RUN_DIR" 2>/dev/null || true

status="nos - initializing"; algo="nos - initializing"; queue=""; sol=""; nos=""; wallet=""
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

# Gather node logs (prefer container)
L="$(podman logs --since 5m nosana-node 2>/dev/null || docker logs --since 5m nosana-node 2>/dev/null || true)"
if [[ -z "$L" && -s "$NOSANA_LOG" ]]; then
  L="$(tail -n 2000 "$NOSANA_LOG" | tr -d '\r')"
fi
CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"

# Status detection
if printf "%s\n" "$CLEAN" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
  status="nos - job"
else
  pos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
  if [[ -n "${pos:-}" ]]; then
    status="nos - queued ${pos}"; queue="${pos}"
  elif printf "%s\n" "$CLEAN" | grep -Eqi '(^|[[:space:]])QUEUED([[:space:]]|$)'; then
    status="nos - queued"
  fi
fi
algo="$status"

# Balances & wallet (best effort)
if [[ -z "${sol:-}" ]]; then sol="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"; fi
if [[ -z "${nos:-}" ]]; then nos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"; fi
if [[ -z "${wallet:-}" ]]; then wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"; fi
if [[ -z "${wallet:-}" ]]; then wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*(Public[[:space:]]*Key|Pubkey|Address)[[:space:]]*:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\2/p' | tail -n1)"; fi
if [[ -z "${wallet:-}" ]]; then wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"; fi

# Version string (balances + wallet prefix)
ver=""
if [[ -n "${sol:-}" ]]; then printf -v solf "%.4f" "$sol"; ver+="S:${solf}"; fi
if [[ -n "${nos:-}" ]]; then printf -v nosf "%.4f" "$nos"; ver+="${ver:+ }N:${nosf}"; fi
if [[ -n "${wallet:-}" ]]; then ver+="${ver:+ }W:$(printf "%s" "$wallet" | cut -c1-5)"; fi

# KH/s rules (classic)
khs="0"
if printf "%s" "$status" | grep -qi 'nos - job'; then
  khs="1"
else
  qfirst="$(printf "%s\n" "$status" | sed -nE 's/.*queued[[:space:]]+([0-9]+)\/[0-9]+.*/\1/p')"
  if [[ -n "${qfirst:-}" ]]; then khs="$qfirst"; fi
fi
khs="$(printf "%s" "$khs" | sed 's|/.*||; s/[^0-9.]//g')"
[[ -z "$khs" ]] && khs="0"

# Arrays (leave empty to avoid GPU stat deps)
temp_json='[]'; fan_json='[]'; bus_json='[]'

# Uptime (best effort)
now=$(date +%s); up=0
if [[ -f "$MINER_DIR/job.start.time" ]]; then st=$(cat "$MINER_DIR/job.start.time"); up=$((now-st))
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then st=$(cat "$MINER_DIR/idle.start.time"); up=$((now-st))
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then st=$(cat "$MINER_DIR/nosana.start.time"); up=$((now-st))
else read -r u _ < /proc/uptime; up=${u%.*}; fi
((up<0)) && up=0

# Emit JSON
printf '{"hs":[%s],"hs_units":"khs","temp":%s,"fan":%s,"uptime":%s,"ver":"%s","ar":[0,0],"algo":"%s","bus_numbers":%s}\n' \
  "$khs" "$temp_json" "$fan_json" "$up" "$ver" "$algo" "$bus_json"
