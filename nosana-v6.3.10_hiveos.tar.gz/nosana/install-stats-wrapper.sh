#!/usr/bin/env bash
    set -euo pipefail
    mkdir -p /hive/miners/custom
    cat >/hive/miners/custom/h-stats.sh <<'BASH'
#!/usr/bin/env bash
exec /hive/miners/custom/nosana/h-stats.sh "$@"
BASH
    chmod +x /hive/miners/custom/h-stats.sh
