#!/usr/bin/env bash
set -euo pipefail
# placeholder; actual prereqs handled in h-run.sh/docker installer
