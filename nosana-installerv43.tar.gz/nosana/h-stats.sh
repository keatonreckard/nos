#!/usr/bin/env bash
# nosana h-stats.sh (v43)
# Prints total_khs on line 1; JSON stats on line 2.

set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR" "$RUN_DIR"
exec 2>>"$LOG_DIR/debug.log"

# Load cached state (wallet/sol/nos/status/queue/idle_mode)
# shellcheck disable=SC1090
[[ -s "$STATE_FILE" ]] && source "$STATE_FILE" || true

status="${status:-nos - initializing}"
queue="${queue:-}"
sol="${sol:-}"
nos="${nos:-}"
wallet="${wallet:-}"
idle_mode="${idle_mode:-}"   # "xmr" or "qubic"

# Helper: strip ANSI
strip_ansi() {
  sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g'
}

# Read nosana log chunk
L=""
if [[ -s "$NOSANA_LOG" ]]; then
  L="$(tail -n 3000 "$NOSANA_LOG" | tr -d '\r' | strip_ansi)"
fi

# Extract queue from NOSANA_LOG
new_queue=""
if [[ -n "$L" ]]; then
  # Try both formats:
  #  "-  QUEUED  ... at position X/Y"
  #  "[nosana] queued X/Y"
  q1=$(printf "%s\n" "$L" | sed -nE 's/.*QUEUED[^0-9]*([0-9]+)\/([0-9]+).*/\1\/\2/p' | tail -n1)
  q2=$(printf "%s\n" "$L" | sed -nE 's/.*queued[[:space:]]+([0-9]+)\/([0-9]+).*/\1\/\2/p' | tail -n1)
  new_queue="${q1:-$q2}"
fi
if [[ -n "$new_queue" ]]; then
  queue="$new_queue"
fi

# Extract wallet and balances; cache them so they don't disappear when QUEUED
if [[ -n "$L" ]]; then
  w=$(printf "%s\n" "$L" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)
  [[ -z "$w" ]] && w=$(printf "%s\n" "$L" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)
  [[ -n "$w" ]] && wallet="$w"

  s=$(printf "%s\n" "$L" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)
  [[ -n "$s" ]] && sol="$s"

  n=$(printf "%s\n" "$L" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)
  [[ -n "$n" ]] && nos="$n"
fi

# Idle miner parsing (separate GPU + CPU for Qubic; CPU only for XMR)
idle_chunk=""
if [[ -s "$IDLE_LOG" ]]; then
  idle_chunk="$(tail -n 200 "$IDLE_LOG" | tr -d '\r' | strip_ansi)"
fi

# Detect idle mode
mode="$idle_mode"
if [[ -n "$idle_chunk" ]]; then
  if printf "%s\n" "$idle_chunk" | grep -q "\[XMR\]"; then
    mode="xmr"
  elif printf "%s\n" "$idle_chunk" | grep -Eq "\[(CUDA|AVX512|AVX2|GENERIC)\]"; then
    mode="qubic"
  fi
fi
idle_mode="$mode"

# Extract per-component hashrates (it/s; integers). We'll output "hs_units":"hs" and hs array as raw it/s.
gpu_hs="0"
cpu_hs="0"

if [[ "$idle_mode" == "xmr" ]]; then
  # Look for XMR lines with "avg it/s" and get the avg number
  xmr=$(printf "%s\n" "$idle_chunk" | grep "\[XMR\]" | grep -E "avg it/s" | sed -nE 's/.*\|\s*([0-9]+)[[:space:]]+avg it\/s.*/\1/p' | tail -n1)
  [[ -n "$xmr" ]] && cpu_hs="$xmr"
else
  # Qubic: CPU from AVX* lines, GPU from CUDA lines (avg it/s)
  c=$(printf "%s\n" "$idle_chunk" | grep -E "\[(AVX512|AVX2|GENERIC)\]" | grep -E "avg it/s" | sed -nE 's/.*\|\s*([0-9]+)[[:space:]]+avg it\/s.*/\1/p' | tail -n1)
  g=$(printf "%s\n" "$idle_chunk" | grep -E "\[CUDA\]" | grep -E "avg it/s" | sed -nE 's/.*\|\s*([0-9]+)[[:space:]]+avg it\/s.*/\1/p' | tail -n1)
  [[ -n "$c" ]] && cpu_hs="$c"
  [[ -n "$g" ]] && gpu_hs="$g"
fi

# Compose algo string
algo_base="nos"
if [[ -n "$queue" ]]; then
  algo="$algo_base - queued $queue"
else
  algo="$algo_base - initializing"
fi
if [[ "$idle_mode" == "xmr" ]]; then
  algo="$algo - idle xmr"
elif [[ "$idle_mode" == "qubic" ]]; then
  algo="$algo - idle qubic"
fi

# Build hs array (separate entries)
hs_json="[]"
if [[ "$idle_mode" == "xmr" ]]; then
  hs_json="[${cpu_hs}]"
else
  hs_json="[${gpu_hs}, ${cpu_hs}]"
fi

# Total kHs = sum(it/s)/1000
total_hs=$(( ${gpu_hs:-0} + ${cpu_hs:-0} ))
khs="$(printf "%.6f" "$(awk -v t="$total_hs" 'BEGIN{ printf (t/1000) }')")"

# Version string: S:<sol> N:<nos> W:<first5>
ver=""
if [[ -n "${sol:-}" || -n "${nos:-}" || -n "${wallet:-}" ]]; then
  shortw=""
  if [[ -n "${wallet:-}" ]]; then shortw="${wallet:0:5}"; fi
  # Keep decimals as-is; don't force rounding beyond what's provided
  vs=""
  [[ -n "${sol:-}" ]] && vs+="S:${sol} "
  [[ -n "${nos:-}" ]] && vs+="N:${nos} "
  [[ -n "${shortw:-}" ]] && vs+="W:${shortw}"
  ver="$(echo "$vs" | sed 's/[[:space:]]*$//')"
fi

# Persist state (cache values)
{
  echo "status=\"$status\""
  echo "queue=\"$queue\""
  echo "sol=\"$sol\""
  echo "nos=\"$nos\""
  echo "wallet=\"$wallet\""
  echo "idle_mode=\"$idle_mode\""
} > "$STATE_FILE"

# Print outputs
echo "$khs"
jq -nc \
  --argjson hs "$hs_json" \
  --arg hs_units "hs" \
  --arg uptime "$(awk 'BEGIN{srand(); print int(rand()*600)+1 }')" \
  --arg ver "$ver" \
  --arg algo "$algo" \
  --argjson temp "[]" \
  --argjson fan "[]" \
  --argjson bus_numbers "[]" \
  '{$hs, $hs_units, $temp, $fan, $uptime, $ver, $algo, $bus_numbers}'
