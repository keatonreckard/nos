#!/usr/bin/env bash
# Idle bridge: mirror idle miner log into main nosana log with a prefix.
set -euo pipefail

LOG_DIR="/var/log/miner/nosana"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR"

case "${1:-start}" in
  start)
    # Ensure only one tailer
    if pgrep -af "idle-bridge.sh start" | grep -v "^$$" | grep -vq grep; then
      exit 0
    fi
    # Start tailer
    nohup bash -c 'tail -n0 -F "$IDLE_LOG" 2>/dev/null | stdbuf -oL -eL sed "s/^/[idle-miner] /" >> "$NOSANA_LOG"' >/dev/null 2>&1 &
    ;;
  stop)
    pgrep -af "idle-bridge.sh start" | awk "{print \$1}" | xargs -r kill
    ;;
  *)
    echo "usage: $0 {start|stop}" >&2
    exit 2
    ;;
esac
