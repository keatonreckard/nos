#!/usr/bin/env bash
set -Eeuo pipefail

IDLE_SCREEN="nosana-idle"
HIVE_MSG="/hive/bin/message"
IDLE_RUN="/hive/miners/custom/nosana/idle-run.sh"

say(){ echo "[$(date -Is)] $*"; }
notify(){ if [ -x "$HIVE_MSG" ]; then "$HIVE_MSG" info "$*"; else echo "[hive-msg] $*"; fi; }

kill_idle(){
  say "Idle kill requested"
  # Kill screen session
  screen -S "$IDLE_SCREEN" -X quit 2>/dev/null || true
  # Kill known worker binaries
  pkill -9 -f 'qli-Client|qli-worker-AVX512|qli-worker-XMR|qli-worker-CUDA' || true
}

job_active_now(){
  # Look for clear job-start signals in the last 30s of logs
  docker logs --since=30s nosana-node 2>/dev/null | \
    grep -E 'Node has found job|is starting|Flow .* is (intializing|initialized|starting|running)|Running action container/run' >/dev/null 2>&1
}

restart_idle_if_needed(){
  # If no job active and idle is not running, start it
  if ! job_active_now; then
    # check screen existing
    if ! screen -ls | grep -q "\.${IDLE_SCREEN}\b"; then
      if [ -x "$IDLE_RUN" ]; then
        notify "NOSANA: idle restart @ :07 (no job active)"
        nohup "$IDLE_RUN" >/var/log/miner/nosana/idle-restart.log 2>&1 & disown || true
      fi
    fi
  fi
}

# Hourly :04 and :07 scheduler without cron
last_kill_hour=""
last_start_hour=""

while true; do
  # Watch for job start signals continuously
  if job_active_now; then
    kill_idle
  fi

  m=$(date +%M)
  h=$(date +%H)

  if [ "$m" = "04" ] && [ "$h" != "$last_kill_hour" ]; then
    notify "NOSANA: idle kill @ :04"
    kill_idle
    last_kill_hour="$h"
  fi

  if [ "$m" = "07" ] && [ "$h" != "$last_start_hour" ]; then
    restart_idle_if_needed
    last_start_hour="$h"
  fi

  sleep 2
done
