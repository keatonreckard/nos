#!/usr/bin/env bash
set -Eeuo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
source "$DIR/nosana.conf" || true

log(){ echo "[$(date -Is)] $*"; }

start_sidecar(){
  if ! docker ps --format '{{.Names}}' | grep -q "^${PODMAN_CONTAINER_NAME}$"; then
    log "Starting Podman-in-Docker sidecar…"
    docker volume inspect podman-cache >/dev/null 2>&1 || docker volume create podman-cache >/dev/null
    docker volume inspect podman-socket >/dev/null 2>&1 || docker volume create podman-socket >/dev/null
    docker run -d --pull=always --gpus=all \
      --name "${PODMAN_CONTAINER_NAME}" \
      --device /dev/fuse \
      --mount source=podman-cache,target=/var/lib/containers \
      --volume podman-socket:/podman \
      --privileged \
      -e ENABLE_GPU=true \
      "${PODMAN_IMAGE}" unix:/podman/podman.sock
    sleep 5
  else
    log "Podman sidecar already running."
  fi
}

fix_default_podman_mtu(){
  log "[sidecar] set default network '${DEFAULT_NET_NAME}' (mtu=${MTU}) and fix built-in 'podman'"
  docker exec "${PODMAN_CONTAINER_NAME}" sh -lc "
set -e
echo '[fix] Create helper network mtuhelper (1500)'
podman network rm -f mtuhelper >/dev/null 2>&1 || true
podman network create --driver bridge -o mtu=1500 mtuhelper >/dev/null

echo '[fix] Find containers on built-in podman net'
ids=\$(podman ps --format \"{{.ID}} {{.Names}} {{.Networks}}\" | awk '\''$0 ~ /(^|[ ,])podman([ ,]|$)/ {print $1}'\'')

if [ -n \"\$ids\" ]; then
  echo '[fix] Move them to mtuhelper temporarily'
  for c in \$ids; do
    podman network connect mtuhelper \"\$c\" || true
    podman network disconnect -f podman \"\$c\" || true
  done
fi

echo '[fix] Recreate built-in podman net with MTU=${MTU}'
podman network rm -f podman >/dev/null 2>&1 || true
podman network create --driver bridge -o mtu=${MTU} podman >/dev/null

echo '[fix] Ensure default user network ${DEFAULT_NET_NAME} exists (MTU=${MTU})'
podman network rm -f ${DEFAULT_NET_NAME} >/dev/null 2>&1 || true
podman network create --driver bridge -o mtu=${MTU} ${DEFAULT_NET_NAME} >/dev/null

if [ -n \"\$ids\" ]; then
  echo '[fix] Move containers back to podman and drop helper'
  for c in \$ids; do
    podman network connect podman \"\$c\" || true
    podman network disconnect -f mtuhelper \"\$c\" || true
  done
fi

podman network rm -f mtuhelper >/dev/null 2>&1 || true
" >/dev/null 2>&1 || true
}

verify_default_mtu(){
  log "[sidecar] default (no --network) MTU:"
  docker exec "${PODMAN_CONTAINER_NAME}" podman run --rm docker.io/alpine cat /sys/class/net/eth0/mtu || true
}

start_node(){
  docker rm -f "${NOSANA_NODE_NAME}" >/dev/null 2>&1 || true
  local image="${NOSANA_CLI_IMAGE}"
  log "Launching ${NOSANA_NODE_NAME} from ${image} (pre-release)"
  docker run -d --pull=always --name "${NOSANA_NODE_NAME}" \
    --network host \
    --volume podman-socket:/root/.nosana/podman:ro \
    "${image}" node start \
      --podman /root/.nosana/podman/podman.sock \
      --network mainnet
}

start_idle_guard(){
  if [ -x "${DIR}/idle-guard.sh" ]; then
    nohup "${DIR}/idle-guard.sh" >/var/log/miner/nosana/idle-guard.log 2>&1 & disown || true
  fi
}

main(){
  log "h-run: cleaning previous containers"
  docker rm -f "${NOSANA_NODE_NAME}" >/dev/null 2>&1 || true

  log "h-run: starting podman sidecar"
  start_sidecar
  fix_default_podman_mtu
  verify_default_mtu

  log "h-run: starting nosana-node container"
  start_node
  start_idle_guard
}
main "$@"
