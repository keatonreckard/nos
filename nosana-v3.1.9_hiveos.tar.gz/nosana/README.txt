Nosana wrapper v3.1.9 (full)
- Fixed monitor.sh quoting and ensured logs exist before use.
- Version string updates with algo; no N/A when values present.
