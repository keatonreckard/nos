#!/usr/bin/env bash
set -euo pipefail
SIDE=podman
mkdir -p /var/log/miner/nosana /run/hive

job_running() {
  docker exec ${SIDE} podman ps --format '{{.Image}} {{.Status}}' 2>/dev/null | grep -E 'nosana/(nn|comfy):' >/dev/null
}

idle_running() {
  screen -ls 2>/dev/null | grep -q '\.idle'
}

KILL_IDLE(){
  screen -S idle -X quit >/dev/null 2>&1 || true
  pkill -9 -f "qli-Client|qli-worker-AVX512|qli-worker-XMR|qli-worker-CUDA" >/dev/null 2>&1 || true
}

START_IDLE(){
  /hive/miners/custom/nosana/idle-run.sh >/dev/null 2>&1 || true
}

echo "[idle-cron] started (kill :04, ensure idle :07)"
{
  while :; do
    m=$(date +%M); s=$(date +%S)
    if [ "$m" = "04" ] && [ "$s" = "00" ]; then
      echo "$(date -Is) [idle-cron] :04 kill idle"
      KILL_IDLE
      sleep 1
    elif [ "$m" = "07" ] && [ "$s" = "00" ]; then
      if job_running; then
        echo "$(date -Is) [idle-cron] :07 skip (job running)"
      else
        if idle_running; then
          echo "$(date -Is) [idle-cron] :07 idle already running"
        else
          echo "$(date -Is) [idle-cron] :07 starting idle"
          START_IDLE
        fi
      fi
      sleep 1
    fi
    sleep 0.5
  done
} >> /var/log/miner/nosana/idle-cron.log 2>&1 &

echo $! > /run/hive/nosana.idle-cron.pid
