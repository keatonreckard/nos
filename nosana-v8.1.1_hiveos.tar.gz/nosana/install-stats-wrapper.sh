\
    #!/usr/bin/env bash
    set -euo pipefail
    MINER_DIR="/hive/miners/custom/nosana"
    TARGET="/hive/miners/custom/h-stats.sh"
    SRC="$MINER_DIR/h-stats-wrapper.sh"
    if [[ ! -x "$SRC" ]]; then
      echo "Missing $SRC" >&2
      exit 1
    fi
    install -m 0755 -D "$SRC" "$TARGET"
    echo "Installed custom stats wrapper to $TARGET"
