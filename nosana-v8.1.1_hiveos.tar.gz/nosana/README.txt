NOSANA (HiveOS custom miner package)
-----------------------------------
Built: 2025-08-21T16:57:00

v8.1.1_hiveos:
- Ensures the stats JSON goes to FD3 (the channel Hive agent ingests) and nothing else.
- Wrapper installs as /hive/miners/custom/h-stats.sh and simply execs your miner's h-stats.sh (keeps FD3).
- No shares in JSON; KH/s mapping unchanged; version caching added.
- Idle files unchanged.
