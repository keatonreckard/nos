\
    #!/usr/bin/env bash
    set -euo pipefail
    exec 3>&1
    # Identify current custom miner
    : "${CUSTOM_MINER:=nosana}"
    miner_stats_path="/hive/miners/custom/${CUSTOM_MINER}/h-stats.sh"
    if [[ ! -x "$miner_stats_path" ]]; then
      echo "stats wrapper: $miner_stats_path not found or not executable" >&2
      # Fallback: output minimal valid JSON to FD3 so agent doesn't break
      printf '%s\n' '{"hs":[0],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"","algo":"nos - initializing","bus_numbers":[]}' >&3
      exit 0
    fi
    # Execute miner stats script; it must write the JSON to FD3
    exec "$miner_stats_path"
