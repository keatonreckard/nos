#!/usr/bin/env bash
# nosana monitor v87
# - Persistent attach to node logs (retry forever)
# - Show full boot lines (Network/Wallet/SOL/NOS/Provider) every start
# - Dedupe within session only; prefix with [nosana-node]
# - Auto start/stop idle miner based on QUEUED / job start/finish
# - FIX: pipeline now prints lines to STDOUT so `miner log` shows them

set -u
export LC_ALL=C

MINER_DIR="${MINER_DIR:-/hive/miners/custom/nosana}"
LOG_DIR="${LOG_DIR:-/var/log/miner/nosana}"
RUN_DIR="${RUN_DIR:-/var/run}"
MINER_LOG="$LOG_DIR/nosana.log"
DEBUG_LOG="$LOG_DIR/debug.log"
IDLE_LOG="$LOG_DIR/idle.log"
SESSION_LOCK="$RUN_DIR/.nosana_session_started"
SEEN_FILE="$MINER_DIR/.node_seen"

mkdir -p "$LOG_DIR" "$RUN_DIR" 2>/dev/null || true
touch "$MINER_LOG" "$DEBUG_LOG" "$IDLE_LOG"

# Truncate logs only on first miner start this boot
if [ ! -f "$SESSION_LOCK" ]; then
  : > "$MINER_LOG"
  : > "$DEBUG_LOG"
  touch "$SESSION_LOCK"
fi

# Reset dedupe so balances/network print every start
rm -f "$SEEN_FILE" 2>/dev/null || true
: > "$SEEN_FILE"

msg() { if [ -x /hive/bin/message ]; then /hive/bin/message info "$1" >/dev/null 2>&1 || true; fi; }

echo "[nosana] monitor started" | tee -a "$MINER_LOG"
msg "NOS: monitor started"

idle_running() { screen -ls 2>/dev/null | grep -qE '\.nosana-idle'; }
start_idle() { if ! idle_running; then bash "$MINER_DIR/idle-run.sh" >>"$DEBUG_LOG" 2>&1 || true; fi; }
stop_idle()  { if  idle_running; then bash "$MINER_DIR/idle-kill.sh" >>"$DEBUG_LOG" 2>&1 || true; fi; }

normalize_line() { sed -E 's/\x1B\[[0-9;]*[A-Za-z]//g; s/\r//g'; }
drop_ascii() {
  awk '{
    s=$0; gsub(/^[[:space:]]+|[[:space:]]+$/, "", s);
    if (s=="") next;
    if (s ~ /^[-=_]{3,}$/) next;
    if (s ~ /^[|\/\\_[:space:]]{5,}$/) next;
    print;
  }'
}
dedupe_and_prefix() {
  while IFS= read -r ln; do
    t="${ln#"${ln%%[![:space:]]*}"}"; t="${t%"${t##*[![:space:]]}"}"
    [ -z "$t" ] && continue
    if ! grep -Fxq -- "$t" "$SEEN_FILE" 2>/dev/null; then
      printf "%s\n" "$t" >> "$SEEN_FILE"
      printf "[nosana-node] %s\n" "$t"
    fi
  done
}

runtime_cmd=""
if command -v docker >/dev/null 2>&1; then
  runtime_cmd="docker"
elif command -v podman >/dev/null 2>&1; then
  runtime_cmd="podman"
fi

stream_logs() {
  while true; do
    if [ -n "$runtime_cmd" ]; then
      $runtime_cmd logs -f --since 0s nosana-node 2>&1 || true
    else
      echo "container runtime not found" 1>&2
      sleep 2
    fi
    sleep 1
  done
}

# NEW: while consumes the stream and echoes back out, then tee logs it
stream_logs | normalize_line | drop_ascii | dedupe_and_prefix | \
while IFS= read -r out; do
  # print the line so Hive sees it
  echo "$out"
  # react to state
  case "$out" in
    *"QUEUED"*|*" In market "*position*)
      start_idle
      ;;
    *"Job "*started*|*" is running"*|*"Flow "*started*|*"Starting job"*|*"Executing"*"job"*)
      stop_idle
      ;;
    *"finished successfully"*|*"Job "*completed*|*"Flow "*finished*|*"Nosana Node finished"*)
      stop_idle
      ;;
  esac
done | tee -a "$MINER_LOG"

# Keep alive
while true; do sleep 60; done