#!/usr/bin/env bash
# Global HiveOS custom stats wrapper (safe pass-through)
# Purpose: call the selected miner's h-stats.sh and forward exactly two lines.
set -euo pipefail
MINER_DIR="${MINER_DIR:-/hive/miners/custom}"
: "${CUSTOM_MINER:?CUSTOM_MINER not set}"
STAT="$MINER_DIR/$CUSTOM_MINER/h-stats.sh"
if [[ ! -x "$STAT" ]]; then
  echo "0"
  echo '{"hs":[],"hs_units":"hs","temp":[],"fan":[],"uptime":"0","ver":"","algo":"nos"}'
  exit 0
fi
# Run and capture
out="$("$STAT" 2>/dev/null || true)"
line1="$(printf "%s\n" "$out" | sed -n '1p')"
line2="$(printf "%s\n" "$out" | sed -n '2p')"
# Normalize
if ! printf "%s" "$line1" | grep -Eq '^[0-9]+([.][0-9]+)?$'; then line1="0"; fi
if [[ -z "$line2" ]]; then line2='{"hs":[],"hs_units":"hs","temp":[],"fan":[],"uptime":"0","ver":"","algo":"nos"}'; fi
printf "%s\n" "$line1"
printf "%s\n" "$line2"
