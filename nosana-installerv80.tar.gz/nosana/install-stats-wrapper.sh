#!/usr/bin/env bash
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/h-stats-wrapper.sh"
DST="/hive/miners/custom/h-stats.sh"
install -m 0755 "$SRC" "$DST"
echo "[nosana] installed stats pass-through wrapper to $DST"
