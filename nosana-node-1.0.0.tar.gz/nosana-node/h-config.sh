```bash
#!/bin/bash

# HiveOS custom miner config script for Nosana Node
# Generates nosana.conf based on extra config

CONFIG_DIR="/hive/miners/custom/nosana-node/config"
CONFIG_FILE="$CONFIG_DIR/nosana.conf"

mkdir -p "$CONFIG_DIR"

# Write extra config to nosana.conf, prefixed with VERBOSE=
echo "VERBOSE=$CUSTOM_USER_CONFIG" > "$CONFIG_FILE"
```
