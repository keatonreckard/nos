```bash
#!/bin/bash

# HiveOS custom miner run script for Nosana Node
# Installs dependencies, manages node, keypair, idle settings, and status updates

MINER_NAME="nosana-node"
MINER_DIR="/hive/miners/custom/$MINER_NAME"
CONFIG_DIR="$MINER_DIR/config"
LOG_DIR="/var/log/miner/$MINER_NAME"
LOG_FILE="$LOG_DIR/$MINER_NAME.log"
STATS_FILE="$MINER_DIR/h-stats.sh"
CONFIG_FILE="$CONFIG_DIR/nosana.conf"
NOSANA_KEY_DIR="/root/.nosana"
NOSANA_KEY_FILE="$NOSANA_KEY_DIR/nosana_key.json"

# Ensure directories exist
mkdir -p "$MINER_DIR" "$CONFIG_DIR" "$LOG_DIR" "$NOSANA_KEY_DIR"

# Install dependencies
install_dependencies() {
    echo "Installing dependencies..." >> "$LOG_FILE"
    apt-get update
    apt-get install -y gpg docker.io jq
    if ! command -v nvidia-smi >/dev/null 2>&1; then
        echo "Installing Nvidia drivers..." >> "$LOG_FILE"
        apt-get install -y nvidia-driver nvidia-utils
    fi
    if ! command -v nvidia-ctk >/dev/null 2>&1; then
        echo "Installing Nvidia Container Toolkit..." >> "$LOG_FILE"
        curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
        curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
            sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
            tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
        apt-get update
        apt-get install -y nvidia-container-toolkit
        nvidia-ctk cdi generate --output=/etc/cdi/nvidia.yaml
    fi
    # Ensure Docker is in user group
    if ! groups | grep -q docker; then
        usermod -aG docker $USER
    fi
    echo "Dependencies installed." >> "$LOG_FILE"
}

# Parse extra config for keypair and idle settings
parse_extra_config() {
    EXTRA_CONFIG="$CUSTOM_USER_CONFIG"
    KEYPAIR=$(echo "$EXTRA_CONFIG" | jq -r '.keypair // ""')
    IDLE_SETTINGS=$(echo "$EXTRA_CONFIG" | jq -r '.idleSettings // ""')
    if [ -n "$KEYPAIR" ]; then
        echo "Writing Solana keypair to $NOSANA_KEY_FILE" >> "$LOG_FILE"
        mkdir -p "$NOSANA_KEY_DIR"
        echo "$KEYPAIR" > "$NOSANA_KEY_FILE"
        chmod 600 "$NOSANA_KEY_FILE"
    fi
}

# Start Nosana node
start_nosana_node() {
    echo "Starting Nosana node..." >> "$LOG_FILE"
    # Set initial algorithm status
    echo "nos - initializing" > "$MINER_DIR/algo"
    # Stop any existing node
    docker rm -f nosana-node podman >/dev/null 2>&1
    kill -9 $(pidof podman) >/dev/null 2>&1
    # Create Docker volumes if not exist
    docker volume create podman-cache >/dev/null 2>&1
    docker volume create podman-socket >/dev/null 2>&1
    # Start podman
    docker run -d \
        --pull=always \
        --gpus=all \
        --name podman \
        --device /dev/fuse \
        --mount source=podman-cache,target=/var/lib/containers \
        --volume podman-socket:/podman \
        --privileged \
        -e ENABLE_GPU=true \
        nosana/podman:v1.1.0 unix:/podman/podman.sock >> "$LOG_FILE" 2>&1
    sleep 5
    # Start Nosana node
    DOCKER_ARGS=(
        --pull=always
        --name nosana-node
        --network host
        --interactive -t
        --volume ~/.nosana/:/root/.nosana/
    )
    NOSANA_NODE_ARGS=(
        node start
        --network mainnet
    )
    if grep -q "VERBOSE=true" "$CONFIG_FILE"; then
        NOSANA_NODE_ARGS+=(--log trace)
    fi
    docker run "${DOCKER_ARGS[@]}" nosana/nosana-cli:latest "${NOSANA_NODE_ARGS[@]}" >> "$LOG_FILE" 2>&1 &
    NODE_PID=$!
}

# Monitor logs and update status
monitor_logs() {
    SOL_BALANCE="0.0000"
    NOS_BALANCE="0.0000"
    CURRENT_ALGO="nos - initializing"
    IDLE_PID=""
    tail -f "$LOG_FILE" | while read -r line; do
        # Output logs to motd watch
        echo "$line"
        # Parse balances
        if echo "$line" | grep -q "SOL Balance:"; then
            NEW_SOL=$(echo "$line" | grep -oP "SOL Balance: \K[0-9.]+(?= SOL)" | head -1 | awk '{printf "%.4f", $1}')
            [ -n "$NEW_SOL" ] && SOL_BALANCE="$NEW_SOL"
        fi
        if echo "$line" | grep -q "NOS Balance:"; then
            NEW_NOS=$(echo "$line" | grep -oP "NOS Balance: \K[0-9.]+(?= NOS)" | head -1 | awk '{printf "%.4f", $1}')
            [ -n "$NEW_NOS" ] && NOS_BALANCE="$NEW_NOS"
        fi
        # Update stats with balances
        cat << EOF > "$STATS_FILE"
#!/bin/bash
khs=0
stats='{"hs":[],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"SOL: $SOL_BALANCE, NOS: $NOS_BALANCE","algo":"$CURRENT_ALGO"}'
echo \$stats
EOF
        chmod +x "$STATS_FILE"
        # Parse queue position
        if echo "$line" | grep -q "Queue position:"; then
            QUEUE_POS=$(echo "$line" | grep -oP "Queue position: \K[0-9]+/[0-9]+" | head -1)
            if [ -n "$QUEUE_POS" ]; then
                CURRENT_ALGO="nos - queued $QUEUE_POS"
                echo "$CURRENT_ALGO" > "$MINER_DIR/algo"
                # Start idle settings if present
                if [ -n "$IDLE_SETTINGS" ] && [ -z "$IDLE_PID" ]; then
                    CMD=$(echo "$IDLE_SETTINGS" | jq -r '.command // ""')
                    ARGS=$(echo "$IDLE_SETTINGS" | jq -r '.arguments // ""' | sed "s/%WORKER_NAME%/$RIG_ID/g")
                    if [ -n "$CMD" ]; then
                        echo "Starting idle command: $CMD $ARGS" >> "$LOG_FILE"
                        $CMD $ARGS >> "$LOG_FILE" 2>&1 &
                        IDLE_PID=$!
                    fi
                fi
            fi
        fi
        # Detect job start
        if echo "$line" | grep -q "Starting job"; then
            CURRENT_ALGO="nos - job"
            echo "$CURRENT_ALGO" > "$MINER_DIR/algo"
            # Kill idle command if running
            if [ -n "$IDLE_PID" ]; then
                echo "Stopping idle command (PID: $IDLE_PID)" >> "$LOG_FILE"
                kill -9 "$IDLE_PID" >/dev/null 2>&1
                IDLE_PID=""
            fi
        fi
    done &
    LOG_MONITOR_PID=$!
}

# Main execution
main() {
    install_dependencies
    parse_extra_config
    start_nosana_node
    monitor_logs
    wait $NODE_PID
}

# Trap SIGTERM to clean up
trap 'echo "Stopping Nosana node..." >> "$LOG_FILE"; docker rm -f nosana-node podman >/dev/null 2>&1; kill -9 $(pidof podman) >/dev/null 2>&1; kill -9 $LOG_MONITOR_PID >/dev/null 2>&1; kill -9 $IDLE_PID >/dev/null 2>&1; exit 0' SIGTERM

main "$@"
```
