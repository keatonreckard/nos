#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"

status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""; idle_enabled=0
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

if [[ -s "$NOSANA_LOG" ]]; then
  [[ -z "${wallet:-}" ]] && wallet=$(grep -E '^Wallet:\s+[A-Za-z0-9]{32,48}' "$NOSANA_LOG" | tail -n1 | awk '{print $2}' 2>/dev/null || true)
  [[ -z "${sol:-}"    ]] && sol=$(grep -E 'SOL balance:\s+[0-9]+\.[0-9]+' "$NOSANA_LOG" | tail -n1 | awk '{print $3}' 2>/dev/null || true)
  [[ -z "${nos:-}"    ]] && nos=$(grep -E 'NOS balance:\s+[0-9]+\.[0-9]+' "$NOSANA_LOG" | tail -n1 | awk '{print $3}' 2>/dev/null || true)
  if [[ "${status}" == "nos - initializing" ]]; then
    if grep -Eq 'claimed job|Job .* started|Flow .* started' "$NOSANA_LOG"; then
      status="nos - job"; queue=""
    else
      qp=$(grep -E 'position [0-9]+/[0-9]+' "$NOSANA_LOG" | tail -n1 | sed -n 's/.*position \([0-9]\+\/[0-9]\+\).*/\1/p' 2>/dev/null || true)
      [[ -n "${qp:-}" ]] && { status="nos - queued ${qp}"; queue="${qp}"; }
    fi
  fi
fi

format4() { awk -v n="${1:-0}" 'BEGIN{printf("%.4f", n+0)}'; }

temp_json='[]'; fan_json='[]'; bus_json='[]'
if [[ -f /hive/bin/gpu-stats ]]; then
  # shellcheck disable=SC1091
  source /hive/bin/gpu-stats || true
  if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then
    temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"
  fi
  if [[ "${#GPU_FAN[@]:-0}" -gt 0 ]]; then
    fan_json="["$(printf "%s," "${GPU_FAN[@]}" | sed 's/,$//')"]"
  fi
  if [[ "${#BUS_IDS[@]:-0}" -gt 0 ]]; then
    bus_list=()
    for b in "${BUS_IDS[@]}"; do
      d=$((16#${b%%:*}))
      bus_list+=("$d")
    done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

now=$(date +%s)
if [[ -f "$MINER_DIR/job.start.time" ]]; then
  start_time=$(cat "$MINER_DIR/job.start.time")
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then
  start_time=$(cat "$MINER_DIR/idle.start.time")
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then
  start_time=$(cat "$MINER_DIR/nosana.start.time")
else
  start_time=$((now - $(awk '{print int($1)}' /proc/uptime)))
fi
uptime=$((now - start_time)); ((uptime<0)) && uptime=0

parse_idle_stats() {
  local L hs_val hs_unit khs="0" acc="0" rej="0"
  [[ -s "$IDLE_LOG" ]] || { echo "0|0|0"; return; }
  L="$(tail -n 400 "$IDLE_LOG")"
  hs_val=$(echo "$L" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1 | awk '{print $1}' 2>/dev/null || true)
  hs_unit=$(echo "$L" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1 | awk '{print $2}' | sed 's#/s##I' 2>/dev/null || true)
  if [[ -n "${hs_val:-}" && -n "${hs_unit:-}" ]]; then
    case "${hs_unit^^}" in
      H) khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v/1000)}');;
      KH) khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v)}');;
      MH) khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v*1000)}');;
      GH) khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v*1000*1000)}');;
    esac
  fi
  if echo "$L" | grep -Eiq 'Shares:|accepted|A:[0-9]+'; then
    if echo "$L" | grep -Eio '([0-9]+)\/([0-9]+)'; then
      acc=$(echo "$L" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f1)
      rej=$(echo "$L" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f2)
    else
      acc=$(echo "$L" | grep -Eio 'A:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)
      rej=$(echo "$L" | grep -Eio 'R:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)
    fi
  fi
  echo "${khs}|${acc}|${rej}"
}

sol4="$( [[ -n "${sol:-}" ]] && format4 "$sol" || echo "N/A")"
nos4="$( [[ -n "${nos:-}" ]] && format4 "$nos" || echo "N/A")"
wallet_short="$(printf '%s' "${wallet:-N/A}" | cut -c1-5)"
ver="S:${sol4} N:${nos4} W:${wallet_short}"

algo="${status:-nos}"

khs="0"; ar_acc="0"; ar_rej="0"
if echo "$algo" | grep -qi 'queued'; then
  IFS='|' read -r khs ar_acc ar_rej <<<"$(parse_idle_stats)"
fi

stats=$(cat <<JSON
{"hs":[${khs}],"hs_units":"khs","temp":${temp_json},"fan":${fan_json},"uptime":${uptime},"ver":"${ver}","ar":[${ar_acc},${ar_rej}],"algo":"${algo}","bus_numbers":${bus_json}}
JSON
)
