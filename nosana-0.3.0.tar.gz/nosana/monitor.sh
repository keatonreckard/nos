#!/usr/bin/env bash
set -uo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
DEBUG_LOG="$LOG_DIR/debug.log"
MINER_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

IDLE_PID_FILE="$RUN_DIR/nosana_idle.pid"
LOCK_FILE="$RUN_DIR/nosana_monitor.lock"
IDLE_TITLE="nosana-idle"   # screen window title

IDLE_COMMAND="$(cat "$MINER_DIR/parsed/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$MINER_DIR/parsed/idle_args" 2>/dev/null || true)"

[[ -f "$LOCK_FILE" ]] && { echo "[$(date -Iseconds)] monitor: removing stale lock" >> "$DEBUG_LOG"; rm -f "$LOCK_FILE"; }
echo $$ > "$LOCK_FILE"
trap 'rm -f "$LOCK_FILE"' EXIT

set_state() {
  local key="$1" val="$2"
  local esc
  esc=$(printf '%s' "$val" | sed -e 's/[\\/&]/\\&/g' -e 's/"/\\"/g')
  touch "$STATE_FILE"
  if grep -q "^${key}=" "$STATE_FILE"; then
    sed -i -E "s#^(${key}=).*#\\1\"${esc}\"#g" "$STATE_FILE"
  else
    echo "${key}=\"${val}\"" >> "$STATE_FILE"
  fi
}

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

miner_screen_present() {
  screen -ls | grep -q "[.]miner[[:space:]]"
}

start_idle() {
  [[ -z "$IDLE_COMMAND" ]] && return 0
  if miner_screen_present && screen -S miner -Q windows 2>/dev/null | grep -q "$IDLE_TITLE"; then
    return 0
  fi
  local args="${IDLE_ARGS//%WORKER_NAME%/${WORKER_NAME:-worker}}"
  date +%s > "$MINER_DIR/idle.start.time"
  rm -f "$MINER_DIR/job.start.time"
  if miner_screen_present; then
    # start as a new window inside the Hive "miner" session
    screen -S miner -X screen -t "$IDLE_TITLE" bash -lc "$IDLE_COMMAND $args 2>&1 | stdbuf -oL -eL tee -a '$IDLE_LOG'"
  else
    # fallback: standalone screen session (rare)
    screen -dmS "$IDLE_TITLE" bash -lc "$IDLE_COMMAND $args 2>&1 | stdbuf -oL -eL tee -a '$IDLE_LOG'"
  fi
  echo "[nosana] queued → idle miner started"
  msg "NOS: queued → started idle miner"
}

stop_idle() {
  if miner_screen_present && screen -S miner -Q windows 2>/dev/null | grep -q "$IDLE_TITLE"; then
    screen -S miner -p "$IDLE_TITLE" -X kill || true
  fi
  if screen -ls | grep -q "[.]$IDLE_TITLE[[:space:]]"; then
    screen -S "$IDLE_TITLE" -X quit || true
  fi
}

bootstrap_state_once() {
  local SINCE="${1:-60m}"
  local bootlog
  bootlog="$(docker logs --since "$SINCE" nosana-node 2>&1 || true)"
  if [[ -z "$bootlog" ]]; then
    set_state status "nos - initializing"
    echo "[nosana] initializing"
    return 0
  fi
  local w sb nb
  w="$(echo "$bootlog" | grep -E '^Wallet:\s+[A-Za-z0-9]{32,48}' | tail -n1 | awk '{print $2}' 2>/dev/null || true)"
  [[ -n "${w:-}" ]] && set_state wallet "$w"
  sb="$(echo "$bootlog" | grep -E 'SOL balance:\s+[0-9]+\.[0-9]+' | tail -n1 | awk '{print $3}' 2>/dev/null || true)"
  nb="$(echo "$bootlog" | grep -E 'NOS balance:\s+[0-9]+\.[0-9]+' | tail -n1 | awk '{print $3}' 2>/dev/null || true)"
  [[ -n "${sb:-}" ]] && set_state sol "$sb"
  [[ -n "${nb:-}" ]] && set_state nos "$nb"

  if echo "$bootlog" | grep -Eqi 'claimed job|Job .* started|Flow .* started'; then
    set_state status "nos - job"; set_state queue ""
    date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
    stop_idle
  elif echo "$bootlog" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
    local pos
    pos="$(echo "$bootlog" | grep -E 'position [0-9]+/[0-9]+' | tail -n1 | sed -n 's/.*position \([0-9]\+\/[0-9]\+\).*/\1/p' 2>/dev/null || true)"
    if [[ -n "${pos:-}" ]]; then
      set_state status "nos - queued ${pos}"; set_state queue "${pos}"
    else
      set_state status "nos - queued"
    fi
    date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
    start_idle
  else
    set_state status "nos - initializing"
  fi
}

date +%s > "$MINER_DIR/nosana.start.time"
set_state status "nos - initializing"
echo "[nosana] monitor started"

bootstrap_state_once "60m"
last_hb=$(date +%s)

last_idle_flush=0

while true; do
  { 
    logchunk="$(docker logs --since 10s nosana-node 2>&1 || true)"
    if [[ -n "$logchunk" ]]; then
      printf "%s\n" "$logchunk" | tee -a "$MINER_LOG"
      while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        if [[ "$line" =~ ^Wallet:\ +([A-Za-z0-9]{32,48}) ]]; then set_state wallet "${BASH_REMATCH[1]}"; fi
        if [[ "$line" =~ SOL\ balance:\ +([0-9]+\.[0-9]+) ]]; then set_state sol "${BASH_REMATCH[1]}"; fi
        if [[ "$line" =~ NOS\ balance:\ +([0-9]+\.[0-9]+) ]]; then set_state nos "${BASH_REMATCH[1]}"; fi
        if [[ "$line" =~ \ position\ ([0-9]+)\/([0-9]+) ]] || [[ "$line" =~ ^.*QUEUED.*position\ ([0-9]+)\/([0-9]+) ]]; then
          pos="${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
          set_state status "nos - queued ${pos}"; set_state queue "${pos}"
          date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
          start_idle
        fi
        if echo "$line" | grep -Eqi 'claimed job|Job .* started|Flow .* started'; then
          set_state status "nos - job"; set_state queue ""
          date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
          stop_idle
        fi
        if echo "$line" | grep -Eq "Nosana Node finished|Job .* completed|Flow .* (finished|completed)"; then
          bootstrap_state_once "10m"
        fi
      done <<< "$logchunk"
    fi

    # lightly splice idle lines into main nosana.log for motd
    now=$(date +%s)
    if (( now - last_idle_flush >= 20 )) && [[ -s "$IDLE_LOG" ]]; then
      tail -n 5 "$IDLE_LOG" | sed 's/^/[idle] /' >> "$MINER_LOG"
      last_idle_flush=$now
    fi
  } || true

  now=$(date +%s)
  if (( now - last_hb >= 30 )); then
    echo "[nosana] hb $(date -Iseconds)"
    last_hb=$now
  fi
  sleep 5
done
