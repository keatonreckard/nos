#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"

# Helper: detect idle miner screen session
idle_running() { screen -ls 2>/dev/null | grep -q "nosana-idle"; }

mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""; idle_enabled=0
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

# Assemble + clean logs, strip ANSI
L=""; [[ -s "$NOSANA_LOG" ]] && L="$(tail -n 3000 "$NOSANA_LOG" | tr -d '\r')"
if [[ -z "$L" ]]; then
  C="$(docker logs --since 10m nosana-node 2>/dev/null || true)"
  [[ -n "$C" ]] && L="$(printf "%s" "$C" | tr -d '\r')"
fi
CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"

# Wallet from explicit labels
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
fi
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*(Public[[:space:]]*Key|Pubkey|Address)[[:space:]]*:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\2/p' | tail -n1)"
fi
# Wallet from node URL
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
fi

# Balances
if [[ -z "${sol:-}" ]]; then
  sol="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
if [[ -z "${nos:-}" ]]; then
  nos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi



# Determine status (latest line logic)
status="nos - initializing"; queue=""
L=""; [[ -s "$NOSANA_LOG" ]] && L="$(tail -n 3000 "$NOSANA_LOG" | tr -d '\r')"
if [[ -z "$L" ]]; then
  C="$(podman logs --since 10m nosana-node 2>/dev/null || docker logs --since 10m nosana-node 2>/dev/null || true)"
  [[ -n "$C" ]] && L="$(printf "%s" "$C" | tr -d '\r')"
fi
CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"

job_ln=$(printf "%s\n" "$CLEAN" | awk '/Node is claiming job|Node has found job|claimed job|Job .* (started|running)|Flow .* (started|running)/ {ln=NR} END{print ln+0}')
queue_ln=$(printf "%s\n" "$CLEAN" | awk '/position[[:space:]]+[0-9]+\/[0-9]+|QUEUED/ {ln=NR} END{print ln+0}')
if (( job_ln > queue_ln && job_ln > 0 )); then
  status="nos - job"; queue=""
else
  pos="$(printf "%s\n" "$CLEAN" | awk "/position[[:space:]]+[0-9]+\/[0-9]+/ {p=\$0} END{print p}" | sed -nE "s/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p")"
  if [[ -n "${pos:-}" ]]; then
    status="nos - queued ${pos}"; queue="${pos}"
  elif printf "%s\n" "$CLEAN" | grep -Eqi 'QUEUED'; then
    status="nos - queued"
  fi
fi

# Decide idle activity: require screen + non-empty idle log to avoid premature flip
idle_active=0
if idle_running && [[ -s "$IDLE_LOG" ]]; then idle_active=1; fi

# Algo mirrors status; when queued + idle, append suffix
algo="${status:-nos}"
if (( idle_active )); then
  if echo "$algo" | grep -qi 'queued'; then
    algo="${algo} - idle mining"
  elif ! echo "$algo" | grep -qi 'job'; then
    algo="nos - idle mining"
  fi
fi

# KH/s policy
khs="0"; ar_acc="0"; ar_rej="0"
if echo "$status" | grep -qi "nos - job"; then
  khs="1"
elif echo "$status" | grep -qi "nos - queued"; then
  if [[ -n "${queue:-}" ]]; then khs="${queue%%/*}"
  else first="$(printf "%s" "$status" | sed -nE "s/.*queued[[:space:]]+([0-9]+).*/\1/p")"; [[ -n "$first" ]] && khs="$first"; fi
elif (( idle_active )); then
  khs="2"
fi

# Sanitize hashrate
khs="$(printf "%s" "$khs" | sed 's|/.*||; s/[^0-9.]//g')"
[[ -z "$khs" ]] && khs="0"

# Uptime



now=$(date +%s)
if [[ -f "$MINER_DIR/job.start.time" ]]; then start_time=$(cat "$MINER_DIR/job.start.time")
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then start_time=$(cat "$MINER_DIR/idle.start.time")
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then start_time=$(cat "$MINER_DIR/nosana.start.time")
else read -r up _ < /proc/uptime; start_time=$(( now - ${up%.*} )); fi
uptime=$((now - start_time)); ((uptime<0)) && uptime=0


algo="${status:-nos}"
# KH/s policy: job=1, queued=queue position (first number), idle=2, else 0
# Idle overrides everything
if idle_running; then
  algo="nos - idle mining"
  khs="2"
elif echo "$status" | grep -qi "nos - job"; then
  khs="1"
elif echo "$status" | grep -qi "nos - queued"; then
  # Extract first number from queue position (e.g., 12/34 -> 12)
  if [[ -n "${queue:-}" ]]; then khs="${queue%%/*}";
  else first="$(printf "%s" "$status" | sed -nE 's/.*queued[[:space:]]+([0-9]+).*/\1/p')"; [[ -n "$first" ]] && khs="$first"; fi
fi
# Version string: only include known fields
ver=""
if [[ -n "${sol:-}" ]]; then printf -v solf "%.4f" "$sol"; ver+="S:${solf}"; fi
if [[ -n "${nos:-}" ]]; then printf -v nosf "%.4f" "$nos"; ver+="${ver:+ }N:${nosf}"; fi
if [[ -n "${wallet:-}" ]]; then ver+="${ver:+ }W:$(printf "%s" "$wallet" | cut -c1-5)"; fi

# GPU arrays (best-effort)
temp_json='[]'; fan_json='[]'; bus_json='[]'
if [[ -f /hive/bin/gpu-stats ]]; then
  source /hive/bin/gpu-stats || true
  if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [[ "${#GPU_FAN[@]:-0}" -gt 0 ]]; then  fan_json ="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
  if [[ "${#BUS_IDS[@]:-0}" -gt 0 ]]; then
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

stats=$(cat <<JSON
{"hs":[${khs}],"hs_units":"khs","temp":${temp_json},"fan":${fan_json},"uptime":${uptime},"ver":"${ver}","ar":[${ar_acc},${ar_rej}],"algo":"${algo}","bus_numbers":${bus_json}}
JSON
)
printf "[%s] h-stats: ver=%s | algo=%s | khs=%s | wallet=%s | sol=%s | nos=%s\n" "$(date -Iseconds)" "$ver" "$algo" "$khs" "$wallet" "$sol" "$nos" >> "$LOG_DIR/debug.log" || true
echo "$stats"
