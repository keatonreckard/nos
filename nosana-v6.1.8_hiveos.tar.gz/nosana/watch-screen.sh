#!/usr/bin/env bash
set -euo pipefail
MINER_DIR="/hive/miners/custom/nosana"
# Start or reattach a screen named nosana-watch that runs the interleaved watcher
if screen -ls | grep -q "nosana-watch"; then
  exec screen -r nosana-watch
else
  screen -S nosana-watch -dm bash -lc "$MINER_DIR/watch-logs.sh"
  exec screen -r nosana-watch
fi
