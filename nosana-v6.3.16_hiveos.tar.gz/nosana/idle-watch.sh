#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
LOG_DIR="/var/log/miner/nosana"
CUSTOM_LOG="/var/log/miner/custom/custom.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
PIDFILE="$RUN_DIR/nosana.idlewatch.pid"
STATE="$RUN_DIR/nosana.idle_state"

mkdir -p "$RUN_DIR" "$LOG_DIR" "$(dirname "$CUSTOM_LOG")"
touch "$NOSANA_LOG" "$IDLE_LOG" "$CUSTOM_LOG"

idle_running(){ screen -ls 2>/dev/null | grep -q "\.nosana-idle"; }

start_idle(){
  if ! idle_running; then
    echo "[idle-queue] watcher: starting idle miner" | tee -a "$IDLE_LOG" "$NOSANA_LOG" "$CUSTOM_LOG" >/dev/null
    ( bash -lc "$MINER_DIR/idle-run.sh" ) >>"$IDLE_LOG" 2>&1 &
  fi
  echo "idle" > "$STATE" 2>/dev/null || true
}
stop_idle(){
  if idle_running; then
    echo "[idle-queue] watcher: stopping idle miner" | tee -a "$IDLE_LOG" "$NOSANA_LOG" "$CUSTOM_LOG" >/dev/null
    bash "$MINER_DIR/idle-kill.sh" >>"$IDLE_LOG" 2>&1 || true
  fi
  echo "stopped" > "$STATE" 2>/dev/null || true
}

detect_and_toggle(){
  # Gather recent logs (favor container, fallback to nosana.log)
  local L CLEAN
  L="$(podman logs --tail 400 nosana-node 2>/dev/null || docker logs --tail 400 nosana-node 2>/dev/null || true)"
  if [[ -z "${L:-}" && -s "$NOSANA_LOG" ]]; then
    L="$(tail -n 400 "$NOSANA_LOG" 2>/dev/null)"
  fi
  [[ -z "${L:-}" ]] && return 0
  CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"

  # Detect states
  if printf "%s\n" "$CLEAN" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* (started|running)|Flow .* (started|running)'; then
    # Job wins over queue
    stop_idle
    return 0
  fi
  if printf "%s\n" "$CLEAN" | grep -Eqi '(^|[[:space:]])QUEUED([[:space:]]|$)|position[[:space:]]+[0-9]+/[0-9]+|\[nosana\][[:space:]]+queued'; then
    start_idle
  else
    stop_idle
  fi
}

# Single instance guard
if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE" 2>/dev/null)" 2>/dev/null; then
  exit 0
fi
echo $$ > "$PIDFILE"
echo "[idle-queue] watcher online" | tee -a "$CUSTOM_LOG" >/dev/null

trap 'rm -f "$PIDFILE"; exit 0' INT TERM EXIT
while true; do
  detect_and_toggle
  sleep 8
done
