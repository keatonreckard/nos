#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
LOG_DIR="/var/log/miner/nosana"
CUSTOM_LOG="/var/log/miner/custom/custom.log"
IDLE_LOG="$LOG_DIR/idle.log"
DEBUG_LOG="$LOG_DIR/debug.log"
mkdir -p "$LOG_DIR" "$RUN_DIR" "$(dirname "$CUSTOM_LOG")"
touch "$IDLE_LOG" "$DEBUG_LOG" "$CUSTOM_LOG"
cmd_file="$MINER_DIR/parsed/idle_command"
args_file="$MINER_DIR/parsed/idle_args"
IDLE_COMMAND="$(cat "$cmd_file" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$args_file" 2>/dev/null || true)"

echo "[$(date -Iseconds)] idle-run preflight" | tee -a "$DEBUG_LOG"
echo "  whoami=$(whoami)  pwd=$(pwd)" | tee -a "$DEBUG_LOG"
echo "  idle_dir=$(dirname "$IDLE_COMMAND") idle_bin=$(basename "$IDLE_COMMAND")" | tee -a "$DEBUG_LOG"
command -v screen >/dev/null 2>&1 && command -v awk >/dev/null 2>&1 && command -v bash >/dev/null 2>&1
command -v screen >/dev/null 2>&1 && echo "$(command -v screen)" | tee -a "$DEBUG_LOG"
command -v awk >/dev/null 2>&1 && echo "$(command -v awk)" | tee -a "$DEBUG_LOG"
command -v bash >/dev/null 2>&1 && echo "$(command -v bash)" | tee -a "$DEBUG_LOG"

if [[ -z "${IDLE_COMMAND:-}" ]]; then
  echo "[idle-run] no idle command configured" | tee -a "$IDLE_LOG" "$CUSTOM_LOG" "$DEBUG_LOG"
  exit 0
fi
if [[ ! -x "$IDLE_COMMAND" ]]; then
  # Try to add exec bit if it exists
  [[ -f "$IDLE_COMMAND" ]] && chmod +x "$IDLE_COMMAND" || true
fi

echo "[$(date -Iseconds)] idle-run: starting idle miner: $IDLE_COMMAND $IDLE_ARGS" | tee -a "$IDLE_LOG" "$CUSTOM_LOG" "$DEBUG_LOG"
# Start screen session
screen -S nosana-idle -X quit >/dev/null 2>&1 || true
screen -dmS nosana-idle bash -lc "$IDLE_COMMAND $IDLE_ARGS 2>&1 | tee -a '$IDLE_LOG'"
sleep 1
session_ok=0; screen -ls 2>/dev/null | grep -q "\.nosana-idle" && session_ok=1 || true
proc_ok=1  # can't reliably get child pid; assume started if screen exists
echo "[$(date -Iseconds)] idle-run: idle miner started (session_ok=$session_ok proc_ok=$proc_ok)" | tee -a "$DEBUG_LOG"
date +%s > "$MINER_DIR/idle.start.time" 2>/dev/null || true
exit 0
