    #!/usr/bin/env bash
    # Wrapper that works both when sourced and when executed.
    set -euo pipefail
    : "${MINER_DIR:=/hive/miners/custom}"
    : "${CUSTOM_MINER:=nosana}"
    stats_out="$("$MINER_DIR/$CUSTOM_MINER/h-stats.sh")"
    # Always set/export stats for callers that source this script
    stats="$stats_out"
    export stats
    # If this script is executed (not sourced), print the JSON for stdout-based callers
    (return 0 2>/dev/null) || printf "%s
" "$stats_out"
