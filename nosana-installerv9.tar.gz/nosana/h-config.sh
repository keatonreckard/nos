#!/usr/bin/env bash
# --- nosana keypair injection (only write if missing; robust parse) ---
{
  LOG_DIR="/var/log/miner/nosana"
  mkdir -p "$LOG_DIR"
  KEYDIR="/root/.nosana"
  KEYFILE="${KEYDIR}/nosana_key.json"

  EXTRA_CFG_RAW="${CUSTOM_USER_CONFIG:-}"
  # Flatten newlines, normalize quotes, unescape common sequences
  EXTRA_ONE="$(echo "$EXTRA_CFG_RAW" | tr '\n' ' ')"
  EXTRA_ONE="${EXTRA_ONE//\\\"/\"}"
  EXTRA_ONE="$(printf "%s" "$EXTRA_ONE" | sed 's/[“”]/"/g; s/[’]/'\''/g')"

  # Log snippet of extra config to help debugging
  printf "%s %s\n" "$(date -Iseconds)" "ExtraConfig sample: $(echo "$EXTRA_ONE" | cut -c1-240)" >> "$LOG_DIR/debug.log"

  if [[ ! -f "$KEYFILE" ]]; then
    # Match "keypair":[ ... ] (quotes optional around the array)
    if [[ "$EXTRA_ONE" =~ \"keypair\"[[:space:]]*:[[:space:]]*\"?\[([^]]+)\]\"? ]]; then
      KEY_ARR_CONTENT="${BASH_REMATCH[1]}"
      # Sanitize to digits, commas, spaces, minus; then rebuild JSON array
      KEY_ARR_CONTENT="$(echo "$KEY_ARR_CONTENT" | tr -cd '0-9, -')"
      KEY_JSON="[${KEY_ARR_CONTENT}]"

      mkdir -p "$KEYDIR"
      # Only write if we still have something that looks like an array
      if echo "$KEY_JSON" | grep -Eq '^\[[0-9 ,-]+\]$'; then
        printf '{ "keypair": %s }\n' "$KEY_JSON" > "$KEYFILE"
        chmod 600 "$KEYFILE"
        echo "$(date -Iseconds) wrote keypair to $KEYFILE" >> "$LOG_DIR/debug.log"
      else
        echo "$(date -Iseconds) parsed keypair invalid; not writing" >> "$LOG_DIR/debug.log"
      fi
    else
      echo "$(date -Iseconds) keypair not found in Extra Config; $KEYFILE missing" >> "$LOG_DIR/debug.log"
    fi
  else
    echo "$(date -Iseconds) keypair file exists; skipping write" >> "$LOG_DIR/debug.log"
  fi
}
# --- end keypair injection ---
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
CONF_FILE="$MINER_DIR/nosana.conf"
RAW_EXTRA_FILE="$MINER_DIR/extra.raw"
PARSED_DIR="$MINER_DIR/parsed"

mkdir -p "$MINER_DIR" "$LOG_DIR" "$PARSED_DIR" "$RUN_DIR" /root/.nosana
chmod 755 "$MINER_DIR"
touch "$LOG_DIR/nosana.log" "$LOG_DIR/debug.log" "$LOG_DIR/idle.log"
chmod 664 "$LOG_DIR/"*.log || true

: "${CUSTOM_USER_CONFIG:=}"
printf '%s' "$CUSTOM_USER_CONFIG" > "$CONF_FILE"
printf '%s' "$CUSTOM_USER_CONFIG" > "$RAW_EXTRA_FILE"

RAW="$CUSTOM_USER_CONFIG"
TRIMMED="$(printf '%s' "$RAW" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
if printf '%s' "$TRIMMED" | grep -q '"idleSettings"'; then
  if printf '%s' "$TRIMMED" | grep -q '^{'; then EXTRA_JSON="$TRIMMED"; else EXTRA_JSON="{$TRIMMED}"; fi
else
  EXTRA_JSON="{}"
fi
IDLE_COMMAND=$(printf '%s' "$EXTRA_JSON" | tr '\n' ' ' | sed -n 's/.*"idleSettings"[[:space:]]*:[[:space:]]*{[^}]*"command"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)
IDLE_ARGS=$(printf '%s' "$EXTRA_JSON" | tr '\n' ' ' | sed -n 's/.*"idleSettings"[[:space:]]*:[[:space:]]*{[^}]*"arguments"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)

mkdir -p "$PARSED_DIR"
printf '%s' "$IDLE_COMMAND" > "$PARSED_DIR/idle_command"
printf '%s' "$IDLE_ARGS"    > "$PARSED_DIR/idle_args"

cat > "$STATE_FILE" <<EOF
status="nos - initializing"
queue=""
sol=""
nos=""
wallet=""
idle_enabled="$( [[ -n "$IDLE_COMMAND" ]] && echo 1 || echo 0 )"
EOF
chmod 664 "$STATE_FILE"

{
  echo "[$(date -Iseconds)] h-config: RAW_EXTRA length=$(printf %s "$RAW" | wc -c)"
  echo "[$(date -Iseconds)] h-config: parsed idle command: $IDLE_COMMAND"
  echo "[$(date -Iseconds)] h-config: parsed idle args:    $IDLE_ARGS"
} >> "$LOG_DIR/debug.log"

date +%s > "$MINER_DIR/nosana.start.time"
exit 0


