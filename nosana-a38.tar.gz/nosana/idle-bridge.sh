#!/usr/bin/env bash
set -euo pipefail
LOG_DIR="/var/log/miner/nosana"
MINER_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

cmd="${1:-}"
case "$cmd" in
  start|"")
    # stream idle log into miner log, prefixing for clarity; survive truncation/rotation (-F)
    # avoid duplicate bridge tails: only one tail should run
    existing="$(pgrep -af 'tail -n0 -F /var/log/miner/nosana/idle.log' || true)"
    if [[ -z "$existing" ]]; then
      ( tail -n0 -F "$IDLE_LOG" 2>/dev/null | stdbuf -oL sed -u 's/^/[idle-miner] /' >> "$MINER_LOG" ) &
      echo "[idle-bridge] tail started ($!)" >> "$LOG_DIR/debug.log"
    fi
    ;;
  stop)
    pkill -f 'tail -n0 -F /var/log/miner/nosana/idle.log' || true
    ;;
esac
