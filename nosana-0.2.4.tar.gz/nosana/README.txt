Nosana HiveOS custom miner wrapper v0.2.4
