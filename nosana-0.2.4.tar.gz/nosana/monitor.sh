#!/bin/bash
log_file="/hive/miners/custom/nosana/nosana.log"
while true; do
  echo "[monitor] heartbeat: $(date)"
  sleep 30
done
