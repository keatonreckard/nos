#!/bin/bash
echo "[h-run] cleaning previous containers"
podman stop nosana-node >/dev/null 2>&1
podman rm nosana-node >/dev/null 2>&1
echo "[h-run] starting nosana-node"
nohup nosana-node > /hive/miners/custom/nosana/nosana.log 2>&1 &
