#!/bin/bash
log_file="/hive/miners/custom/nosana/nosana.log"
uptime=$(awk '{print $1}' /proc/uptime | cut -d. -f1)
echo "{\"hs\":[0],\"hs_units\":\"khs\",\"uptime\":$uptime,\"algo\":\"nosana\"}"
