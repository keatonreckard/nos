NOSANA (HiveOS custom miner package)
-----------------------------------
Built: 2025-08-21T16:39:59

v8.0.9_hiveos:
- Removes any "ar" from stats at the source *and* sanitizes final JSON before print.
- Adds version caching: once SOL/NOS/Wallet are parsed, "ver" persists until refreshed.
- Preserves your idle logic files and existing algo behavior. KH/s mapping unchanged.
