```bash
#!/bin/bash

cd /hive/miners/custom/nosana

temp_json='[]'
fan_json='[]'
busid_json='[]'
if [ -f /hive/bin/gpu-stats ]; then
  source /hive/bin/gpu-stats
fi

khs=0

algo=$(cat algo.state 2>/dev/null || echo "nos - starting node")
sol_bal=$(cat sol_bal 2>/dev/null || echo "0.0000")
nos_bal=$(cat nos_bal 2>/dev/null || echo "0.0000")
wallet_short=$(cat wallet.txt 2>/dev/null | cut -c1-5 || echo "unkno")

ver="v2.0b | S:$sol_bal | N:$nos_bal | W:$wallet_short"

# Calculate uptime based on mode
now=$(date +%s)
if [ -f job.start.time ]; then
  start_time=$(cat job.start.time)
  uptime=$((now - start_time))
elif [ -f idle.start.time ]; then
  start_time=$(cat idle.start.time)
  uptime=$((now - start_time))
elif [ -f nosana.start.time ]; then
  start_time=$(cat nosana.start.time)
  uptime=$((now - start_time))
else
  uptime=$(awk '{print int($1)}' /proc/uptime)
fi

stats=$(jq -nc \
  --argjson hs "[]" \
  --arg hs_units "khs" \
  --argjson temp "$temp_json" \
  --argjson fan "$fan_json" \
  --arg uptime "$uptime" \
  --arg ver "$ver" \
  --argjson ar "[0,0]" \
  --arg algo "$algo" \
  --argjson bus_numbers "$busid_json" \
  '{hs: $hs, hs_units: $hs_units, temp: $temp, fan: $fan, uptime: $uptime, ver: $ver, ar: $ar, algo: $algo, bus_numbers: $bus_numbers}')

echo $khs
echo $stats
```