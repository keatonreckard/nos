```bash
#!/bin/bash

log_file=$1
debug_log="/hive/miners/custom/nosana/debug.log"
cd /hive/miners/custom/nosana

# Check if debug flag exists
if [ -f /hive/miners/custom/nosana/debug.flag ]; then
  DEBUG=true
else
  DEBUG=false
fi

# Tail the log and parse, stripping ANSI colors
tail -f "$log_file" | while read -r line; do
  if [[ "$DEBUG" == true ]]; then
    echo "$line" >> "$debug_log"  # Append original to debug if enabled
  fi
  clean_line=$(echo "$line" | sed 's/\x1B\[[0-9;]*[mGK]//g' | sed 's/[^a-zA-Z0-9 .:\/-]//g')
  line="$clean_line"  # Use clean for parsing

  if [[ "$line" == *"SOL balance:"* ]]; then
    sol_str=$(echo "$line" | grep -oE '[0-9]+\.[0-9]+' | head -1)
    if [[ -n "$sol_str" ]]; then
      sol=$(printf "%.4f" "$sol_str" 2>/dev/null)
      if [[ -n "$sol" ]]; then
        echo "$sol" > sol_bal
        if [[ "$DEBUG" == true ]]; then
          echo "Parsed SOL balance: $sol" >> "$debug_log"
        fi
      fi
    fi
  fi

  if [[ "$line" == *"NOS balance:"* ]]; then
    nos_str=$(echo "$line" | grep -oE '[0-9]+\.[0-9]+' | head -1)
    if [[ -n "$nos_str" ]]; then
      nos=$(printf "%.4f" "$nos_str" 2>/dev/null)
      if [[ -n "$nos" ]]; then
        echo "$nos" > nos_bal
        if [[ "$DEBUG" == true ]]; then
          echo "Parsed NOS balance: $nos" >> "$debug_log"
        fi
      fi
    fi
  fi

  if [[ "$line" == *"Wallet:"* ]]; then
    wallet=$(echo "$line" | awk '{print $2}')
    echo "$wallet" > wallet.txt
    if [[ "$DEBUG" == true ]]; then
      echo "Parsed Wallet: $wallet" >> "$debug_log"
    fi
  fi

  if [[ "$line" == *"QUEUED"* ]]; then
    pos=$(echo "$line" | grep -oP 'position \K\d+/\d+')
    if [[ -n "$pos" ]]; then
      echo "nos - queued $pos" > algo.state
      if [[ "$DEBUG" == true ]]; then
        echo "Updated algo to nos - queued $pos" >> "$debug_log"
      fi
    fi
    # Start idle miner if not running and settings exist
    if [ ! -f idle.pid ] && [ -f idle_command ] && [ -f idle_arguments ]; then
      command=$(cat idle_command)
      arguments=$(cat idle_arguments)
      $command $arguments &
      echo $! > idle.pid
      date +%s > idle.start.time
      echo "idle mining - queued $pos" > algo.state
      if [[ "$DEBUG" == true ]]; then
        echo "Started idle miner with PID $! and updated algo to idle mining - queued $pos" >> "$debug_log"
      fi
    fi
  fi

  if [[ "$line" == *"Node has claimed job"* ]]; then
    echo "nos - job" > algo.state
    date +%s > job.start.time
    if [[ "$DEBUG" == true ]]; then
      echo "Updated algo to nos - job" >> "$debug_log"
    fi
    if [ -f idle.pid ]; then
      kill $(cat idle.pid)
      rm -f idle.pid
      rm -f idle.start.time
      if [[ "$DEBUG" == true ]]; then
        echo "Killed idle miner" >> "$debug_log"
      fi
    fi
  fi
done
```