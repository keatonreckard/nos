#!/bin/bash

# Set working directory
cd /hive/miners/custom/nosana

# Cleanup previous instances
docker rm -f podman nosana-node >/dev/null 2>&1
killall -9 podman >/dev/null 2>&1
if [ -f idle.pid ]; then
  kill $(cat idle.pid) >/dev/null 2>&1
  rm -f idle.pid
fi
if [ -f monitor.pid ]; then
  kill $(cat monitor.pid) >/dev/null 2>&1
  rm -f monitor.pid
fi

# Clear log file for fresh start
> "$CUSTOM_LOG_BASENAME.log"

# Install dependencies if missing
if ! command -v gpg >/dev/null 2>&1; then
  apt-get update
  apt-get install -y gpg
fi

if ! command -v docker >/dev/null 2>&1; then
  # Docker install script for HiveOS
  set -e
  apt-get update || true
  apt-get install -y --allow-downgrades ca-certificates curl
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | tee /etc/apt/sources.list.d/docker.list >/dev/null
  apt-get update || true
  apt-get install -y --allow-downgrades docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin || true
  if [ -f "/etc/hiveos-release" ]; then
    apt-get install -y --allow-downgrades iptables arptables ebtables
    update-alternatives --set iptables /usr/sbin/iptables-legacy
    update-alternatives --set ip6tables /usr/sbin/ip6tables-legacy
  fi
  mkdir -p /etc/systemd/system/docker.service.d
  echo -e "[Service]\nExecStart=\nExecStart=/usr/bin/dockerd -H fd:// --containerd=/run/containerd/containerd.sock --ip6tables=false" | tee /etc/systemd/system/docker.service.d/override.conf
  systemctl daemon-reload
  systemctl enable --now docker
  systemctl restart docker
fi

groupadd docker || true
usermod -aG docker user

# Check for specific driver version from config
CONFIG_FILE="/hive/miners/custom/nosana/nosana.conf"
if [ -f "$CONFIG_FILE" ]; then
  CUSTOM_USER_CONFIG=$(cat "$CONFIG_FILE")
  driver=$(echo "$CUSTOM_USER_CONFIG" | sed -n 's/.*"driver"\s*:\s*"\([^"]*\)".*/\1/p' | sed 's/^[ \t]*//;s/[ \t]*$//')
  if [[ -n "$driver" ]]; then
    echo "Updating to specific NVIDIA driver version: $driver"
    nvidia-driver-update "$driver"
    sleep 5
  fi
fi

if ! command -v nvidia-smi >/dev/null 2>&1; then
  # NVIDIA Driver Installation
  echo "Installing NVIDIA drivers..."
  apt-get update
  apt-get install -y nvidia-driver
  if ! command -v nvidia-smi >/dev/null 2>&1; then
    echo "NVIDIA driver installation failed. Please visit https://www.linuxbabe.com/ubuntu/install-nvidia-driver-ubuntu for manual installation."
    exit 1
  fi
  echo "NVIDIA drivers installed successfully."
fi

if ! command -v nvidia-ctk >/dev/null 2>&1; then
  # Install NVIDIA Container Toolkit
  echo "Installing NVIDIA Container Toolkit..."
  curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg \
    && curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
    sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
  sudo apt-get update
  sudo apt-get install -y nvidia-container-toolkit -o Dpkg::Options::="--force-confnew"
  # Configure NVIDIA Container Toolkit for Docker
  sudo nvidia-ctk runtime configure --runtime=docker
  sudo systemctl restart docker
  # Wait for Docker to fully restart
  sleep 5
  if ! command -v nvidia-ctk >/dev/null 2>&1; then
    echo "NVIDIA Container Toolkit installation failed. Please check the configuration steps at https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html."
    exit 1
  fi
  echo "NVIDIA Container Toolkit installed and configured successfully."
fi

# Download and patch Nosana start script
wget -qO start.sh https://nosana.com/start.sh
sed -i '/--interactive -t/d' start.sh
sed -i 's/if \[\[ "$(groups)" != \*"docker"\* \]\]; then/if false; then/' start.sh
sed -i '/manage-docker-as-a-non-root-user / {n; s/exit 1/#exit 1/;}' start.sh
sed -i 's/\$HOME\/\.nosana/\/root\/.nosana/g' start.sh
sed -i 's/~\/\.nosana/\/root\/.nosana/g' start.sh

# Set initial state
echo "nos - starting node" > algo.state

# Record start time
date +%s > nosana.start.time

# Start monitor in background
./monitor.sh "$CUSTOM_LOG_BASENAME.log" &
echo $! > monitor.pid

# Start Nosana node in a loop to prevent quick exits
while true; do
  if [ -f verbose.flag ]; then
    bash start.sh --verbose 2>&1 | tee -a "$CUSTOM_LOG_BASENAME.log" &
  else
    bash start.sh 2>&1 | tee -a "$CUSTOM_LOG_BASENAME.log" &
  fi
  start_pid=$!
  wait $start_pid
  echo "Nosana node exited, restarting in 10 seconds..." >> "$CUSTOM_LOG_BASENAME.log"
  sleep 10
done