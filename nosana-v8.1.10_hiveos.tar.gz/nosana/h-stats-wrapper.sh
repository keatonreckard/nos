#!/usr/bin/env bash
# HiveOS custom miner stats wrapper (mirror miner_stats)
set -euo pipefail

MINER_DIR="/hive/miners/custom"
LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

: "${CUSTOM_MINER:=nosana}"

# 1) Collect miner JSON (single line), exactly as your miner prints it
RAW="$("$MINER_DIR/$CUSTOM_MINER/h-stats.sh" 2>>"$LOG_DIR/debug.log" | tr -d '\r' | head -n1 || true)"
RAW="$(printf "%s" "$RAW" | sed -E ':a;N;$!ba;s/\n/ /g')"

# Safety: if RAW is empty or not JSON, provide a minimal stub so HiveOS won't choke
if ! printf "%s" "$RAW" | grep -q '^{'; then
  RAW='{"hs":[0],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"","algo":"nos - initializing","bus_numbers":[]}'
fi

# Optional: remove shares field if present (prevents `[ , ]` corner cases)
RAW="$(printf "%s" "$RAW" | sed -E 's/,"ar":\[[^]]*\]//g; s/"ar":\[[^]]*\],?//g')"

# Emit the miner JSON as the first line
printf "%s\n" "$RAW"

# 2) Build the 'method: stats' line with miner_stats mirroring the first block.
# Compute total_khs from the first element of .hs if jq is available; otherwise simple grep/awk fallback.
total_khs=""
if command -v jq >/dev/null 2>&1; then
  total_khs="$(printf "%s" "$RAW" | jq -r 'try (.hs[0]) // 0' 2>/dev/null || echo 0)"
else
  total_khs="$(printf "%s" "$RAW" | sed -nE 's/.*"hs":\[\s*([0-9.]+).*/\1/p')"
  total_khs="${total_khs:-0}"
fi

# Emit a compact 'method: stats' object. Hive agent will merge rig_id, passwd, temps, etc.
printf '{"method":"stats","params":{"miner":"custom","total_khs":%s,"miner_stats":%s}}\n' \
  "${total_khs:-0}" \
  "$(printf "%s" "$RAW")"
