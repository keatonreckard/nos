#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

# ---- paths ----
MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
NOSANA_LOG="/run/hive/miner.1"   # node logs
IDLE_LOG="/run/hive/miner.2"     # idle logs

# ---- helpers ----
read_kv_state() {
  # shellcheck disable=SC1090
  [[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true
}

# best-effort: compute uptime from our stamp files
calc_uptime() {
  local stamp="$1" now ts
  now="$(date +%s)"
  if [[ -f "$stamp" ]]; then
    ts="$(cat "$stamp" 2>/dev/null || echo "$now")"
    if [[ "$ts" =~ ^[0-9]+$ ]] && (( now >= ts )); then
      echo $(( now - ts)); return
    fi
  fi
  echo 0
}

# extract latest idle hashrate (it/s) and algo from miner.2 and convert to kH/s
# returns: echo "<algo_lower>" and sets global IDLE_KHS (float string)
IDLE_KHS="0"
parse_idle_khs() {
  local line algo its
  # read last ~50 lines to find most recent rate
  line="$(tail -n 50 "$IDLE_LOG" 2>/dev/null | grep -Eo '\[[A-Za-z0-9]+\].*it/s' | tail -n 1 || true)"
  if [[ -n "$line" ]]; then
    # prefer explicit [XMR] or other tag
    if [[ "$line" =~ \[([A-Za-z0-9]+)\] ]]; then
      algo="${BASH_REMATCH[1]}"
    fi
  else
    # fall back to generic it/s line
    line="$(tail -n 50 "$IDLE_LOG" 2>/dev/null | grep -Eo '[0-9]+[[:space:]]+it/s' | tail -n 1 || true)"
    algo="IDLE"
  fi
  # extract numeric it/s
  if [[ "$line" =~ ([0-9]+)[[:space:]]+it/s ]]; then
    its="${BASH_REMATCH[1]}"
  else
    its="0"
  fi
  # algo mapping
  local al=$(echo "${algo:-idle}" | tr '[:upper:]' '[:lower:]')
  case "$al" in
    xmr|rx|rx/0) al="idle xmr";;
    qbc|qubic|qli|qbic) al="idle qubic";;
    *) al="idle";;
  esac
  # convert to kH/s string with 2 decimals
  # avoid bc; use awk
  IDLE_KHS="$(awk -v n="$its" 'BEGIN{ printf "%.2f", n/1000.0 }')"
  echo "$al"
}

# ---- main ----
read_kv_state
status="${status:-nos - initializing}"

# Determine algo string and total khs based on state
algo="nos - initializing"
total_khs="0.00"
hs_units="khs"

# Choose reference time for uptime
if [[ "$status" == "nos - job" ]]; then
  uptime="$(calc_uptime "$MINER_DIR/job.start.time")"
  algo="nos - job"
  total_khs="1.00"   # sentinel when job running
elif [[ "$status" == "nos - queued" ]]; then
  uptime="$(calc_uptime "$MINER_DIR/idle.start.time")"
  # parse idle miner for algo and rate
  idle_algo="$(parse_idle_khs)"
  algo="nos - ${idle_algo}"
  total_khs="$IDLE_KHS"
else
  uptime="$(calc_uptime "$MINER_DIR/nosana.start.time")"
  algo="nos - initializing"
  total_khs="0.00"
fi

# Build hs array; single value is fine for Hive dashboard
hs_json="$(jq -nc --arg k "$total_khs" '[($k|tonumber)]')"

# miner_stats object
stats="$(jq -nc   --argjson hs "${hs_json}"   --arg hs_units "${hs_units}"   --argjson temp '[]'   --argjson fan '[]'   --arg uptime "${uptime}"   --arg ver ""   --arg algo "${algo}"   --argjson bus_numbers '[]'   '{ $hs, $hs_units, $temp, $fan, $uptime, $ver, $algo, $bus_numbers }'
)"

# Output for Hive agent: first line total khs, second line miner_stats JSON
echo "${total_khs}"
echo "${stats}"
