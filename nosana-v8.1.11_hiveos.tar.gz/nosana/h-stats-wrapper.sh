#!/usr/bin/env bash
# HiveOS custom miner stats wrapper — normalize + mirror
set -euo pipefail

MINER_ROOT="/hive/miners/custom"
THIS="${CUSTOM_MINER:-nosana}"
MINER_DIR="$MINER_ROOT/$THIS"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
mkdir -p "$LOG_DIR" "$RUN_DIR"
exec 2>>"$LOG_DIR/debug.log"

# 1) Fetch miner JSON (single line)
RAW="$("$MINER_DIR/h-stats.sh" 2>>"$LOG_DIR/debug.log" | tr -d '\r' | head -n1 || true)"
RAW="$(printf "%s" "$RAW" | sed -E ':a;N;$!ba;s/\n/ /g')"

# Basic sanity stub if not JSON
if ! printf "%s" "$RAW" | grep -q '^{'; then
  RAW='{"hs":[0],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"","algo":"nos - initializing","bus_numbers":[]}'
fi

# 2) Helpers for ver/algo fallback
compute_ver() {
  local L wallet sol nos v w5
  [[ -s "$LOG_DIR/nosana.log" ]] || return 1
  L="$(tail -n 3000 "$LOG_DIR/nosana.log" | tr -d '\r')"
  wallet="$(printf "%s\n" "$L" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
  [[ -z "$wallet" ]] && wallet="$(printf "%s\n" "$L" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
  sol="$(printf "%s\n" "$L" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
  nos="$(printf "%s\n" "$L" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
  [[ -z "$wallet$sol$nos" ]] && return 1
  [[ -n "$sol" ]] && printf -v sol "%.4f" "$sol"
  [[ -n "$nos" ]] && printf -v nos "%.4f" "$nos"
  w5="$(printf "%s" "$wallet" | cut -c1-5)"
  v=""; [[ -n "$sol" ]] && v+="S:${sol}"
  [[ -n "$nos" ]] && v+="${v:+ }N:${nos}"
  [[ -n "$w5" ]]  && v+="${v:+ }W:${w5}"
  printf "%s" "$v"
}

compute_algo() {
  local L pos
  [[ -s "$LOG_DIR/nosana.log" ]] || { printf "nos - initializing"; return 0; }
  L="$(tail -n 3000 "$LOG_DIR/nosana.log" | tr -d '\r')"
  if printf "%s\n" "$L" | grep -Eqi 'Node is claiming job|Node has found job|Job .* started|Flow .* running|is running'; then
    printf "nos - job"
  else
    pos="$(printf "%s\n" "$L" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
    if [[ -n "$pos" ]]; then
      printf "nos - queued %s" "$pos"
    elif printf "%s\n" "$L" | grep -Eqi 'QUEUED'; then
      printf "nos - queued"
    else
      printf "nos - initializing"
    fi
  fi
}

have_jq=0
command -v jq >/dev/null 2>&1 && have_jq=1

OUT="$RAW"

# 3) Normalize fields using jq if available
if [[ $have_jq -eq 1 ]]; then
  curv="$(printf "%s" "$OUT" | jq -r 'try .ver catch empty' 2>/dev/null || true)"
  cura="$(printf "%s" "$OUT" | jq -r 'try .algo catch empty' 2>/dev/null || true)"
  # derive missing ver/algo
  if [[ -z "$curv" || "$curv" == "null" ]]; then
    nv="$(compute_ver || true)"
    [[ -n "$nv" ]] && OUT="$(printf "%s" "$OUT" | jq -c --arg v "$nv" '.ver=$v')" || true
  fi
  if [[ -z "$cura" || "$cura" == "null" ]]; then
    na="$(compute_algo)"
    OUT="$(printf "%s" "$OUT" | jq -c --arg a "$na" '.algo=$a')" || true
  fi
  # ensure status and ar present & sane
  OUT="$(printf "%s" "$OUT" | jq -c '.status="running" | (if (.ar|type)=="array" and (.ar|length)>=2 then . else .ar=[0,0] end)')"
else
  # crude sed fallbacks
  printf "%s" "$OUT" | grep -q '"status":' || OUT="$(printf "%s" "$OUT" | sed 's/^{/{\"status\":\"running\",/')" 
  printf "%s" "$OUT" | grep -q '"ar":'     || OUT="$(printf "%s" "$OUT" | sed 's/}$/,\"ar\":[0,0]}/')" 
fi

# 4) Emit miner JSON (first line)
printf "%s\n" "$OUT"

# 5) Emit method:stats with mirrored miner_stats (second line). Compute total_khs.
total_khs="0"
if [[ $have_jq -eq 1 ]]; then
  total_khs="$(printf "%s" "$OUT" | jq -r 'try (.hs[0]) // 0' 2>/dev/null || echo 0)"
else
  total_khs="$(printf "%s" "$OUT" | sed -nE 's/.*"hs":\[\s*([0-9.]+).*/\1/p')"
  total_khs="${total_khs:-0}"
fi

printf '{"method":"stats","params":{"miner":"custom","total_khs":%s,"miner_stats":%s}}\n' \
  "${total_khs:-0}" \
  "$(printf "%s" "$OUT")"
