#!/usr/bin/env bash
set -euo pipefail
MINER_ROOT="/hive/miners/custom"
PKG_DIR="$MINER_ROOT/nosana"
LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR"
cp -f "$PKG_DIR/h-stats-wrapper.sh" "$MINER_ROOT/h-stats.sh"
chmod 0755 "$MINER_ROOT/h-stats.sh"
echo "[install-stats-wrapper] Installed: $MINER_ROOT/h-stats.sh -> nosana wrapper" >> "$LOG_DIR/debug.log"
