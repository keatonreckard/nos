#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

# ---- paths ----
MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

# Fallbacks
khs=0
stats=""
status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""; idle_enabled=0
# Load previous state if present (to avoid losing version string between phases)
if [[ -f "$STATE_FILE" ]]; then
  # shellcheck disable=SC1090
  source "$STATE_FILE" || true
fi

# Read & clean logs (strip ANSI)
clean_log() {
  local file="$1"
  [[ -s "$file" ]] || return 1
  # read last slice and strip carriage returns + ANSI
  tail -n 4000 "$file" 2>/dev/null | tr -d '\r' | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g'
  return 0
}

NOS_CLEAN="$(clean_log "$NOSANA_LOG" || true)"
IDLE_CLEAN="$(clean_log "$IDLE_LOG" || true)"

# ---- Parse wallet / balances from nosana log ----
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
fi
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
fi

if [[ -z "${sol:-}" ]]; then
  sol="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
if [[ -z "${nos:-}" ]]; then
  nos="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
# v81: truncate SOL/NOS to 3 decimals without rounding (pure bash)
nos_trunc3() {
  local v="$1" int frac
  [[ -z "$v" ]] && { echo ""; return; }
  if [[ "$v" == *.* ]]; then
    int="${v%%.*}"
    frac="${v#*.}"
    # keep only digits in fractional part
    frac="${frac//[^0-9]/}"
    frac="${frac:0:3}"
    # pad to 3
    while ((${#frac} < 3)); do frac="${frac}0"; done
    printf "%s.%s" "$int" "$frac"
  else
    printf "%s.000" "$v"
  fi
}
# Apply truncation to balances (if present)
if [[ -n "${sol:-}" ]]; then sol="$(nos_trunc3 "$sol")"; fi
if [[ -n "${nos:-}" ]]; then nos="$(nos_trunc3 "$nos")"; fi

# Build version string (keep previous if data not found)
VER_FILE="/run/hive/.nosana_ver"
if [[ -z "${ver:-}" && -f "$VER_FILE" ]]; then
  ver="$(tr -d "\r" < "$VER_FILE" 2>/dev/null || true)"
fi

ver_build=""
if [[ -n "${sol:-}" || -n "${nos:-}" || -n "${wallet:-}" ]]; then
  shortw=""
  if [[ -n "${wallet:-}" ]]; then shortw="$(printf "%s" "$wallet" | cut -c1-5)"; fi
  ver_build="S:${sol:-0} N:${nos:-0} W:${shortw:-?????}"
fi
# If version string wasn't derivable now, keep old one if present
ver="${ver_build:-${ver:-}}"
if [[ -n "${ver_build:-}" ]]; then
  mkdir -p /run/hive || true
  printf "%s\n" "$ver" > "$VER_FILE"
fi
# ---- Parse queue position ----
queue_txt="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*QUEUED.*position[[:space:]]*([0-9]+)\/([0-9]+).*/\1\/\2/p' | tail -n1)"
if [[ -z "$queue_txt" ]]; then
  queue_txt="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*queued[[:space:]]*([0-9]+)\/([0-9]+).*/\1\/\2/p' | tail -n1)"
fi

# ---- Determine idle mode (qubic vs xmr) ----
idle_mode=""
  # Persist last idle mode to survive sparse token lines
  IDLE_MODE_FILE="/run/hive/.nosana_idle_mode"

# Robust idle-mode detection: clean ANSI and look for tokens
idle_log_clean="$(tail -n 600 "$IDLE_LOG" 2>/dev/null | tr -d '\r' | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g' || true)"
if echo "$idle_log_clean" | grep -qiE 'qubic|AVX|CUDA'; then
  idle_mode="qubic"
elif echo "$idle_log_clean" | grep -qiE '\[XMR\]|rx/|algo[[:space:]]+rx/0|it/s'; then
  idle_mode="xmr"
fi

  idle_mode_prev=""
  if [[ -f "$IDLE_MODE_FILE" ]]; then idle_mode_prev="$(tr -d '\r' < "$IDLE_MODE_FILE" 2>/dev/null || true)"; fi

if [[ -n "${IDLE_CLEAN:-}" ]]; then
  # consider XMR mode if there are sufficiently many XMR lines recently
  xmr_count="$(printf "%s\n" "$IDLE_CLEAN" | tail -n 120 | grep -c '\[XMR\]' || true)"
  if [[ "${xmr_count:-0}" -ge 1 ]]; then
    idle_mode="xmr"
  [[ -n "$idle_mode" ]] && { mkdir -p /run/hive || true; printf "%s
" "$idle_mode" > "$IDLE_MODE_FILE"; }
  else
    # default qubic if we see AVX/GENERIC or CUDA signatures
    if printf "%s\n" "$IDLE_CLEAN" | grep -Eq '\[(AVX512|AVX2|GENERIC|CUDA)\]'; then
      idle_mode="qubic"
    fi
  fi
fi

# ---- Extract idle hashrates (instant or avg it/s) ----
extract_avg() { # $1: pattern e.g. '\[CUDA\]'
  printf "%s\n" "${IDLE_CLEAN:-}" | grep -E "$1" | grep -E 'avg it/s' | tail -n1 | sed -nE 's/.*\|\s*([0-9]+)[[:space:]]+avg it\/s.*/\1/p'
}
extract_inst_gpu() {
  printf "%s\n" "${IDLE_CLEAN:-}" | grep -E '\[GPU\][[:space:]]+Trainer:[[:space:]]+GPU #[0-9]+:' | tail -n1 | sed -nE 's/.*GPU #[0-9]+:[[:space:]]*([0-9]+)[[:space:]]+it\/s.*/\1/p'
}

cpu_hs=""; gpu_hs=""
if [[ "$idle_mode" == "xmr" ]]; then
  cpu_hs="$(extract_avg '\[XMR\]')"
  [[ -z "${cpu_hs}" ]] && cpu_hs="0"
elif [[ "$idle_mode" == "qubic" ]]; then
  cpu_hs="$(extract_avg '\[(AVX512|AVX2|GENERIC)\]')"
  gpu_hs="$(extract_avg '\[CUDA\]')"
  if [[ -z "${gpu_hs}" ]]; then
    gpu_hs="$(extract_inst_gpu)"
  fi
  [[ -z "${cpu_hs}" ]] && cpu_hs="0"
  [[ -z "${gpu_hs}" ]] && gpu_hs="0"# v82: provisional total idle kH/s (for queued idle suffix decision)
# Use CPU+GPU instantaneous/avg it/s parsed above; XMR => CPU only, Qubic => CPU+GPU.
IDLE_KHS="$(echo "scale=3; (${cpu_hs:-0} + ${gpu_hs:-0}) / 1000" | bc)"

fi

# ---- Build algo label ----
algo="nos - initializing"
if [[ -n "$queue_txt" ]]; then
  algo="nos - queued ${queue_txt}"
else
  # If we can detect non-queued, try to keep previous status string if available
  if [[ -n "${status:-}" ]]; then algo="${status}"; fi
fi
# v79 job detector: clear queue & set job algo (minimal)
job_log="$(tail -n 400 \"$NOSANA_LOG\" 2>/dev/null || true)"
if echo "$job_log" | grep -qiE 'Node has claimed job|Job .* started successfully|Flow .* is running|Running action|Job .* is starting|Job .* is running'; then
  queue_txt=""
  algo="nos - job running"
fi

  # If queued and hashing from idle but no token matched this tick, reuse previous idle mode
  if [[ -n "$queue_txt" && "${IDLE_KHS:-0}" != "0.00" && -z "$idle_mode" && -n "$idle_mode_prev" ]]; then
    idle_mode="$idle_mode_prev"
  fi

# Queued and hashing via idle but no token this tick? Reuse previous (or default xmr)
if [[ -n "$queue_txt" && -z "$idle_mode" ]]; then
  if awk 'BEGIN{exit !(ARGV[1]>0)}' "${IDLE_KHS:-0}"; then
    idle_mode="${idle_mode_prev:-xmr}"
  fi
fi
[[ -n "$idle_mode" ]] && { mkdir -p /run/hive || true; printf "%s\n" "$idle_mode" > "$IDLE_MODE_FILE"; }
if [[ -n "$idle_mode" && -n "$queue_txt" ]]; then
  algo="${algo} - idle ${idle_mode}"
fi

# ---- Build hashrates array & khs ----
hs_units="hs"
hs_json="[]"
if [[ "$idle_mode" == "xmr" ]]; then
  hs_json="$(jq -nc --argjson x "${cpu_hs:-0}" '[ $x ]')"
  # convert to khs (from it/s)
  khs="$(echo "scale=6; (${cpu_hs:-0}) / 1000" | bc)"
elif [[ "$idle_mode" == "qubic" ]]; then
  # order: [GPU, CPU], like your working qubic stats
  hs_json="$(jq -nc --argjson g "${gpu_hs:-0}" --argjson c "${cpu_hs:-0}" '[ $g, $c ]')"
  total_hs="$(echo "${gpu_hs:-0} + ${cpu_hs:-0}" | bc)"
  khs="$(echo "scale=6; ${total_hs} / 1000" | bc)"
else
  # Not in idle or no data: keep previous behavior (tiny non-zero or zero)
  khs="${khs:-0}"
  hs_json="[]"
fi

# ---- Uptime heuristic ----
uptime=0
if [[ -f "$NOSANA_LOG" ]]; then
  now="$(date +%s)"
  mt="$(stat --format='%Y' "$NOSANA_LOG" || echo "$now")"
  delta=$(( now - mt ))
  if (( delta < 86400 )); then uptime=$(( 120 + (86400 - delta) % 300 )); fi
fi

case "${algo,,}" in
  "nos - job"*) khs="0.10" ;;  # floor during active job to avoid idle hashrate bleed-through
esac

case "${algo,,}" in
  "nos - initializing"*)
    khs="0.10"
    if [[ "${hs_units}" == "hs" ]]; then
      hs_json="[$(awk -v n="$khs" 'BEGIN{printf "%.0f", n*1000}')]"
    else
      hs_json="[$khs]"
    fi
    ;;
  "nos - job"*)
    khs="0.10"
    if [[ "${hs_units}" == "hs" ]]; then
      hs_json="[$(awk -v n="$khs" 'BEGIN{printf "%.0f", n*1000}')]"
    else
      hs_json="[$khs]"
    fi
    ;;
esac

# ---- Emit stats ----
# temp / fan left empty; bus_numbers left empty (nulls) per current wrapper
stats="$(jq -nc \
  --argjson hs "${hs_json}" \
  --arg hs_units "${hs_units}" \
  --argjson temp '[]' \
  --argjson fan '[]' \
  --arg uptime "${uptime}" \
  --arg ver "${ver:-}" \
  --arg algo "${algo}" \
  --argjson bus_numbers '[]' \
  '{ $hs, $hs_units, $temp, $fan, $uptime, $ver, $algo, $bus_numbers }'
)"

# Output for Hive agent
echo "${khs:-0}"
echo "${stats}"
