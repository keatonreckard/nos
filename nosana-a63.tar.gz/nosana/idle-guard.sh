#!/usr/bin/env bash
set -euo pipefail

IDLE_SESSION="nosana-idle"
IDLE_PAT='qli-Client|qli-worker-AVX512|qli-worker-XMR|qli-worker-CUDA'
MSG_BIN="/hive/bin/message"
MSG() { if [ -x "$MSG_BIN" ]; then "$MSG_BIN" info "$*"; else echo "$*"; fi; }

log() { echo "[idle-guard] $*"; }

kill_idle() {
  screen -S "$IDLE_SESSION" -X quit 2>/dev/null || true
  pkill -9 -f "$IDLE_PAT" 2>/dev/null || true
}

job_running() {
  # any podman job container with "-1" suffix on name
  docker exec podman podman ps --format '{{.Names}}' 2>/dev/null | grep -Eq -- '-1$'
}

restart_idle_if_needed() {
  if job_running; then return 0; fi
  local idle_bin="/hive/miners/custom/qubjetski.PPLNS/qli-Client"
  if [ -x "$idle_bin" ] && ! screen -ls | grep -q "\.${IDLE_SESSION}\b"; then
    bash /hive/miners/custom/nosana/idle-run.sh || true
    MSG "NOSANA: idle miner restarted (:07)"
  fi
}

# fire hourly schedule
( while :; do
    now=$(date +%M)
    if [ "$now" = "04" ]; then
      kill_idle
      MSG "NOSANA: idle miner killed (:04)"
      sleep 60
    elif [ "$now" = "07" ]; then
      restart_idle_if_needed
      sleep 60
    else
      sleep 20
    fi
  done ) &

# main loop: watch nosana-node logs for job events
NODE_CONT="${NOSANA_NODE_NAME:-nosana-node}"

while :; do
  if docker ps --format '{{.Names}}' | grep -q "^${NODE_CONT}$"; then
    docker logs -f "$NODE_CONT" 2>&1 | \
    grep -E -m 1 'Node has found job|is claiming job|job .* is starting|Flow .* is intializing|Flow .* is initialized' && {
      kill_idle
      MSG "NOSANA: idle miner killed (job event)"
      # brief debounce
      sleep 2
    }
  else
    sleep 5
  fi
done
