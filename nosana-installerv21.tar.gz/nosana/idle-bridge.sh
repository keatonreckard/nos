#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR" /var/run
DEBUG_LOG="$LOG_DIR/debug.log"

# Discover miner log basename
resolve_miner_log() {
  local ml
  if [[ -n "${CUSTOM_LOG_BASENAME:-}" ]]; then
    ml="${CUSTOM_LOG_BASENAME}.log"
  else
    # Try to read from our manifest
    local m="/hive/miners/custom/nosana/h-manifest.conf"
    if [[ -r "$m" ]]; then
      local raw
      raw="$(grep -E '^\s*CUSTOM_LOG_BASENAME=' "$m" | tail -n1 | cut -d= -f2- | sed -e 's/^"//; s/"$//' -e "s/^'//; s/'$//")"
      if [[ -n "$raw" ]]; then
        ml="${raw}.log"
      fi
    fi
    # Fallback
    if [[ -z "${ml:-}" ]]; then
      ml="/var/log/miner/nosana/nosana.log"
    fi
  fi
  echo "$ml"
}

MINER_LOG="$(resolve_miner_log)"
IDLE_LOG="$LOG_DIR/idle.log"
PID_FILE="/var/run/nosana-idle-bridge.pid"

start() {
  # Avoid duplicate tails
  if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    exit 0
  fi

  echo "[$(date -Iseconds)] idle-bridge starting; MINER_LOG=$MINER_LOG IDLE_LOG=$IDLE_LOG" >> "$DEBUG_LOG"

  touch "$IDLE_LOG" "$MINER_LOG"

  # Wait up to 120s for nosana-idle screen to appear; once up, enable logging with low flush
  for i in $(seq 1 120); do
    if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then
      screen -S nosana-idle -X logfile "$IDLE_LOG" || true
      screen -S nosana-idle -X logfile flush 1 || true
      screen -S nosana-idle -X log on || true
      echo "[$(date -Iseconds)] enabled screen logging to $IDLE_LOG (iter=$i)" >> "$DEBUG_LOG"
      break
    fi
    sleep 1
  done

  # Start bridge (CR->NL, strip ANSI, prefix); keep running even if log is still empty now
  ( exec stdbuf -o0 -e0 tail -F "$IDLE_LOG" \
      | stdbuf -o0 -e0 sed -u -r 's/\r/\n/g; s/\x1B\[[0-9;?]*[ -\/]*[@-~]//g' \
      | awk '{ print "[idle-miner] " $0 }' >> "$MINER_LOG" ) &

  echo $! > "$PID_FILE"
  echo "[$(date -Iseconds)] idle-bridge tail started (pid=$(cat "$PID_FILE"))" >> "$DEBUG_LOG"
}

stop() {
  if [[ -f "$PID_FILE" ]]; then
    kill "$(cat "$PID_FILE")" 2>/dev/null || true
    rm -f "$PID_FILE"
    echo "[$(date -Iseconds)] idle-bridge stopped" >> "$DEBUG_LOG"
  fi
}

case "${1:-}" in
  start) start ;;
  stop) stop ;;
  restart) stop; start ;;
  *) echo "usage: $0 {start|stop|restart}"; exit 1 ;;
esac
