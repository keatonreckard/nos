#!/bin/bash

log=$CUSTOM_LOG_BASENAME.log
algo_file=/tmp/nosana_algo
ver_file=/tmp/nosana_ver
wallet=""
sol=""
nos=""

update_ver() {
  if [ -n "$sol" ] && [ -n "$nos" ] && [ -n "$wallet" ]; then
    sol_trunc=$(echo "$sol" | sed 's/\([0-9]*\.[0-9]\{4\}\).*/\1/')
    nos_trunc=$(echo "$nos" | sed 's/\([0-9]*\.[0-9]\{4\}\).*/\1/')
    echo "SOL: $sol_trunc NOS: $nos_trunc Wallet: $wallet" > "$ver_file"
  fi
}

tail -f "$log" | while read line; do
  if echo "$line" | grep -q "Initializing Nosana-Node"; then
    echo "nos - initializing" > "$algo_file"
  fi
  if echo "$line" | grep "Wallet: "; then
    wallet=$(echo "$line" | awk '{print $2}')
    update_ver
  fi
  if echo "$line" | grep "SOL balance: "; then
    sol=$(echo "$line" | awk '{print $3}')
    update_ver
  fi
  if echo "$line" | grep "NOS balance: "; then
    nos=$(echo "$line" | awk '{print $3}')
    update_ver
  fi
  if echo "$line" | grep -q "QUEUED .* position"; then
    pos=$(echo "$line" | grep -oE '[0-9]+/[0-9]+')
    echo "nos - queued $pos" > "$algo_file"
    if [ -f /hive/miners/custom/nosana/idle_cmd.sh ] && [ ! -f /tmp/idle.pid ]; then
      /hive/miners/custom/nosana/idle_cmd.sh &
      echo $! > /tmp/idle.pid
    fi
  fi
  if echo "$line" | grep -q "Node has claimed job" || echo "$line" | grep -q "is starting"; then
    echo "nos - job" > "$algo_file"
    if [ -f /tmp/idle.pid ]; then
      kill $(cat /tmp/idle.pid) >/dev/null 2>&1
      rm -f /tmp/idle.pid
    fi
  fi
done