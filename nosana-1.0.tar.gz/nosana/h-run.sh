#!/bin/bash
cd /hive/miners/custom/nosana
./nosana-miner.sh --network="$CUSTOM_ALGO" $CUSTOM_USER_CONFIG
