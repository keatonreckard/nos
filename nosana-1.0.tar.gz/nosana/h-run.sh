#!/bin/bash

log=$CUSTOM_LOG_BASENAME.log

# Check and install dependencies only if missing
apt-get update -y
if ! command -v gpg >/dev/null 2>&1; then
  apt-get install -y gnupg
fi
if ! command -v docker >/dev/null 2>&1; then
  apt-get install -y docker.io
  usermod -aG docker root
fi
if ! command -v nvidia-ctk >/dev/null 2>&1; then
  distribution=ubuntu$(lsb_release -rs)
  curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
  curl -s -L https://nvidia.github.io/libnvidia-container/${distribution}/libnvidia-container.list | \
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
    tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
  apt-get update -y
  apt-get install -y nvidia-container-toolkit
  nvidia-ctk runtime configure --runtime=docker
  systemctl restart docker
fi

# Read verbose flag
verbose=$(cat /hive/miners/custom/nosana/verbose.flag)
if [ "$verbose" = "true" ]; then
  OPTS="--verbose"
else
  OPTS=""
fi

# Start the nosana node and capture output
bash <(wget -qO- https://nosana.com/start.sh) $OPTS > "$log" 2>&1 &
echo $! > /tmp/nosana.pid

# Start monitor in background
/hive/miners/custom/nosana/monitor.sh &

# Wait on the main process
wait $(cat /tmp/nosana.pid)