#!/bin/bash
# Generates Nosana miner config based on Flight Sheet parameters

# Default config file
CONFIG_FILE="/hive/miners/custom/nosana/nosana.conf"

# Write Flight Sheet parameters to config
echo "NETWORK=$CUSTOM_ALGO" > "$CONFIG_FILE"
echo "VERBOSE=$CUSTOM_USER_CONFIG" >> "$CONFIG_FILE"
