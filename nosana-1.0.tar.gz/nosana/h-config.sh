#!/bin/bash

# Parse extra config
if [ -f "$CUSTOM_CONFIG_FILENAME" ]; then
  EXTRA=$(sed 's/^VERBOSE=//' "$CUSTOM_CONFIG_FILENAME")
else
  EXTRA="{}"
fi

# Install jq if not present
if ! command -v jq >/dev/null 2>&1; then
  apt-get update
  apt-get install -y jq
fi

keypair=$(echo "$EXTRA" | jq -r '.keypair // empty')
verbose=$(echo "$EXTRA" | jq -r '.VERBOSE // false')
idle_settings=$(echo "$EXTRA" | jq '.idleSettings // empty')

# Handle keypair for new node
mkdir -p /root/.nosana
if [ -n "$keypair" ] && [ ! -f /root/.nosana/nosana_key.json ]; then
  echo "$keypair" > /root/.nosana/nosana_key.json
fi

# Save verbose flag
echo "$verbose" > /hive/miners/custom/nosana/verbose.flag

# Save idle command if present
if [ -n "$idle_settings" ]; then
  command=$(echo "$idle_settings" | jq -r '.command // empty')
  arguments=$(echo "$idle_settings" | jq -r '.arguments // empty' | sed "s/%WORKER_NAME%/${WORKER_NAME}/g")
  if [ -n "$command" ] && [ -n "$arguments" ]; then
    echo "#!/bin/bash" > /hive/miners/custom/nosana/idle_cmd.sh
    echo "${command} ${arguments} >> ${CUSTOM_LOG_BASENAME}.log 2>&1" >> /hive/miners/custom/nosana/idle_cmd.sh
    chmod +x /hive/miners/custom/nosana/idle_cmd.sh
  fi
fi