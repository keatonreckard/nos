#!/bin/bash
CONFIG_FILE="/hive/miners/custom/nosana/nosana.conf"
echo "NETWORK=$CUSTOM_ALGO" > "$CONFIG_FILE"
echo "VERBOSE=$CUSTOM_USER_CONFIG" >> "$CONFIG_FILE"
