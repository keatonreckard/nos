#!/bin/bash
khs=0
stats=""
if [ -f /run/hive/miner.0.stats ]; then
  stats=$(cat /run/hive/miner.0.stats)
  queue_position=$(jq -r '.hs[0]' /run/hive/miner.0.stats)
  uptime=$(jq -r '.uptime' /run/hive/miner.0.stats)
  khs=$queue_position
else
  stats='{"hs":["Idle"],"hs_units":"position","uptime":0,"ver":"1.0","algo":"nosana","name":"nosana"}'
  khs="Idle"
fi
