#!/bin/bash
# Provides Nosana miner stats for HiveOS

khs=0
stats=""

# Read stats from nosana-miner.sh output
if [ -f /run/hive/miner.0.stats ]; then
  stats=$(cat /run/hive/miner.0.stats)
  queue_position=$(jq -r '.hs[0]' /run/hive/miner.0.stats)
  uptime=$(jq -r '.uptime' /run/hive/miner.0.stats)
  khs=$queue_position
else
  stats='{"hs":["Idle"],"hs_units":"position","uptime":0,"ver":"1.0","algo":"nosana","name":"nosana"}'
  khs="Idle"
fi
