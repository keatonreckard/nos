#!/bin/bash

  # Nosana Miner Wrapper for HiveOS

  # Logging functions
  log_std() { printf "\033[1;36m==> \033[1;38;5;231m%s\033[0m\n" "$1"; }
  log_err() { printf "\033[1;91m==> \033[1;38;5;231m%s\033[0m\n" "$1"; }

  # Default values
  NETWORK="mainnet"
  VERBOSE=false
  PRE_RELEASE=""
  DOCKER_IMAGE="nosana/nosana-cli:latest"
  STATS_FILE="/run/hive/miner.0.stats"
  LOG_FILE="/var/log/miner/nosana/nosana.log"

  # Parse HiveOS Flight Sheet parameters
  while [ $# -gt 0 ]; do
    case "$1" in
      --network=*) NETWORK="${1#*=}" ;;
      --verbose) VERBOSE=true ;;
      --pre-release) PRE_RELEASE="next" ;;
      *) log_err "Unknown parameter: $1" ;;
    esac
    shift
  done

  # Override NETWORK with CUSTOM_ALGO if set
  [ -n "$CUSTOM_ALGO" ] && NETWORK="$CUSTOM_ALGO"

  # Check dependencies
  if ! command -v docker >/dev/null 2>&1; then
    log_err "🧯 Docker is not installed. Installing..."
    sudo apt update && sudo apt install -y docker.io
    sudo systemctl start docker
    sudo systemctl enable docker
  fi
  log_std "✅ Docker is installed."

  # Automatically add user to docker group if not already a member
  if ! groups | grep -q docker; then
    log_std "Adding user to docker group..."
    sudo usermod -aG docker $USER
    log_std "✅ User added to docker group. Re-executing script with new group..."
    # Re-execute script to apply new group without requiring logout
    exec sg docker -c "$0 $*"
  fi
  log_std "✅ Docker is in user group."

  if ! command -v nvidia-smi >/dev/null 2>&1; then
    log_err "🧯 NVIDIA drivers are not installed. See: https://www.linuxbabe.com/ubuntu/install-nvidia-driver-ubuntu"
    exit 1
  fi
  log_std "✅ NVIDIA drivers installed."

  if ! command -v nvidia-ctk >/dev/null 2>&1; then
    log_err "🧯 NVIDIA Container Toolkit is not installed. See: https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html"
    exit 1
  fi
  log_std "✅ NVIDIA Container Toolkit installed."

  # Check NVIDIA Container Toolkit configuration
  if ! docker run --gpus all nvidia/cuda:11.0.3-base-ubuntu18.04 nvidia-smi >/dev/null 2>&1; then
    log_err "🧯 NVIDIA Container Toolkit is not configured. See: https://docs.nosana.io/hosts/grid-ubuntu.html#linux-configure-the-nvidia-container-toolkit"
    exit 1
  fi
  log_std "✅ NVIDIA Container Toolkit configured."

  # Ensure ~/.nosana directory exists
  mkdir -p ~/.nosana

  # Ensure log directory exists
  mkdir -p /var/log/miner/nosana

  # Stop and remove any existing Nosana node container
  log_std "Stopping any existing Nosana node..."
  docker rm --force nosana-node >/dev/null 2>&1

  # Build Docker command
  DOCKER_ARGS=(--pull=always --name nosana-node --network host --interactive -t --volume ~/.nosana/:/root/.nosana/ -e CLI_VERSION="$PRE_RELEASE")
  NOSANA_ARGS=(node start --network "$NETWORK")
  [ "$VERBOSE" = true ] && NOSANA_ARGS+=(--log trace) && log_std "🔥 Starting Nosana node with verbose logging..." || log_std "🔥 Starting Nosana node..."

  # Start the Nosana node in background
  docker run -d "${DOCKER_ARGS[@]}" "$DOCKER_IMAGE" "${NOSANA_ARGS[@]}" >/dev/null 2>&1
  if [ $? -eq 0 ]; then
    log_std "Nosana node started successfully."
  else
    log_err "Failed to start Nosana node."
    exit 1
  fi

  # Background process to monitor logs and update HiveOS stats
  monitor_logs() {
    local job_start_time=0 queue_position="Idle" last_position=""
    mkdir -p "$(dirname "$STATS_FILE")"
    docker logs -f nosana-node > "$LOG_FILE" 2>&1 &
    tail -f "$LOG_FILE" | while read -r line; do
      if echo "$line" | grep -q "QUEUED at position"; then
        new_position=$(echo "$line" | grep -oE "[0-9]+/[0-9]+")
        if [ "$new_position" != "$last_position" ]; then
          queue_position="$new_position"
          last_position="$new_position"
          /hive/bin/message info "Nosana node queued at position $queue_position"
        fi
      elif echo "$line" | grep -qE "Job is starting|node has found job"; then
        job_start_time=$(date +%s)
        queue_position="Running"
        /hive/bin/message info "Nosana node started a job"
      elif echo "$line" | grep -q "Idle"; then
        queue_position="Idle"
        job_start_time=0
        last_position=""
      fi
      local uptime=0
      [ $job_start_time -gt 0 ] && uptime=$(( $(date +%s) - job_start_time ))
      cat <<EOF > "$STATS_FILE"
{
  "hs": ["$queue_position"],
  "hs_units": "position",
  "uptime": $uptime,
  "ver": "1.0",
  "algo": "nosana",
  "name": "nosana"
}
EOF
    done
  }

  # Start log monitoring in background
  monitor_logs &

  # Monitor the container for HiveOS
  while true; do
    if ! docker ps | grep -q nosana-node; then
      log_err "Nosana node container stopped. Exiting."
      killall tail >/dev/null 2>&1
      exit 1
    fi
    sleep 10
  done
