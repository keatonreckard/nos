#!/bin/bash

# Nosana Miner Wrapper for HiveOS

# Logging functions
log_std() { printf "\033[1;36m==> \033[1;38;5;231m%s\033[0m\n" "$1"; }
log_err() { printf "\033[1;91m==> \033[1;38;5;231m%s\033[0m\n" "$1"; }

# Default values
NETWORK="mainnet"
VERBOSE=false
PRE_RELEASE=""
DOCKER_IMAGE="nosana/nosana-cli:latest"
PODMAN_IMAGE="nosana/podman:v1.1.0"
STATS_FILE="/run/hive/miner.0.stats"
LOG_FILE="/var/log/miner/nosana/nosana.log"

# Parse HiveOS Flight Sheet parameters
while [ $# -gt 0 ]; do
  case "$1" in
    --network=*) NETWORK="${1#*=}" ;;
    --verbose) VERBOSE=true ;;
    --pre-release) PRE_RELEASE="next" ;;
    *) log_err "Unknown parameter: $1" ;;
  esac
  shift
done

# Override NETWORK with CUSTOM_ALGO if set
[ -n "$CUSTOM_ALGO" ] && NETWORK="$CUSTOM_ALGO"

# Check dependencies
if ! command -v docker >/dev/null 2>&1; then
  log_err "🧯 Docker is not installed. Installing..."
  sudo apt update && sudo apt install -y docker.io
  sudo systemctl start docker
  sudo systemctl enable docker
fi
log_std "✅ Docker is installed."

# Automatically add user to docker group
if ! groups | grep -q docker; then
  log_std "Adding user to docker group..."
  sudo usermod -aG docker $USER
  log_std "✅ User added to docker group. Re-executing..."
  exec sg docker -c "$0 $*" || { log_err "Failed to re-execute with docker group"; exit 1; }
fi
log_std "✅ Docker is in user group."

if ! command -v nvidia-smi >/dev/null 2>&1; then
  log_err "🧯 NVIDIA drivers are not installed. See: https://www.linuxbabe.com/ubuntu/install-nvidia-driver-ubuntu"
  exit 1
fi
log_std "✅ NVIDIA drivers installed."

if ! command -v nvidia-ctk >/dev/null 2>&1; then
  log_err "🧯 NVIDIA Container Toolkit is not installed. See: https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html"
  exit 1
fi
log_std "✅ NVIDIA Container Toolkit installed."

# Check NVIDIA Container Toolkit configuration
if ! docker run --gpus all nvidia/cuda:11.0.3-base-ubuntu18.04 nvidia-smi >/dev/null 2>&1; then
  log_err "🧯 NVIDIA Container Toolkit is not configured. See: https://docs.nosana.io/hosts/grid-ubuntu.html#linux-configure-the-nvidia-container-toolkit"
  exit 1
fi
log_std "✅ NVIDIA Container Toolkit configured."

# Ensure directories exist
mkdir -p ~/.nosana
mkdir -p /var/log/miner/nosana
: > "$LOG_FILE"  # Clear log file

# Create Docker volumes for Podman
if ! docker volume ls | grep -q podman-cache; then
  docker volume create podman-cache >/dev/null 2>&1
fi
if ! docker volume ls | grep -q podman-socket; then
  docker volume create podman-socket >/dev/null 2>&1
fi

# Stop and remove existing containers
log_std "Stopping any existing containers..."
docker rm -f podman nosana-node >/dev/null 2>&1

# Start Podman container
log_std "🔥 Starting podman..."
docker run -d \
  --pull=always \
  --gpus=all \
  --name podman \
  --device /dev/fuse \
  --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman \
  --privileged \
  -e ENABLE_GPU=true \
  "$PODMAN_IMAGE" unix:/podman/podman.sock >/tmp/podman-start.log 2>&1
if [ $? -eq 0 ]; then
  log_std "Podman started successfully."
else
  log_err "Failed to start Podman. Check logs:"
  cat /tmp/podman-start.log
  exit 1
fi
sleep 5  # Wait for Podman to start

# Start Nosana node
log_std "🔥 Starting Nosana node..."
DOCKER_ARGS=(--pull=always --name nosana-node --network host --interactive -t --volume ~/.nosana/:/root/.nosana/ --volume podman-socket:/root/.nosana/podman:ro -e CLI_VERSION="$PRE_RELEASE")
NOSANA_ARGS=(node start --network "$NETWORK")
[ "$VERBOSE" = true ] && NOSANA_ARGS+=(--log trace) && log_std "🔥 Starting Nosana node with verbose logging..."

docker run -d "${DOCKER_ARGS[@]}" "$DOCKER_IMAGE" "${NOSANA_ARGS[@]}" >/tmp/nosana-start.log 2>&1
if [ $? -eq 0 ]; then
  log_std "Nosana node started successfully."
else
  log_err "Failed to start Nosana node. Check logs:"
  cat /tmp/nosana-start.log
  docker logs nosana-node
  exit 1
fi

# Background process to monitor logs and update HiveOS stats
monitor_logs() {
  local job_start_time=0 queue_position="Idle" last_position=""
  mkdir -p "$(dirname "$STATS_FILE")"
  docker logs -f nosana-node > "$LOG_FILE" 2>&1 &
  local log_pid=$!
  sleep 5
  if ! ps -p $log_pid >/dev/null; then
    log_err "Log tailing failed."
    exit 1
  fi
  tail -f "$LOG_FILE" | while read -r line; do
    echo "$line" >> /tmp/nosana-debug.log
    if echo "$line" | grep -q "QUEUED at position"; then
      new_position=$(echo "$line" | grep -oE "[0-9]+/[0-9]+")
      if [ "$new_position" != "$last_position" ]; then
        queue_position="$new_position"
        last_position="$new_position"
        /hive/bin/message info "Nosana node queued at position $queue_position"
      fi
    elif echo "$line" | grep -qE "Job is starting|node has found job"; then
      job_start_time=$(date +%s)
      queue_position="Running"
      /hive/bin/message info "Nosana node started a job"
    elif echo "$line" | grep -q "Idle"; then
      queue_position="Idle"
      job_start_time=0
      last_position=""
    fi
    local uptime=0
    [ $job_start_time -gt 0 ] && uptime=$(( $(date +%s) - job_start_time ))
    cat <<EOF > "$STATS_FILE"
{
  "hs": ["$queue_position"],
  "hs_units": "position",
  "uptime": $uptime,
  "ver": "1.0",
  "algo": "nosana",
  "name": "nosana"
}
EOF
  done &
  local tail_pid=$!
  while true; do
    if ! ps -p $log_pid >/dev/null || ! ps -p $tail_pid >/dev/null; then
      log_err "Log monitoring stopped."
      docker logs nosana-node
      kill $log_pid $tail_pid 2>/dev/null
      exit 1
    fi
    sleep 10
  done
}

# Start log monitoring
monitor_logs &

# Monitor containers
while true; do
  if ! docker ps | grep -q nosana-node || ! docker ps | grep -q podman; then
    log_err "Container stopped (nosana-node or podman). Logs:"
    docker logs nosana-node
    docker logs podman
    killall tail >/dev/null 2>&1
    exit 1
  fi
  sleep 10
done
