Nosana wrapper v3.1.18: ANSI-stripped sed parsing for wallet/balances; robust algo; docker logs fallback.


v5.6 changes:
- Robust idle command resolution: supports split command/args or a single full command line.
- Emits explicit 'NOS: idle miner start attempt' and 'NOS: idle miner started' messages.
- Uses a runner script with bash -lc to avoid quoting issues and interleaves logs reliably.
- No changes to node start, stats format/version string, balance reads, or dashboard messages beyond idle notices.
