# --- v5.6: robust idle command resolver ---
resolve_idle_cmdline() {
  # Priority 1: explicit combined cmdline file (if ever present)
  local cmdline_file="$MINER_DIR/parsed/idle_cmdline"
  local cmd_file="$MINER_DIR/parsed/idle_command"
  local args_file="$MINER_DIR/parsed/idle_args"
  local conf_json="$MINER_DIR/nosana.conf"
  IDLE_CMDLINE=""

  if [[ -s "$cmdline_file" ]]; then
    IDLE_CMDLINE="$(cat "$cmdline_file" 2>/dev/null || true)"
  fi
  if [[ -z "$IDLE_CMDLINE" && -s "$cmd_file" ]]; then
    local c="$(cat "$cmd_file" 2>/dev/null || true)"
    local a=""
    [[ -s "$args_file" ]] && a="$(cat "$args_file" 2>/dev/null || true)"
    if [[ -n "$a" ]]; then
      IDLE_CMDLINE="$c $a"
    else
      # If args are empty but command itself already includes args, use it as-is
      IDLE_CMDLINE="$c"
    fi
  fi
  if [[ -z "$IDLE_CMDLINE" && -s "$conf_json" ]]; then
    # Extract idleSettings.command/args from nosana.conf (simple awk JSON parse)
    local c="$(awk 'BEGIN{RS="[,{}]"} /"idleSettings"/{f=1} f && /"command"/ {gsub(/.*"command"[[:space:]]*:[[:space:]]*"/,""); gsub(/".*/,"",$0); print; exit}' "$conf_json" 2>/dev/null)"
    local a="$(awk 'BEGIN{RS="[,{}]"} /"idleSettings"/{f=1} f && /"args"/ {gsub(/.*"args"[[:space:]]*:[[:space:]]*"/,""); gsub(/".*/,"",$0); print; exit}' "$conf_json" 2>/dev/null)"
    if [[ -n "$c" || -n "$a" ]]; then
      if [[ -n "$a" ]]; then
        IDLE_CMDLINE="$c $a"
      else
        IDLE_CMDLINE="$c"
      fi
    fi
  fi
  if [[ -z "$IDLE_CMDLINE" && -n "${IDLE_COMMAND:-}" ]]; then
    # fallback to older vars if set
    if [[ -n "${IDLE_ARGS:-}" ]]; then
      IDLE_CMDLINE="$IDLE_COMMAND $IDLE_ARGS"
    else
      IDLE_CMDLINE="$IDLE_COMMAND"
    fi
  fi
  if [[ -z "$IDLE_CMDLINE" ]]; then
    logd "[idle] resolve: EMPTY (no parsed files, nosana.conf, or env)"
  else
    logd "[idle] resolve: cmdline='$IDLE_CMDLINE'"
  fi
}
# --- end v5.6 ---
#!/usr/bin/env bash
set -uo pipefail
export LC_ALL=C
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
DEBUG_LOG="$LOG_DIR/debug.log"
MINER_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
mkdir -p "$LOG_DIR" "$RUN_DIR"; touch "$MINER_LOG" "$DEBUG_LOG" "$IDLE_LOG"

IDLE_COMMAND="$(cat "$MINER_DIR/parsed/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$MINER_DIR/parsed/idle_args" 2>/dev/null || true)"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

set_state() {
  local key="$1" val="$2"
  local vesc="${val//\\/\\\\}"; vesc="${vesc//\"/\\\"}"
  mkdir -p "$(dirname "$STATE_FILE")"; touch "$STATE_FILE"
  awk -v k="$key" -v v="$vesc" '
    BEGIN{done=0}
    $0 ~ ("^"k"=") { print k"=\""v"\""; done=1; next }
    { print }
    END{ if(!done) print k"=\""v"\"" }
  ' "$STATE_FILE" > "$STATE_FILE.tmp" && mv "$STATE_FILE.tmp" "$STATE_FILE"
}

date +%s > "$MINER_DIR/nosana.start.time"
set_state status "nos - initializing"
echo "[nosana] monitor started" | tee -a "$MINER_LOG"; msg "NOS: monitor started"

bootstrap() {
  local bootlog
  bootlog="$(docker logs --since 60m nosana-node 2>&1 || true)"
  [[ -n "$bootlog" ]] && printf "%s\n" "$bootlog" | tee -a "$MINER_LOG"
  if printf '%s\n' "$bootlog" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
    set_state status "nos - queued"; msg "NOS: queued"
    date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
  elif printf '%s\n' "$bootlog" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
    set_state status "nos - job"; msg "NOS: job"; date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
  fi
}
bootstrap

last_pos=""
while true; do
  logchunk="$(docker logs --since 10s nosana-node 2>&1 || true)"
  if [[ -n "$logchunk" ]]; then
    printf "%s\n" "$logchunk" | tee -a "$MINER_LOG"
    if echo "$logchunk" | grep -Eq "position [0-9]+/[0-9]+"; then
      pos="$(echo "$logchunk" | grep -E 'position [0-9]+/[0-9]+' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/')"
      [[ -n "$pos" && "$pos" != "$last_pos" ]] && { echo "[nosana] queued ${pos}" | tee -a "$MINER_LOG"; msg "NOS: queued ${pos}"; last_pos="$pos"; }
      set_state status "nos - queued ${pos}"; date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
    fi
    if echo "$logchunk" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
      set_state status "nos - job"; date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"; msg "NOS: job started"
    fi
    if echo "$logchunk" | grep -Eq "Nosana Node finished|Job .* completed|finished successfully|Flow .* (finished|completed)"; then
      echo "[nosana] job finished" | tee -a "$MINER_LOG"; msg "NOS: job finished"
    fi
  fi
  sleep 5
done


# v5.6 override
start_idle() {
  # breadcrumbs visible everywhere
  /hive/bin/message "NOS: idle miner start attempt"
  echo "[idle] start attempt" | tee -a "$DEBUG_LOG" >> "$MINER_LOG"

  resolve_idle_cmdline
  if [[ -z "${IDLE_CMDLINE:-}" ]]; then
    echo "[idle] not starting: IDLE_CMDLINE empty" | tee -a "$DEBUG_LOG" >> "$MINER_LOG"
    return 1
  fi

  if is_idle_running; then
    echo "[idle] already running" | tee -a "$DEBUG_LOG" >> "$MINER_LOG"
    return 0
  fi

  mkdir -p "$RUN_DIR"
  RUNNER="$RUN_DIR/nosana-idle-run.sh"
  cat > "$RUNNER" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
# Use bash -lc so complex args/flags are handled; stdbuf to flush logs
exec bash -lc "stdbuf -oL -eL $IDLE_CMDLINE" 2>&1
EOF
  chmod +x "$RUNNER"

  # launch via screen and interleave logs into both idle.log and nosana.log
  screen -dmS nosana-idle bash -lc '
    set -o pipefail
    export IDLE_CMDLINE='"'"'$IDLE_CMDLINE'"'"'
    '"$RUNNER"' | tee -a "'"$IDLE_LOG"'" | sed -u "s/^/[idle] /" >> "'"$MINER_LOG"'"
  '

  sleep 1
  if ! screen -ls 2>/dev/null | grep -q '\.nosana-idle'; then
    echo "[idle] start failed: no screen session after 1s" | tee -a "$DEBUG_LOG" >> "$MINER_LOG"
    { echo "----- idle.log (tail) -----"; tail -n 50 "$IDLE_LOG" 2>/dev/null || true; } | sed -u "s/^/[idle] /" >> "$MINER_LOG"
    return 1
  fi

  date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
  /hive/bin/message "NOS: idle miner started"
  echo "[idle] started OK" | tee -a "$DEBUG_LOG" >> "$MINER_LOG"
  return 0
}

# v5.6 minimal QUEUED trigger inside heartbeat loop will call start_idle()
