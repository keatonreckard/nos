Nosana custom miner wrapper v54

- Fix: monitor.sh while-loop syntax (no process substitution; simple pipe)
- Fix: Never show idle suffix/idle hashrate during 'initializing'
- Fix: Kill idle screen and clear miner.2 on (re)start
- Feature: Queue position messages and idle start/kill notices
- Feature: miner_status.2 maintained (running/stopped)
- Stats: 0.01 kH for initializing and queued(no idle); 1.000 kH for job
- Idle parsing: converts it/s -> kH/s, supports XMR and QUBIC

