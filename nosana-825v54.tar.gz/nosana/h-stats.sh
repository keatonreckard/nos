#!/usr/bin/env bash
# Emit Hive stats JSON for dashboard
set -e

# shellcheck source=/dev/null
. "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)/h-config.sh"

phase="initializing"
q="0"
t="0"
if [ -f "${NOSANA_STATE}" ]; then
  # shellcheck disable=SC1090
  . "${NOSANA_STATE}" 2>/dev/null || true
fi

algo="nos - initializing"
hs="0.01"  # default tiny hashrate for non-idle phases
hs_unit="khs"
idle_algo=""
idle_khs=""

# If queued and idle is running, parse idle hashrate
if [ "${phase}" = "queued" ]; then
  if [ -f "${IDLE_STATUS}" ] && grep -q "running" "${IDLE_STATUS}" 2>/dev/null; then
    # Parse last line with it/s for either XMR or QUBIC
    last="$(tac "${IDLE_OUT}" 2>/dev/null | grep -m1 -E "\\[(XMR|QUBIC)\\].*[0-9]+[[:space:]]it/s")" || true
    if [ -n "$last" ]; then
      # Detect algo label
      if echo "$last" | grep -q "\\[XMR\\]"; then idle_algo="idle xmr"; else idle_algo="idle qubic"; fi
      # extract the current it/s number (first occurrence before 'it/s')
      its="$(echo "$last" | sed -n 's/.*\\[.*\\][^0-9]*\\([0-9]\\+\\)\\([0-9]*\\)[[:space:]]it\\/s.*/\\1\\2/p' | head -n1)"
      # If the above pattern fails for decimals, try a more permissive grep+awk
      if [ -z "$its" ]; then
        its="$(echo "$last" | grep -oE '[0-9]+(\\.[0-9]+)?[[:space:]]it/s' | head -n1 | tr -d ' ' | sed 's/it\\/s//')"
      fi
      # Convert to kH/s by dividing by 1000; keep 3 decimals
      if [ -n "$its" ]; then
        # awk math is simpler/portable
        idle_khs="$(awk -v v="$its" 'BEGIN{printf "%.3f", v/1000.0}')" || true
      fi
    fi
    if [ -n "$idle_khs" ]; then
      hs="$idle_khs"
      algo="nos queued ${q}/${t} - ${idle_algo}"
    else
      algo="nos queued ${q}/${t}"
      hs="0.01"
    fi
  else
    algo="nos queued ${q}/${t}"
    hs="0.01"
  fi
elif [ "${phase}" = "job" ]; then
  algo="nos - job"
  hs="1.000"
else
  # initializing
  algo="nos - initializing"
  hs="0.01"
fi

# Build minimal miner_stats JSON
printf '{"hs":[%s],"hs_units":"khs","temp":[],"fan":[],"uptime":"%s","ver":"","algo":"%s","bus_numbers":[]}\n' "$hs" "$(sed -n 's/.*up \\([0-9: a-zA-Z]*\\).*/\\1/p' /proc/uptime 2>/dev/null | head -n1 | tr -d '\n')" "$algo"
