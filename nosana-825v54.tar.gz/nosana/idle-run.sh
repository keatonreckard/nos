#!/usr/bin/env bash
# Start the idle miner in a dedicated screen and stream to miner.2
set -e
# shellcheck source=/dev/null
. "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)/h-config.sh"

# Must have a command
if [ -z "${IDLE_COMMAND:-}" ]; then
  exit 0
fi

# Ensure previous screen is gone
screen -S nosana-idle -X quit >/dev/null 2>&1 || true
sleep 0.2

# Clear output at start
: > "${IDLE_OUT}" 2>/dev/null || true

# Start screen session that runs the idle miner and tees output to miner.2
screen -dmS nosana-idle bash -lc '
  set -e
  # Run idle miner; sanitize carriage returns for MOTD
  (stdbuf -oL '"${IDLE_COMMAND}"' 2>&1 | stdbuf -oL sed -u "s/\r/\n/g") | tee -a "'"${IDLE_OUT}"'"
'
