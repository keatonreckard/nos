#!/usr/bin/env bash
# Start nosana node and monitoring; ensure idle miner is reset first.
set -e

# Load config/env
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
# shellcheck source=/dev/null
. "${SCRIPT_DIR}/h-config.sh"

ts() { date "+[%Y-%m-%dT%H:%M:%S%z]"; }

log()  { echo "$(ts) $*"; echo "$(ts) $*" >> "${LOG_DIR}/nosana.log"; }
dbg()  { echo "$(ts) $*" >> "${LOG_DIR}/debug.log"; }

# 1) Kill any stale idle screen & clear miner.2
if screen -list | grep -q "nosana-idle"; then
  log "NOS: idle miner killed (pre-start)"
  screen -S nosana-idle -X quit || true
fi
echo "stopped" > "${IDLE_STATUS}" 2>/dev/null || true
echo "waiting for node to enter queued state to start idle miner" > "${IDLE_OUT}" 2>/dev/null || true
dbg "cleared previous idle miner outputs"

log "h-run: cleaning previous containers"
# remove old containers quietly
docker rm --force podman nosana-node >/dev/null 2>&1 || true

# 2) start podman sidecar container (volume socket variant)
log "h-run: starting podman sidecar - container"
docker run -d --pull=always --gpus=all --name podman   --device /dev/fuse --mount source=podman-cache,target=/var/lib/containers   --volume podman-socket:/podman --privileged -e ENABLE_GPU=true   nosana/podman:v1.1.0 unix:/podman/podman.sock >/dev/null

# wait until socket appears inside the sidecar and is forwarded
sleep 2
log "h-run: podman socket is up"

# 3) Launch nosana node container (podman provider through mounted volume)
log "h-run: starting nosana-node - podman provider via volume"
docker run -d --pull=always --name nosana-node --network host -t   -e CLI_VERSION=   -v /root/.nosana/:/root/.nosana/   -v podman-socket:/root/.nosana/podman:ro   nosana/nosana-cli:latest node start --network mainnet >/dev/null

# 4) Stream logs from the node ONLY to miner.1 (append; do not truncate)
# Use stdbuf and CR->LF sanitation to avoid overprinting
( docker logs -f nosana-node 2>&1 | stdbuf -oL sed -u 's/\r/\n/g' >> "${NODE_OUT}" ) &
echo $! > "${STATE_DIR}/nosana.node.tail.pid"

# 5) Start monitor
nohup bash -lc "${SCRIPT_DIR}/monitor.sh" >/dev/null 2>&1 &
log "NOS: monitor started"
