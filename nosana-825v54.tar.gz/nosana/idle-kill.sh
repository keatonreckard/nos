#!/usr/bin/env bash
# Kill the idle miner screen and mark as stopped
set -e
# shellcheck source=/dev/null
. "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)/h-config.sh"
screen -S nosana-idle -X quit >/dev/null 2>&1 || true
echo "stopped" > "${IDLE_STATUS}" 2>/dev/null || true
echo "waiting for node to enter queued state to start idle miner" > "${IDLE_OUT}" 2>/dev/null || true
