#!/usr/bin/env bash
# nosana h-config.sh v54
# Ensures directories and env; NO side-effects beyond setup.

LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/run/hive"
STATE_DIR="/var/run"
NOSANA_STATE="${STATE_DIR}/nosana.state"
IDLE_STATUS="${RUN_DIR}/miner_status.2"
IDLE_OUT="${RUN_DIR}/miner.2"
NODE_OUT="${RUN_DIR}/miner.1"

# Create dirs/files
mkdir -p "${LOG_DIR}" || true
touch "${LOG_DIR}/nosana.log" "${LOG_DIR}/debug.log" "${LOG_DIR}/idle.log" 2>/dev/null || true
touch "${NODE_OUT}" "${IDLE_OUT}" 2>/dev/null || true

# Put a starting banner in miner.2 only if empty
if [ ! -s "${IDLE_OUT}" ]; then
  echo "waiting for node to enter queued state to start idle miner" > "${IDLE_OUT}" 2>/dev/null || true
fi

# Default status file
[ -f "${IDLE_STATUS}" ] || echo "stopped" > "${IDLE_STATUS}"

# read idle command if provided
IDLE_COMMAND_FILE="/hive/miners/custom/nosana/idle.cmd"
if [ -z "${IDLE_COMMAND:-}" ] && [ -f "${IDLE_COMMAND_FILE}" ]; then
  # shellcheck disable=SC1090
  IDLE_COMMAND="$(cat "${IDLE_COMMAND_FILE}")"
  export IDLE_COMMAND
fi

export LOG_DIR RUN_DIR STATE_DIR NOSANA_STATE IDLE_STATUS IDLE_OUT NODE_OUT IDLE_COMMAND
