#!/usr/bin/env bash
# Watches miner.1 for queue state; controls idle miner.
# Avoid set -u to prevent unbound var crashes in long-running tail pipelines.
set -eE

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
# shellcheck source=/dev/null
. "${SCRIPT_DIR}/h-config.sh"

ts() { date "+[%Y-%m-%dT%H:%M:%S%z]"; }
log()  { echo "$(ts) $*"; echo "$(ts) $*" >> "${LOG_DIR}/nosana.log"; }
dbg()  { echo "$(ts) $*"; echo "$(ts) $*" >> "${LOG_DIR}/debug.log"; }

# Simple agent-screen message helper (best-effort)
say() { echo "NOS: $*"; }

# State
queue_pos=""
queue_tot=""
phase="initializing"
idle_enabled="1"   # treat idle as enabled if IDLE_COMMAND is present
if [ -z "${IDLE_COMMAND:-}" ]; then
  idle_enabled="0"
fi

idle_running="0"

# Initialize state file
printf 'phase=%s\nqueue=%s/%s\n' "$phase" "${queue_pos:-0}" "${queue_tot:-0}" > "${NOSANA_STATE}" 2>/dev/null || true

# Functions
idle_start() {
  [ "$idle_enabled" = "1" ] || return 0
  if [ "$idle_running" = "1" ]; then return 0; fi
  if [ -z "${IDLE_COMMAND:-}" ]; then return 0; fi
  bash -lc "${SCRIPT_DIR}/idle-run.sh" || true
  echo "running" > "${IDLE_STATUS}" 2>/dev/null || true
  idle_running="1"
  log "NOS: idle miner started"
  say "idle miner started"
}

idle_stop() {
  if [ "$idle_running" = "0" ] && ! screen -list | grep -q "nosana-idle"; then
    return 0
  fi
  bash -lc "${SCRIPT_DIR}/idle-kill.sh" || true
  echo "stopped" > "${IDLE_STATUS}" 2>/dev/null || true
  idle_running="0"
  log "NOS: idle miner killed"
  say "idle miner killed"
  # reset placeholder text
  echo "waiting for node to enter queued state to start idle miner" > "${IDLE_OUT}" 2>/dev/null || true
}

update_queue_note() {
  local new_q="$1" new_t="$2"
  if [ "$new_q" != "$queue_pos" ] || [ "$new_t" != "$queue_tot" ]; then
    queue_pos="$new_q"; queue_tot="$new_t"
    dbg "queue updated to ${queue_pos}/${queue_tot}"
    say "queued ${queue_pos}/${queue_tot}"
  fi
  printf 'phase=%s\nqueue=%s/%s\n' "$phase" "${queue_pos:-0}" "${queue_tot:-0}" > "${NOSANA_STATE}" 2>/dev/null || true
}

enter_phase() {
  local p="$1"
  if [ "$phase" != "$p" ]; then
    phase="$p"
    dbg "phase -> ${phase}"
    if [ "$phase" = "initializing" ]; then
      idle_stop   # never show idle during init
    fi
    printf 'phase=%s\nqueue=%s/%s\n' "$phase" "${queue_pos:-0}" "${queue_tot:-0}" > "${NOSANA_STATE}" 2>/dev/null || true
  fi
}

# On start we are initializing
enter_phase "initializing"

# Tail monitor loop. Keep very simple to avoid 'done' syntax issues.
tail -Fn0 "${NODE_OUT}" | while IFS= read -r line; do
  # Normalize carriage returns
  line="${line//$'\r'/\\r}"

  # Detect queued position
  if echo "$line" | grep -q "QUEUED"; then
    # Example: '-  QUEUED  In market ... at position 3/4'
    pos="$(echo "$line" | sed -n 's/.*position[[:space:]]*\\([0-9]\\+\\)\\/\\([0-9]\\+\\).*/\\1/p')"
    tot="$(echo "$line" | sed -n 's/.*position[[:space:]]*\\([0-9]\\+\\)\\/\\([0-9]\\+\\).*/\\2/p')"
    [ -n "$pos" ] && [ -n "$tot" ] || { pos="0"; tot="0"; }
    enter_phase "queued"
    update_queue_note "$pos" "$tot"
    # start idle when queued
    idle_start
    continue
  fi

  # Detect job start (very generic)
  if echo "$line" | grep -Eq "Starting job|Job started|RUNNING job|Running job|BEGIN WORK"; then
    enter_phase "job"
    idle_stop
    continue
  fi

  # Detect node startup sequences to keep init phase
  if echo "$line" | grep -Eq "Starting Nosana CLI|Node api.*running|Checking Specs|Health check completed"; then
    enter_phase "initializing"
    continue
  fi

  # Detect job finish -> back to queued (idle can come back later when queued shows again)
  if echo "$line" | grep -Eq "job finished|Job completed|Node shutdown successfully|Node shutdown"; then
    enter_phase "initializing"
    idle_stop
    continue
  fi

done
