#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
OUT_TOP="/hive/miners/custom/h-stats.sh"
OUT_MINER="/hive/miners/custom/nosana/h-stats.sh"

mkdir -p "$(dirname "$OUT_TOP")" "$(dirname "$OUT_MINER")"

# Install the ACTUAL stats producer so the agent gets valid JSON from either path
cp -f "$MINER_DIR/h-stats.sh" "$OUT_TOP"
cp -f "$MINER_DIR/h-stats.sh" "$OUT_MINER"
chmod 755 "$OUT_TOP" "$OUT_MINER"

echo "[nosana] installed stats script to $OUT_TOP and $OUT_MINER"
