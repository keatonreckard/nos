#!/usr/bin/env bash
set -uo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
DEBUG_LOG="$LOG_DIR/debug.log"
MINER_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR" "$RUN_DIR"
touch "$MINER_LOG" "$DEBUG_LOG" "$IDLE_LOG"

PARSE_TAIL_LINES=300
IDLE_RETRY_SECS=20

# Runtime flags
QUEUED_MODE=0
LAST_IDLE_MSG=0
STATE="init"
last_pos=""

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

set_state() {
  local key="$1" val="$2"
  local vesc="${val//\\/\\\\}"; vesc="${vesc//\"/\\\"}"
  mkdir -p "$(dirname "$STATE_FILE")"; touch "$STATE_FILE"
  awk -v k="$key" -v v="$vesc" '
    BEGIN{done=0}
    $0 ~ ("^"k"=") { print k"=\""v"\""; done=1; next }
    { print }
    END{ if(!done) print k"=\""v"\"" }
  ' "$STATE_FILE" > "$STATE_FILE.tmp" && mv "$STATE_FILE.tmp" "$STATE_FILE"
  # Trigger idle immediately when status becomes queued
  if [[ "$key" == "status" ]] && echo "$val" | grep -Eq '^nos - queued'; then
    echo "[nosana] set_state detected queued -> start_idle" | tee -a "$MINER_LOG" "$DEBUG_LOG"
    QUEUED_MODE=1; STATE="queued"
    start_idle
  fi
}

# Interleave idle log into main log with [idle] prefix
if [[ ! -f "$RUN_DIR/idle_tail.pid" ]] || ! kill -0 "$(cat "$RUN_DIR/idle_tail.pid" 2>/dev/null)" 2>/dev/null; then
  nohup bash -lc "tail -n0 -F '$IDLE_LOG' | sed -u 's/^/[idle] /' >> '$MINER_LOG'" >/dev/null 2>&1 &
  echo $! > "$RUN_DIR/idle_tail.pid"
fi

idle_running() { screen -ls 2>/dev/null | grep -q '\.nosana-idle'; }

start_idle() {
  local now cmd args_raw args
  now="$(date +%s)"
  # Preferred parsed files
  cmd="$(cat "$MINER_DIR/parsed/idle_command" 2>/dev/null || true)"
  args_raw="$(cat "$MINER_DIR/parsed/idle_args" 2>/dev/null || true)"
  # Fallback to nosana.conf if needed
  if [[ -z "$cmd" ]] && [[ -f "$MINER_DIR/nosana.conf" ]]; then
    raw="$(cat "$MINER_DIR/nosana.conf")"
    trimmed="$(printf '%s' "$raw" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
    if printf '%s' "$trimmed" | grep -q '"idleSettings"'; then
      if printf '%s' "$trimmed" | grep -q '^{'; then extra_json="$trimmed"; else extra_json="{$trimmed}"; fi
      cmd="$(printf '%s' "$extra_json" | tr '\n' ' ' | sed -n 's/.*"idleSettings"[[:space:]]*:[[:space:]]*{[^}]*"command"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)"
      args_raw="$(printf '%s' "$extra_json" | tr '\n' ' ' | sed -n 's/.*"idleSettings"[[:space:]]*:[[:space:]]*{[^}]*"arguments"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)"
    fi
  fi
  args="$(printf '%s' "$args_raw" | sed -E 's/^[[:space:]]+//')"
  if [[ -z "$cmd" ]]; then
    if (( LAST_IDLE_MSG == 0 || now - LAST_IDLE_MSG >= IDLE_RETRY_SECS )); then
      echo "[nosana] idle: command not set yet (waiting for config)" | tee -a "$MINER_LOG"
      LAST_IDLE_MSG="$now"
    fi
    return 0
  fi
  idle_running && return 0
  echo "[nosana] start_idle(reason=queued)" | tee -a "$MINER_LOG"
  msg "NOS: idle miner starting"
  screen -dmS nosana-idle bash -lc "cd / && stdbuf -oL -eL $cmd $args 2>&1 | tee -a '$IDLE_LOG'"
  echo "[nosana] idle miner started: $cmd $args" | tee -a "$MINER_LOG"
  date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
}

stop_idle() {
  if idle_running; then
    msg "NOS: idle miner stopping"
    screen -S nosana-idle -X quit || true
    echo "[nosana] idle miner stopped" | tee -a "$MINER_LOG"
  fi
  rm -f "$MINER_DIR/idle.start.time"
}

date +%s > "$MINER_DIR/nosana.start.time"
set_state status "nos - initializing"
echo "[nosana] monitor started" | tee -a "$MINER_LOG"; msg "NOS: monitor started"

bootstrap() {
  local bootlog
  bootlog="$(docker logs --since 10m nosana-node 2>&1 || true)"
  [[ -n "$bootlog" ]] && printf "%s\n" "$bootlog" | tee -a "$MINER_LOG"
  if printf '%s\n' "$bootlog" | grep -Eqi 'position[[:space:]]+[0-9]+/[0-9]+'; then
    pos="$(printf '%s\n' "$bootlog" | grep -E 'position[[:space:]]+[0-9]+/[0-9]+' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/')"
    [[ -n "$pos" ]] && { echo "[nosana] queued ${pos}" | tee -a "$MINER_LOG"; msg "NOS: queued ${pos}"; last_pos="$pos"; }
    set_state status "nos - queued ${pos}"
    QUEUED_MODE=1; STATE="queued"
    start_idle
  elif printf '%s\n' "$bootlog" | grep -Eqi '\bQUEUED\b'; then
    set_state status "nos - queued"
    QUEUED_MODE=1; STATE="queued"
    start_idle
  elif printf '%s\n' "$bootlog" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
    set_state status "nos - job"; QUEUED_MODE=0; STATE="job"; msg "NOS: job"
    date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
    stop_idle
  fi
}
bootstrap

while true; do
  logchunk="$(docker logs --since 10s nosana-node 2>&1 || true)"
  if [[ -n "$logchunk" ]]; then
    printf "%s\n" "$logchunk" | tee -a "$MINER_LOG"

    # QUEUED detection (fresh logs only)
    if echo "$logchunk" | grep -Eq 'position[[:space:]]+[0-9]+/[0-9]+'; then
      pos="$(echo "$logchunk" | grep -E 'position[[:space:]]+[0-9]+/[0-9]+' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/')"
      if [[ -n "$pos" && "$pos" != "$last_pos" ]]; then
        echo "[nosana] queued ${pos}" | tee -a "$MINER_LOG"; msg "NOS: queued ${pos}"
        last_pos="$pos"
      fi
      if [[ "$STATE" != "queued" ]]; then
        set_state status "nos - queued ${pos}"
        QUEUED_MODE=1; STATE="queued"
      fi
      start_idle
    elif echo "$logchunk" | grep -Eqi '\bQUEUED\b'; then
      if [[ "$STATE" != "queued" ]]; then
        set_state status "nos - queued"
        QUEUED_MODE=1; STATE="queued"
      fi
      start_idle
    fi

    # JOB start detection (fresh only)
    if echo "$logchunk" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
      if [[ "$STATE" != "job" ]]; then
        set_state status "nos - job"
        QUEUED_MODE=0; STATE="job"
        msg "NOS: job started"
        date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
        stop_idle
      fi
    fi

    # JOB finished (log only; do not affect idle/state to avoid flapping)
    if echo "$logchunk" | grep -Eq "Nosana Node finished|Job .* completed|finished successfully|Flow .* (finished|completed)"; then
      echo "[nosana] job finished" | tee -a "$MINER_LOG"
      msg "NOS: job finished"
    fi
  fi

  # Keep idle alive while queued
  if [[ "$QUEUED_MODE" -eq 1 ]]; then
    start_idle
  fi

  sleep 5
done
