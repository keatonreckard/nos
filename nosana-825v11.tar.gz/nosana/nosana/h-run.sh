#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"

# Hive live logs
MINER1="/run/hive/miner.1"   # nosana-node (CLI) logs
MINER2="/run/hive/miner.2"   # idle miner logs

mkdir -p "$RUN_DIR" "/run/hive"
: > "$MINER1" || true
: > "$MINER2" || true
touch "$STATE_FILE"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }
log() { echo "[$(date -Iseconds)] $*" >> "$MINER1"; }

set_state() {
  local key="$1" val="$2"
  local vesc="${val//\\/\\\\}"; vesc="${vesc//\"/\\\"}"
  awk -v k="$key" -v v="$vesc" '
    BEGIN{done=0}
    $0 ~ ("^"k"=") { print k"=\""v"\""; done=1; next }
    { print }
    END{ if(!done) print k"=\""v"\"" }
  ' "$STATE_FILE" > "$STATE_FILE.tmp" && mv "$STATE_FILE.tmp" "$STATE_FILE"
}

idle_running() { screen -ls 2>/dev/null | grep -q "\.nosana-idle"; }

# Read parsed idle configs if provided by h-config.sh
PARSED_DIR="$MINER_DIR/parsed"
IDLE_COMMAND="$(cat "$PARSED_DIR/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$PARSED_DIR/idle_args" 2>/dev/null || true)"

start_idle() {
  if [[ -n "${IDLE_COMMAND:-}" ]] && ! idle_running; then
    screen -dmS nosana-idle bash -lc "exec stdbuf -oL -eL ${IDLE_COMMAND} ${IDLE_ARGS} >> ${MINER2} 2>&1"
    msg "NOS: idle miner started"
  fi
}

kill_idle() {
  if idle_running; then
    screen -S nosana-idle -X quit || true
  fi
  if [[ -n "${IDLE_COMMAND:-}" ]]; then
    pkill -f -- "$IDLE_COMMAND" || true
  fi
  msg "NOS: idle miner killed"
}

# Clean up any old containers
log "h-run: cleaning previous containers"
docker rm -f nosana-node podman >/dev/null 2>&1 || true
pkill -9 -f "podman system service" 2>/dev/null || true
docker container prune -f >/dev/null 2>&1 || true

# Ensure volumes
docker volume inspect podman-cache >/dev/null 2>&1 || docker volume create podman-cache >/dev/null
docker volume inspect podman-socket >/dev/null 2>&1 || docker volume create podman-socket >/dev/null

log "h-run: starting podman sidecar"
docker rm -f podman >/dev/null 2>&1 || true
docker run -d --restart=unless-stopped --name podman \
  -v podman-cache:/var/lib/containers \
  -v podman-socket:/podman \
  nosana/podman:v1.1.0 unix:/podman/podman.sock >> "$MINER1" 2>&1 || true

# Wait up to 30s for sidecar socket to appear
sidecar_ready=0
for i in $(seq 1 30); do
  if docker exec podman sh -c 'test -S /podman/podman.sock' >/dev/null 2>&1; then
    sidecar_ready=1
    log "h-run: podman sidecar socket is up"
    break
  fi
  sleep 1
done
if [[ "$sidecar_ready" -ne 1 ]]; then
  log "h-run: WARNING - podman socket not ready after 30s"
  docker logs --tail=80 podman >> "$MINER1" 2>&1 || true
fi

# Start CLI container (podman provider by default)
log "h-run: starting nosana-node (podman provider)"
msg "NOS: node starting"
docker rm -f nosana-node >/dev/null 2>&1 || true
docker run -d --pull=always --name nosana-node --network host --gpus=all \
  -v /root/.nosana/:/root/.nosana/ \
  -v podman-socket:/root/.nosana/podman:ro \
  -e CLI_VERSION= \
  -e CONTAINER_HOST="unix:///root/.nosana/podman/podman.sock" \
  -e PODMAN_HOST="unix:///root/.nosana/podman/podman.sock" \
  nosana/nosana-cli:latest \
  node start --network "${SOL_NET_ENV:=mainnet}" >> "$MINER1" 2>&1 || true

sleep 3

# Check for podman provider error and fall back to docker provider
health_log="$(docker logs --since 3s nosana-node 2>&1 || true)"
if printf '%s\n' "$health_log" | grep -q "Provider is not healthy (podman)"; then
  log "h-run: podman provider unhealthy; switching to docker provider"
  docker rm -f nosana-node >/dev/null 2>&1 || true
  docker run -d --pull=always --name nosana-node --network host --gpus=all \
    -v /root/.nosana/:/root/.nosana/ \
    -v /var/run/docker.sock:/var/run/docker.sock:ro \
    -e CLI_VERSION= \
    -e CONTAINER_HOST="" \
    -e PODMAN_HOST="" \
    -e DOCKER_HOST="/var/run/docker.sock" \
    nosana/nosana-cli:latest \
    node start --network "${SOL_NET_ENV:=mainnet}" >> "$MINER1" 2>&1 || true
fi

# Follow final provider logs to miner.1
( docker logs -f nosana-node 2>&1 >> "$MINER1" ) &
LOG_FOLLOW_PID=$!

sleep 2
msg "NOS: node container launched"

# Initialize state
date +%s > "$MINER_DIR/nosana.start.time"
set_state status "nos - initializing"
msg "NOS: monitor started"

# Bootstrap
bootlog="$(docker logs --since 60m nosana-node 2>&1 || true)"
if printf '%s\n' "$bootlog" | grep -Eqi 'Node is claiming job|claimed job|Job .* started|Flow .* started|is running'; then
  set_state status "nos - job"
  kill_idle
  msg "NOS: job"
elif printf '%s\n' "$bootlog" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
  set_state status "nos - queued"
  start_idle
  msg "NOS: queued"
fi

# Monitor loop (5s polling)
while :; do
  logchunk="$(docker logs --since 10s nosana-node 2>&1 || true)"
  if [[ -n "$logchunk" ]]; then
    if echo "$logchunk" | grep -Eqi 'Node is claiming job|claimed job|Job .* started|Flow .* started|is running'; then
      set_state status "nos - job"
      kill_idle
      date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
      msg "NOS: job started"
    elif echo "$logchunk" | grep -Eqi 'Nosana Node finished|Job .* (completed|finished)|Flow .* (finished|completed)'; then
      msg "NOS: job finished"
    fi

    if echo "$logchunk" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
      set_state status "nos - queued"
      date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
      start_idle
      msg "NOS: queued"
    fi
  fi
  sleep 5
done
