#!/usr/bin/env bash
set -euo pipefail
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
CONF_FILE="$MINER_DIR/nosana.conf"
RAW_EXTRA_FILE="$MINER_DIR/extra.raw"
PARSED_DIR="$MINER_DIR/parsed"
KEY_FILE="/root/.nosana/nosana_key.json"

mkdir -p "$MINER_DIR" "$LOG_DIR" "$PARSED_DIR"
chmod 755 "$MINER_DIR"
touch "$LOG_DIR/nosana.log" "$LOG_DIR/debug.log" "$LOG_DIR/idle.log"

: "${CUSTOM_USER_CONFIG:=}"

# Store RAW extra config exactly as provided (no prefixes)
echo "$CUSTOM_USER_CONFIG" > "$CONF_FILE"
echo "$CUSTOM_USER_CONFIG" > "$RAW_EXTRA_FILE"

# Keypair extraction (best-effort)
KEYPAIR_JSON=""
if grep -q '"keypair"' "$RAW_EXTRA_FILE"; then
  KEYPAIR_JSON=$(sed -n 's/.*"keypair"[[:space:]]*:[[:space:]]*\(\[[^]]*\]\).*/\1/p' "$RAW_EXTRA_FILE" | head -n1)
fi

# Normalize to JSON object for parsing idleSettings
RAW="$CUSTOM_USER_CONFIG"
TRIMMED="$(echo "$RAW" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
if echo "$TRIMMED" | grep -q '"idleSettings"'; then
  if echo "$TRIMMED" | grep -q '^{'; then
    EXTRA_JSON="$TRIMMED"
  else
    EXTRA_JSON="{$TRIMMED}"
  fi
else
  EXTRA_JSON="{}"
fi

IDLE_COMMAND=$(echo "$EXTRA_JSON" | tr '\n' ' ' | sed -n 's/.*"idleSettings"[[:space:]]*:[[:space:]]*{[^}]*"command"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)
IDLE_ARGS=$(echo "$EXTRA_JSON" | tr '\n' ' ' | sed -n 's/.*"idleSettings"[[:space:]]*:[[:space:]]*{[^}]*"arguments"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)

echo "$IDLE_COMMAND" > "$PARSED_DIR/idle_command"
echo "$IDLE_ARGS"    > "$PARSED_DIR/idle_args"

mkdir -p /root/.nosana
chmod 700 /root/.nosana

if [[ -n "${KEYPAIR_JSON}" ]]; then
  if [[ ! -f "$KEY_FILE" ]]; then
    echo "$KEYPAIR_JSON" > "$KEY_FILE"
    chmod 600 "$KEY_FILE"
  fi
fi

cat > "$STATE_FILE" <<EOF
status="nos - initializing"
queue=""
sol=""
nos=""
wallet=""
idle_enabled="$( [[ -n "$IDLE_COMMAND" ]] && echo 1 || echo 0 )"
EOF
chmod 664 "$STATE_FILE"

{
  echo "[$(date -Iseconds)] h-config: RAW_EXTRA length=$(printf %s "$RAW" | wc -c)"
  echo "[$(date -Iseconds)] h-config: parsed idle command: $IDLE_COMMAND"
  echo "[$(date -Iseconds)] h-config: parsed idle args:    $IDLE_ARGS"
} >> "$LOG_DIR/debug.log"

date +%s > "$MINER_DIR/nosana.start.time"
exit 0
