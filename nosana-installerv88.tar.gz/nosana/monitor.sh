#!/usr/bin/env bash
# nosana monitor v88 (rollback style)
# - Print node logs raw (ANSI stripped) so all lines show (Network/Wallet/SOL/NOS/Provider)
# - Echo to stdout AND persist to /var/log/miner/nosana/nosana.log
# - Start idle miner on QUEUED; stop on job start/finish
# - No dedupe, no fancy filters

set -u
export LC_ALL=C

MINER_DIR="${MINER_DIR:-/hive/miners/custom/nosana}"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
MINER_LOG="$LOG_DIR/nosana.log"
DEBUG_LOG="$LOG_DIR/debug.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR" "$RUN_DIR" 2>/dev/null || true
# Do not nuke previous session log; Hive rotates on its own. Only start new section.
echo "[nosana] monitor started" | tee -a "$MINER_LOG"

# Helpers
idle_running() { screen -ls 2>/dev/null | grep -qE '\.nosana-idle'; }
start_idle() { if ! idle_running; then bash "$MINER_DIR/idle-run.sh" >>"$DEBUG_LOG" 2>&1 || true; fi; }
stop_idle()  { if  idle_running; then bash "$MINER_DIR/idle-kill.sh" >>"$DEBUG_LOG" 2>&1 || true; fi; }

strip_ansi() { sed -E 's/\x1B\[[0-9;]*[A-Za-z]//g; s/\r//g'; }

runtime=""
if command -v docker >/dev/null 2>&1; then
  runtime="docker"
elif command -v podman >/dev/null 2>&1; then
  runtime="podman"
fi

attach() {
  while true; do
    if [ -n "$runtime" ]; then
      $runtime logs -f --since 0s nosana-node 2>&1 || true
    else
      echo "[nosana-node] container runtime not found" 1>&2
    fi
    sleep 1
  done
}

# Stream, print, and react
attach | strip_ansi | while IFS= read -r line; do
  # prefix like older builds
  out="[nosana-node] ${line}"
  echo "$out" | tee -a "$MINER_LOG" >/dev/null

  case "$line" in
    *"QUEUED"*|*" In market "*position*)
      start_idle
      ;;
    *"Job "*started*|*" is running"*|*"Flow "*started*|*"Starting job"*|*"Executing"*"job"*)
      stop_idle
      ;;
    *"finished successfully"*|*"Job "*completed*|*"Flow "*finished*|*"Nosana Node finished"*)
      stop_idle
      ;;
  esac
done

# keep alive
while true; do sleep 60; done