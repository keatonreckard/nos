#!/usr/bin/env bash
screen -r nosana-idle || echo "Idle screen not running."

# v5.7: start queued idle watcher (standalone, safe)
nohup /hive/miners/custom/nosana/queued-trigger.sh >/dev/null 2>&1 &
