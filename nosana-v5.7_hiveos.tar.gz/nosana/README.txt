Nosana wrapper v3.1.18: ANSI-stripped sed parsing for wallet/balances; robust algo; docker logs fallback.


v5.7 changes:
- Restores node startup unchanged; adds standalone queued-trigger.sh launched from idle-screen.sh only.
- When QUEUED appears in nosana.log, starts idle immediately; kills idle ASAP on job start.
- Interleaves idle output into nosana.log and idle.log and posts HiveOS dashboard messages.
