#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
MINER_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
DEBUG_LOG="$LOG_DIR/debug.log"
IDLE_PID_FILE="$RUN_DIR/nosana-idle.pid"

mkdir -p "$LOG_DIR" "$RUN_DIR"; touch "$MINER_LOG" "$IDLE_LOG" "$DEBUG_LOG"

msg(){ [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

is_idle_running() {
  screen -ls 2>/dev/null | grep -q '\.nosana-idle'
}

resolve_idle_cmdline() {
  # Prefer parsed files written by h-config
  local cmd_file="$MINER_DIR/parsed/idle_command"
  local args_file="$MINER_DIR/parsed/idle_args"
  IDLE_CMDLINE=""
  if [[ -s "$cmd_file" ]]; then
    local c="$(cat "$cmd_file")"
    if [[ -s "$args_file" ]]; then
      IDLE_CMDLINE="$c $(cat "$args_file")"
    else
      IDLE_CMDLINE="$c"
    fi
  fi
  # As a fallback, accept an already-composed one-liner in idle_command
  if [[ -z "$IDLE_CMDLINE" && -s "$cmd_file" ]]; then
    IDLE_CMDLINE="$(cat "$cmd_file")"
  fi
}

start_idle() {
  resolve_idle_cmdline
  echo "[idle-trigger] start attempt (cmdline: ${IDLE_CMDLINE:-<empty>})" | tee -a "$DEBUG_LOG" >> "$MINER_LOG"
  msg "NOS: idle miner start attempt"
  if [[ -z "${IDLE_CMDLINE:-}" ]]; then
     echo "[idle-trigger] no command to run" | tee -a "$DEBUG_LOG" >> "$MINER_LOG"
     return 1
  fi
  if is_idle_running; then
     echo "[idle-trigger] already running" | tee -a "$DEBUG_LOG" >> "$MINER_LOG"
     return 0
  fi
  screen -dmS nosana-idle bash -lc '
    set -o pipefail
    '"$IDLE_CMDLINE"' 2>&1 | sed -u "s/^/[idle] /" | tee -a "'"$IDLE_LOG"'" >> "'"$MINER_LOG"'"
  '
  sleep 0.5
  if is_idle_running; then
    msg "NOS: idle miner started"
    echo "[idle-trigger] started OK" | tee -a "$DEBUG_LOG" >> "$MINER_LOG"
  else
    echo "[idle-trigger] failed to start (no screen session)" | tee -a "$DEBUG_LOG" >> "$MINER_LOG"
    return 1
  fi
}

kill_idle_fast() {
  # Fast, not clean
  (screen -ls | awk '/\.nosana-idle/ {print $1}' | xargs -r -n1 screen -S >/dev/null 2>&1 || true)
  pkill -9 -f nosana-idle || true
  pkill -9 -f qli-Client || true
  msg "NOS: idle miner killed"
  echo "[idle-trigger] idle killed" | tee -a "$DEBUG_LOG" >> "$MINER_LOG"
}

# Main watcher: follow miner log for state cues
tail -Fn0 "$MINER_LOG" | while IFS= read -r line; do
  if echo "$line" | grep -Eqi '(^|[[:space:]]|-)QUEUED|nos - queued|position[[:space:]]+[0-9]+/[0-9]+'; then
    start_idle || true
  fi
  if echo "$line" | grep -Eqi 'Node is claiming job|claimed job|Job .* started|Flow .* started|is running|job started'; then
    kill_idle_fast || true
  fi
done
