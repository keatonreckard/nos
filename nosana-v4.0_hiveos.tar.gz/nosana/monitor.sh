#!/usr/bin/env bash
set -uo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
DEBUG_LOG="$LOG_DIR/debug.log"
MINER_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR" "$RUN_DIR"
touch "$MINER_LOG" "$DEBUG_LOG" "$IDLE_LOG"

# Idle command and args (kept as-is: parsed by h-config.sh into these files)
IDLE_COMMAND="$(cat "$MINER_DIR/parsed/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$MINER_DIR/parsed/idle_args" 2>/dev/null || true)"

# Hive dashboard message passthrough (unchanged behavior)
msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

# Persist key=value status to STATE_FILE (unchanged behavior expected by stats)
set_state() {
  local key="$1" val="$2"
  local vesc="${val//\\/\\\\}"; vesc="${vesc//"/\\"}"
  mkdir -p "$(dirname "$STATE_FILE")"; touch "$STATE_FILE"
  awk -v k="$key" -v v="$vesc" '
    BEGIN{done=0}
    $0 ~ ("^"k"=") { print k"=""v"""; done=1; next }
    { print }
    END{ if(!done) print k"=""v""" }
  ' "$STATE_FILE" > "$STATE_FILE.tmp" && mv "$STATE_FILE.tmp" "$STATE_FILE"
}

# --- NEW: Interleave idle miner logs into main miner log (for MOTD/miner screen) ---
if [[ ! -f "$RUN_DIR/idle_tail.pid" ]] || ! kill -0 "$(cat "$RUN_DIR/idle_tail.pid" 2>/dev/null)" 2>/dev/null; then
  nohup bash -lc "tail -n0 -F '$IDLE_LOG' | sed -u 's/^/[idle] /' >> '$MINER_LOG'" >/dev/null 2>&1 &
  echo $! > "$RUN_DIR/idle_tail.pid"
fi

idle_running() { screen -ls | grep -q '\.nosana-idle'; }

start_idle() {
  [[ -z "$IDLE_COMMAND" ]] && return 0
  idle_running && return 0
  msg "NOS: idle miner starting"
  screen -dmS nosana-idle bash -lc "stdbuf -oL -eL $IDLE_COMMAND $IDLE_ARGS 2>&1 | tee -a '$IDLE_LOG'"
  echo "[nosana] idle miner started: $IDLE_COMMAND $IDLE_ARGS" | tee -a "$MINER_LOG"
  date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
}

stop_idle() {
  idle_running || return 0
  msg "NOS: idle miner stopping"
  screen -S nosana-idle -X quit || true
  echo "[nosana] idle miner stopped" | tee -a "$MINER_LOG"
  rm -f "$MINER_DIR/idle.start.time"
}

date +%s > "$MINER_DIR/nosana.start.time"
set_state status "nos - initializing"
echo "[nosana] monitor started" | tee -a "$MINER_LOG"; msg "NOS: monitor started"

bootstrap() {
  local bootlog
  bootlog="$(docker logs --since 60m nosana-node 2>&1 || true)"
  [[ -n "$bootlog" ]] && printf "%s\n" "$bootlog" | tee -a "$MINER_LOG"

  if printf '%s\n' "$bootlog" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
    set_state status "nos - queued"
    msg "NOS: queued"
    start_idle
  elif printf '%s\n' "$bootlog" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
    set_state status "nos - job"
    msg "NOS: job"
    date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
    stop_idle
  fi
}
bootstrap

last_pos=""
while true; do
  logchunk="$(docker logs --since 10s nosana-node 2>&1 || true)"
  if [[ -n "$logchunk" ]]; then
    printf "%s\n" "$logchunk" | tee -a "$MINER_LOG"

    if echo "$logchunk" | grep -Eq "position [0-9]+/[0-9]+"; then
      pos="$(echo "$logchunk" | grep -E 'position [0-9]+/[0-9]+' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/')"
      [[ -n "$pos" && "$pos" != "$last_pos" ]] && { echo "[nosana] queued ${pos}" | tee -a "$MINER_LOG"; msg "NOS: queued ${pos}"; last_pos="$pos"; }
      set_state status "nos - queued ${pos}"
      start_idle
    fi

    if echo "$logchunk" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
      set_state status "nos - job"
      msg "NOS: job started"
      date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
      stop_idle
    fi

    if echo "$logchunk" | grep -Eq "Nosana Node finished|Job .* completed|finished successfully|Flow .* (finished|completed)"; then
      echo "[nosana] job finished" | tee -a "$MINER_LOG"
      msg "NOS: job finished"
    fi
  fi
  sleep 5
done
