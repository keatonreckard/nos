#!/usr/bin/env bash
set -euo pipefail
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
DEBUG_LOG="$LOG_DIR/debug.log"
mkdir -p "$LOG_DIR"
touch "$LOG_DIR/nosana.log" "$DEBUG_LOG" "$LOG_DIR/idle.log"
# --- nosana node log tee cleanup (miner.1) ---
if [[ -f /run/hive/.nosana_node_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_node_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_node_tail.pid
fi
: > /run/hive/miner.1 || true
# ---------------------------------------------

# --- nosana idle cleanup: clear stale idle screen, tail, and motd feed ---
mkdir -p /run/hive || true
if screen -ls 2>/dev/null | grep -q '\.nosana-idle'; then
  screen -S nosana-idle -X quit || true
fi
if [[ -f /run/hive/.nosana_idle_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_idle_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_idle_tail.pid
fi
: > /run/hive/miner.2 || true
# ------------------------------------------------------------------------

nohup bash "$MINER_DIR/idle-tee.sh" "$LOG_DIR/idle.log" >/dev/null 2>&1 &
nohup stdbuf -oL tail -n +1 -F "$LOG_DIR/nosana.log" | stdbuf -oL grep -a -v -E '\[XMR\]|SHARES:|Trainer:|\srx/|qubic|QUBIC|AVX|CUDA' > /run/hive/miner.1 2>/dev/null & echo $! > /run/hive/.nosana_node_tail.pid
# --- nosana idle cleanup: clear stale idle screen, tail, and motd feed ---
mkdir -p /run/hive || true
if screen -ls 2>/dev/null | grep -q '\.nosana-idle'; then
  screen -S nosana-idle -X quit || true
fi
if [[ -f /run/hive/.nosana_idle_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_idle_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_idle_tail.pid
fi
: > /run/hive/miner.2 || true
# ------------------------------------------------------------------------


msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

echo "[$(date -Iseconds)] h-run: cleaning previous containers" | tee -a "$DEBUG_LOG"
docker rm -f nosana-node podman >/dev/null 2>&1 || true
pkill -9 -f "podman system service" 2>/dev/null || true
docker container prune -f >/dev/null 2>&1 || true

docker volume inspect podman-cache >/dev/null 2>&1 || docker volume create podman-cache >/dev/null
docker volume inspect podman-socket >/dev/null 2>&1 || docker volume create podman-socket >/dev/null

echo "[$(date -Iseconds)] h-run: starting podman sidecar" | tee -a "$DEBUG_LOG"
docker run -d --pull=always --gpus=all --name podman --device /dev/fuse \
  --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman --privileged -e ENABLE_GPU=true \
  nosana/podman:v1.1.0 unix:/podman/podman.sock >> "$DEBUG_LOG" 2>&1 || true
sleep 5

      # a49: Backend-aware Podman default-network MTU (fix unbound $MTU by quoting heredoc)
      MTU_VAL="${NOSANA_MTU:-1420}"

      docker exec -e MTU="$MTU_VAL" -i podman sh <<'EOF'
set -eu
backend="$(podman info --format "{{.Host.NetworkBackend}}" 2>/dev/null || echo netavark)"
echo "[sidecar] network backend: $backend"

if [ "$backend" = "netavark" ]; then
  mkdir -p /etc/containers/networks
  UUID="$(cat /proc/sys/kernel/random/uuid 2>/dev/null || true)"
  [ -n "$UUID" ] || UUID="00000000-0000-4000-8000-000000000000"
  cat >/etc/containers/networks/podman.json <<JSON
{
  "name": "podman",
  "id": "$UUID",
  "driver": "bridge",
  "network_interface": "podman0",
  "subnets": [{"subnet": "10.88.0.0/16", "gateway": "10.88.0.1"}],
  "ipv6_enabled": false,
  "dns_enabled": true,
  "internal": false,
  "options": { "mtu": "$MTU" }
}
JSON
  ip link set podman0 down 2>/dev/null || true
  ip link del podman0 2>/dev/null || true
  podman network reload podman >/dev/null 2>&1 || true
  echo "[sidecar] wrote /etc/containers/networks/podman.json with mtu=$MTU"

else
  mkdir -p /etc/cni/net.d
  cat >/etc/cni/net.d/87-podman-bridge.conflist <<JSON
{
  "cniVersion": "0.4.0",
  "name": "podman",
  "plugins": [
    {
      "type": "bridge",
      "bridge": "cni-podman0",
      "isGateway": true,
      "ipMasq": true,
      "hairpinMode": true,
      "mtu": $MTU,
      "ipam": {
        "type": "host-local",
        "routes": [{"dst":"0.0.0.0/0"}],
        "ranges": [[{"subnet":"10.88.0.0/16"}]]
      }
    },
    {"type":"portmap","capabilities":{"portMappings":true}},
    {"type":"firewall"}
  ]
}
JSON
  ip link show | awk "/cni-podman0|podman0/ {print \$2}" | sed "s/://" | while read -r ifc; do
    ip link set "$ifc" down 2>/dev/null || true
    ip link del "$ifc" 2>/dev/null || true
  done
  echo "[sidecar] wrote /etc/cni/net.d/87-podman-bridge.conflist with mtu=$MTU"
fi

echo "[sidecar] verify MTU via no-flag run:"
podman run --rm alpine sh -c "ip link show eth0 | grep mtu" || true
EOF

      # a49: record miner start for uptime=0
      date +%s > /run/hive/nosana.start_ts || true

echo "[$(date -Iseconds)] h-run: starting nosana-node container" | tee -a "$DEBUG_LOG"
msg "NOS: node starting"
docker run -d --pull=always --name nosana-node --network host --gpus=all \
  --volume /root/.nosana/:/root/.nosana/ \
  --volume podman-socket:/root/.nosana/podman:ro \
  nosana node start --network "${SOL_NET_ENV:=mainnet}" --podman /root/.nosana/podman/podman.sock >> "$DEBUG_LOG" 2>&1 || true
sleep 2
msg "NOS: node container launched"

exec bash "$MINER_DIR/monitor.sh"
