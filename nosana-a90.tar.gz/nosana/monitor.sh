\
    #!/usr/bin/env bash
    set -euo pipefail
    export LC_ALL=C
    export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    MINER_DIR="/hive/miners/custom/nosana"
    LOG_DIR="/var/log/miner/nosana"
    mkdir -p "$LOG_DIR" 2>/dev/null || true
    DEBUG_LOG="$LOG_DIR/debug.log"
    NOSANA_LOG="$LOG_DIR/nosana.log"

    msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }
    log(){ echo "[$(date -Iseconds)] $*" | tee -a "$DEBUG_LOG" >&2; }

    kill_idle(){
      # kill screen and any qli* processes
      screen -S nosana-idle -X quit 2>/dev/null || true
      pkill -9 -f 'qli-Client|qli-worker-AVX512|qli-worker-XMR|qli-worker-CUDA' 2>/dev/null || true
      msg "NOSANA: idle miner killed (job event)"
    }

    # Tail CLI logs and kill idle when job events appear
    if docker ps -q -f "name=^nosana-node$" | grep . >/dev/null; then
      log "[monitor] following nosana-node logs"
      docker logs -f nosana-node 2>&1 | awk '
        /Node has found job|has claimed job|Job .* is starting|Flow .* is starting|Flow .* started/ {print; fflush(); system("bash -lc '\''/hive/miners/custom/nosana/idle-kill.sh'\''"); next}
        {print; fflush()}
      ' | tee -a "$NOSANA_LOG"
    else
      log "[monitor] nosana-node not running"
    fi
