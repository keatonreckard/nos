\
    #!/usr/bin/env bash
    set -euo pipefail
    export LC_ALL=C
    export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

    MINER_DIR="/hive/miners/custom/nosana"
    LOG_DIR="/var/log/miner/nosana"
    PARSED_DIR="$MINER_DIR/parsed"
    mkdir -p "$LOG_DIR" "$PARSED_DIR" /var/log/miner 2>/dev/null || true

    DEBUG_LOG="$LOG_DIR/debug.log"
    NOSANA_LOG="$LOG_DIR/nosana.log"
    : > "$DEBUG_LOG" || true
    : > "$NOSANA_LOG" || true

    msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }
    log_std(){ echo "[$(date -Iseconds)] $*" | tee -a "$DEBUG_LOG" >&2; }
    log_err(){ echo "[$(date -Iseconds)] ERROR: $*" | tee -a "$DEBUG_LOG" >&2; }

    # ---- Launch Podman sidecar (GPU-enabled) ----
    ensure_sidecar(){
      if ! docker ps --format '{{.Names}}' | grep -qx podman; then
        log_std "[sidecar] starting nosana/podman:v1.1.0"
        docker volume inspect podman-cache >/dev/null 2>&1 || docker volume create podman-cache >/dev/null
        docker volume inspect podman-socket >/dev/null 2>&1 || docker volume create podman-socket >/dev/null
        docker run -d \
          --pull=always \
          --gpus=all \
          --name podman \
          --device /dev/fuse \
          --mount source=podman-cache,target=/var/lib/containers \
          --volume podman-socket:/podman \
          --privileged \
          -e ENABLE_GPU=true \
          nosana/podman:v1.1.0 unix:/podman/podman.sock >/dev/null
        sleep 5
      else
        log_std "[sidecar] podman already running"
      fi
    }

    # ---- Fix default 'podman' network MTU INSIDE sidecar ----
    fix_podman_default_mtu(){
      local mtu="${1:-1420}"
      log_std "[sidecar] set default network 'podman' MTU=${mtu}"
      docker exec podman sh -lc '
        set -e
        # create helper so we can move any existing containers off "podman"
        podman network rm -f mtuhelper >/dev/null 2>&1 || true
        podman network create --driver bridge -o mtu=1500 mtuhelper >/dev/null 2>&1 || true
        ids="$(podman ps --format "{{.ID}} {{.Names}} {{.Networks}}" | awk '\''$0 ~ /(^|[ ,])podman([ ,]|$)/ {print $1}'\'')" || true
        if [ -n "$ids" ]; then
          for c in $ids; do
            podman network connect mtuhelper "$c" || true
            podman network disconnect -f podman "$c" || true
          done
        fi
        podman network rm -f podman >/dev/null 2>&1 || true
        podman network create --driver bridge -o mtu='"${mtu}"' podman >/dev/null 2>&1
        if [ -n "$ids" ]; then
          for c in $ids; do
            podman network connect podman "$c" || true
            podman network disconnect -f mtuhelper "$c" || true
          done
        fi
        podman network rm -f mtuhelper >/dev/null 2>&1 || true
        podman run --rm docker.io/alpine cat /sys/class/net/eth0/mtu 2>/dev/null || true
      ' | tee -a "$DEBUG_LOG" || true
    }

    # ---- Start Nosana CLI (pre-release) ----
    start_nosana_node(){
      local name="nosana-node"
      # cleanup stale
      if docker ps -aq -f "name=^${name}$" >/dev/null | grep . >/dev/null 2>&1; then
        docker rm -f "${name}" >/dev/null 2>&1 || true
      fi
      mkdir -p /root/.nosana 2>/dev/null || true
      log_std "[node] starting Nosana CLI (pre-release)"
      docker run -d \
        --pull=always \
        --name "${name}" \
        --interactive -t \
        --volume /root/.nosana/:/root/.nosana/ \
        --volume podman-socket:/root/.nosana/podman:ro \
        -e CLI_VERSION=next \
        nosana/nosana-cli:latest node start --podman /root/.nosana/podman/podman.sock --network mainnet >/dev/null
      sleep 2
      docker ps --format '{{.ID}} {{.Image}} {{.Names}}' | grep "${name}" | tee -a "$DEBUG_LOG" || true
    }

    # ---- MAIN ----
    log_std "h-run: cleaning previous containers"
    docker rm -f nosana-node >/dev/null 2>&1 || true

    ensure_sidecar
    fix_podman_default_mtu "${NOSANA_MTU:-1420}"
    start_nosana_node

    # kick-off monitor (non-blocking)
    nohup bash "$MINER_DIR/monitor.sh" >>"$DEBUG_LOG" 2>&1 & disown || true
    msg "NOSANA: node started (pre-release) with MTU ${NOSANA_MTU:-1420}"
    exit 0
