#!/usr/bin/env bash
set -euo pipefail

CUSTOM_LOG_BASENAME="${CUSTOM_LOG_BASENAME:-nosana}"
LOG_DIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
MINER_DIR="/hive/miners/custom/nosana"
PARSED_DIR="$MINER_DIR/parsed"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
IDLE_PID="$RUN_DIR/idle.pid"
TAIL_PID="$RUN_DIR/idle.tail.pid"

mkdir -p "$LOG_DIR" "$PARSED_DIR" "$RUN_DIR"

echo "[nosana] monitor started" | tee -a "$LOG_DIR/nosana.log" >/dev/null

read_file() { [[ -f "$1" ]] && cat "$1" || echo ""; }

idle_cmd="$(read_file "$PARSED_DIR/idle_command")"
idle_args="$(read_file "$PARSED_DIR/idle_args")"

log() { printf "[%s] monitor: %s\n" "$(date -Iseconds)" "$*" | tee -a "$LOG_DIR/debug.log" >/dev/null; }

is_idle_running() {
  [[ -f "$IDLE_PID" ]] || return 1
  local p; p="$(cat "$IDLE_PID" 2>/dev/null || true)"
  [[ -n "$p" && -d "/proc/$p" ]] && return 0 || return 1
}

start_idle_tail() {
  [[ -f "$TAIL_PID" ]] && kill "$(cat "$TAIL_PID")" >/dev/null 2>&1 || true
  ( tail -n 25 -F "$IDLE_LOG" 2>/dev/null | sed -u 's/^/[idle] /' >> "$LOG_DIR/nosana.log" & echo $! > "$TAIL_PID" )
}

start_idle() {
  if is_idle_running; then
    return 0
  fi
  if [[ -z "$idle_cmd" ]]; then
    log "start_idle: idle command not configured"
    return 1
  fi
  log "start_idle hook (cmd:'$idle_cmd' args:'$idle_args')"
  echo "[nosana] attempting to start idle miner" | tee -a "$LOG_DIR/nosana.log" >/dev/null
  nohup bash -lc "$idle_cmd $idle_args" >> "$IDLE_LOG" 2>&1 & echo $! > "$IDLE_PID"
  date +%s > "$MINER_DIR/idle.start.time"
  start_idle_tail
  # Save state
  { echo "idle_enabled=1"; } > "$STATE_FILE".tmp
  [[ -f "$STATE_FILE" ]] && cat "$STATE_FILE" >> "$STATE_FILE".tmp || true
  mv -f "$STATE_FILE".tmp "$STATE_FILE"
}

stop_idle() {
  if is_idle_running; then
    log "stop_idle"
    kill "$(cat "$IDLE_PID")" >/dev/null 2>&1 || true
    rm -f "$IDLE_PID"
  fi
  [[ -f "$TAIL_PID" ]] && kill "$(cat "$TAIL_PID")" >/dev/null 2>&1 || true
  rm -f "$TAIL_PID"
  { echo "idle_enabled=0"; } > "$STATE_FILE".tmp
  [[ -f "$STATE_FILE" ]] && cat "$STATE_FILE" >> "$STATE_FILE".tmp || true
  mv -f "$STATE_FILE".tmp "$STATE_FILE"
}

# Parse a log chunk and react
process_chunk() {
  local logchunk="$1"
  # Queue detection
  if echo "$logchunk" | grep -Eqi 'QUEUED|position[[:space:]]+[0-9]+/[0-9]+'; then
    local pos=""
    pos="$(echo "$logchunk" | grep -E 'position[[:space:]]+[0-9]+/[0-9]+' | tail -n1 | sed -n 's/.*position[[:space:]]\([0-9]\+\/[0-9]\+\).*/\1/p')" || true
    if [[ -n "$pos" ]]; then
      echo "[nosana] queued ${pos}" | tee -a "$LOG_DIR/nosana.log" >/dev/null
    else
      echo "[nosana] queued" | tee -a "$LOG_DIR/nosana.log" >/dev/null
    fi
    start_idle
    return
  fi

  # Job started
  if echo "$logchunk" | grep -Eqi 'claimed job|started successfully|Flow .* is running'; then
    echo "[nosana] job started" | tee -a "$LOG_DIR/nosana.log" >/dev/null
    date +%s > "$MINER_DIR/job.start.time"
    stop_idle
    return
  fi

  # Node restart / shutdown
  if echo "$logchunk" | grep -Eqi 'Node shutdown successfully|Node has restarted successfully'; then
    echo "[nosana] node lifecycle event" | tee -a "$LOG_DIR/nosana.log" >/dev/null
  fi
}

# Monitor loop
touch "$NOSANA_LOG"
tail -n 0 -F "$NOSANA_LOG" 2>/dev/null | while IFS= read -r line; do
  printf "%s\n" "$line" >> "$LOG_DIR/debug.log"
  process_chunk "$line"
done &

# Also trigger once on current content to catch queued state on startup
if [[ -s "$NOSANA_LOG" ]]; then
  process_chunk "$(tail -n 200 "$NOSANA_LOG")"
fi
