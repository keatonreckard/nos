#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
PARSED_DIR="$MINER_DIR/parsed"
LOG_DIR="/var/log/miner/nosana"
mkdir -p "$PARSED_DIR" "$LOG_DIR"

RAW_EXTRA="${RAW_EXTRA:-}"
CONF_FILE="$MINER_DIR/nosana.conf"

# prefer RAW_EXTRA (Hive dashboard "Extra config arguments"), fallback to nosana.conf
SRC="$RAW_EXTRA"
if [[ -z "$SRC" && -s "$CONF_FILE" ]]; then
  SRC="$(cat "$CONF_FILE")"
fi

# Extract idleSettings.command and idleSettings.arguments from JSON-like content
# We don't assume perfect JSON; make flexible with grep/sed.
idle_cmd=""
idle_args=""

if [[ -n "$SRC" ]]; then
  # pull the block for idleSettings{...}
  blk="$(echo "$SRC" | tr -d '\r' | sed -n 's/.*"idleSettings"[[:space:]]*:[[:space:]]*{//p; s/.*"idleSettings"[[:space:]]*:[[:space:]]*{/{/p;')"
  if [[ -z "$blk" ]]; then
    blk="$(echo "$SRC" | sed -n 's/.*idleSettings[[:space:]]*:[[:space:]]*{//p; s/.*idleSettings[[:space:]]*:[[:space:]]*{/{/p;')"
  fi
  # Extract command
  idle_cmd="$(echo "$SRC" | grep -Eo '"command"[[:space:]]*:[[:space:]]*"[^"]+"' | head -n1 | sed -E 's/.*"command"[[:space:]]*:[[:space:]]*"([^"]*)".*/\1/')"
  idle_args="$(echo "$SRC" | grep -Eo '"arguments"[[:space:]]*:[[:space:]]*"[^"]*"' | head -n1 | sed -E 's/.*"arguments"[[:space:]]*:[[:space:]]*"([^"]*)".*/\1/')"
fi

# Write parsed results
mkdir -p "$MINER_DIR/parsed"
echo "${idle_cmd}"  > "$MINER_DIR/parsed/idle_command"
echo "${idle_args}" > "$MINER_DIR/parsed/idle_args"

echo "[$(date -Iseconds)] h-config: RAW_EXTRA length=${#RAW_EXTRA}"
echo "[$(date -Iseconds)] h-config: parsed idle command: ${idle_cmd}"
echo "[$(date -Iseconds)] h-config: parsed idle args: ${idle_args}"
