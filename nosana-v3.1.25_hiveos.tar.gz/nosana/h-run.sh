#!/usr/bin/env bash
set -euo pipefail

CUSTOM_LOG_BASENAME="${CUSTOM_LOG_BASENAME:-nosana}"
LOG_DIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
MINER_DIR="/hive/miners/custom/nosana"
PARSED_DIR="$MINER_DIR/parsed"
mkdir -p "$LOG_DIR" "$PARSED_DIR" "$RUN_DIR"

NOSANA_NS="nosana"
PODMAN_SOCK_DIR="/root/.nosana/podman"
PODMAN_SOCK_PATH="$PODMAN_SOCK_DIR/podman.sock"
SIDE_C_NAME="nosana_podman"
NODE_C_NAME="nosana_node"

log() { printf "[%s] %s\n" "$(date -Iseconds)" "$*" | tee -a "$LOG_DIR/debug.log"; }

# Clean any old containers
clean_containers() {
  for tool in docker nerdctl; do
    if command -v "$tool" >/dev/null 2>&1; then
      $tool rm -f "$SIDE_C_NAME" "$NODE_C_NAME" >/dev/null 2>&1 || true
      return 0
    fi
  done
  return 0
}

start_sidecar() {
  mkdir -p "$PODMAN_SOCK_DIR"
  for tool in docker nerdctl; do
    if command -v "$tool" >/dev/null 2>&1; then
      log "h-run: starting podman sidecar"
      $tool run -d --restart=unless-stopped --privileged \
        --name "$SIDE_C_NAME" \
        -v "$PODMAN_SOCK_DIR:/run/podman" \
        nosana/podman:v1.1.0 >/dev/null
      # wait for socket
      for i in $(seq 1 30); do
        [[ -S "$PODMAN_SOCK_PATH" ]] && return 0
        sleep 1
      done
      log "ERROR: podman.sock not created at $PODMAN_SOCK_PATH"
      return 1
    fi
  done
  log "ERROR: neither docker nor nerdctl found"
  return 1
}

start_node() {
  for tool in docker nerdctl; do
    if command -v "$tool" >/dev/null 2>&1; then
      log "h-run: starting nosana-node container"
      $tool run -d --restart=unless-stopped --name "$NODE_C_NAME" \
        --network host \
        -v /root/.nosana:/root/.nosana \
        -v "$PODMAN_SOCK_DIR:$PODMAN_SOCK_DIR" \
        -e NOSANA_PROVIDER="podman" \
        nosana/nosana-cli:latest >/dev/null

      # stream logs to file
      ( $tool logs -f "$NODE_C_NAME" >> "$LOG_DIR/nosana.log" 2>&1 & echo $! > "$RUN_DIR/nosana.logs.pid" )
      return 0
    fi
  done
  log "ERROR: neither docker nor nerdctl found to start nosana node"
  return 1
}

# main
log "h-run: cleaning previous containers"
clean_containers || true
start_sidecar
start_node

# record start time for stats
date +%s > "$MINER_DIR/nosana.start.time"

# launch monitor (safe to relaunch; it self-deduplicates using PID file)
bash "$MINER_DIR/monitor.sh" >/dev/null 2>&1 & disown || true
