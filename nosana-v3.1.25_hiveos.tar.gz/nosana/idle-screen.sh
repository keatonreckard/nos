#!/usr/bin/env bash
set -euo pipefail
CUSTOM_LOG_BASENAME="${CUSTOM_LOG_BASENAME:-nosana}"
LOG_DIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
IDLE_LOG="$LOG_DIR/idle.log"
exec tail -n 100 -F "$IDLE_LOG"
