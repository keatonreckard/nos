Nosana HiveOS Integration (v3.1.25)

Changes in 3.1.25
- Fix: $CUSTOM_LOG_BASENAME undefined — now defaults to 'nosana'.
- Fix: Reliable podman sidecar via docker/nerdctl with socket wait before node start.
- Fix: Idle miner auto start/stop when queue state changes; idle log mirrored into main nosana log.
- Fix: Wallet/SOL/NOS parsing from CLI logs; version string updated live.
- Behavior: When QUEUED, hashrate is passthrough from idle miner; if none found, reports 999 kH/s on dashboard.
- Messages: Queue state changes and lifecycle events echoed to miner log/agent-screen.
- No breaking changes to previous config format (idleSettings).

Files:
- h-manifest.conf : version + meta
- h-run.sh        : starts podman sidecar and nosana node; invokes monitor
- h-config.sh     : parses idleSettings from extra config or nosana.conf
- h-stats.sh      : builds stats JSON; parses wallet/balances; passes idle hashrate
- monitor.sh      : watches nosana log, manages idle miner, mirrors idle log
- idle-screen.sh  : helper to attach to idle miner output
- nosana.conf     : user config (optional), same folder

Logs:
- /var/log/miner/nosana/nosana.log (Nosana CLI log)
- /var/log/miner/nosana/idle.log   (Idle miner log)
- /var/log/miner/nosana/debug.log  (debug from scripts)

