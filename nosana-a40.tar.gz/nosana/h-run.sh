#!/usr/bin/env bash
set -euo pipefail
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
DEBUG_LOG="$LOG_DIR/debug.log"
mkdir -p "$LOG_DIR"
touch "$LOG_DIR/nosana.log" "$DEBUG_LOG" "$LOG_DIR/idle.log"
# --- nosana node log tee cleanup (miner.1) ---
if [[ -f /run/hive/.nosana_node_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_node_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_node_tail.pid
fi
: > /run/hive/miner.1 || true
# ---------------------------------------------

# --- nosana idle cleanup: clear stale idle screen, tail, and motd feed ---
mkdir -p /run/hive || true
if screen -ls 2>/dev/null | grep -q '\.nosana-idle'; then
  screen -S nosana-idle -X quit || true
fi
if [[ -f /run/hive/.nosana_idle_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_idle_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_idle_tail.pid
fi
: > /run/hive/miner.2 || true
# ------------------------------------------------------------------------

nohup bash "$MINER_DIR/idle-tee.sh" "$LOG_DIR/idle.log" >/dev/null 2>&1 &
nohup stdbuf -oL tail -n +1 -F "$LOG_DIR/nosana.log" | stdbuf -oL grep -a -v -E '\[XMR\]|SHARES:|Trainer:|\srx/|qubic|QUBIC|AVX|CUDA' > /run/hive/miner.1 2>/dev/null & echo $! > /run/hive/.nosana_node_tail.pid
# --- nosana idle cleanup: clear stale idle screen, tail, and motd feed ---
mkdir -p /run/hive || true
if screen -ls 2>/dev/null | grep -q '\.nosana-idle'; then
  screen -S nosana-idle -X quit || true
fi
if [[ -f /run/hive/.nosana_idle_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_idle_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_idle_tail.pid
fi
: > /run/hive/miner.2 || true
# ------------------------------------------------------------------------


msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

echo "[$(date -Iseconds)] h-run: cleaning previous containers" | tee -a "$DEBUG_LOG"
docker rm -f nosana-node podman >/dev/null 2>&1 || true
pkill -9 -f "podman system service" 2>/dev/null || true
docker container prune -f >/dev/null 2>&1 || true

docker volume inspect podman-cache >/dev/null 2>&1 || docker volume create podman-cache >/dev/null
docker volume inspect podman-socket >/dev/null 2>&1 || docker volume create podman-socket >/dev/null

echo "[$(date -Iseconds)] h-run: starting podman sidecar" | tee -a "$DEBUG_LOG"
docker run -d --pull=always --gpus=all --name podman --device /dev/fuse \
  --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman --privileged -e ENABLE_GPU=true \
  nosana/podman:v1.1.0 unix:/podman/podman.sock >> "$DEBUG_LOG" 2>&1 || true
sleep 5

      # Enforce MTU and inject Podman network automatically for all jobs (wrapper approach)
      MTU_VAL="${NOSANA_MTU:-1420}"
      NET_VAL="${NOSANA_MTU_NET:-lowmtu}"

      docker exec -e NET="$NET_VAL" -e MTU="$MTU_VAL" -i podman sh <<'POD'
set -eu

# 1) Ensure the network exists with the requested MTU
if podman network inspect "$NET" >/dev/null 2>&1; then
  CUR="$(podman network inspect "$NET" | awk -F\" '/"mtu":/ {print $4; exit}' || true)"
  if [ "${CUR:-}" != "$MTU" ] && [ -n "$MTU" ]; then
    podman network rm -f "$NET" >/dev/null 2>&1 || true
    podman network create --driver bridge -o mtu="$MTU" "$NET"
    echo "[sidecar] recreated network $NET with MTU=$MTU"
  else
    echo "[sidecar] network $NET already at MTU=${CUR:-unknown}"
  fi
else
  podman network create --driver bridge -o mtu="$MTU" "$NET"
  echo "[sidecar] created network $NET with MTU=$MTU"
fi

# 2) Install a tiny wrapper that injects --network $NET for any "podman run" missing a network/pod flag
if [ -x /usr/bin/podman ] && [ ! -e /usr/bin/podman.real ]; then
  cp -f /usr/bin/podman /usr/bin/podman.real || true
fi

cat >/usr/local/bin/podman <<'WRAP'
#!/bin/sh
REAL=/usr/bin/podman.real
[ -x "$REAL" ] || REAL=/usr/libexec/podman
CONF_NET="${PODMAN_FORCE_NETWORK:-__NET__}"
CONF_MTU="${PODMAN_FORCE_MTU:-__MTU__}"

# ensure network exists (best-effort)
"$REAL" network inspect "$CONF_NET" >/dev/null 2>&1 || "$REAL" network create --driver bridge -o mtu="$CONF_MTU" "$CONF_NET" >/dev/null 2>&1 || true

need_net=1
for a in "$@"; do
  case "$a" in
    --net=*|--network=*|--net|--network|--pod=*|-p) need_net=0 ;;
  esac
done

if [ "${1-}" = "run" ] && [ "$need_net" -eq 1 ]; then
  exec "$REAL" "$@" --network "$CONF_NET"
else
  exec "$REAL" "$@"
fi
WRAP
chmod +x /usr/local/bin/podman
ln -sf /usr/local/bin/podman /usr/bin/podman

# 3) Quick verification (no --network flag)
podman run --rm alpine sh -c "ip link show eth0 | grep mtu" || true
POD

echo "[$(date -Iseconds)] h-run: starting nosana-node container" | tee -a "$DEBUG_LOG"
msg "NOS: node starting"
docker run -d --pull=always --name nosana-node --network host --gpus=all \
  --volume /root/.nosana/:/root/.nosana/ \
  --volume podman-socket:/root/.nosana/podman:ro \
  -e CLI_VERSION= nosana/nosana-cli:latest \
  node start --network "${SOL_NET_ENV:=mainnet}" >> "$DEBUG_LOG" 2>&1 || true
sleep 2
msg "NOS: node container launched"

exec bash "$MINER_DIR/monitor.sh"
