NOSANA (HiveOS custom miner package)
-----------------------------------
Built: 2025-08-21T17:21:23

v8.1.3_hiveos:
- idle-run.sh now sanitizes parsed files to survive accidental garbage:
  * first token treated as command; any extra tokens appended to args
  * trims CRs/newlines; collapses whitespace
  * truncates noise like "root@host", "grep/tail/cat ..." if accidentally appended
  * verifies command existence before launching
- No changes to stats/algo/version logic or idle detection (monitor.sh).
