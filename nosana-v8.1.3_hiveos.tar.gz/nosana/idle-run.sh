#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="${MINER_DIR:-/hive/miners/custom/nosana}"
LOG_DIR="${LOG_DIR:-/var/log/miner/nosana}"
RUN_DIR="${RUN_DIR:-/var/run}"
PARSED_DIR="${PARSED_DIR:-$MINER_DIR/parsed}"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR" "$PARSED_DIR"

# --- read & sanitize command/args from parsed files ---
raw_cmd="$(head -n1 "$PARSED_DIR/idle_command" 2>/dev/null || true)"
raw_args="$(cat "$PARSED_DIR/idle_args" 2>/dev/null || true)"
# strip CR and collapse whitespace/newlines
raw_cmd="$(printf "%s" "$raw_cmd" | tr -d '\r' | sed -E 's/^[[:space:]]+//; s/[[:space:]]+$//; s/[[:space:]]+/ /g')"
raw_args="$(printf "%s" "$raw_args" | tr -d '\r' | tr '\n' ' ' | sed -E 's/[[:space:]]+/ /g; s/^[[:space:]]+//; s/[[:space:]]+$//')"

# if raw_cmd contains inline args, split first token as command, rest into args
inline_args=""
if [[ "$raw_cmd" == *" "* ]]; then
  inline_args="${raw_cmd#* }"
  raw_cmd="${raw_cmd%% *}"
fi

# guard against accidental terminal fragments (best-effort)
# cut at tokens that look like a shell prompt or stray commands accidentally appended
cut_noise() {
  # cut the string at first occurrence of markers
  local s="$1"
  s="$(printf "%s" "$s" | sed -E 's/(^|[[:space:]])root@[[:alnum:]\.\-_:]+.*$//')"
  s="$(printf "%s" "$s" | sed -E 's/(^|[[:space:]])(grep|tail|cat)[[:space:]].*$//')"
  printf "%s" "$s" | sed -E 's/[[:space:]]+$//'
}
inline_args="$(cut_noise "$inline_args")"
raw_args="$(cut_noise "$raw_args")"

cmd="$raw_cmd"
args="$inline_args"
[[ -n "${args// }" && -n "${raw_args// }" ]] && args="$args $raw_args" || args="${args:-$raw_args}"

# empty? bail quietly
if [[ -z "${cmd// }" ]]; then
  echo "idle-run: no command configured" >> "$IDLE_LOG"
  exit 0
fi

# verify command exists
if command -v "$cmd" >/dev/null 2>&1; then
  true
elif [[ -x "$cmd" ]]; then
  true
else
  echo "idle-run: command not found or not executable: $cmd" >> "$IDLE_LOG"
  exit 0
fi

# prevent duplicate session
if screen -ls 2>/dev/null | grep -q "\.nosana-idle"; then
  echo "idle-run: nosana-idle already running" >> "$IDLE_LOG"
  exit 0
fi

# launcher
launcher="$MINER_DIR/.idle_exec.sh"
cat > "$launcher" <<'LAUNCH'
#!/usr/bin/env bash
set -euo pipefail
exec bash -lc "$NOSANA_IDLE_CMD $NOSANA_IDLE_ARGS"
LAUNCH
chmod 755 "$launcher"
export NOSANA_IDLE_CMD="$cmd"
export NOSANA_IDLE_ARGS="$args"

echo "idle-run: launching: $cmd $args" >> "$IDLE_LOG"
screen -dmS nosana-idle env -i HOME="$HOME" PATH="$PATH" SHELL="/bin/bash" TERM=xterm-256color \
  MINER_DIR="$MINER_DIR" LOG_DIR="$LOG_DIR" "$launcher" >>"$IDLE_LOG" 2>&1 || true
