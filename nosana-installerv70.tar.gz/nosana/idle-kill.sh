#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
LOG_DIR="/var/log/miner/nosana"
DEBUG_LOG="$LOG_DIR/debug.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
mkdir -p "$LOG_DIR"; touch "$DEBUG_LOG" "$NOSANA_LOG"
msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

rc=0
if screen -ls 2>/dev/null | grep -q "${IDLE_SCREEN:-miner2}"; then
  screen -S "${IDLE_SCREEN:-miner2}" -X quit || true
fi

# Also SIGKILL any leftover idle process by screen child (best effort)
pkill -9 -f "\[idle\]" 2>/dev/null || rc=$?

echo "[$(date -Iseconds)] idle-kill: idle miner killed" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
msg "NOS: idle miner killed"
exit 0
