#!/usr/bin/env bash
# Attach to the existing idle miner screen session *only*.
set -euo pipefail
export LC_ALL=C
if screen -ls 2>/dev/null | grep -q "\.${IDLE_SCREEN:-miner2}"; then
  exec screen -r "${IDLE_SCREEN:-miner2}"
else
  echo "${IDLE_SCREEN:-miner2} is not running. (No attach)"
  echo "Check logs: /var/log/miner/nosana/idle.log and nosana.log"
  exit 1
fi
