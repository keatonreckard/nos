#!/usr/bin/env bash
set -euo pipefail
: "${CUSTOM_LOG_BASENAME:=nosana}"
MINER_DIR="/hive/miners/custom/${CUSTOM_LOG_BASENAME}"
LOG_DIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
DEBUG_LOG="${LOG_DIR}/debug.log"
PARSED_DIR="${MINER_DIR}/parsed"
mkdir -p "${LOG_DIR}" "${PARSED_DIR}"

log(){ printf "[%s] h-config: %s\n" "$(date -Iseconds)" "$*" | tee -a "${DEBUG_LOG}"; }

RAW="${CUSTOM_USERCONF:+$CUSTOM_USERCONF}"
RAW_EXTRA="${CUSTOM_MINER_CONFIG:+$CUSTOM_MINER_CONFIG}"
log "RAW_EXTRA length=${#RAW_EXTRA}"

# Extract idleSettings JSON (very permissive)
idle_cmd=""; idle_args=""
if echo "${RAW_EXTRA}" | grep -q '"idleSettings"'; then
  # command
  idle_cmd="$(echo "${RAW_EXTRA}" | sed -nE 's/.*"idleSettings"\s*:\s*\{[^}]*"command"\s*:\s*"([^"]+)".*/\1/p' | tail -n1)"
  # arguments
  idle_args="$(echo "${RAW_EXTRA}" | sed -nE 's/.*"idleSettings"\s*:\s*\{[^}]*"arguments"\s*:\s*"([^"]+)".*/\1/p' | tail -n1)"
  # Expand %WORKER_NAME%
  idle_args="${idle_args//%WORKER_NAME%/${WORKER_NAME:-worker}}"
  log "parsed idle command: ${idle_cmd}"
  log "parsed idle args: ${idle_args}"
  echo "${idle_cmd}" > "${PARSED_DIR}/idle_command"
  echo "${idle_args}" > "${PARSED_DIR}/idle_args"
fi
