nosana wrapper 0.2.9


Version: 3.1.36
- Reverted to docker-run podman sidecar and 'node run'
- Idle miner auto-start while queued, auto-stop on job
- Version string shows SOL/NOS/Wallet
