    #!/usr/bin/env bash
    set -euo pipefail
    : "${CUSTOM_LOG_BASENAME:=nosana}"

    MINER_DIR="/hive/miners/custom/${CUSTOM_LOG_BASENAME}"
    RUN_DIR="/var/run"
    STATE_FILE="${RUN_DIR}/${CUSTOM_LOG_BASENAME}.state"
    LOG_DIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
    IDLE_LOG="${LOG_DIR}/idle.log"
    NOSANA_LOG="${LOG_DIR}/nosana.log"

    mkdir -p "${LOG_DIR}" "${RUN_DIR}"

    status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""; idle_enabled=0
    [[ -f "${STATE_FILE}" ]] && source "${STATE_FILE}" || true

    scrape_logs(){
      [[ -s "${NOSANA_LOG}" ]] || return 0
      local L
      L="$(tail -n 1000 "${NOSANA_LOG}")"

      # Wallet
      if [[ -z "${wallet:-}" ]]; then
        wallet="$(echo "${L}" | sed -nE 's/^Wallet:[[:space:]]*([A-Za-z0-9]{32,60}).*/\1/p' | tail -n1)"
      fi

      # SOL
      if [[ -z "${sol:-}" ]]; then
        sol="$(echo "${L}" | sed -nE 's/^SOL balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
      fi

      # NOS
      if [[ -z "${nos:-}" ]]; then
        nos="$(echo "${L}" | sed -nE 's/^NOS balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
      fi

      # Queue
      if echo "${L}" | grep -Eq 'QUEUED.*position[[:space:]]+[0-9]+/[0-9]+'; then
        qpos="$(echo "${L}" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
        [[ -n "${qpos}" ]] && status="nos - queued ${qpos}"
      elif echo "${L}" | grep -Eqi 'Job .* started|Flow .* running|Node has claimed job'; then
        status="nos - job"
      fi
    }
    scrape_logs

    format4() { awk -v n="${1:-}" 'BEGIN{ if (n=="" || n=="N/A") print "N/A"; else printf("%.4f", n+0) }'; }
    shorten_wallet(){ local w="${1:-}"; [[ -n "${w}" ]] && printf "%s" "${w}" | cut -c1-5 || echo "N/A"; }

    # GPU info (best-effort)
    temp_json='[]'; fan_json='[]'; bus_json='[]'
    if [[ -f /hive/bin/gpu-stats ]]; then
      # shellcheck disable=SC1091
      source /hive/bin/gpu-stats || true
      if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
      if [[ "${#GPU_FAN[@]:-0}"  -gt 0 ]]; then fan_json ="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
      if [[ "${#BUS_IDS[@]:-0}"  -gt 0 ]]; then
        bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
        bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
      fi
    fi

    # Uptime
    now=$(date +%s)
    if [[ -f "${MINER_DIR}/job.start.time" ]]; then start_time=$(cat "${MINER_DIR}/job.start.time")
    elif [[ -f "${MINER_DIR}/idle.start.time" ]]; then start_time=$(cat "${MINER_DIR}/idle.start.time")
    elif [[ -f "${MINER_DIR}/nosana.start.time" ]]; then start_time=$(cat "${MINER_DIR}/nosana.start.time")
    else start_time=$((now - $(awk '{print int($1)}' /proc/uptime)))
    fi
    uptime=$((now - start_time)); ((uptime<0)) && uptime=0

    # Idle passthrough khs if queued
    parse_idle(){
      [[ -s "${IDLE_LOG}" ]] || { echo "0|0|0"; return; }
      local L hs khs unit acc=0 rej=0
      L="$(tail -n 400 "${IDLE_LOG}")"
      hs="$(echo "${L}" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1)"
      if [[ -n "${hs}" ]]; then
        val="$(echo "${hs}" | awk '{print $1}')"
        unit="$(echo "${hs}" | awk '{print $2}' | tr '[:lower:]' '[:upper:]' | sed 's#/S##')"
        case "${unit}" in
          H)  khs=$(awk -v v="${val}" 'BEGIN{printf("%.6f", v/1000)}');;
          KH) khs=$(awk -v v="${val}" 'BEGIN{printf("%.6f", v)}');;
          MH) khs=$(awk -v v="${val}" 'BEGIN{printf("%.6f", v*1000)}');;
          GH) khs=$(awk -v v="${val}" 'BEGIN{printf("%.6f", v*1000*1000)}');;
          *)  khs="0";;
        esac
      else
        khs="0"
      fi
      # Shares (optional)
      if echo "${L}" | grep -Eiq 'A:[0-9]+'; then
        acc="$(echo "${L}" | grep -Eio 'A:[0-9]+' | tail -n1 | cut -d: -f2)"
        rej="$(echo "${L}" | grep -Eio 'R:[0-9]+' | tail -n1 | cut -d: -f2)"
      fi
      echo "${khs}|${acc}|${rej}"
    }

    algo="${status}"
    khs="0"; ar_acc="0"; ar_rej="0"
    if echo "${algo}" | grep -qi 'queued'; then
      IFS='|' read -r khs ar_acc ar_rej <<<"$(parse_idle)"
      [[ -z "${khs}" || "${khs}" == "0" ]] && khs="999"
    fi

    sol4="$( [[ -n "${sol:-}" ]] && format4 "${sol}" || echo "N/A")"
    nos4="$( [[ -n "${nos:-}" ]] && format4 "${nos}" || echo "N/A")"
    wshort="$(shorten_wallet "${wallet:-}")"
    ver="S:${sol4} N:${nos4} W:${wshort}"

    stats=$(cat <<JSON
{"hs":[${khs}],"hs_units":"khs","temp":${temp_json},"fan":${fan_json},"uptime":${uptime},"ver":"${ver}","ar":[${ar_acc},${ar_rej}],"algo":"${algo}","bus_numbers":${bus_json}}
JSON
)
    printf "[%s] h-stats: ver=%s | algo=%s | khs=%s | wallet=%s | sol=%s | nos=%s\n" "$(date -Iseconds)" "${ver}" "${algo}" "${khs}" "${wallet:-}" "${sol:-}" "${nos:-}" >> "${LOG_DIR}/debug.log" || true
    echo "${stats}"
