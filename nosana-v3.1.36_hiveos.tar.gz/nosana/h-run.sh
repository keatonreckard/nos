#!/usr/bin/env bash
set -euo pipefail
: "${CUSTOM_LOG_BASENAME:=nosana}"
MINER_DIR="/hive/miners/custom/${CUSTOM_LOG_BASENAME}"
LOG_DIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
RUN_DIR="/var/run"
STATE_FILE="${RUN_DIR}/${CUSTOM_LOG_BASENAME}.state"
mkdir -p "${LOG_DIR}" "${RUN_DIR}" "/root/.nosana/podman"

NOSANA_LOG="${LOG_DIR}/nosana.log"
DEBUG_LOG="${LOG_DIR}/debug.log"
PODMAN_SOCK="/root/.nosana/podman/podman.sock"

log(){ printf "[%s] h-run: %s\n" "$(date -Iseconds)" "$*" | tee -a "${DEBUG_LOG}"; }

# Clean previous containers (best-effort, ignore errors)
log "cleaning previous containers"
(docker rm -f nosana-node >/dev/null 2>&1 || true)
(docker rm -f nosana-podman >/dev/null 2>&1 || true)

# Start podman sidecar (inside Docker), produces ${PODMAN_SOCK}
log "starting podman sidecar"
docker run -d --restart=always --name nosana-podman \
  --privileged \
  -v /root/.nosana/podman:/var/run/podman \
  nosana/podman:v1.1.0 >/dev/null

# Give sidecar a moment to write the socket
for i in $(seq 1 30); do
  [[ -S "${PODMAN_SOCK}" ]] && break
  sleep 1
done
if [[ ! -S "${PODMAN_SOCK}" ]]; then
  echo "[${(date +%FT%T%z)}] ERROR: podman.sock not created at ${PODMAN_SOCK}" | tee -a "${DEBUG_LOG}"
  exit 1
fi

# Start nosana CLI container
log "starting nosana-node container"
# Run in background container, then stream logs below
docker run -d --restart=always --name nosana-node \
  --network host \
  -v /root/.nosana:/root/.nosana \
  -v /root/.nosana/podman:/root/.nosana/podman \
  -e NOSANA_PROVIDER=podman \
  nosana/nosana-cli:latest node run >/dev/null

# Stream container logs to file and stdout to keep miner process attached
# (use tail -F on our file, while docker logs runs in background)
(docker logs -f nosana-node >> "${NOSANA_LOG}" 2>&1 &)

# Touch state markers
date +%s > "${MINER_DIR}/nosana.start.time" || true

# Keep foreground alive by tailing the nosana log
exec tail -F "${NOSANA_LOG}"
