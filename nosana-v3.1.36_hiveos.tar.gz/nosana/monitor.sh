#!/usr/bin/env bash
set -euo pipefail
: "${CUSTOM_LOG_BASENAME:=nosana}"
MINER_DIR="/hive/miners/custom/${CUSTOM_LOG_BASENAME}"
LOG_DIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
RUN_DIR="/var/run"
STATE_FILE="${RUN_DIR}/${CUSTOM_LOG_BASENAME}.state"
NOSANA_LOG="${LOG_DIR}/nosana.log"
IDLE_LOG="${LOG_DIR}/idle.log"
DEBUG_LOG="${LOG_DIR}/debug.log"
PARSED_DIR="${MINER_DIR}/parsed"
IDLE_CMD_FILE="${PARSED_DIR}/idle_command"
IDLE_ARGS_FILE="${PARSED_DIR}/idle_args"

mkdir -p "${LOG_DIR}" "${RUN_DIR}" "${PARSED_DIR}"

log(){ printf "[%s] monitor: %s\n" "$(date -Iseconds)" "$*" | tee -a "${DEBUG_LOG}"; }

get_idle_cmd(){ [[ -s "${IDLE_CMD_FILE}" ]] && cat "${IDLE_CMD_FILE}" || echo ""; }
get_idle_args(){ [[ -s "${IDLE_ARGS_FILE}" ]] && cat "${IDLE_ARGS_FILE}" || echo ""; }

idle_running() {
  pgrep -f "$(get_idle_cmd)" >/dev/null 2>&1
}

start_idle(){
  local cmd args
  cmd="$(get_idle_cmd)"
  args="$(get_idle_args)"
  if [[ -z "${cmd}" ]]; then
    log "start_idle requested but no idle command configured"
    return 0
  fi
  log "attempting to start idle (cmd:'${cmd}' args:'${args}')"
  nohup bash -c "exec ${cmd} ${args}" >> "${IDLE_LOG}" 2>&1 &
  echo $! > "${RUN_DIR}/${CUSTOM_LOG_BASENAME}.idle.pid"
  date +%s > "${MINER_DIR}/idle.start.time" || true
  echo "idle_enabled=1" > "${STATE_FILE}.tmp"; mv -f "${STATE_FILE}.tmp" "${STATE_FILE}"
  echo "[${CUSTOM_LOG_BASENAME}] idle miner started" | tee -a "${NOSANA_LOG}" >/dev/null
}

stop_idle(){
  if idle_running; then
    pkill -f "$(get_idle_cmd)" || true
    echo "[${CUSTOM_LOG_BASENAME}] idle miner stopped" | tee -a "${NOSANA_LOG}" >/dev/null
  fi
  echo "idle_enabled=0" > "${STATE_FILE}.tmp"; mv -f "${STATE_FILE}.tmp" "${STATE_FILE}"
  rm -f "${RUN_DIR}/${CUSTOM_LOG_BASENAME}.idle.pid" || true
}

# Initial state
echo "status=nos - initializing" > "${STATE_FILE}.tmp"; mv -f "${STATE_FILE}.tmp" "${STATE_FILE}"

log "watching nosana log for queue/job transitions"
touch "${NOSANA_LOG}"
tail -n0 -F "${NOSANA_LOG}" | while IFS= read -r line; do
  # Queue position
  if echo "${line}" | grep -Eq 'QUEUED.*position[[:space:]]+[0-9]+/[0-9]+'; then
    pos="$(echo "${line}" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
    status="nos - queued ${pos}"
    echo "status=${status}" > "${STATE_FILE}.tmp"; mv -f "${STATE_FILE}.tmp" "${STATE_FILE}"
    echo "[${CUSTOM_LOG_BASENAME}] queued ${pos}" | tee -a "${NOSANA_LOG}" >/dev/null
    if ! idle_running; then
      start_idle
    fi
  fi

  # Job start markers
  if echo "${line}" | grep -Eqi 'Job .* started|Flow .* running|Node has claimed job'; then
    echo "status=nos - job" > "${STATE_FILE}.tmp"; mv -f "${STATE_FILE}.tmp" "${STATE_FILE}"
    echo "[${CUSTOM_LOG_BASENAME}] job started" | tee -a "${NOSANA_LOG}" >/dev/null
    stop_idle
    date +%s > "${MINER_DIR}/job.start.time" || true
  fi

  # Node health running
  if echo "${line}" | grep -Eqi 'Node api .* running'; then
    echo "[${CUSTOM_LOG_BASENAME}] node api running" | tee -a "${NOSANA_LOG}" >/dev/null
    date +%s > "${MINER_DIR}/nosana.start.time" || true
  fi
done
