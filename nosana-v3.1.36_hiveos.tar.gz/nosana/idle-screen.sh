#!/usr/bin/env bash
: "${CUSTOM_LOG_BASENAME:=nosana}"
LOG_DIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
IDLE_LOG="${LOG_DIR}/idle.log"
mkdir -p "${LOG_DIR}"
exec tail -F "${IDLE_LOG}"
