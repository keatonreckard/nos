#!/usr/bin/env bash
set -euo pipefail
exec /hive/miners/custom/nosana/h-run.sh
