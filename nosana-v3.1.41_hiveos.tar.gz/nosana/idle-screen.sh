#!/usr/bin/env bash
: "${CUSTOM_LOG_BASENAME:=nosana}"
LOGDIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
tail -f "${LOGDIR}/idle.log"
