#!/usr/bin/env bash
set -euo pipefail
ts() { date +"[%Y-%m-%dT%H:%M:%S%z]"; }

: "${CUSTOM_LOG_BASENAME:=nosana}"
LOGDIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
NOSLOG="${LOGDIR}/nosana.log"
DBG="${LOGDIR}/debug.log"
mkdir -p "$LOGDIR"

wallet="$(grep -a 'Wallet:' "$NOSLOG" 2>/dev/null | tail -n1 | sed -E 's/.*Wallet:[[:space:]]*//')"
sol="$(grep -a 'SOL balance:' "$NOSLOG" 2>/dev/null | tail -n1 | sed -E 's/.*SOL balance:[[:space:]]*//; s/[[:space:]]*SOL.*$//' )"
nos="$(grep -a 'NOS balance:' "$NOSLOG" 2>/dev/null | tail -n1 | sed -E 's/.*NOS balance:[[:space:]]*//; s/[[:space:]]*NOS.*$//' )"

# Build ver string: S:<sol> N:<nos> W:<first5>
w5="$(printf '%s' "$wallet" | cut -c1-5)"
[ -z "$w5" ] && w5="N/A"
[ -z "$sol" ] && sol="N/A"
[ -z "$nos" ] && nos="N/A"
ver="S:${sol} N:${nos} W:${w5}"

# Algo / position / khs logic
pos="$(grep -aE 'queued[[:space:]]+[0-9]+/[0-9]+' "$NOSLOG" 2>/dev/null | tail -n1 | sed -E 's/.*queued[[:space:]]+([0-9]+\/[0-9]+).*/\1/i')"
if [ -n "$pos" ]; then
  algo="nos - queued ${pos}"
  khs="999"
else
  # Running if job started
  if grep -aEq 'Job .* (is starting|started|is running|running)' "$NOSLOG" 2>/dev/null; then
    algo="nos - running"
    khs="0"
  else
    algo="nos - initializing"
    khs="0"
  fi
fi

echo "$(ts) h-stats: ver=${ver} | algo=${algo} | khs=${khs} | wallet=${wallet} | sol=${sol} | nos=${nos}" >> "$DBG"

# Minimal JSON for convenience
printf '{"ver":"%s","algo":"%s","khs":%s,"wallet":"%s","sol":"%s","nos":"%s"}\n' \
  "$ver" "$algo" "$khs" "$wallet" "$sol" "$nos"
