#!/usr/bin/env bash
set -euo pipefail

ts() { date +"[%Y-%m-%dT%H:%M:%S%z]"; }
log() { echo "$(ts) $*" | tee -a "$DBG"; }

: "${CUSTOM_LOG_BASENAME:=nosana}"
LOGDIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
mkdir -p "$LOGDIR"
NOSLOG="${LOGDIR}/nosana.log"
DBG="${LOGDIR}/debug.log"

SIDECAR_NAME="nos-podman"
NODE_NAME="nosana-node"
PODMAN_SOCK="/root/.nosana/podman/podman.sock"

# Clean previous containers (best-effort)
log "h-run: cleaning previous containers"
{ docker rm -f "${SIDECAR_NAME}" >/dev/null 2>&1 || true; } || true
{ docker rm -f "${NODE_NAME}"   >/dev/null 2>&1 || true; } || true

# Try to start podman sidecar (non-fatal)
log "h-run: starting podman sidecar"
mkdir -p "$(dirname "$PODMAN_SOCK")" || true
# Note: sidecar image is nosana/podman:v1.1.0 (same as before)
docker run -d --restart=always \
  --name "${SIDECAR_NAME}" \
  -v /root/.nosana/podman:/var/run/podman \
  nosana/podman:v1.1.0 >/dev/null 2>&1 || true

# wait up to 25s for the socket to appear
tries=25
while [ $tries -gt 0 ]; do
  if [ -S "$PODMAN_SOCK" ]; then
    break
  fi
  sleep 1
  tries=$((tries-1))
done

PROVIDER="podman"
if [ ! -S "$PODMAN_SOCK" ]; then
  echo "$(ts) ERROR: podman.sock not created at ${PODMAN_SOCK}" | tee -a "$DBG"
  PROVIDER="docker"
fi

echo "$(ts) Using provider: ${PROVIDER}" | tee -a "$DBG"
echo "$(ts) starting nosana-node container" | tee -a "$DBG"

# Start the CLI container in foreground; pipe logs to nosana.log
# Mount both sockets; the CLI will pick the one matching --provider
DOCKER_ARGS=(
  run --rm --name "${NODE_NAME}"
  -v /root/.nosana:/root/.nosana
  -v /var/run/docker.sock:/var/run/docker.sock
)

if [ -S "$PODMAN_SOCK" ]; then
  DOCKER_ARGS+=( -v "$PODMAN_SOCK":/var/run/podman/podman.sock )
fi

# Pull latest quietly first
docker pull --quiet nosana/nosana-cli:latest >/dev/null 2>&1 || true

# Run
exec docker "${DOCKER_ARGS[@]}" \
  nosana/nosana-cli:latest node run --provider "${PROVIDER}" --log debug 2>&1 | tee -a "$NOSLOG"
