Nosana custom miner (HiveOS) — v3.1.41

Files:
- h-manifest.conf        : basic manifest (keeps previous naming; sets version)
- h-config.sh            : parses RAW_EXTRA for idle miner command/args
- h-run.sh               : starts podman sidecar, waits for socket, then starts Nosana node;
                           if podman socket is missing, safely falls back to docker.
- monitor.sh             : runs the node and auto-starts/stops idle miner based on queue status
- h-stats.sh             : builds ver string (S/N/W), algo status, khs and logs a debug line
- idle-screen.sh         : tiny helper to tail logs on the console
- nosana.conf            : reserved (optional extra env)


Key behavior (unchanged from before):
- Container names: nos-podman (sidecar), nosana-node (CLI container)
- Log base: $CUSTOM_LOG_BASENAME (defaults to 'nosana')
- Logs live in /var/log/miner/<logbase>/{nosana.log,debug.log,idle.log}

Only change vs older drops:
- Robust fallback to docker if the podman sidecar's podman.sock never appears.
