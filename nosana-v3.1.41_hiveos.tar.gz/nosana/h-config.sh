#!/usr/bin/env bash
set -e
ts() { date +"[%Y-%m-%dT%H:%M:%S%z]"; }

: "${CUSTOM_LOG_BASENAME:=nosana}"
LOGDIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
mkdir -p "$LOGDIR"
DBG="${LOGDIR}/debug.log"

RAW="${RAW_EXTRA:-}"
echo "$(ts) h-config: RAW_EXTRA length=${#RAW}" >> "$DBG"

IDLE_CMD=""
IDLE_ARGS=""

if command -v jq >/dev/null 2>&1; then
  IDLE_CMD="$(printf '%s' "$RAW" | jq -r '.idle.command // empty' 2>/dev/null || true)"
  IDLE_ARGS="$(printf '%s' "$RAW" | jq -r '.idle.args // empty' 2>/dev/null || true)"
fi

# fallback: try to scrape "command" / "arguments" from raw
if [ -z "$IDLE_CMD" ]; then
  IDLE_CMD="$(printf '%s' "$RAW" | sed -n 's/.*\"command\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p' | head -n1)"
fi
if [ -z "$IDLE_ARGS" ]; then
  IDLE_ARGS="$(printf '%s' "$RAW" | sed -n 's/.*\"arguments\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p' | head -n1)"
fi

echo "$(ts) h-config: parsed idle command: ${IDLE_CMD}" >> "$DBG"
echo "$(ts) h-config: parsed idle args: ${IDLE_ARGS}" >> "$DBG"

CONF="/run/nosana-idle.conf"
# shell-escaped
{
  printf 'NOS_IDLE_CMD=%q\n' "$IDLE_CMD"
  printf 'NOS_IDLE_ARGS=%q\n' "$IDLE_ARGS"
} > "$CONF"
