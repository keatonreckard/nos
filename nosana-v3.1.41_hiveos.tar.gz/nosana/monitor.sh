#!/usr/bin/env bash
set -euo pipefail
ts() { date +"[%Y-%m-%dT%H:%M:%S%z]"; }
log() { echo "$(ts) [nosana] $*" | tee -a "$DBG"; }

: "${CUSTOM_LOG_BASENAME:=nosana}"
LOGDIR="/var/log/miner/${CUSTOM_LOG_BASENAME}"
mkdir -p "$LOGDIR"
NOSLOG="${LOGDIR}/nosana.log"
DBG="${LOGDIR}/debug.log"
IDLELOG="${LOGDIR}/idle.log"
IDLEPID="/run/nosana-idle.pid"
IDLECONF="/run/nosana-idle.conf"

log "monitor started"

# Make sure config file exists (parses RAW_EXTRA if present)
/hive/miners/custom/nosana/h-config.sh || true

start_idle() {
  if [ -f "$IDLEPID" ] && kill -0 "$(cat "$IDLEPID")" 2>/dev/null; then
    return 0
  fi
  # shellcheck disable=SC1090
  [ -f "$IDLECONF" ] && . "$IDLECONF"
  if [ -n "${NOS_IDLE_CMD:-}" ]; then
    log "starting idle miner"
    nohup bash -lc "${NOS_IDLE_CMD} ${NOS_IDLE_ARGS:-}" >> "$IDLELOG" 2>&1 &
    echo $! > "$IDLEPID"
  else
    log "idle miner command not set; skipping"
  fi
}

stop_idle() {
  if [ -f "$IDLEPID" ]; then
    if kill -0 "$(cat "$IDLEPID")" 2>/dev/null; then
      log "stopping idle miner"
      kill "$(cat "$IDLEPID")" 2>/dev/null || true
    fi
    rm -f "$IDLEPID"
  fi
}

# Run the node in background and watch its log
( /hive/miners/custom/nosana/h-run.sh ) &
NODE_PID=$!

# A tiny loop that toggles idle miner from queued/running state
queued_seen=""
running_seen=""
while kill -0 "$NODE_PID" 2>/dev/null; do
  sleep 5
  # read last 200 lines to search status
  chunk="$(tail -n 200 "$NOSLOG" 2>/dev/null || true)"
  # normalize to lowercase once for simple greps
  lower="$(printf '%s\n' "$chunk" | tr '[:upper:]' '[:lower:]')"

  if echo "$lower" | grep -q "queued" ; then
    if [ "$queued_seen" != "1" ]; then
      log "state: QUEUED (enabling idle)"
      start_idle
      queued_seen="1"; running_seen=""
    fi
  elif echo "$lower" | grep -Eq "job .* (is starting|started|is running|running)"; then
    if [ "$running_seen" != "1" ]; then
      log "state: RUNNING (disabling idle)"
      stop_idle
      running_seen="1"; queued_seen=""
    fi
  fi
done

# On node exit, stop idle just in case
stop_idle
wait "$NODE_PID" || true
