#!/bin/bash

# This script is called to generate any config, but since Nosana doesn't use a traditional config file,
# we use it to parse the extra config and prepare files for keypair, idle settings, and verbose.

# Ensure directories exist
mkdir -p /hive/miners/custom/nosana

# Save the user config to the config file for potential editing or reference
echo "$CUSTOM_USER_CONFIG" > "$CUSTOM_CONFIG_FILENAME"

# Parse CUSTOM_USER_CONFIG for keypair, idleSettings, VERBOSE, and debug
# Assuming CUSTOM_USER_CONFIG is a string like "VERBOSE=true "keypair":"[120,89,...]" "idleSettings":{"command":"/path/to/miner","arguments":"--algo ... %WORKER_NAME%"} "debug":"true""

# Extract VERBOSE
if [[ "$CUSTOM_USER_CONFIG" == *"VERBOSE=true"* ]]; then
  touch /hive/miners/custom/nosana/verbose.flag
else
  rm -f /hive/miners/custom/nosana/verbose.flag
fi

# Extract keypair, allowing spaces around :
keypair=$(echo "$CUSTOM_USER_CONFIG" | sed -n 's/.*"keypair"\s*:\s*"\[\([^]]*\)\]".*/\1/p' | tr -d ' ')
if [[ -n "$keypair" ]]; then
  sudo mkdir -p /root/.nosana
  sudo sh -c "echo '[$keypair]' > /root/.nosana/nosana_key.json"
fi

# Extract idleSettings JSON part
idle_json=$(echo "$CUSTOM_USER_CONFIG" | grep -oP '"idleSettings"\s*:\s*{\s*\K[^}]+(?=\s*})')
if [[ -n "$idle_json" ]]; then
  idle_command=$(echo "$idle_json" | sed -n 's/.*"command":"\([^"]*\)".*/\1/p' | sed 's/^[ \t]*//;s/[ \t]*$//')
  idle_arguments=$(echo "$idle_json" | sed -n 's/.*"arguments":"\([^"]*\)".*/\1/p' | sed 's/^[ \t]*//;s/[ \t]*$//')
  # Replace %WORKER_NAME% with actual $WORKER_NAME
  idle_arguments=${idle_arguments//%WORKER_NAME%/$WORKER_NAME}
  echo "$idle_command" > /hive/miners/custom/nosana/idle_command
  echo "$idle_arguments" > /hive/miners/custom/nosana/idle_arguments
else
  rm -f /hive/miners/custom/nosana/idle_command /hive/miners/custom/nosana/idle_arguments
fi

# Extract debug flag, default off
if [[ "$CUSTOM_USER_CONFIG" == *"debug\":\"true"* ]]; then
  touch /hive/miners/custom/nosana/debug.flag
else
  rm -f /hive/miners/custom/nosana/debug.flag
fi