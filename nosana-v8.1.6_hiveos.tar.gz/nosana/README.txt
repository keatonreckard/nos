NOSANA for HiveOS — v8.1.6_hiveos
Built: 2025-08-21T17:56:22

Included files + permissions:
{
  "idle-kill.sh": "0o755",
  "idle-run.sh": "0o755",
  "idle-screen.sh": "0o644",
  "install-stats-wrapper.sh": "0o755",
  "monitor.sh": "0o755",
  "h-config.sh": "0o755",
  "h-manifest.conf": "0o644",
  "h-run.sh": "0o755",
  "h-stats.sh": "0o755",
  "h-stats-wrapper.sh": "0o755"
}

Highlights:
- Stats JSON: no "ar", single-line STDOUT, KH/s mapping (init+job=1, queued X/Y=X), version cache for S:/N:/W:.
- Wrapper (/hive/miners/custom/h-stats.sh) executes miner stats and strips any residual "ar".
- Idle: original idle-run behavior preserved. idle-screen.sh is non-executable so monitor uses idle-run (prevents TTY attach errors).

Install:
  tar -xzf nosana-v8.1.6_hiveos.tar.gz -C /hive/miners/custom
  bash /hive/miners/custom/nosana/install-stats-wrapper.sh

Verify:
  /hive/miners/custom/nosana/h-stats.sh | jq .
  CUSTOM_MINER=nosana /hive/miners/custom/h-stats.sh | jq .
  screen -ls | grep nosana-idle || true
