#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
PARSED_DIR="$MINER_DIR/parsed"
LOG_DIR="/var/log/miner/nosana"
CUSTOM_LOG="/var/log/miner/custom/custom.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$PARSED_DIR" "$LOG_DIR" "$(dirname "$CUSTOM_LOG")"
touch "$IDLE_LOG" "$CUSTOM_LOG"

# Try parsed files first (preferred, created by h-config.sh)
IDLE_COMMAND="$(cat "$PARSED_DIR/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$PARSED_DIR/idle_args" 2>/dev/null || true)"

# Helper: extract JSON fields from a blob
extract_from_json() {
  local blob="$1" key="$2"
  printf "%s" "$blob" | tr -d '\r\n' \
   | sed -nE "s/.*\"idleSettings\"[[:space:]]*:[[:space:]]*\\{[^}]*\"${key}\"[[:space:]]*:[[:space:]]*\"([^\"]*)\".*/\\1/p" \
   | tail -n1
}

# If missing, try to read from EXTRA files and parse idleSettings JSON
if [[ -z "${IDLE_COMMAND:-}" ]]; then
  for F in "$MINER_DIR/extra.raw" "/run/hive/custom/extra.txt" "/run/hive/extra.txt" "/hive/miners/custom/extra.txt"; do
    [[ -s "$F" ]] || continue
    RAW="$(cat "$F")"
    cmd="$(extract_from_json "$RAW" command)"
    args="$(extract_from_json "$RAW" arguments)"
    if [[ -n "$cmd" ]]; then
      IDLE_COMMAND="$cmd"
      IDLE_ARGS="$args"
      break
    fi
  done
fi

# As a final fallback, accept key=value style too
if [[ -z "${IDLE_COMMAND:-}" ]]; then
  for F in "$MINER_DIR/extra.raw" "/run/hive/custom/extra.txt" "/run/hive/extra.txt" "/hive/miners/custom/extra.txt"; do
    [[ -s "$F" ]] || continue
    IDLE_COMMAND="$(sed -nE 's/^[[:space:]]*(IDLE_COMMAND|idle_command)[[:space:]]*[:=][[:space:]]*(.*)$/\2/p' "$F" | tail -n1)"
    IDLE_ARGS="$(sed -nE 's/^[[:space:]]*(IDLE_ARGS|idle_args)[[:space:]]*[:=][[:space:]]*(.*)$/\2/p' "$F" | tail -n1)"
    [[ -n "${IDLE_COMMAND:-}" ]] && break
  done
fi

# Trim quotes/space
IDLE_COMMAND="$(printf "%s" "${IDLE_COMMAND:-}" | sed -E 's/^["'\'' ]+//; s/["'\'' ]+$//')"
IDLE_ARGS="$(printf "%s" "${IDLE_ARGS:-}" | sed -E 's/^["'\'' ]+//; s/["'\'' ]+$//')"

# Substitute %WORKER_NAME%
if [[ -z "${WORKER_NAME:-}" ]]; then
  # Best-effort: source if Hive exports it
  [[ -f /hive-config/wallet.conf ]] && . /hive-config/wallet.conf || true
fi
WN="${WORKER_NAME:-$(hostname)}"
IDLE_ARGS="${IDLE_ARGS//%WORKER_NAME%/$WN}"

if [[ -z "${IDLE_COMMAND:-}" ]]; then
  echo "[$(date -Iseconds)] idle-run: no idle command configured in EXTRA" | tee -a "$IDLE_LOG" "$CUSTOM_LOG"
  exit 0
fi

# Ensure binary is executable if it's a path
if [[ -f "$IDLE_COMMAND" && ! -x "$IDLE_COMMAND" ]]; then chmod +x "$IDLE_COMMAND" || true; fi

echo "[$(date -Iseconds)] idle-run: starting idle miner: $IDLE_COMMAND $IDLE_ARGS" | tee -a "$IDLE_LOG" "$CUSTOM_LOG"

# Start (in a screen for visibility) and tee output to idle.log
screen -S nosana-idle -X quit >/dev/null 2>&1 || true
screen -dmS nosana-idle bash -lc "$IDLE_COMMAND $IDLE_ARGS 2>&1 | tee -a '$IDLE_LOG'"

date +%s > "$MINER_DIR/idle.start.time" 2>/dev/null || true
exit 0
