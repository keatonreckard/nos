#!/usr/bin/env bash
# Attach to idle miner screen session without spawning a login shell.
# This prevents ~/.profile from running (and avoids 'motd: command not found').
set -euo pipefail
export LC_ALL=C
if screen -ls 2>/dev/null | grep -q "nosana-idle"; then
  exec screen -xRR nosana-idle
else
  echo "nosana-idle screen session not running."
  echo "Tip: check /var/log/miner/nosana/idle.log and /var/log/miner/nosana/nosana.log"
  exit 1
fi
