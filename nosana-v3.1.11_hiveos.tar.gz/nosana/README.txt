Nosana wrapper v3.1.11: stats derive directly from logs; idle passthrough; stable logging.
