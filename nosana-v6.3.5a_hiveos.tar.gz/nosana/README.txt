NOSANA (HiveOS custom miner package)
-----------------------------------
Built: 2025-08-21T15:16:36
Top-level dir: nosana

Change:
- Minimal h-stats tweak so KH/s reports "1" while status is "nos - initializing" (node starting)
  (Job already reports 1 kH/s; queued keeps first X from X/Y if present).

Contents:
- h-manifest.conf
- h-config.sh
- h-run.sh
- h-stats.sh  (patched as above)
- monitor.sh
- idle-screen.sh

Permissions:
- *.sh => 0755 (executable)
- *.conf / README.txt => 0644

Install:
- In HiveOS "Custom miner", set Name to "nosana", and URL to the .tar.gz link you host.
  (This package extracts to /hive/miners/custom/nosana)
