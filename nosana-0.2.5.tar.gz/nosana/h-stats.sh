#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
IDLE_PID_FILE="$RUN_DIR/nosana_idle.pid"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"

status="nos - initializing"
queue=""
sol=""
nos=""
wallet=""
idle_enabled=0

if [[ -f "$STATE_FILE" ]]; then
  # shellcheck disable=SC1090
  source "$STATE_FILE" || true
fi

# Fallbacks from nosana.log
if [[ -s "$NOSANA_LOG" ]]; then
  if [[ -z "${wallet:-}" ]]; then
    wl=$(tac "$NOSANA_LOG" | grep -m1 -E '^Wallet:\s+[A-Za-z0-9]{32,48}' | awk '{print $2}' || true)
    [[ -n "${wl:-}" ]] && wallet="$wl"
  fi
  if [[ -z "${sol:-}" ]]; then
    sb=$(tac "$NOSANA_LOG" | grep -m1 -E 'SOL balance:\s+[0-9]+\.[0-9]+' | awk '{print $3}' || true)
    [[ -n "${sb:-}" ]] && sol="$sb"
  fi
  if [[ -z "${nos:-}" ]]; then
    nb=$(tac "$NOSANA_LOG" | grep -m1 -E 'NOS balance:\s+[0-9]+\.[0-9]+' | awk '{print $3}' || true)
    [[ -n "${nb:-}" ]] && nos="$nb"
  fi
  if [[ "${status}" == "nos - initializing" ]]; then
    if tac "$NOSANA_LOG" | grep -Eq 'claimed job|Job .* started|Flow .* started'; then
      status="nos - job"
      queue=""
    else
      qp=$(tac "$NOSANA_LOG" | grep -m1 -E 'position [0-9]+/[0-9]+' | sed -n 's/.*position \([0-9]\+\/[0-9]\+\).*/\1/p' || true)
      if [[ -n "${qp:-}" ]]; then
        status="nos - queued ${qp}"
        queue="${qp}"
      fi
    fi
  fi
fi

format4() {
  local x="${1:-}"
  if [[ -z "$x" ]]; then printf ""; return; fi
  awk -v n="$x" 'BEGIN{printf("%.4f", n+0)}'
}

parse_idle_stats() {
  local tail_lines=400
  local hs_val="" hs_unit="" khs="0" acc="" rej=""
  local L
  if [[ ! -s "$IDLE_LOG" ]]; then echo "0|0|0"; return; fi
  L="$(tail -n "$tail_lines" "$IDLE_LOG")"

  if echo "$L" | grep -Eiq 'Total( |_)Speed:|Total Hashrate:|Total speed:|speed .* H/s|hashrate' ; then
    hs_val=$(echo "$L" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1 | awk '{print $1}')
    hs_unit=$(echo "$L" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1 | awk '{print $2}' | sed 's#/s##I')
  fi

  if [[ -n "$hs_val" && -n "$hs_unit" ]]; then
    case "${hs_unit^^}" in
      H)   khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v/1000)}') ;;
      KH)  khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v)}') ;;
      MH)  khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v*1000)}') ;;
      GH)  khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v*1000*1000)}') ;;
      *)   khs="0" ;;
    esac
  fi

  if echo "$L" | grep -Eiq 'Shares:|accepted|A:[0-9]+' ; then
    if echo "$L" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 >/dev/null 2>&1 ; then
      acc=$(echo "$L" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f1)
      rej=$(echo "$L" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d'/' -f2)
    elif echo "$L" | grep -Eio 'A:[0-9]+' | tail -n1 >/dev/null 2>&1 ; then
      acc=$(echo "$L" | grep -Eio 'A:[0-9]+' | tail -n1 | cut -d: -f2)
      rej=$(echo "$L" | grep -Eio 'R:[0-9]+' | tail -n1 | cut -d: -f2)
    fi
  fi

  [[ -z "$acc" ]] && acc="0"
  [[ -z "$rej" ]] && rej="0"
  echo "${khs}|${acc}|${rej}"
}

idle_running=0
if [[ -f "$IDLE_PID_FILE" ]]; then
  pid="$(cat "$IDLE_PID_FILE" 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]] && kill -0 "$pid" 2>/dev/null; then
    idle_running=1
  fi
fi

sol4="$(format4 "${sol:-}")"
nos4="$(format4 "${nos:-}")"
wallet_short="$(printf '%s' "${wallet:-N/A}" | cut -c1-5)"
ver="S:${sol4:-N/A} N:${nos4:-N/A} W:${wallet_short}"

algo="${status:-nos}"

now=$(date +%s)
if [[ -f "$MINER_DIR/job.start.time" ]]; then
  start_time=$(cat "$MINER_DIR/job.start.time")
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then
  start_time=$(cat "$MINER_DIR/idle.start.time")
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then
  start_time=$(cat "$MINER_DIR/nosana.start.time")
else
  st=$(awk '{print int($1)}' /proc/uptime)
  start_time=$((now - st))
fi
uptime=$(( now - start_time ))
if (( uptime < 0 )); then uptime=0; fi

khs="0"; ar_acc="0"; ar_rej="0"
if echo "$status" | grep -qi 'queued' && [[ "$idle_running" -eq 1 ]]; then
  IFS='|' read -r khs ar_acc ar_rej <<<"$(parse_idle_stats)"
fi

stats=$(cat <<JSON
{"hs":[${khs}],"hs_units":"khs","temp":[],"fan":[],"uptime":${uptime},"ver":"${ver}","ar":[${ar_acc},${ar_rej}],"algo":"${algo}"}
JSON
)

echo "${khs}"
echo "${stats}"
