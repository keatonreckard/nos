#!/usr/bin/env bash
# ---- robust defaults (added) ----
: "${NOSANA_MTU:=1420}"
: "${NOSANA_NODE_NAME:=nosana-node}"
: "${CONTAINER_NAME:=${NOSANA_NODE_NAME}}"
: "${PRE_RELEASE:=next}"
# ---------------------------------
set -euo pipefail
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
DEBUG_LOG="$LOG_DIR/debug.log"
mkdir -p "$LOG_DIR"
touch "$LOG_DIR/nosana.log" "$DEBUG_LOG" "$LOG_DIR/idle.log"
# --- nosana node log tee cleanup (miner.1) ---
if [[ -f /run/hive/.nosana_node_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_node_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_node_tail.pid
fi
: > /run/hive/miner.1 || true
# ---------------------------------------------

# --- nosana idle cleanup: clear stale idle screen, tail, and motd feed ---
mkdir -p /run/hive || true
if screen -ls 2>/dev/null | grep -q '\.nosana-idle'; then
  screen -S nosana-idle -X quit || true
fi
if [[ -f /run/hive/.nosana_idle_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_idle_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_idle_tail.pid
fi
: > /run/hive/miner.2 || true
# ------------------------------------------------------------------------

nohup bash "$MINER_DIR/idle-tee.sh" "$LOG_DIR/idle.log" >/dev/null 2>&1 &
nohup stdbuf -oL tail -n +1 -F "$LOG_DIR/nosana.log" | stdbuf -oL grep -a -v -E '\[XMR\]|SHARES:|Trainer:|\srx/|qubic|QUBIC|AVX|CUDA' > /run/hive/miner.1 2>/dev/null & echo $! > /run/hive/.nosana_node_tail.pid
# --- nosana idle cleanup: clear stale idle screen, tail, and motd feed ---
mkdir -p /run/hive || true
if screen -ls 2>/dev/null | grep -q '\.nosana-idle'; then
  screen -S nosana-idle -X quit || true
fi
if [[ -f /run/hive/.nosana_idle_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_idle_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_idle_tail.pid
fi
: > /run/hive/miner.2 || true
# ------------------------------------------------------------------------


msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

echo "[$(date -Iseconds)] h-run: cleaning previous containers" | tee -a "$DEBUG_LOG"
docker rm -f nosana-node podman >/dev/null 2>&1 || true
pkill -9 -f "podman system service" 2>/dev/null || true
docker container prune -f >/dev/null 2>&1 || true

docker volume inspect podman-cache >/dev/null 2>&1 || docker volume create podman-cache >/dev/null
docker volume inspect podman-socket >/dev/null 2>&1 || docker volume create podman-socket >/dev/null

echo "[$(date -Iseconds)] h-run: starting podman sidecar" | tee -a "$DEBUG_LOG"
docker run -d --pull=always --gpus=all --name podman --device /dev/fuse \
  --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman --privileged -e ENABLE_GPU=true \
  nosana/podman:v1.1.0 unix:/podman/podman.sock >> "$DEBUG_LOG" 2>&1 || true
sleep 5

      # set default network 'lowmtu' (mtu=1420) and fix built-in 'podman'
      docker exec -i podman sh <<'EOF'
set -eu
echo "[sidecar] set default network 'lowmtu' (mtu=1420) and fix built-in 'podman'"
podman network rm -f lowmtu >/dev/null 2>&1 || true
podman network create --driver bridge -o mtu=1420 lowmtu >/dev/null || true
mkdir -p /etc/containers
printf "[network]\ndefault_network=\"lowmtu\"\n" > /etc/containers/containers.conf
podman network rm -f mtuhelper >/dev/null 2>&1 || true
podman network create --driver bridge -o mtu=1420 mtuhelper >/dev/null || true
ids="$(podman ps --format "{{.ID}} {{.Names}} {{.Networks}} {{.ImageName}}" | awk '$0 ~ /(^|[ ,])podman([ ,]|$)/ {print $1}')"
if [ -n "$ids" ]; then
  for c in $ids; do
    podman network connect mtuhelper "$c" || true
    podman network disconnect -f podman "$c" || true
  done
fi
podman network rm -f podman >/dev/null 2>&1 || true
podman network create --driver bridge -o mtu=1420 podman >/dev/null || true
if [ -n "$ids" ]; then
  for c in $ids; do
    podman network connect podman "$c" || true
    podman network disconnect -f mtuhelper "$c" || true
  done
fi
podman network rm -f mtuhelper >/dev/null 2>&1 || true
echo "[sidecar] default (no --network) MTU:"
podman run --rm docker.io/alpine sh -lc 'cat /sys/class/net/eth0/mtu 2>/dev/null || (ip link show eth0 | sed -n "s/.*mtu \([0-9]\+\).*/\1/p")' || true
EOF

echo "[$(date -Iseconds)] h-run: starting nosana-node container" | tee -a "$DEBUG_LOG"
msg "NOS: node starting"
docker run -d --pull=always --name nosana-node --network host --gpus=all \
  --volume /root/.nosana/:/root/.nosana/ \
  --volume podman-socket:/root/.nosana/podman:ro \
  -e CLI_VERSION= nosana/nosana-cli:prerelease \
  node start --network "${SOL_NET_ENV:=mainnet}" >> "$DEBUG_LOG" 2>&1 || true
sleep 2
msg "NOS: node container launched"

nohup bash "$MINER_DIR/idle-guard.sh" "$CONTAINER_NAME" >/var/log/miner/nosana/idle-guard.log 2>&1 &
exec bash "$MINER_DIR/monitor.sh"

# kick off idle guard
bash /hive/miners/custom/nosana/idle-guard.sh nosana-node || true