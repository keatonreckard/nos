#!/usr/bin/env bash
set -euo pipefail
LOG_CONT="${1:-}"
IDLE_RUN="/hive/miners/custom/nosana/idle-run.sh"
LOG_DIR="/var/log/miner/nosana"
PID_DIR="/run/hive"
mkdir -p "$LOG_DIR" "$PID_DIR"

send_msg(){
  local msg="$1"
  if command -v message >/dev/null 2>&1; then
    message info "$msg" >/dev/null 2>&1 || true
  elif [ -x /hive/bin/message ]; then
    /hive/bin/message info "$msg" >/dev/null 2>&1 || true
  else
    echo "[nosana] MESSAGE: $msg"
  fi
}

KILL_IDLE(){
  screen -S nosana-idle -X quit >/dev/null 2>&1 || true
  screen -ls 2>/dev/null | awk '/\.nosana-idle\s/ {print $1}' \
    | while read s; do screen -S "$s" -X quit >/dev/null 2>&1 || true; done
  pkill -9 -f "qli-Client|qli-worker-AVX512|qli-worker-XMR|qli-worker-CUDA" >/dev/null 2>&1 || true
}

IDLE_RUNNING(){
  screen -ls 2>/dev/null | grep -Eq '\.nosana-idle\s' && return 0
  pgrep -f "qli-Client|qli-worker-AVX512|qli-worker-XMR|qli-worker-CUDA" >/dev/null 2>&1 && return 0
  return 1
}

JOB_RUNNING(){
  docker exec podman sh -lc 'podman ps --format "{{.ImageName}}" 2>/dev/null' 2>/dev/null \
    | grep -E -q "^nosana/(nn|comfy):" && return 0 || return 1
}

START_IDLE(){
  if [ -x "$IDLE_RUN" ]; then
    bash "$IDLE_RUN" >> "$LOG_DIR/idle-run.log" 2>&1 || true
  fi
}

if [ -z "${LOG_CONT}" ]; then
  LOG_CONT="$(docker ps --format '{{.Names}} {{.Image}}' | awk '$2 ~ /nosana\/nosana-cli/ {print $1; exit}')"
  LOG_CONT="${LOG_CONT:-nosana-node}"
fi

KILL_IDLE

{
  echo "[idle-guard] watching docker logs of ${LOG_CONT}"
  docker logs -f --tail=0 "${LOG_CONT}" 2>&1 \
  | stdbuf -oL -eL grep -E --line-buffered "Node has found job|Node is claiming job|Job .* is starting|Flow .* initialized|Running action container/run" \
  | while read -r _; do KILL_IDLE; done
} >> "$LOG_DIR/idle-guard.log" 2>&1 &
echo $! > "$PID_DIR/nosana.idle-guard.pid"

{
  echo "[idle-guard] starting minute-aligned scheduler"
  last_kill_hour=""
  last_restart_hour=""
  while :; do
    now_s="$(date +%S)"
    sleep $((60 - 10#$now_s))
    m="$(date +%M)"
    h="$(date +%H)"
    if [ "$m" = "04" ] && [ "$h" != "$last_kill_hour" ]; then
      KILL_IDLE
      send_msg "NOSANA: idle miner killed by schedule at :04 (hour ${h})"
      last_kill_hour="$h"
    fi
    if [ "$m" = "07" ] && [ "$h" != "$last_restart_hour" ]; then
      if ! JOB_RUNNING && ! IDLE_RUNNING; then
        START_IDLE
        send_msg "NOSANA: idle miner (re)started at :07 (no job running)"
      fi
      last_restart_hour="$h"
    fi
  done
} >> "$LOG_DIR/idle-guard.log" 2>&1 &
echo $! > "$PID_DIR/nosana.idle-guard-sched.pid"
