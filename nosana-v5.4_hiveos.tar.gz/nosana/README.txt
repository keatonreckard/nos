Nosana wrapper v3.1.18: ANSI-stripped sed parsing for wallet/balances; robust algo; docker logs fallback.


v5.4 changes:
- **Always-announced idle start attempt** (visible in both miner log and HiveOS messages).
- Robust start via a runner script to avoid quoting/arg issues; logs tail if start fails.
- Extra QUEUED pattern (lines beginning with "-  QUEUED").
- Keeps heartbeat + watchdog; no changes to run flow, stats, balances, or message behavior.
