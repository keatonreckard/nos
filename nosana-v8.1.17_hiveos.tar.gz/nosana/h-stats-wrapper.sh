#!/usr/bin/env bash
# HiveOS custom miner stats wrapper (v8.1.17_hiveos)
set -euo pipefail
MINER_DIR="${MINER_DIR:-/hive/miners/custom}"

run_if_exists() { local p="$1"; [[ -f "$p" ]] && exec bash "$p"; }

if [[ -n "${CUSTOM_MINER:-}" && -f "$MINER_DIR/$CUSTOM_MINER/h-stats.sh" ]]; then
  exec bash "$MINER_DIR/$CUSTOM_MINER/h-stats.sh"
fi
run_if_exists "$MINER_DIR/nosana/h-stats.sh"

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
run_if_exists "$SELF_DIR/nosana/h-stats.sh"

# Fallback
echo '{"hs":[0],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"","ar":[0,0],"algo":"nos - initializing","bus_numbers":[]}'
