Nosana wrapper v3.1.12: hardened stats parsing; detects 'Node is claiming job'; clean version string.
