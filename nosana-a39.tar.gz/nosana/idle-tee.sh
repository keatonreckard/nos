#!/usr/bin/env bash
set -euo pipefail
IDLE_LOG="${1:-/var/log/miner/nosana/idle.log}"
MINER2="/run/hive/miner.2"
PID_FILE="/run/hive/.nosana_idle_tail.pid"
SESSION="nosana-idle"

idle_running() { screen -ls 2>/dev/null | grep -q "\.${SESSION}"; }

start_tail() {
  mkdir -p /run/hive || true
  stdbuf -oL tail -n +1 -F "$IDLE_LOG" > "$MINER2" &
  echo $! > "$PID_FILE"
}

stop_tail() {
  [[ -f "$PID_FILE" ]] || return 0
  pid="$(cat "$PID_FILE" || true)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f "$PID_FILE"
}

# Loop: only mirror logs while the idle screen session exists
while :; do
  if idle_running; then
    if [[ ! -f "$PID_FILE" ]] || ! kill -0 "$(cat "$PID_FILE" 2>/dev/null || echo 0)" 2>/dev/null; then
      start_tail
    fi
  else
    stop_tail
  fi
  sleep 3
done
