#!/usr/bin/env bash
# nosana/h-stats.sh
# IMPORTANT: sourced by the Hive agent via /hive/miners/custom/h-stats.sh.
# MUST print nothing. Must define:
#   - khs   (numeric)
#   - stats (valid JSON: hs, hs_units, temp, fan, uptime, ver, algo, bus_numbers)
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

_escape_json() { printf '%s' "${1:-}" | sed 's/\\/\\\\/g; s/"/\\"/g'; }

status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true
prev_sol="${sol:-}"; prev_nos="${nos:-}"; prev_wallet="${wallet:-}"

CLEAN=""
found_sol=""; found_nos=""; found_wallet="";
if [[ -s "$NOSANA_LOG" ]]; then
  CLEAN="$(tail -n 3000 "$NOSANA_LOG" | tr -d $'\r' | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"
fi

algo="${status:-nos}"
if [[ -n "$CLEAN" ]]; then
  if printf '%s\n' "$CLEAN" | grep -Eqi 'Node is claiming job|has found job|claimed job|Job .* started|Flow .* started|is running'; then
    algo="nos - job"; queue=""
  else
    qpos="$(printf '%s\n' "$CLEAN" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
    if [[ -n "$qpos" ]]; then
      algo="nos - queued ${qpos}"; queue="$qpos"
    elif printf '%s\n' "$CLEAN" | grep -Eqi 'QUEUED'; then
      algo="nos - queued"
    fi
  fi
fi

now=$(date +%s)
if   [[ -f "$MINER_DIR/job.start.time"  ]]; then start_time=$(cat "$MINER_DIR/job.start.time")
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then start_time=$(cat "$MINER_DIR/idle.start.time")
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then start_time=$(cat "$MINER_DIR/nosana.start.time")
else read -r up _ < /proc/uptime; start_time=$(( now - ${up%.*} ))
fi
uptime=$((now - start_time)); ((uptime<0)) && uptime=0

temp_json="[]"; fan_json="[]"; bus_json="[]"
if [[ -f /hive/bin/gpu-stats ]]; then
  # shellcheck disable=SC1091
  source /hive/bin/gpu-stats || true
  if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [[ "${#GPU_FAN[@]:-0}"  -gt 0 ]]; then fan_json="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
  if [[ "${#BUS_IDS[@]:-0}"  -gt 0 ]]; then
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

if [[ -n "$CLEAN" ]]; then
  wallet="$(printf '%s\n' "$CLEAN" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
  [[ -z "$wallet" ]] && wallet="$(printf '%s\n' "$CLEAN" | sed -nE 's/.*(Public[[:space:]]*Key|Pubkey|Address)[[:space:]]*:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\2/p' | tail -n1)"
  sol="$(printf '%s\n' "$CLEAN" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
  nos="$(printf '%s\n' "$CLEAN" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi

# Fallback to previous persisted values if current parse yielded empty
[[ -z "${sol:-}"     && -n "${prev_sol:-}"    ]] && sol="${prev_sol}"
[[ -z "${nos:-}"     && -n "${prev_nos:-}"    ]] && nos="${prev_nos}"
[[ -z "${wallet:-}"  && -n "${prev_wallet:-}" ]] && wallet="${prev_wallet}"

ver_core=""
[[ -n "${sol:-}"    ]] && printf -v solf "%.4f" "$sol" && ver_core+="S:${solf}"
[[ -n "${nos:-}"    ]] && printf -v nosf "%.4f" "$nos" && ver_core+="${ver_core:+ }N:${nosf}"
[[ -n "${wallet:-}" ]] && ver_core+="${ver_core:+ }W:$(printf '%s' "$wallet" | cut -c1-5)"


# Persist: only overwrite if we found fresh values
[[ -n "${found_sol}" ]] && sol="${found_sol}"
[[ -n "${found_nos}" ]] && nos="${found_nos}"
[[ -n "${found_wallet}" ]] && wallet="${found_wallet}"

# Save state (shell-safe quoting) so queued/idle keeps showing last known balances
printf 'status=%q
queue=%q
sol=%q
nos=%q
wallet=%q
idle_enabled=%q
' \
  "${status:-}" "${queue:-}" "${sol:-}" "${nos:-}" "${wallet:-}" "${idle_enabled:-0}" > "$STATE_FILE"


ver="${ver_core}"


khs="1"
if echo "$algo" | grep -qi 'queued' && [[ -n "${queue:-}" ]]; then
  qn="$(printf '%s' "$queue" | awk -F'/' '{print $1}')"
  [[ "$qn" =~ ^[0-9]+$ ]] && khs="$qn"
fi

algo_j="$(_escape_json "$algo")"
ver_j="$(_escape_json "$ver")"
stats="{\"hs\":[${khs}],\"hs_units\":\"khs\",\"temp\":${temp_json},\"fan\":${fan_json},\"uptime\":${uptime},\"ver\":\"${ver_j}\",\"algo\":\"${algo_j}\",\"bus_numbers\":${bus_json}}"
