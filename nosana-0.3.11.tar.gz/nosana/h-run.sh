#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="${RUN_DIR}/nosana.state"
NOS_LOG="${LOG_DIR}/nosana.log"
DBG_LOG="${LOG_DIR}/debug.log"

mkdir -p "${LOG_DIR}" "${RUN_DIR}"

ts(){ date +"[%Y-%m-%dT%H:%M:%S%z]"; }

echo "$(ts) h-run: cleaning previous containers" | tee -a "${DBG_LOG}"
# Kill old monitor
if pgrep -f "nosana/monitor.sh" >/dev/null 2>&1; then
  pkill -f "nosana/monitor.sh" || true
fi
docker rm -f nosana-node podman >/dev/null 2>&1 || true

echo "$(ts) h-run: starting podman sidecar" | tee -a "${DBG_LOG}"
if ! docker volume ls | grep -q podman-cache; then docker volume create podman-cache >/dev/null; fi
if ! docker volume ls | grep -q podman-socket; then docker volume create podman-socket >/dev/null; fi
docker run -d --pull=always --gpus=all --name podman --device /dev/fuse   --mount source=podman-cache,target=/var/lib/containers   --volume podman-socket:/podman   --privileged -e ENABLE_GPU=true nosana/podman:v1.1.0 unix:/podman/podman.sock >>"${DBG_LOG}" 2>&1 || true

echo "$(ts) h-run: starting nosana-node container" | tee -a "${DBG_LOG}"
# Remove -it to avoid TTY errors
docker run --pull=always --name nosana-node --network host   --gpus all --volume /root/.nosana/:/root/.nosana/   --volume podman-socket:/root/.nosana/podman:ro -e CLI_VERSION=   nosana/nosana-cli:latest node start   > "${NOS_LOG}" 2>&1 &

# start monitor after a short delay
( sleep 2; bash "${MINER_DIR}/monitor.sh" ) >> "${DBG_LOG}" 2>&1 &
echo "$(ts) [nosana] monitor started" | tee -a "${DBG_LOG}"

# foreground: stream nosana log so Hive keeps miner alive
touch "${NOS_LOG}"
exec tail -F "${NOS_LOG}"
