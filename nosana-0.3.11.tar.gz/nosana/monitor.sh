\
#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="${RUN_DIR}/nosana.state"
NOS_LOG="${LOG_DIR}/nosana.log"
IDLE_LOG="${LOG_DIR}/idle.log"
IDLE_SESSION="nosana-idle"

mkdir -p "${LOG_DIR}" "${RUN_DIR}"
touch "${NOS_LOG}" "${STATE_FILE}"

read_kv(){
  local key="$1"; local def="${2:-}"
  if [[ -f "${MINER_DIR}/nosana.conf" ]]; then
    local line
    line="$(grep -Eo '^VERBOSE=.*' "${MINER_DIR}/nosana.conf" || true)"
    # nosana.conf contains entire extra config; we just keep it available if needed.
  fi
  echo "${def}"
}

start_idle(){
  # only if not already running
  if ! screen -list | grep -q "\\.${IDLE_SESSION}"; then
    # Try to pull idleSettings from nosana.conf (JSON-ish). Expect keys: idleSettings.command, idleSettings.arguments
    local cmd args
    cmd="$(grep -oP '"idleSettings"\s*:\s*\{[^}]*\}' "${MINER_DIR}/nosana.conf" 2>/dev/null | grep -oP '"command"\s*:\s*"\K[^"]+' || true)"
    args="$(grep -oP '"idleSettings"\s*:\s*\{[^}]*\}' "${MINER_DIR}/nosana.conf" 2>/dev/null | grep -oP '"arguments"\s*:\s*"\K[^"]+' || true)"
    if [[ -n "${cmd}" ]]; then
      echo "[nosana] idle start: ${cmd}" > "${IDLE_LOG}"
      screen -dmS "${IDLE_SESSION}" bash -lc "exec ${cmd} ${args} >>'${IDLE_LOG}' 2>&1"
    fi
  fi
}

stop_idle(){
  if screen -list | grep -q "\\.${IDLE_SESSION}"; then
    screen -S "${IDLE_SESSION}" -X quit || true
  fi
}

write_state(){
  local status="$1" queue="$2" sol="$3" nos="$4" wallet="$5" idle="$6"
  cat > "${STATE_FILE}" <<EOF
status="${status}"
queue="${queue}"
sol="${sol}"
nos="${nos}"
wallet="${wallet}"
idle_enabled="${idle}"
EOF
  chmod 644 "${STATE_FILE}"
}

parse_log(){
  local L
  L="$(tail -n 500 "${NOS_LOG}")"

  # Wallet / balances
  local wallet sol nos
  wallet="$(echo "${L}" | awk '/^Wallet:/ {w=$2} END{print w}')"
  sol="$(echo "${L}" | awk '/^SOL balance:/ {g=$3} END{print g}')"
  nos="$(echo "${L}" | awk '/^NOS balance:/ {g=$3} END{print g}')"

  # Status detection
  local status="nos - initializing"
  local queue=""
  if echo "${L}" | grep -qE 'QUEUED.*position'; then
    queue="$(echo "${L}" | grep -E 'QUEUED.*position' | tail -n1 | grep -Eo '[0-9]+/[0-9]+' | tail -n1)"
    if [[ -n "${queue}" ]]; then
      status="nos - queued ${queue}"
    else
      status="nos - queued"
    fi
  elif echo "${L}" | grep -qiE 'Job .* (started successfully|is running|is starting|Flow .* is running)'; then
    status="nos - job"
  fi

  printf "%s|%s|%s|%s|%s\n" "${status}" "${queue}" "${sol}" "${nos}" "${wallet}"
}

# Main loop
while true; do
  read -r status queue sol nos wallet < <(parse_log | awk -F'|' '{print $1, $2, $3, $4, $5}')
  # Toggle idle miner based on status
  if echo "${status}" | grep -qi 'queued'; then
    start_idle; idle="1"
  else
    stop_idle; idle="0"
  fi
  write_state "${status}" "${queue}" "${sol}" "${nos}" "${wallet}" "${idle}"
  sleep 5
done
