#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
CONF="$MINER_DIR/nosana.conf"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"

mkdir -p "${MINER_DIR}" "${LOG_DIR}" "${RUN_DIR}"

# Hive passes extra config in $CUSTOM_USER_CONFIG prefixed with VERBOSE=...
# We store it verbatim for monitor/runner.
echo "${CUSTOM_USER_CONFIG:-}" > "${CONF}"

# Touch state so h-stats has something to read immediately
STATE_FILE="${RUN_DIR}/nosana.state"
if [[ ! -f "${STATE_FILE}" ]]; then
  cat > "${STATE_FILE}" <<EOF
status="nos - initializing"
queue=""
sol=""
nos=""
wallet=""
idle_enabled="0"
EOF
  chmod 644 "${STATE_FILE}"
fi
