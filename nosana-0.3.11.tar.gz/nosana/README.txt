Nosana HiveOS wrapper 0.3.11 – fixes: robust state parsing, idle toggle, GPU stats on job.
