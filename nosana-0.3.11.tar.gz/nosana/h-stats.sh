\
#!/usr/bin/env bash
# Emit Hive stats JSON for the custom miner.
set -euo pipefail

RUN_DIR="/var/run"
STATE_FILE="${RUN_DIR}/nosana.state"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="${LOG_DIR}/idle.log"

status="nos - initializing"
queue=""
sol=""
nos=""
wallet=""
idle_enabled="0"

if [[ -f "${STATE_FILE}" ]]; then
  # shellcheck disable=SC1090
  source "${STATE_FILE}" || true
fi

format4(){ awk -v n="${1:-0}" 'BEGIN{printf("%.4f", n+0)}'; }

short_wallet(){
  if [[ -n "${wallet}" ]]; then printf "%s" "${wallet:0:5}"; else printf "N/A"; fi
}

ver_parts=()
if [[ -n "${sol}" ]]; then ver_parts+=("S:$(format4 "${sol}")"); else ver_parts+=("S:N/A"); fi
if [[ -n "${nos}" ]]; then ver_parts+=("N:$(format4 "${nos}")"); else ver_parts+=("N:N/A"); fi
ver_parts+=("W:$(short_wallet)")
if [[ -n "${queue}" ]]; then ver_parts+=("Q:${queue}"); fi
ver="$(IFS=' '; echo "${ver_parts[*]}")"

algo="${status}"

# Hashrate & shares from idle miner when queued
khs="0"
ar_acc="0"; ar_rej="0"

parse_idle(){
  [[ -s "${IDLE_LOG}" ]] || { echo "0 0 0"; return; }
  local tailn=300
  local L; L="$(tail -n ${tailn} "${IDLE_LOG}")"
  local val unit
  val="$(echo "${L}" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1 | awk '{print $1}')"
  unit="$(echo "${L}" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1 | awk '{print $2}' | sed 's#/s##I')"
  local kh="0"
  case "${unit^^}" in
    H) kh=$(awk -v v="${val:-0}" 'BEGIN{printf("%.6f", v/1000)}');;
    KH) kh=$(awk -v v="${val:-0}" 'BEGIN{printf("%.6f", v)}');;
    MH) kh=$(awk -v v="${val:-0}" 'BEGIN{printf("%.6f", v*1000)}');;
    GH) kh=$(awk -v v="${val:-0}" 'BEGIN{printf("%.6f", v*1000*1000)}');;
    *) kh="0";;
  esac
  local acc rej
  acc="$(echo "${L}" | grep -Eio 'A:[0-9]+' | tail -n1 | cut -d: -f2)"; acc="${acc:-0}"
  rej="$(echo "${L}" | grep -Eio 'R:[0-9]+' | tail -n1 | cut -d: -f2)"; rej="${rej:-0}"
  echo "${kh} ${acc} ${rej}"
}

if echo "${algo}" | grep -qi 'queued' && [[ "${idle_enabled:-0}" == "1" ]]; then
  read -r khs ar_acc ar_rej < <(parse_idle)
fi

# GPU stats when job to show temps/fans/bus on dashboard
temp_json='[]'; fan_json='[]'; bus_json='[]'
if echo "${algo}" | grep -qi 'job'; then
  if [[ -x /hive/bin/gpu-stats ]]; then
    source /hive/bin/gpu-stats
    # gpu-temp and fan-speed arrays provided by gpu-stats
    if [[ -n "${gpu_temp[@]+x}" ]]; then temp_json=$(jq -nc --argjson a "$(printf '%s\n' "${gpu_temp[@]:-}" | jq -R . | jq -s .)" '$a'); fi
    if [[ -n "${gpu_fan[@]+x}" ]]; then fan_json=$(jq -nc --argjson a "$(printf '%s\n' "${gpu_fan[@]:-}" | jq -R . | jq -s .)" '$a'); fi
    if [[ -n "${bus_ids[@]+x}" ]]; then
      # Convert hex like 01:00.0 to decimal bus number
      mapfile -t busnums < <(printf '%s\n' "${bus_ids[@]}" | sed 's/^[[:space:]]*//' | awk -F: '{print "0x"$1}' | xargs -I{} bash -lc 'printf "%d\n" {}' )
      bus_json=$(jq -nc --argjson a "$(printf '%s\n' "${busnums[@]:-}" | jq -R . | jq -s .)" '$a')
    fi
  fi
fi

# Uptime heuristic: use process start times if available, else system uptime
uptime=$(awk '{print int($1)}' /proc/uptime)

stats=$(jq -nc \
  --argjson hs "[$khs]" \
  --arg hs_units "khs" \
  --argjson temp "${temp_json}" \
  --argjson fan "${fan_json}" \
  --arg uptime "${uptime}" \
  --arg ver "${ver}" \
  --argjson ar "[${ar_acc},${ar_rej}]" \
  --arg algo "${algo}" \
  --argjson bus_numbers "${bus_json}" \
  '{hs:$hs,hs_units:$hs_units,temp:$temp,fan:$fan,uptime:($uptime|tonumber),ver:$ver,ar:$ar,algo:$algo,bus_numbers:$bus_numbers}')

# First line must be total_khs as number
echo "${khs}"
echo "${stats}"
