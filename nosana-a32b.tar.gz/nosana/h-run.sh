#!/usr/bin/env bash
# MTU defaults
NOSANA_MTU_NET="${NOSANA_MTU_NET:-normmtu}"
NOSANA_MTU="${NOSANA_MTU:-1500}"
set -euo pipefail
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
DEBUG_LOG="$LOG_DIR/debug.log"
ensure_docker_global_mtu() {
  # Persist MTU in /etc/docker/daemon.json, restart Docker if changed.
  # Honors NOSANA_MTU (default set earlier).
  local desired="${NOSANA_MTU:-1420}"
  local changed=0
  mkdir -p /etc/docker

  # Backup current config if present
  if [ -f /etc/docker/daemon.json ]; then
    cp -f /etc/docker/daemon.json "/etc/docker/daemon.json.bak.$(date +%s)" || true
  fi

  if command -v jq >/dev/null 2>&1 && [ -s /etc/docker/daemon.json ]; then
    # Merge MTU into existing JSON
    local tmp; tmp="$(mktemp)"
    if jq --argjson m "$desired" '.mtu = $m' /etc/docker/daemon.json > "$tmp"; then
      if ! cmp -s "$tmp" /etc/docker/daemon.json; then
        mv "$tmp" /etc/docker/daemon.json
        changed=1
      else
        rm -f "$tmp"
      fi
    fi
  elif [ -s /etc/docker/daemon.json ] && [ -z "${NOSANA_DOCKER_FORCE_DAEMON_REWRITE:-}" ]; then
    echo "[h-run] NOTE: /etc/docker/daemon.json exists and jq not found; skipping MTU merge. Set NOSANA_DOCKER_FORCE_DAEMON_REWRITE=1 to overwrite." >> "$DEBUG_LOG"
  else
    # Write minimal config with MTU (either file missing/empty, or force rewrite)
    printf '{ "mtu": %s }
' "$desired" > /etc/docker/daemon.json
    changed=1
  fi

  if [ "$changed" = "1" ]; then
    echo "[h-run] docker daemon MTU set to $desired; restarting docker..." >> "$DEBUG_LOG"
    if command -v systemctl >/dev/null 2>&1; then
      systemctl daemon-reload >/dev/null 2>&1 || true
      systemctl restart docker >/dev/null 2>&1 || true
    fi
    if ! docker info >/dev/null 2>&1; then
      service docker restart >/dev/null 2>&1 || true
    fi
    # Give Docker a moment to come back
    sleep 2
  else
    echo "[h-run] docker daemon MTU already configured (or merge skipped)." >> "$DEBUG_LOG"
  fi
}

# Node Docker network
if [[ "${NOSANA_DOCKER_USE_HOST:-0}" == "1" ]]; then
  NET_ARGS="--network host"
else
  NET_ARGS="--network ${NOSANA_MTU_NET}"
fi
mkdir -p "$LOG_DIR"
touch "$LOG_DIR/nosana.log" "$DEBUG_LOG" "$LOG_DIR/idle.log"
# --- nosana node log tee cleanup (miner.1) ---
if [[ -f /run/hive/.nosana_node_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_node_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_node_tail.pid
fi
: > /run/hive/miner.1 || true
# ---------------------------------------------

# --- nosana idle cleanup: clear stale idle screen, tail, and motd feed ---
mkdir -p /run/hive || true
if screen -ls 2>/dev/null | grep -q '\.nosana-idle'; then
  screen -S nosana-idle -X quit || true
fi
if [[ -f /run/hive/.nosana_idle_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_idle_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_idle_tail.pid
fi
: > /run/hive/miner.2 || true
# ------------------------------------------------------------------------

nohup bash "$MINER_DIR/idle-tee.sh" "$LOG_DIR/idle.log" >/dev/null 2>&1 &
nohup stdbuf -oL tail -n +1 -F "$LOG_DIR/nosana.log" | stdbuf -oL grep -a -v -E '\[XMR\]|SHARES:|Trainer:|\srx/|qubic|QUBIC|AVX|CUDA' > /run/hive/miner.1 2>/dev/null & echo $! > /run/hive/.nosana_node_tail.pid
# --- nosana idle cleanup: clear stale idle screen, tail, and motd feed ---
mkdir -p /run/hive || true
if screen -ls 2>/dev/null | grep -q '\.nosana-idle'; then
  screen -S nosana-idle -X quit || true
fi
if [[ -f /run/hive/.nosana_idle_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_idle_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_idle_tail.pid
fi
: > /run/hive/miner.2 || true
# ------------------------------------------------------------------------


msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

echo "[$(date -Iseconds)] h-run: cleaning previous containers" | tee -a "$DEBUG_LOG"
docker rm -f nosana-node podman >/dev/null 2>&1 || true
pkill -9 -f "podman system service" 2>/dev/null || true
docker container prune -f >/dev/null 2>&1 || true

docker volume inspect podman-cache >/dev/null 2>&1 || docker volume create podman-cache >/dev/null
docker volume inspect podman-socket >/dev/null 2>&1 || docker volume create podman-socket >/dev/null

echo "[$(date -Iseconds)] h-run: starting podman sidecar" | tee -a "$DEBUG_LOG"
docker run -d --pull=always --gpus=all --name podman --device /dev/fuse \
  --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman --privileged -e ENABLE_GPU=true \
  nosana/podman:v1.1.0 unix:/podman/podman.sock >> "$DEBUG_LOG" 2>&1 || true

# Enforce Podman default network + wrapper (global MTU for all inner runs)
docker exec -e NET="${NOSANA_MTU_NET}" -e MTU="${NOSANA_MTU}" podman sh -lc '
  set -eu
  if podman network inspect "$NET" >/dev/null 2>&1; then
    if ! podman network inspect "$NET" | grep -q "\"mtu\": *\"$MTU\""; then
      podman network rm -f "$NET" >/dev/null 2>&1 || true
      podman network create --driver bridge -o mtu=$MTU "$NET"
    fi
  else
    podman network create --driver bridge -o mtu=$MTU "$NET"
  fi
  mkdir -p /etc/containers/containers.conf.d
  cat >/etc/containers/containers.conf.d/90-default-net.conf <<EOF
[network]
default_network = "$NET"
EOF
  if [ -x /usr/bin/podman ] && [ ! -e /usr/bin/podman.real ]; then
    mv /usr/bin/podman /usr/bin/podman.real
  fi
  cat >/usr/local/bin/podman <<WRAP
#!/bin/sh
REAL=/usr/bin/podman.real
NET="\${PODMAN_FORCE_NETWORK:-$NET}"
MTU="\${PODMAN_FORCE_MTU:-$MTU}"
if ! "\$REAL" network inspect "\$NET" >/dev/null 2>&1; then
  "\$REAL" network create --driver bridge -o mtu=\$MTU "\$NET" >/dev/null 2>&1 || true
fi
need_net=1
for a in "\$@"; do
  case "\$a" in
    --net=*|--network=*|--net|--network|--pod=*) need_net=0 ;;
  esac
done
if [ "\$1" = "run" ] && [ "\$need_net" -eq 1 ]; then
  exec "\$REAL" "\$@" --network "\$NET"
else
  exec "\$REAL" "\$@"
fi
WRAP
  chmod +x /usr/local/bin/podman
  ln -sf /usr/local/bin/podman /usr/bin/podman
  echo "[podman] default_network=$NET mtu=$MTU (wrapper active)"
' || true
sleep 5

echo "[$(date -Iseconds)] h-run: starting nosana-node container" | tee -a "$DEBUG_LOG"
if ! docker network inspect "${NOSANA_MTU_NET}" >/dev/null 2>&1; then
  docker network create --driver bridge -o "com.docker.network.driver.mtu=${NOSANA_MTU}" "${NOSANA_MTU_NET}" || true
fi
ensure_docker_global_mtu
msg "NOS: node starting"
docker run -d $NET_ARGS --pull=always --name nosana-node --gpus=all \
  --volume /root/.nosana/:/root/.nosana/ \
  --volume podman-socket:/root/.nosana/podman:ro \
  -e CLI_VERSION= nosana/nosana-cli:latest \
  node start --network "${SOL_NET_ENV:=mainnet}" >> "$DEBUG_LOG" 2>&1 || true
sleep 2
msg "NOS: node container launched"

exec bash "$MINER_DIR/monitor.sh"
