#!/usr/bin/env bash
# nosana h-stats.sh (v8.1.21_hiveos) — define $khs and $stats for Hive agent.
# IMPORTANT: this file is *sourced* by the agent; avoid set -e/-u/exec redirs/printing.
# Only set khs and stats variables; do not echo anything.

# Defensive defaults
khs="0"
stats='{"hs":[0],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"","algo":"nos","bus_numbers":[]}'

# Paths
MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"

# Make sure log dir exists (best-effort, no failure propagation)
mkdir -p "$LOG_DIR" >/dev/null 2>&1 || true

# Load state if present (best-effort)
if [[ -f "$STATE_FILE" ]]; then . "$STATE_FILE" || true; fi

# Read/clean nosana log
L=""
if [[ -s "$NOSANA_LOG" ]]; then
  L="$(tail -n 3000 "$NOSANA_LOG" 2>/dev/null | tr -d '\r')"
else
  C="$(docker logs --since 10m nosana-node 2>/dev/null || true)"
  if [[ -n "$C" ]]; then L="$(printf "%s" "$C" | tr -d '\r')"; fi
fi
CLEAN="$(printf "%s" "$L" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"

# Wallet
wallet=""
if [[ -z "$wallet" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
fi
if [[ -z "$wallet" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
fi

# Balances
sol=""; nos=""
if [[ -z "$sol" ]]; then
  sol="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
if [[ -z "$nos" ]]; then
  nos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi

# Determine status
status="nos - initializing"
if printf "%s\n" "$CLEAN" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* running|is running'; then
  status="nos - job"
else
  pos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
  if [[ -n "$pos" ]]; then
    status="nos - queued ${pos}"
  elif printf "%s\n" "$CLEAN" | grep -Eqi '\bQUEUED\b'; then
    status="nos - queued"
  fi
fi

# Uptime
now=$(date +%s)
if   [[ -f "$MINER_DIR/job.start.time"  ]]; then start_time=$(cat "$MINER_DIR/job.start.time")
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then start_time=$(cat "$MINER_DIR/idle.start.time")
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then start_time=$(cat "$MINER_DIR/nosana.start.time")
else read -r up _ < /proc/uptime; start_time=$(( now - ${up%.*} )); fi
uptime=$((now - start_time)); if ((uptime<0)); then uptime=0; fi

# KH/s mapping (minimal, numeric only)
algo="$status"
qfirst="$(printf "%s\n" "$algo" | sed -nE 's/.*queued[[:space:]]+([0-9]+)\/[0-9]+.*/\1/p')"
if printf "%s" "$algo" | grep -qi 'nos - job'; then
  khs="1"
elif printf "%s" "$algo" | grep -qi 'nos - initializing'; then
  khs="1"
elif printf "%s" "$algo" | grep -qi 'nos - queued' && [[ -n "$qfirst" ]]; then
  khs="$qfirst"
else
  khs="1"
fi
khs="$(printf "%s" "$khs" | sed 's|/.*||; s/[^0-9.]//g')"; if [[ -z "$khs" ]]; then khs="1"; fi

# Version string
ver=""
if [[ -n "$sol" ]]; then printf -v solf "%.4f" "$sol"; ver+="S:${solf}"; fi
if [[ -n "$nos" ]]; then printf -v nosf "%.4f" "$nos"; ver+="${ver:+ }N:${nosf}"; fi
if [[ -n "$wallet" ]]; then ver+="${ver:+ }W:$(printf "%s" "$wallet" | cut -c1-5)"; fi

# GPU/system arrays
temp_json='[]'; fan_json='[]'; bus_json='[]'
if [[ -f /hive/bin/gpu-stats ]]; then
  # shellcheck disable=SC1091
  . /hive/bin/gpu-stats || true
  if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [[ "${#GPU_FAN[@]:-0}"  -gt 0 ]]; then  fan_json="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
  if [[ "${#BUS_IDS[@]:-0}"  -gt 0 ]]; then
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

# JSON-safe strings
j_escape() { sed 's/\\/\\\\/g; s/"/\\"/g'; }
algo_json="$(printf "%s" "$algo" | j_escape)"
ver_json="$(printf "%s" "$ver"  | j_escape)"

# Build final JSON (no shares field)
stats="{\"hs\":[${khs}],\"hs_units\":\"khs\",\"temp\":${temp_json},\"fan\":${fan_json},\"uptime\":${uptime},\"ver\":\"${ver_json}\",\"algo\":\"${algo_json}\",\"bus_numbers\":${bus_json}}"
