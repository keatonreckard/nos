\
    #!/usr/bin/env bash
    set -euo pipefail
    MINER_DIR="/hive/miners/custom/nosana"
    LOG_DIR="/var/log/miner/nosana"
    mkdir -p "$LOG_DIR"
    echo "[idle-run] $(date -Iseconds) requested start" >> "$LOG_DIR/agent.log"
    date +%s > "$MINER_DIR/idle.start.time"

    # Placeholder: your existing idle start command can be inserted here.
    # This file is included only for completeness; not auto-invoked by h-run.sh
    # Example (uncomment and adjust if you want to manage idle from here):
    # /hive/miners/custom/qubjetski.PPLNS/qli-Client ... >> "$LOG_DIR/idle.log" 2>&1 &

    exit 0
