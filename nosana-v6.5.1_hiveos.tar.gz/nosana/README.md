nosana custom miner (HiveOS) — v5.0.11
======================================
Changes requested:
- While a job is RUNNING: force hashrate = 1 kH/s (never 0)
- While QUEUED: prefer idle miner rate; if empty, use the queue position X from X/Y as X kH/s
  (no slash appears in the hashrate value)
- Always output valid JSON (no empty arrays, no hs with a slash, no ar:[,])
- "ver" string includes wallet/balances when found: "S:<sol> N:<nos> W:<first5>"
- On miner restart, kill idle miner so it doesn't keep running in the background
- Quiet stdout except for the final JSON line from h-stats.sh

Files:
  h-run.sh      - starts miner session; kills idle miner first
  h-stop.sh     - stops miner session (best-effort) and idle miner
  h-stats.sh    - reports stats in HiveOS JSON format with the rules above
  idle-run.sh   - helper (optional) placeholder for idle start (your existing idle can still be used)
  idle-stop.sh  - helper to stop idle miner
  VERSION       - version tag
  README.md     - this file

Install:
  tar -xzf nosana-5.0.11b.tar.gz -C /hive/miners/custom/

