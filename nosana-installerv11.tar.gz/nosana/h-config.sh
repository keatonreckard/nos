#!/usr/bin/env bash
# --- nosana keypair injection (only write if missing; robust parse) ---
{
  LOG_DIR="/var/log/miner/nosana"
  mkdir -p "$LOG_DIR"
  KEYDIR="/root/.nosana"
  KEYFILE="${KEYDIR}/nosana_key.json"

  EXTRA_CFG_RAW="${CUSTOM_USER_CONFIG:-}"
  # Flatten newlines, normalize quotes, unescape common sequences
  EXTRA_ONE="$(echo "$EXTRA_CFG_RAW" | tr '\n' ' ')"
  EXTRA_ONE="${EXTRA_ONE//\\\"/\"}"
  EXTRA_ONE="$(printf "%s" "$EXTRA_ONE" | sed 's/[“”]/"/g; s/[’]/'\''/g')"

  printf "%s %s\n" "$(date -Iseconds)" "ExtraConfig sample: $(echo "$EXTRA_ONE" | cut -c1-240)" >> "$LOG_DIR/debug.log"

  ensure_array_from_text() {
    # usage: ensure_array_from_text "text" -> prints [n,n,...] or nothing
    local txt="$1"
    # Prefer explicit keypair match from the text
    if echo "$txt" | grep -Eq '"keypair"[[:space:]]*:[[:space:]]*"?\[[0-9 ,\-]+\]"?'; then
      local arr
      arr="$(echo "$txt" | sed -n 's/.*"keypair"[[:space:]]*:[[:space:]]*"?\(\[[0-9 ,\-]\+\]\)"?.*/\1/p' | head -n1)"
      # Sanitize
      arr="$(echo "$arr" | tr -cd '0-9, -\[\]')"
      if echo "$arr" | grep -Eq '^\[[0-9 ,-]+\]$'; then
        echo "$arr"
        return 0
      fi
    fi
    # Fallback: if txt itself looks like a bare array
    if echo "$txt" | grep -Eq '^\[[0-9 ,-]+\]$'; then
      echo "$txt"
      return 0
    fi
    return 1
  }

  mkdir -p "$KEYDIR"

  if [[ ! -f "$KEYFILE" ]]; then
    # Parse from Extra Config and write as bare array
    if arr="$(ensure_array_from_text "$EXTRA_ONE")"; then
      printf '%s\n' "$arr" > "$KEYFILE"
      chmod 600 "$KEYFILE"
      echo "$(date -Iseconds) wrote keypair (bare array) to $KEYFILE" >> "$LOG_DIR/debug.log"
    else
      echo "$(date -Iseconds) keypair not found in Extra Config; $KEYFILE missing" >> "$LOG_DIR/debug.log"
    fi
  else
    # If file exists but is not a bare array, normalize it
    if ! grep -Eq '^\[[0-9 ,-]+\]$' "$KEYFILE"; then
      # Try to recover from existing content or Extra Config
      current="$(cat "$KEYFILE" 2>/dev/null || true)"
      if arr="$(ensure_array_from_text "$current")"; then
        printf '%s\n' "$arr" > "$KEYFILE"
        chmod 600 "$KEYFILE"
        echo "$(date -Iseconds) normalized existing key file to bare array" >> "$LOG_DIR/debug.log"
      elif arr="$(ensure_array_from_text "$EXTRA_ONE")"; then
        printf '%s\n' "$arr" > "$KEYFILE"
        chmod 600 "$KEYFILE"
        echo "$(date -Iseconds) replaced existing key file with bare array from Extra Config" >> "$LOG_DIR/debug.log"
      else
        echo "$(date -Iseconds) keypair file exists but not parsable; left unchanged" >> "$LOG_DIR/debug.log"
      fi
    else
      echo "$(date -Iseconds) keypair file exists in correct format; skipping write" >> "$LOG_DIR/debug.log"
    fi
  fi
}
# --- end keypair injection ---

set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
CONF_FILE="$MINER_DIR/nosana.conf"
RAW_EXTRA_FILE="$MINER_DIR/extra.raw"
PARSED_DIR="$MINER_DIR/parsed"

mkdir -p "$MINER_DIR" "$LOG_DIR" "$PARSED_DIR" "$RUN_DIR" /root/.nosana
chmod 755 "$MINER_DIR"
touch "$LOG_DIR/nosana.log" "$LOG_DIR/debug.log" "$LOG_DIR/idle.log"
chmod 664 "$LOG_DIR/"*.log || true

: "${CUSTOM_USER_CONFIG:=}"
printf '%s' "$CUSTOM_USER_CONFIG" > "$CONF_FILE"
printf '%s' "$CUSTOM_USER_CONFIG" > "$RAW_EXTRA_FILE"

RAW="$CUSTOM_USER_CONFIG"
TRIMMED="$(printf '%s' "$RAW" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
if printf '%s' "$TRIMMED" | grep -q '"idleSettings"'; then
  if printf '%s' "$TRIMMED" | grep -q '^{'; then EXTRA_JSON="$TRIMMED"; else EXTRA_JSON="{$TRIMMED}"; fi
else
  EXTRA_JSON="{}"
fi
IDLE_COMMAND=$(printf '%s' "$EXTRA_JSON" | tr '\n' ' ' | sed -n 's/.*"idleSettings"[[:space:]]*:[[:space:]]*{[^}]*"command"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)
IDLE_ARGS=$(printf '%s' "$EXTRA_JSON" | tr '\n' ' ' | sed -n 's/.*"idleSettings"[[:space:]]*:[[:space:]]*{[^}]*"arguments"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)

mkdir -p "$PARSED_DIR"
printf '%s' "$IDLE_COMMAND" > "$PARSED_DIR/idle_command"
printf '%s' "$IDLE_ARGS"    > "$PARSED_DIR/idle_args"

cat > "$STATE_FILE" <<EOF
status="nos - initializing"
queue=""
sol=""
nos=""
wallet=""
idle_enabled="$( [[ -n "$IDLE_COMMAND" ]] && echo 1 || echo 0 )"
EOF
chmod 664 "$STATE_FILE"

{
  echo "[$(date -Iseconds)] h-config: RAW_EXTRA length=$(printf %s "$RAW" | wc -c)"
  echo "[$(date -Iseconds)] h-config: parsed idle command: $IDLE_COMMAND"
  echo "[$(date -Iseconds)] h-config: parsed idle args:    $IDLE_ARGS"
} >> "$LOG_DIR/debug.log"

date +%s > "$MINER_DIR/nosana.start.time"
exit 0


