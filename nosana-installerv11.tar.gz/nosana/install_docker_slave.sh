#!/bin/bash
set -e
# Add Docker's official GPG key
sudo apt-get update || true
sudo apt-get install -y --allow-downgrades ca-certificates curl || true
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

# Add the repository to Apt sources
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo \"$VERSION_CODENAME\") stable" | sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
sudo apt-get update || true

# Install Docker (tolerate HiveOS quirks)
sudo apt-get install -y --allow-downgrades docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin || true

# Hack around iptables/ip6tables shenanigans on HiveOS
if [ -f "/etc/hiveos-release" ]; then
  sudo apt-get install -y --allow-downgrades iptables arptables ebtables
  sudo update-alternatives --set iptables /usr/sbin/iptables-legacy || true
  sudo update-alternatives --set ip6tables /usr/sbin/ip6tables-legacy || true
fi

# Disable ip6tables in docker service
sudo mkdir -p /etc/systemd/system/docker.service.d
echo -e "[Service]\nExecStart=\nExecStart=/usr/bin/dockerd -H fd:// --containerd=/run/containerd/containerd.sock --ip6tables=false" | sudo tee /etc/systemd/system/docker.service.d/override.conf >/dev/null

# Enable & restart Docker
sudo systemctl daemon-reload
sudo systemctl enable --now docker || true
sudo systemctl restart docker || true
