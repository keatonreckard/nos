#!/usr/bin/env bash
set -euo pipefail
LOG_CONT="${1:-nosana-node}"
mkdir -p /var/log/miner/nosana /run/hive

KILL_IDLE(){
  screen -S idle -X quit >/dev/null 2>&1 || true
  pkill -9 -f "qli-Client|qli-worker-AVX512|qli-worker-XMR|qli-worker-CUDA" >/dev/null 2>&1 || true
}

# immediate pre-kill (so benchmark isn't tainted)
KILL_IDLE

{
  echo "[idle-guard] watching docker logs of ${LOG_CONT}"
  docker logs -f --tail=0 "${LOG_CONT}" 2>&1   | stdbuf -oL -eL grep -E --line-buffered "Node has found job|Node is claiming job|Job .* is starting|Flow .* initialized|Running action container/run"   | while read -r _; do
      KILL_IDLE
    done
} >> /var/log/miner/nosana/idle-guard.log 2>&1 &

echo $! > /run/hive/nosana.idle-guard.pid
