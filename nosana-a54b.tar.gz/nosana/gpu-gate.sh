#!/usr/bin/env bash
set -euo pipefail
# Pause new nosana job containers until GPU util < threshold, then unpause.
THRESH="${NOSANA_GPU_GATE_THRESH:-10}"   # percent
TIMEOUT="${NOSANA_GPU_GATE_TIMEOUT:-20}" # seconds
SIDE=podman

gpu_busy () {
  if ! command -v nvidia-smi >/dev/null 2>&1; then return 2; fi
  local maxu
  maxu=$(nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits 2>/dev/null | awk 'max<$1{max=$1} END{print (max=="")?0:max}')
  [ "${maxu:-0}" -ge "$THRESH" ] && return 0 || return 1
}

mkdir -p /var/log/miner/nosana /run/hive
{
  echo "[gpu-gate] watching ${SIDE} events; threshold=${THRESH}% timeout=${TIMEOUT}s"
  docker exec -i ${SIDE} sh -lc 'podman events --format "{{.Type}} {{.Action}} {{.ImageName}} {{.ID}} {{.Name}}"' 2>&1   | stdbuf -oL -eL awk '/^container start / && ($3 ~ /^nosana\/(nn|comfy)/) {print $4" "$5}'   | while read -r ID NAME; do
      echo "[gpu-gate] pause $NAME ($ID)"
      docker exec ${SIDE} podman pause "$ID" >/dev/null 2>&1 || true

      t=0
      while gpu_busy; rc=$?; do
        if [ "$rc" -eq 2 ]; then
          echo "[gpu-gate] nvidia-smi not found; unpausing"
          break
        fi
        [ "$t" -ge "$TIMEOUT" ] && { echo "[gpu-gate] timeout hit; unpausing"; break; }
        sleep 1; t=$((t+1))
      done

      echo "[gpu-gate] unpause $NAME ($ID)"
      docker exec ${SIDE} podman unpause "$ID" >/dev/null 2>&1 || true
    done
} >> /var/log/miner/nosana/gpu-gate.log 2>&1 &

echo $! > /run/hive/nosana.gpu-gate.pid
