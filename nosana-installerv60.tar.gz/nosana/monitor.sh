#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

msg(){ echo "[nosana] $*"; }

LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="${STATE_FILE:-$RUN_DIR/nosana.state}"
NOSANA_LOG="${NOSANA_LOG:-$LOG_DIR/nosana.log}"
IDLE_LOG="${IDLE_LOG:-$LOG_DIR/idle.log}"

mkdir -p "$LOG_DIR" "$RUN_DIR"
exec 2>>"$LOG_DIR/debug.log"

# Ensure state exists
[[ -f "$STATE_FILE" ]] || { echo "status=initializing" > "$STATE_FILE"; }

# start/ensure idle-bridge
if ! pgrep -af "idle-bridge.sh start" >/dev/null 2>&1; then
  /hive/miners/custom/nosana/idle-bridge.sh start || true
fi

msg "monitor started"

# One-shot pass to derive initial status from nosana.log without altering logs
touch "$NOSANA_LOG"
tail -n 400 "$NOSANA_LOG" | sed -n '1,400p' >/dev/null 2>&1 || true

# background watcher to keep minimal state up to date
(
  while true; do
    L=$(tail -n 120 "$NOSANA_LOG" 2>/dev/null | tr -d '\r')
    status=""
    qpos=""
    if echo "$L" | grep -q " QUEUED "; then
      status="queued"
      qpos=$(echo "$L" | grep -Eo 'position[[:space:]]+[0-9]+/[0-9]+' | tail -n1 | awk '{print $2}')
    elif echo "$L" | grep -qiE "RUNNING|Executing job|Starting job|Job started|Flow .* running"; then
      status="job"
    else
      status="initializing"
    fi

    # Detect idle algo from idle log
    idle_algo=""
    I=$(tail -n 60 "$IDLE_LOG" 2>/dev/null || true)
    if echo "$I" | grep -q "\[XMR\]"; then idle_algo="xmr";
    elif echo "$I" | grep -q "\[CUDA\]\|\[AVX"; then idle_algo="qubic"; fi

    # Persist state atomically
    {
      echo "status=$status"
      echo "queued_pos=$qpos"
      echo "idle_algo=$idle_algo"
    } > "${STATE_FILE}.tmp"
    # Keep existing wallet/balances if present
    if [[ -f "$STATE_FILE" ]]; then
      grep -E '^(wallet|sol|nos)=' "$STATE_FILE" >> "${STATE_FILE}.tmp" || true
    fi
    mv -f "${STATE_FILE}.tmp" "$STATE_FILE"

    sleep 5
  done
) &

# Keep monitor alive
while true; do sleep 300; done
