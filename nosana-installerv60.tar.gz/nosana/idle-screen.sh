#!/usr/bin/env bash
set -euo pipefail
screen -ls | grep -i idle || true
