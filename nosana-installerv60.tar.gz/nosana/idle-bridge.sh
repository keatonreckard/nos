#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="${IDLE_LOG:-$LOG_DIR/idle.log}"
NOSANA_LOG="${NOSANA_LOG:-$LOG_DIR/nosana.log}"
mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

cmd=${1:-start}

case "$cmd" in
  start)
    echo "[$(date -Is)] idle-bridge starting; MINER_LOG=$NOSANA_LOG IDLE_LOG=$IDLE_LOG" >> "$LOG_DIR/debug.log"
    touch "$IDLE_LOG" "$NOSANA_LOG"
    # Use awk to prefix each new line and append to nosana.log
    # tail -n0 -F avoids truncation; if multiple bridges run, harmless duplicate lines filtered by uniq below
    tail -n0 -F "$IDLE_LOG" 2>/dev/null | awk '{print "[idle] " $0}' >> "$NOSANA_LOG" &
    echo "[$(date -Is)] idle-bridge tail started (pid=$!)" >> "$LOG_DIR/debug.log"
    ;;
  stop)
    # stop any bridge tails
    pgrep -f "tail -n0 -F $IDLE_LOG" | xargs -r kill || true
    ;;
  *)
    echo "usage: $0 {start|stop}"
    exit 1 ;;
esac
