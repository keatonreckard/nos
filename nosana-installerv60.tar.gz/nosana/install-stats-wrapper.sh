#!/usr/bin/env bash
set -euo pipefail
dest="/hive/bin/custom-stats"
src="/hive/miners/custom/nosana/h-stats-wrapper.sh"
mkdir -p "$(dirname "$dest")"
cp -f "$src" "$dest"
chmod 0755 "$dest"
echo "[nosana] installed stats wrapper to $dest"
