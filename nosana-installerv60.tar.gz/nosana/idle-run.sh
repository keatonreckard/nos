#!/usr/bin/env bash
set -euo pipefail
echo "idle-run: no-op placeholder (idle miner externally managed)" >&2 || true
exit 0
