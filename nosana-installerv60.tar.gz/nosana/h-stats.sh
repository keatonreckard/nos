#!/usr/bin/env bash
# Emits Hive custom miner stats for Nosana + idle miner (qubic/xmr)
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
LOG_DIR="/var/log/miner/nosana"
STATE_FILE="$RUN_DIR/nosana.state"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

# helpers
trim() { sed -E 's/^[[:space:]]+|[[:space:]]+$//g'; }
fmt_sol(){ awk '{printf("%.4f", $1+0)}'; }
fmt_nos(){ awk '{printf("%.3f", $1+0)}'; }
short_wallet(){ awk '{print substr($0,1,5)}'; }

# read/seed state
status="initializing"; queued=""; idle_algo=""
wallet=""; sol=""; nos=""
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

# Parse balances and wallet from nosana.log (keep last known if not found)
L="$(tail -n 600 "$NOSANA_LOG" 2>/dev/null | tr -d '\r' || true)"
wlog="$(printf "%s\n" "$L" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
[[ -n "${wlog:-}" ]] && wallet="$wlog"
slog="$(printf "%s\n" "$L" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9.]+).*/\1/p' | tail -n1)"
[[ -n "${slog:-}" ]] && sol="$(printf "%s" "$slog" | fmt_sol)"
nlog="$(printf "%s\n" "$L" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9.]+).*/\1/p' | tail -n1)"
[[ -n "${nlog:-}" ]] && nos="$(printf "%s" "$nlog" | fmt_nos)"

# Persist wallet/balances
{
  echo "status=${status}"
  echo "queued_pos=${queued}"
  echo "idle_algo=${idle_algo}"
  echo "wallet=${wallet}"
  echo "sol=${sol}"
  echo "nos=${nos}"
} > "${STATE_FILE}.tmp"
mv -f "${STATE_FILE}.tmp" "$STATE_FILE"

# Version string always shown if we have any pieces
ver=""
if [[ -n "${sol:-}" || -n "${nos:-}" || -n "${wallet:-}" ]]; then
  sol4="${sol:-}"; nos3="${nos:-}"; w5=""
  [[ -n "${sol4}" ]] || sol4="$(printf "0.0000")"
  [[ -n "${nos3}" ]] || nos3="$(printf "0.000")"
  [[ -n "${wallet:-}" ]] && w5="$(printf "%s" "$wallet" | short_wallet)"
  ver="S:${sol4} N:${nos3} W:${w5}"
fi

# Default outputs
khs=0
hs_units="hs"
hs_json="[]"
temp_json="[]"
fan_json="[]"
bus_json="[]"
algo="nos - initializing"

# derive status/queued/idle_algo from state or logs
if [[ -z "${status:-}" || "${status:-}" == "initializing" ]]; then
  # try infer
  if printf "%s" "$L" | grep -q " QUEUED "; then
    status="queued"
  fi
fi
if [[ "$status" == "queued" ]]; then
  q=$(printf "%s" "$L" | grep -Eo 'position[[:space:]]+[0-9]+/[0-9]+' | tail -n1 | awk '{print $2}')
  [[ -n "$q" ]] && queued="$q"
fi

# Determine idle algo from idle log
I="$(tail -n 80 "$IDLE_LOG" 2>/dev/null || true)"
if echo "$I" | grep -q "\[XMR\]"; then idle_algo="xmr"
elif echo "$I" | grep -q "\[CUDA\]\|\[AVX"; then idle_algo="qubic"
fi

# Parse idle hashrates
get_avg(){
  # Pull the last "avg it/s" number for a given tag
  tag="$1"
  echo "$I" | grep "$tag" | grep -Eo '[0-9]+[[:space:]]+avg it/s' | awk '{print $1}' | tail -n1
}
get_inst(){
  tag="$1"
  echo "$I" | grep "$tag" | grep -Eo '\[[A-Z0-9]+\][^|]*\|[[:space:]]*[0-9]+ it/s' | awk '{print $NF}' | sed 's/it\/s//' | tail -n1
}

gpu_it=0; cpu_it=0; xmr_it=0

if [[ "$idle_algo" == "xmr" ]]; then
  xmr_it="$(get_avg '[XMR]')"; xmr_it="${xmr_it:-0}"
  # to kH/s
  khs="$(awk -v v="${xmr_it:-0}" 'BEGIN{printf("%.6f", v/1000)}')"
  hs_units="khs"
  hs_json="$(printf '[%s]' "$khs")"
  algo_suffix="idle xmr"
elif [[ "$idle_algo" == "qubic" ]]; then
  gpu_it="$(get_avg '\[CUDA\]')"; gpu_it="${gpu_it:-0}"
  cpu_it="$(get_avg '\[AVX')";  cpu_it="${cpu_it:-0}"
  total_it=$(awk -v a="$gpu_it" -v b="$cpu_it" 'BEGIN{print a+b}')
  khs="$(awk -v v="${total_it:-0}" 'BEGIN{printf("%.6f", v/1000)}')"
  hs_units="hs"
  hs_json="$(printf '[%s,%s]' "${gpu_it:-0}" "${cpu_it:-0}")"
  algo_suffix="idle qubic"
else
  algo_suffix=""
fi

# Bus mapping (GPU only) via gpu-stats JSON, if available
if command -v gpu-stats >/dev/null 2>&1; then
  G=$(gpu-stats 2>/dev/null | tail -n1 || true)
  # Expected JSON fields; tolerate missing
  bus=$(echo "$G" | jq -r '.busids // []' 2>/dev/null || echo "[]")
  brand=$(echo "$G" | jq -r '.brand // []' 2>/dev/null || echo "[]")
  # Map: choose first non-cpu as GPU0 bus number in decimal
  if echo "$brand" | grep -q "nvidia"; then
    b=$(jq -r 'to_entries[] | select(.value!="cpu") | .key' <<<"$brand" 2>/dev/null | head -n1)
    if [[ -n "$b" ]]; then
      hex=$(jq -r ".[$b]" <<<"$bus" 2>/dev/null)
      if [[ "$hex" != "null" && -n "$hex" ]]; then
        # convert "01:00.0" to decimal domain "1"
        dec=$(echo "$hex" | awk -F: '{gsub(/^0+/,"",$1); if($1=="")$1=0; print $1}' )
        bus_json=$(printf '[%s,null]' "$dec")
      fi
    fi
  fi
fi
[[ -z "$bus_json" ]] && bus_json="[]"

# Final algo string per state
case "${status:-initializing}" in
  job)
    khs="1"
    hs_units="khs"
    hs_json="[1]"
    algo="nos - job"
    ;;
  queued)
    algo="nos - queued ${queued:-}"
    [[ -n "$algo_suffix" ]] && algo="$algo - $algo_suffix"
    ;;
  *)
    # initializing
    algo="nos - initializing"
    # If still spinning but we have idle, keep idle hashrate but suppress idle suffix in algo during init?
    # Per user: show 1 kH/s during initializing
    khs="1"
    hs_units="khs"
    hs_json="[1]"
    ;;
esac

# Prepare stats JSON
stats=$(jq -nc \
        --arg khs "$khs" \
        --arg hs_units "$hs_units" \
        --argjson hs "$hs_json" \
        --argjson temp "$temp_json" \
        --argjson fan "$fan_json" \
        --arg uptime "0" \
        --arg ver "$ver" \
        --arg algo "$algo" \
        --argjson bus_numbers "$bus_json" \
        '{$hs, $hs_units, $temp, $fan, $uptime, $ver, $algo, $bus_numbers}')

echo "$khs"
echo "$stats"
