#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

# Paths
RUN_DIR="/var/run"
LOG_DIR="/var/log/miner/nosana"
STATE_FILE="${RUN_DIR}/nosana.state"
IDLE_LOG="${LOG_DIR}/idle.log"
NOSANA_LOG="${LOG_DIR}/nosana.log"
mkdir -p "$LOG_DIR" "$RUN_DIR"

# Seed state file if missing
if [[ ! -f "$STATE_FILE" ]]; then
  {
    echo 'status=initializing'
    echo 'queued_pos='
    echo 'wallet='
    echo 'sol='
    echo 'nos='
    echo 'idle_algo='
  } > "$STATE_FILE"
fi

# export for other scripts
export RUN_DIR LOG_DIR STATE_FILE IDLE_LOG NOSANA_LOG
