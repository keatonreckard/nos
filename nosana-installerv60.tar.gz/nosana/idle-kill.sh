#!/usr/bin/env bash
set -euo pipefail
# Try to kill a known screen/tail if present
pgrep -af "qli-Client" | awk '{print $1}' | xargs -r kill || true
pgrep -af "tail -n0 -F /var/log/miner/nosana/idle.log" | awk '{print $1}' | xargs -r kill || true
exit 0
