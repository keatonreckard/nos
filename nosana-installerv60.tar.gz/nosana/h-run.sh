#!/usr/bin/env bash
set -euo pipefail
# Preserve user's existing setup; do nothing
echo "[nosana] h-run passthrough (leaving existing node startup unchanged)"
exit 0
