#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
STATE_FILE="/var/run/nosana.state"
mkdir -p "$LOG_DIR"

DEBUG="$LOG_DIR/debug.log"
NOSANA_LOG="$LOG_DIR/nosana.log"

log(){ echo "[$(date -Iseconds)] $*" >> "$DEBUG"; }

# Clean previous containers (best-effort)
log "h-run: cleaning previous containers"
if command -v podman >/dev/null 2>&1; then
  : # handled inside sidecar
fi

# Start podman sidecar
log "h-run: starting podman sidecar"
podman run -d --rm --name nosana-podman --privileged --network host --pid host nosana/podman:v1.1.0 >/dev/null 2>&1 || true

# Start nosana node
log "h-run: starting nosana-node container"
# We rely on nosana-cli default command to start; logs will be retrieved via podman logs -f if available.
# Fallback: run it detached; podman required by sidecar
podman run -d --rm --name nosana-node --network host -v /root/.nosana:/root/.nosana nosana/nosana-cli:latest >/dev/null 2>&1 || true

# Mark a "nosana started" timestamp for uptime fallback
date +%s > "$MINER_DIR/nosana.start.time" 2>/dev/null || true

# Background log collector to file if not already running (optional)
if ! pgrep -f "podman logs -f nosana-node" >/dev/null 2>&1; then
  ( podman logs -f nosana-node 2>&1 | sed -u 's/^/[nosana] /' >> "$NOSANA_LOG" ) >/dev/null 2>&1 &
fi

# Start monitor (supervised by Hive's miner loop typically)
nohup bash "$MINER_DIR/monitor.sh" >> "$NOSANA_LOG" 2>&1 & disown || true
