#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
PARSED_DIR="$MINER_DIR/parsed"
mkdir -p "$LOG_DIR" "$PARSED_DIR"

DEBUG="$LOG_DIR/debug.log"

raw=""
# Prefer explicit nosana.conf
if [[ -f "$MINER_DIR/nosana.conf" ]]; then
  raw="$(cat "$MINER_DIR/nosana.conf")"
fi

# Fallback to environment-style extras if present
for v in CUSTOM_MINER_CONFIG CUSTOM_CONFIG EXTRA; do
  if [[ -z "$raw" && -n "${!v:-}" ]]; then
    raw="${!v}"
  fi
done

echo "[$(date -Iseconds)] h-config: RAW_EXTRA length=${#raw}" >> "$DEBUG"

# Extract "command" and "arguments" robustly using sed/grep without requiring strict JSON.
# We look for idleSettings object and then capture "command"/"arguments" values.
idle_cmd="$(echo "$raw" | tr -d '\r' | grep -oP '"command"\s*:\s*"\K[^"]+' 2>/dev/null || true)"
idle_args="$(echo "$raw" | tr -d '\r' | grep -oP '"arguments"\s*:\s*"\K[^"]+' 2>/dev/null || true)"

# If not found, also try a simpler pattern idleSettings: { command: "...", arguments: "..." }
if [[ -z "$idle_cmd" ]]; then
  idle_cmd="$(echo "$raw" | tr -d '\r' | grep -oE 'command[[:space:]]*:[[:space:]]*"[^"]+' | sed -E 's/.*:"//' || true)"
fi
if [[ -z "$idle_args" ]]; then
  idle_args="$(echo "$raw" | tr -d '\r' | grep -oE 'arguments[[:space:]]*:[[:space:]]*"[^"]*' | sed -E 's/.*:"//' || true)"
fi

# Expand %WORKER_NAME% if present
if [[ -n "${idle_args:-}" ]]; then
  idle_args="${idle_args//%WORKER_NAME%/${WORKER_NAME:-worker}}"
fi

# Save parsed results
echo "${idle_cmd:-}" > "$PARSED_DIR/idle_command"
echo "${idle_args:-}" > "$PARSED_DIR/idle_args"

echo "[$(date -Iseconds)] h-config: parsed idle command: ${idle_cmd:-}" >> "$DEBUG"
echo "[$(date -Iseconds)] h-config: parsed idle args: ${idle_args:-}" >> "$DEBUG"
