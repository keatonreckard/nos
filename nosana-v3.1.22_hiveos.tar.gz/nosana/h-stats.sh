#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"

dbg(){ echo "[$(date -Iseconds)] $*" >> "$LOG_DIR/debug.log"; }

# Load state if present
status="nos - initializing"; wallet=""; sol=""; nos=""
if [[ -f "$STATE_FILE" ]]; then
  # shellcheck disable=SC1090
  source "$STATE_FILE" || true
fi

# Wallet/SOL/NOS can be refined from recent logs
if [[ -s "$NOSANA_LOG" ]]; then
  chunk="$(tail -n 400 "$NOSANA_LOG")"
  [[ -z "${wallet:-}" ]] && wallet="$(echo "$chunk" | grep -E '^[[:space:]]*Wallet:' | tail -n1 | sed -E 's/.*Wallet:[[:space:]]*([A-Za-z0-9]{32,})/\1/' || true)"
  [[ -z "${sol:-}"    ]] && sol="$(echo "$chunk" | grep -E '^[[:space:]]*SOL balance:' | tail -n1 | sed -E 's/.*SOL balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/' || true)"
  [[ -z "${nos:-}"    ]] && nos="$(echo "$chunk" | grep -E '^[[:space:]]*NOS balance:' | tail -n1 | sed -E 's/.*NOS balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/' || true)"
fi

fmt4(){
  local v="${1:-}"
  if [[ "$v" =~ ^[0-9]+([.][0-9]+)?$ ]]; then
    printf "%.4f" "$v"
  else
    printf "0.0000"
  fi
}

# Build version string
sol4="$(fmt4 "${sol:-}")"
nos4="$(fmt4 "${nos:-}")"
wshort="$( [[ -n "${wallet:-}" ]] && echo "$wallet" | cut -c1-5 || echo '-----')"
ver="S:${sol4} N:${nos4} W:${wshort}"

# Algo from status
algo="${status:-nos - initializing}"

# Uptime: prefer job/idle/nosana timestamps
now=$(date +%s)
if [[ -f "$MINER_DIR/job.start.time" ]]; then start_time=$(cat "$MINER_DIR/job.start.time")
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then start_time=$(cat "$MINER_DIR/idle.start.time")
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then start_time=$(cat "$MINER_DIR/nosana.start.time")
else start_time=$((now - $(awk '{print int($1)}' /proc/uptime))); fi
uptime=$((now - start_time)); ((uptime<0)) && uptime=0

# GPU env (best effort)
temp_json='[]'; fan_json='[]'; bus_json='[]'
if [[ -f /hive/bin/gpu-stats ]]; then
  # shellcheck disable=SC1091
  source /hive/bin/gpu-stats || true
  if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [[ "${#GPU_FAN[@]:-0}" -gt 0 ]]; then  fan_json="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
  if [[ "${#BUS_IDS[@]:-0}" -gt 0 ]]; then
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

# Idle hashrate passthrough when queued
parse_idle(){
  [[ -s "$IDLE_LOG" ]] || { echo "0|0|0"; return; }
  L="$(tail -n 300 "$IDLE_LOG")"
  # match e.g. "1234.5 kH/s" or "1.23 MH/s" or "99 H/s"
  rate_line="$(echo "$L" | grep -Eio '[0-9]+([.][0-9]+)?[[:space:]]*(H|KH|MH|GH)/s' | tail -n1 || true)"
  khs="0"
  if [[ -n "$rate_line" ]]; then
    num="$(echo "$rate_line" | awk '{print $1}')"
    unit="$(echo "$rate_line" | awk '{print $2}' | tr '[:lower:]' '[:upper:]' | sed 's#/S##')"
    case "$unit" in
      H)  khs=$(printf "%.6f" "$(echo "$num / 1000" | bc -l 2>/dev/null || echo 0)") ;;
      KH) khs=$(printf "%.6f" "$num") ;;
      MH) khs=$(printf "%.6f" "$(echo "$num * 1000" | bc -l 2>/dev/null || echo 0)") ;;
      GH) khs=$(printf "%.6f" "$(echo "$num * 1000000" | bc -l 2>/dev/null || echo 0)") ;;
      *)  khs="0" ;;
    esac
  fi
  echo "${khs}|0|0"
}

khs="0"; ar_acc="0"; ar_rej="0"
if echo "$algo" | grep -qi 'queued'; then
  IFS='|' read -r khs ar_acc ar_rej <<<"$(parse_idle)"
  [[ -z "$khs" || "$khs" == "0" ]] && khs="999"
fi

stats=$(cat <<JSON
{"hs":[${khs}],"hs_units":"khs","temp":${temp_json},"fan":${fan_json},"uptime":${uptime},"ver":"${ver}","ar":[${ar_acc},${ar_rej}],"algo":"${algo}","bus_numbers":${bus_json}}
JSON
)

dbg "h-stats: ver=${ver} | algo=${algo} | khs=${khs} | wallet=${wallet} | sol=${sol} | nos=${nos}"
echo "${stats}"
