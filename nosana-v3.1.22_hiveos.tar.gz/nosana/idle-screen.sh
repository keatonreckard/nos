#!/usr/bin/env bash
LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR"
echo "Tailing idle miner log: $LOG_DIR/idle.log"
exec tail -F "$LOG_DIR/idle.log"
