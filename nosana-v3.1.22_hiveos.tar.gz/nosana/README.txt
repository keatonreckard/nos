Nosana custom miner for HiveOS
Version: 3.1.22

What this does
- Runs Nosana CLI node inside the provided sidecar (podman) and streams logs to /var/log/miner/nosana.
- Detects queue vs job state and shows it on the dashboard (algo).
- Scrapes Wallet / SOL balance / NOS balance from Nosana CLI logs and exposes them in the version string.
- Starts an idle miner while queued. Stops it when a job starts. Hashrate from idle miner passes through to the dashboard; if unknown we report 999 kH/s while queued.
- Emits small status notes into the nosana log (prefixed with [nosana]) that you can watch via agent-screen or miner log.

Files
- h-config.sh     : parse idleSettings and save parsed command/args
- h-run.sh        : start containers (podman sidecar + nosana CLI), set timestamps
- monitor.sh      : watch nosana log, control idle miner, maintain state and notes
- h-stats.sh      : send hashrate/algo/version for dashboard
- idle-screen.sh  : tail idle miner output
- h-manifest.conf : simple manifest (name/version)
- nosana.conf     : example config; you can paste your idleSettings here

Idle settings example (nosana.conf)
idleSettings={"command":"/hive/miners/custom/qubjetski.PPLNS/qli-Client","arguments":" --ClientSettings:PoolAddress=wss://example/ws/ABC --ClientSettings:Alias=%WORKER_NAME% --ClientSettings:AccessToken=YOUR_TOKEN ..."}

Install
  cd /hive/miners/custom
  tar -xzf nosana-v3.1.22_hiveos.tar.gz
  chmod +x nosana/*.sh
  miner stop; sleep 2; miner start

Logs
  /var/log/miner/nosana/nosana.log   (Nosana CLI + monitor notes)
  /var/log/miner/nosana/idle.log     (Idle miner output)
  /var/log/miner/nosana/debug.log    (debug from scripts)

State
  /var/run/nosana.state               (wallet/sol/nos/status/queue/idle flag)
