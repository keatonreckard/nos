#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
PARSED_DIR="$MINER_DIR/parsed"
STATE_FILE="/var/run/nosana.state"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
DEBUG="$LOG_DIR/debug.log"

mkdir -p "$LOG_DIR" "$PARSED_DIR"

note(){ echo "[nosana] $*" | tee -a "$NOSANA_LOG" >/dev/null; }
dbg(){ echo "[$(date -Iseconds)] $*" >> "$DEBUG"; }

get_idle_cmd(){
  local cmd args
  [[ -f "$PARSED_DIR/idle_command" ]] && cmd="$(cat "$PARSED_DIR/idle_command")" || cmd=""
  [[ -f "$PARSED_DIR/idle_args" ]]    && args="$(cat "$PARSED_DIR/idle_args")"    || args=""
  echo "$cmd|$args"
}

is_running(){ ps -p "$1" >/dev/null 2>&1; }

start_idle(){
  local parsed cmd args
  parsed="$(get_idle_cmd)"
  cmd="${parsed%%|*}"; args="${parsed#*|}"
  if [[ -z "$cmd" ]]; then
    dbg "monitor: start_idle requested but no idle command parsed"
    return 0
  fi
  if [[ -f /var/run/idle.pid ]]; then
    local pid; pid="$(cat /var/run/idle.pid || true)"
    if [[ -n "$pid" ]] && is_running "$pid"; then
      return 0
    fi
  fi
  note "start_idle: $cmd $args"
  (stdbuf -oL -eL "$cmd" $args >> "$IDLE_LOG" 2>&1) &
  echo $! > /var/run/idle.pid
  date +%s > "$MINER_DIR/idle.start.time" || true
}

stop_idle(){
  if [[ -f /var/run/idle.pid ]]; then
    local pid; pid="$(cat /var/run/idle.pid || true)"
    if [[ -n "$pid" ]] && is_running "$pid"; then
      note "stop_idle: killing idle miner pid=$pid"
      kill "$pid" >/dev/null 2>&1 || true
      sleep 1
      kill -9 "$pid" >/dev/null 2>&1 || true
    fi
    rm -f /var/run/idle.pid
  fi
}

# Track last queue string to avoid spamming
last_queue=""
last_status=""
wallet=""; sol=""; nos=""

echo "[nosana] monitor started"
dbg "monitor: started"

while true; do
  # Parse nosana log tail
  if [[ -s "$NOSANA_LOG" ]]; then
    chunk="$(tail -n 400 "$NOSANA_LOG")"

    # Scrape balances/wallet
    w_line="$(echo "$chunk" | grep -E '^[[:space:]]*Wallet:' | tail -n1 || true)"
    s_line="$(echo "$chunk" | grep -E '^[[:space:]]*SOL balance:' | tail -n1 || true)"
    n_line="$(echo "$chunk" | grep -E '^[[:space:]]*NOS balance:' | tail -n1 || true)"
    if [[ -n "$w_line" ]]; then wallet="$(echo "$w_line" | sed -E 's/.*Wallet:[[:space:]]*([A-Za-z0-9]{32,})/\1/')"; fi
    if [[ -n "$s_line" ]]; then sol="$(echo "$s_line" | sed -E 's/.*SOL balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/')"; fi
    if [[ -n "$n_line" ]]; then nos="$(echo "$n_line" | sed -E 's/.*NOS balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/')"; fi

    # Detect queue status or job
    status="nos - initializing"
    if echo "$chunk" | grep -Eq 'claimed job|Job .* started|Flow .* is running'; then
      status="nos - job"
    else
      pos="$(echo "$chunk" | grep -E 'position [0-9]+/[0-9]+' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/' || true)"
      if [[ -n "$pos" ]]; then
        status="nos - queued $pos"
      elif echo "$chunk" | grep -Eqi '\bQUEUED\b'; then
        status="nos - queued"
      fi
    fi

    # React to status changes
    if [[ "$status" != "$last_status" ]]; then
      note "status: $status"
      case "$status" in
        nos\ -\ queued*)
          start_idle
          ;;
        nos\ -\ job|nos\ -\ initializing)
          stop_idle
          ;;
      esac
      last_status="$status"
    fi

    # Extract queue text to send one liner
    if [[ "$status" == nos\ -\ queued* && "$status" != "$last_queue" ]]; then
      note "queued $(echo "$status" | sed -E 's/.*queued[[:space:]]+//')"
      last_queue="$status"
    fi

    # Persist state (used by h-stats.sh)
    {
      echo "status=\"$status\""
      echo "queue=\"${status#nos - queued }\""  # may be same as status if no numbers
      echo "wallet=\"${wallet}\""
      echo "sol=\"${sol}\""
      echo "nos=\"${nos}\""
    } > "$STATE_FILE".tmp
    mv -f "$STATE_FILE".tmp "$STATE_FILE"
  fi

  sleep 9
done
