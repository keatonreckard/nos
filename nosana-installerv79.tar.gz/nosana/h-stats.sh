#!/usr/bin/env bash
# robust stats producer for Hive custom miner
# outputs exactly two lines:
#   1) numeric kH/s
#   2) JSON with algo and details
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
IDLE_ACTIVE_FILE="$RUN_DIR/idle.active"
LOG_DIR="/var/log/miner/nosana"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR" >/dev/null 2>&1 || true

# read state file if present (format key=value per line)
read_state() {
  STATE="initializing"; QUEUE_POS=""; MARKET_ID=""
  if [ -f "$STATE_FILE" ]; then
    # shellcheck disable=SC1090
    . "$STATE_FILE" || true
  fi
  IDLE_ACTIVE="0"
  [ -f "$IDLE_ACTIVE_FILE" ] && IDLE_ACTIVE="1"
}

# read idle khs from idle log (best-effort)
idle_khs() {
  # Try to find a pure numeric line (kH/s) near the end
  if [ -f "$IDLE_LOG" ]; then
    tail -n 200 "$IDLE_LOG" 2>/dev/null | sed -nE 's/^[[:space:]]*([0-9]+(\.[0-9]+)?)$/\1/p' | tail -n 1
    if [ "${PIPESTATUS[0]}${PIPESTATUS[1]}${PIPESTATUS[2]}" = "000" ]; then
      return 0
    fi
    # Or parse "... speed ... N H/s"
    local hs
    hs="$(tail -n 200 "$IDLE_LOG" 2>/dev/null | sed -nE 's/.*speed[^0-9]*([0-9]+(\.[0-9]+)?)\s*H\/s.*/\1/p' | tail -n 1)"
    if [ -n "$hs" ]; then
      awk -v v="$hs" 'BEGIN{ printf "%.3f\n", v/1000.0 }'
      return 0
    fi
  fi
  echo "0"
}

read_state

algo_base="nos"
algo="$algo_base"
khs="0"

case "${STATE:-initializing}" in
  initializing)
    algo="${algo_base} - initializing"
    khs="1"
    ;;
  queued)
    if [ "$IDLE_ACTIVE" = "1" ]; then
      # include queue position if known
      if [ -n "${QUEUE_POS:-}" ]; then
        algo="${algo_base} - queued ${QUEUE_POS} - idle xmr"
      else
        algo="${algo_base} - queued - idle xmr"
      fi
      tmpk="$(idle_khs)"; [ -n "$tmpk" ] && khs="$tmpk" || khs="0"
    else
      if [ -n "${QUEUE_POS:-}" ]; then
        algo="${algo_base} - queued ${QUEUE_POS}"
      else
        algo="${algo_base} - queued"
      fi
      khs="0"
    fi
    ;;
  job)
    algo="${algo_base} - job"
    khs="1"
    ;;
  *)
    algo="${algo_base}"
    khs="0"
    ;;
esac

# Build JSON
hs_units="hs"
hs_json="[]"
if [ "$khs" != "0" ]; then
  # 1 kH/s -> 1000 hs
  hs_val="$(awk -v v="$khs" 'BEGIN{ printf "%d\n", v*1000 }')"
  hs_json="[$hs_val]"
fi
# Use epoch seconds for "uptime" field to keep schema stable
uptime="$(date +%s)"
ver=""

# Output:
printf "%s\n" "$khs"
printf '{"hs":%s,"hs_units":"%s","temp":[],"fan":[],"uptime":"%s","ver":"%s","algo":"%s","bus_numbers":[]}\n' \
  "${hs_json}" "${hs_units}" "${uptime}" "${ver}" "${algo}"
