#!/usr/bin/env bash
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/h-stats-wrapper.sh"  # CHANGED
DST="/hive/miners/custom/h-stats.sh"  # CHANGED
install -m 0755 "$SRC" "$DST"  # CHANGED
echo "[nosana] installed stats wrapper -> $DST"  # CHANGED
