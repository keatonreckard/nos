#!/usr/bin/env bash
# nosana/h-stats.sh — defines khs and stats; prints nothing
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
NOSANA_LOG="$LOG_DIR/nosana.log"

escape_json () { printf "%s" "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }  # CHANGED

status="nos - initializing"; queue=""  # CHANGED
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true  # CHANGED
if [[ -z "${queue:-}" && -s "$NOSANA_LOG" ]]; then  # CHANGED
  q=$(tail -n 400 "$NOSANA_LOG" 2>/dev/null | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)  # CHANGED
  [[ -n "$q" ]] && queue="$q"  # CHANGED
fi  # CHANGED

algo="${status:-nos}"  # CHANGED
[[ -n "${queue:-}" ]] && algo="nos - queued ${queue}"  # CHANGED

khs_val="1"  # CHANGED
if [[ "$algo" =~ queued && "${queue:-}" =~ ^([0-9]+)/[0-9]+$ ]]; then  # CHANGED
  khs_val="${BASH_REMATCH[1]}"  # CHANGED
fi  # CHANGED

now=$(date +%s)  # CHANGED
if   [[ -f "$MINER_DIR/job.start.time"  ]]; then start_time=$(cat "$MINER_DIR/job.start.time")  # CHANGED
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then start_time=$(cat "$MINER_DIR/idle.start.time")  # CHANGED
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then start_time=$(cat "$MINER_DIR/nosana.start.time")  # CHANGED
else read -r up _ < /proc/uptime; start_time=$(( now - ${up%.*} )); fi  # CHANGED
uptime=$((now - start_time)); ((uptime<0)) && uptime=0  # CHANGED

ver_parts=()  # CHANGED
[[ -n "${sol:-}"    ]] && { printf -v solf "%.4f" "$sol";  ver_parts+=("S:${solf}"); }  # CHANGED
[[ -n "${nos:-}"    ]] && { printf -v nosf "%.4f" "$nos";  ver_parts+=("N:${nosf}"); }  # CHANGED
[[ -n "${wallet:-}" ]] && ver_parts+=("W:$(printf "%s" "$wallet" | cut -c1-5)")  # CHANGED
ver="$(IFS=' '; echo "${ver_parts[*]-}")"  # CHANGED

temp_json='[]'; fan_json='[]'; bus_json='[]'  # CHANGED
if [[ -f /hive/bin/gpu-stats ]]; then  # CHANGED
  source /hive/bin/gpu-stats || true  # CHANGED
  [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]] && temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"  # CHANGED
  [[ "${#GPU_FAN[@]:-0}"  -gt 0 ]] &&  fan_json="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"  # CHANGED
  if [[ "${#BUS_IDS[@]:-0}"  -gt 0 ]]; then  # CHANGED
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done  # CHANGED
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"  # CHANGED
  fi  # CHANGED
fi  # CHANGED

khs="${khs_val}"  # CHANGED
algo_json="$(escape_json "$algo")"; ver_json="$(escape_json "$ver")"  # CHANGED
stats="{\"hs\":[${khs}],\"hs_units\":\"khs\",\"temp\":${temp_json},\"fan\":${fan_json},\"uptime\":${uptime:-0},\"ver\":\"${ver_json}\",\"algo\":\"${algo_json}\",\"bus_numbers\":${bus_json}}"  # CHANGED
