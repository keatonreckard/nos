#!/usr/bin/env bash
# Delegates to nosana's h-stats so the Hive agent sources vars (no stdout)  # CHANGED
set -euo pipefail  # CHANGED
# shellcheck disable=SC1091  # CHANGED
source /hive/miners/custom/nosana/h-stats.sh  # CHANGED
