#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
IDLE_ACTIVE_FILE="$RUN_DIR/idle.active"
LOG_DIR="/var/log/miner/nosana"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR" >/dev/null 2>&1 || true

read_state() {
  STATE="initializing"; QUEUE_POS=""; MARKET_ID=""
  if [ -f "$STATE_FILE" ]; then
    # shellcheck disable=SC1090
    . "$STATE_FILE"
    # the file may not define all vars; defaults above remain
  fi
  IDLE_ACTIVE="0"
  [ -f "$IDLE_ACTIVE_FILE" ] && IDLE_ACTIVE="1"
}

# Try to parse an idle hashrate in kH/s from last known line (optional)
idle_khs() {
  local kh=""
  # Look for a pure number line (like 19.074000) or "speed" lines from xmrig-like output
  if [ -f "$IDLE_LOG" ]; then
    kh="$(tac "$IDLE_LOG" 2>/dev/null | sed -nE 's/^[[:space:]]*([0-9]+(\.[0-9]+)?)$/\1/p;q')"
    if [ -z "$kh" ]; then
      kh="$(tac "$IDLE_LOG" 2>/dev/null | sed -nE 's/.*speed[^0-9]*([0-9]+(\.[0-9]+)?)\s*H\/s.*/\1/p;q')"
      # convert H/s to kH/s
      if [ -n "$kh" ]; then
        awk -v v="$kh" 'BEGIN{ printf "%.3f\n", v/1000.0 }'
        return
      fi
    fi
  fi
  [ -n "$kh" ] && printf "%s\n" "$kh" || printf "0\n"
}

read_state

algo_base="nos"
algo="$algo_base"
khs="0"

case "${STATE:-initializing}" in
  initializing)
    algo="${algo_base} - initializing"
    khs="1"
    ;;
  queued)
    if [ "${IDLE_ACTIVE}" = "1" ]; then
      algo="${algo_base} - queued ${QUEUE_POS:-} - idle xmr"
      khs="$(idle_khs)"
    else
      algo="${algo_base} - queued ${QUEUE_POS:-}"
      khs="0"
    fi
    ;;
  job)
    algo="${algo_base} - job"
    khs="1"
    ;;
  *)
    algo="${algo_base}"
    khs="0"
    ;;
esac

# Build JSON payload for Hive
# We report a single "device" hashrate array; units in "hs" for compatibility with custom
hs_units="hs"
hs_json="[]"
if [ "$khs" != "0" ]; then
  # represent 1 kH/s as 1000 hs
  hs_val=$(awk -v v="$khs" 'BEGIN{ printf "%d\n", v*1000 }')
  hs_json="[$hs_val]"
fi
uptime="$(awk 'BEGIN{s=systime(); printf "%d\n", s }')"
ver=""

printf "%s\n" "$khs"
# shellcheck disable=SC1117
printf '{"hs":%s,"hs_units":"%s","temp":[],"fan":[],"uptime":"%s","ver":"%s","algo":"%s","bus_numbers":[]}\n' \
  "${hs_json}" "${hs_units}" "${uptime}" "${ver}" "${algo}"
