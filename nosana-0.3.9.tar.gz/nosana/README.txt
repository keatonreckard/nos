Nosana HiveOS wrapper — version 0.3.9
-------------------------------------
This build is the **working** 0.3.6 baseline, version-bumped to 0.3.9, with ONLY these fixes:
- Robust parsing of Wallet / SOL / NOS from nosana.log (line-by-line AND periodic rescan)
- Queue detection ("nos - queued xx/yy"), and idle miner start via idleSettings
- Job detection ("nos - job") and idle miner stop
- Survives wrapper restarts while a job is running by bootstrapping from recent logs
- GPU temps/fans shown on dashboard while job is running
- Version string shows S/N/W and Q when present

Files:
- h-manifest.conf
- h-config.sh
- h-run.sh
- h-stats.sh
- monitor.sh
- nosana.conf (generated at runtime)
Logs:
- /var/log/miner/nosana/nosana.log   (streamed docker logs)
- /var/log/miner/nosana/idle.log     (stdout from idle miner)
- /var/log/miner/nosana/debug.log    (wrapper/monitor notes)
State:
- /var/run/nosana.state (bash vars sourced by h-stats)
