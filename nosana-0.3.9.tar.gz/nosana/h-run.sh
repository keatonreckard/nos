#!/usr/bin/env bash
# Start the nosana node container and the monitor. Keep behavior same as the working 0.3.6.
set -euo pipefail

SELF_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_DIR="/var/log/miner/nosana"
STATE="/var/run/nosana.state"
mkdir -p "$LOG_DIR"
: > "$LOG_DIR/debug.log" || true

log(){ echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')] $*" | tee -a "$LOG_DIR/debug.log" ; }

# Clean previous containers
log "h-run: cleaning previous containers"
docker rm -f nosana-node podman >/dev/null 2>&1 || true

# Start podman sidecar (unchanged from earlier working builds)
log "h-run: starting podman sidecar"
docker volume create podman-cache >/dev/null 2>&1 || true
docker volume create podman-socket >/dev/null 2>&1 || true
docker run -d --pull=always --gpus=all --name podman --device /dev/fuse \
  --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman \
  --privileged -e ENABLE_GPU=true \
  nosana/podman:v1.1.0 unix:/podman/podman.sock >/dev/null 2>&1 || true

# Start nosana-node (no -it; mount /root/.nosana explicitly)
log "h-run: starting nosana-node container"
mkdir -p /root/.nosana
docker run -d --pull=always --name nosana-node --network host \
  --gpus all \
  -v /root/.nosana:/root/.nosana \
  -v podman-socket:/root/.nosana/podman:ro \
  nosana/nosana-cli:latest \
  node start >/dev/null 2>&1 || true

# Stream container logs
( docker logs -f nosana-node >>"$LOG_DIR/nosana.log" 2>&1 ) & disown

# Seed state
{
  echo 'status="nos - initializing"'
  echo 'queue=""'
  echo 'sol=""'
  echo 'nos=""'
  echo 'wallet=""'
  echo 'idle_enabled="0"'
} > "$STATE"

# Start monitor (single instance)
pgrep -f "/nosana/monitor.sh" >/dev/null 2>&1 && kill $(pgrep -f "/nosana/monitor.sh") || true
nohup bash "$SELF_DIR/monitor.sh" >>"$LOG_DIR/debug.log" 2>&1 &
echo "[nosana] monitor started" | tee -a "$LOG_DIR/debug.log"
