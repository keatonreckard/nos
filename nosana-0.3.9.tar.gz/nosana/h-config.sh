#!/usr/bin/env bash
# Generate nosana.conf (VERBOSE=...) and optionally write keypair to /root/.nosana/nosana_key.json
set -euo pipefail
cd "$(dirname "$0")"

mkdir -p /var/log/miner/nosana
CONF_PATH="/hive/miners/custom/nosana/nosana.conf"
RAW_PATH="/hive/miners/custom/nosana/extra.raw"
echo "${CUSTOM_USER_CONFIG:-}" > "$RAW_PATH"

# Extract "keypair":[...] and write it exactly to /root/.nosana/nosana_key.json
KEYPAIR_JSON=$(grep -Eo '"keypair"\s*:\s*\[[^]]+\]' "$RAW_PATH" || true)
if [[ -n "${KEYPAIR_JSON:-}" ]]; then
  mkdir -p /root/.nosana
  echo "${KEYPAIR_JSON#*:}" | sed 's/^[[:space:]]*//' > /root/.nosana/nosana_key.json
  chmod 600 /root/.nosana/nosana_key.json
fi

# Hive will prefix VERBOSE= for custom miners; if user provided raw, normalize to a single VERBOSE= line.
VER_LINE="$(echo "${CUSTOM_USER_CONFIG:-}" | sed -n '1p')"
if [[ "$VER_LINE" != VERBOSE=* ]]; then
  VER_LINE="VERBOSE=${CUSTOM_USER_CONFIG:-}"
fi
echo "$VER_LINE" > "$CONF_PATH"
