#!/usr/bin/env bash
# Monitor nosana.log, manage idle miner, update nosana.state, and rescan periodically for robustness.
set -euo pipefail

LOG_DIR="/var/log/miner/nosana"
NOS_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
STATE="/var/run/nosana.state"
EXTRA="/hive/miners/custom/nosana/extra.raw"

mkdir -p "$LOG_DIR"
touch "$NOS_LOG" "$IDLE_LOG"

ensure_state(){
  [[ -f "$STATE" ]] || {
    {
      echo 'status="nos - initializing"'
      echo 'queue=""'
      echo 'sol=""'
      echo 'nos=""'
      echo 'wallet=""'
      echo 'idle_enabled="0"'
    } > "$STATE"
  }
}
ensure_state

idle_running(){ screen -ls | grep -q '\.nosana-idle' ; }

start_idle(){
  local cmd args
  cmd=$(grep -Eo '"command"\s*:\s*"[^"]+"' "$EXTRA" 2>/dev/null | sed -E 's/.*"\s*:\s*"([^"]+)".*/\1/' | head -n1 || true)
  args=$(grep -Eo '"arguments"\s*:\s*"[^"]+"' "$EXTRA" 2>/dev/null | sed -E 's/.*"\s*:\s*"([^"]+)".*/\1/' | head -n1 || true)
  [[ -z "${cmd:-}" ]] && return 0
  echo "[nosana] idle start: $cmd $args" >> "$IDLE_LOG"
  # Start detached screen for idle miner
  screen -S nosana-idle -dm bash -lc "$cmd $args >>$IDLE_LOG 2>&1"
  sed -i 's/^idle_enabled=.*/idle_enabled="1"/' "$STATE"
}

stop_idle(){
  if idle_running; then screen -S nosana-idle -X quit || true; fi
  sed -i 's/^idle_enabled=.*/idle_enabled="0"/' "$STATE"
}

update_balances_from_text(){
  local txt="$1"
  local w s n
  w=$(echo "$txt" | awk '/^[[:space:]]*Wallet:/{print $2}' | tail -n1)
  s=$(echo "$txt" | awk '/^[[:space:]]*SOL balance:/{print $3}' | tail -n1)
  n=$(echo "$txt" | awk '/^[[:space:]]*NOS balance:/{print $3}' | tail -n1)
  [[ -n "$w" ]] && sed -i "s/^wallet=.*/wallet=\"$w\"/" "$STATE"
  [[ -n "$s" ]] && sed -i "s/^sol=.*/sol=\"$s\"/" "$STATE"
  [[ -n "$n" ]] && sed -i "s/^nos=.*/nos=\"$n\"/" "$STATE"
}

update_queue_from_text(){
  local txt="$1"
  local q
  q=$(echo "$txt" | grep -E 'QUEUED.*position' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/')
  if [[ -n "$q" ]]; then
    sed -i "s/^queue=.*/queue=\"$q\"/" "$STATE"
    sed -i "s/^status=.*/status=\"nos - queued $q\"/" "$STATE"
  fi
}

update_job_status_from_text(){
  local txt="$1"
  if echo "$txt" | grep -qiE 'started successfully|is running|Running container|Node has claimed job'; then
    sed -i 's/^status=.*/status="nos - job"/' "$STATE"
  fi
}

# Bootstrap once at start
bootstrap(){
  local tailtxt
  tailtxt="$(tail -n 400 "$NOS_LOG" 2>/dev/null || true)"
  update_balances_from_text "$tailtxt"
  update_queue_from_text "$tailtxt"
  update_job_status_from_text "$tailtxt"
  # If we're queued and idle miner not running, start it
  if grep -q '^status="nos - queued ' "$STATE" 2>/dev/null; then
    idle_running || start_idle
  fi
  # If we're on a job, ensure idle miner is stopped
  if grep -q '^status="nos - job"' "$STATE" 2>/dev/null; then
    stop_idle
  fi
}
bootstrap

# Periodic rescan to self-heal (every 15s)
(
  while sleep 15; do
    tailtxt="$(tail -n 400 "$NOS_LOG" 2>/dev/null || true)"
    update_balances_from_text "$tailtxt"
    update_queue_from_text "$tailtxt"
    update_job_status_from_text "$tailtxt"
    # Manage idle miner based on status
    if grep -q '^status="nos - queued ' "$STATE" 2>/dev/null; then
      idle_running || start_idle
    elif grep -q '^status="nos - job"' "$STATE" 2>/dev/null; then
      stop_idle
    fi
    echo "[nosana] hb $(date +'%Y-%m-%dT%H:%M:%S%z')" >> "$LOG_DIR/debug.log"
  done
) &

# Realtime log follow to catch transitions ASAP
( tail -n0 -F "$NOS_LOG" & echo $! > /tmp/_nos_tail.pid ) | while IFS= read -r line; do
  case "$line" in
    Wallet:*) update_balances_from_text "$line" ;;
    "SOL balance:"*) update_balances_from_text "$line" ;;
    "NOS balance:"*) update_balances_from_text "$line" ;;
  esac
  if echo "$line" | grep -qE 'QUEUED.*position'; then
    update_queue_from_text "$line"
    idle_running || start_idle
  fi
  if echo "$line" | grep -qiE 'started successfully|is running|Running container|Node has claimed job'; then
    sed -i 's/^status=.*/status="nos - job"/' "$STATE"
    stop_idle
  fi
done
