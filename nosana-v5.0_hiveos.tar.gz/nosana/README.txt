Nosana wrapper v3.1.18: ANSI-stripped sed parsing for wallet/balances; robust algo; docker logs fallback.


---
v5.0 changes:
- Start idle miner automatically when queued (from docker logs).
- Idle logs are interleaved into nosana.log with [idle] prefix, and still saved to idle.log.
- Instant idle kill when a job starts (screen quit + pkill -9).
- Added detailed debug logs for decision path.
