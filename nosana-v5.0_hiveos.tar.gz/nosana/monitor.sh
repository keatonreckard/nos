#!/usr/bin/env bash
set -uo pipefail
export LC_ALL=C
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
DEBUG_LOG="$LOG_DIR/debug.log"
MINER_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
IDLE_PID_FILE="$RUN_DIR/nosana-idle.pid"
mkdir -p "$LOG_DIR" "$RUN_DIR"; touch "$MINER_LOG" "$DEBUG_LOG" "$IDLE_LOG"

IDLE_COMMAND="$(cat "$MINER_DIR/parsed/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$MINER_DIR/parsed/idle_args" 2>/dev/null || true)"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }
logd() { printf "[%s] %s\n" "$(date -Iseconds)" "$1" | tee -a "$DEBUG_LOG" >> "$MINER_LOG"; }

set_state() {
  local key="$1" val="$2"
  local vesc="${val//\\/\\\\}"; vesc="${vesc//\"/\\\"}"
  mkdir -p "$(dirname "$STATE_FILE")"; touch "$STATE_FILE"
  awk -v k="$key" -v v="$vesc" '
    BEGIN{done=0}
    $0 ~ ("^"k"=") { print k"=\""v"\""; done=1; next }
    { print }
    END{ if(!done) print k"=\""v"\"" }
  ' "$STATE_FILE" > "$STATE_FILE.tmp" && mv "$STATE_FILE.tmp" "$STATE_FILE"
}

is_idle_running() {
  screen -ls 2>/dev/null | grep -q '\.nosana-idle' && return 0
  [[ -s "$IDLE_PID_FILE" ]] && kill -0 "$(cat "$IDLE_PID_FILE" 2>/dev/null)" 2>/dev/null && return 0
  pgrep -f -x "$IDLE_COMMAND" >/dev/null 2>&1 && return 0
  return 1
}

start_idle() {
  if [[ -z "${IDLE_COMMAND:-}" ]]; then
    logd "[idle] not starting: IDLE_COMMAND empty (set via idleSettings.command)"
    return 1
  fi
  if is_idle_running; then
    return 0
  fi
  logd "[idle] starting: ${IDLE_COMMAND} ${IDLE_ARGS}"
  # Use screen session for user to attach (idle-screen.sh). Interleave logs into miner log.
  # The pipeline shows in screen, appends to idle.log, and tags into nosana.log.
  screen -dmS nosana-idle bash -lc '
    set -o pipefail
    stdbuf -oL -eL '"$IDLE_COMMAND $IDLE_ARGS"' 2>&1 \
      | tee -a "'"$IDLE_LOG"'" \
      | sed -u "s/^/[idle] /" >> "'"$MINER_LOG"'"
  '

  # Save screen PID if available
  sleep 0.2
  local_sid="$(screen -ls 2>/dev/null | awk "/\.nosana-idle/ {print \$1}" | head -n1)"
  if [[ -n "$local_sid" ]]; then
    echo "${local_sid%%.*}" > "$IDLE_PID_FILE" || true
  fi
  # Mark idle start time for uptime calculation
  date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
  msg "NOS: idle miner started"
  logd "[idle] started OK (sid=${local_sid:-unknown})"
}

kill_idle_fast() {
  if is_idle_running; then
    logd "[idle] killing idle miner ASAP (job started)"
    # Kill screen session and any remaining process matching the command
    screen -S nosana-idle -X quit >/dev/null 2>&1 || true
    pkill -9 -f -- "$IDLE_COMMAND" >/dev/null 2>&1 || true
    if [[ -s "$IDLE_PID_FILE" ]]; then
      kill -9 "$(cat "$IDLE_PID_FILE" 2>/dev/null)" >/dev/null 2>&1 || true
      rm -f "$IDLE_PID_FILE"
    fi
    rm -f "$MINER_DIR/idle.start.time"
    msg "NOS: idle miner stopped"
  fi
}

# Initial state
date +%s > "$MINER_DIR/nosana.start.time"
set_state status "nos - initializing"
echo "[nosana] monitor started" | tee -a "$MINER_LOG"; msg "NOS: monitor started"

bootstrap() {
  local bootlog
  bootlog="$(docker logs --since 60m nosana-node 2>&1 || true)"
  [[ -n "$bootlog" ]] && printf "%s\n" "$bootlog" | tee -a "$MINER_LOG"
  if printf '%s\n' "$bootlog" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
    set_state status "nos - queued"; msg "NOS: queued"
    start_idle || true
  elif printf '%s\n' "$bootlog" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
    set_state status "nos - job"; msg "NOS: job"
    kill_idle_fast
    date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
  fi
}
bootstrap

last_pos=""
# Tight loop for fast reaction
while true; do
  logchunk="$(docker logs --since 1s nosana-node 2>&1 || true)"
  if [[ -n "$logchunk" ]]; then
    printf "%s\n" "$logchunk" | tee -a "$MINER_LOG"
    if echo "$logchunk" | grep -Eq "position [0-9]+/[0-9]+"; then
      pos="$(echo "$logchunk" | grep -E 'position [0-9]+/[0-9]+' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/')"
      [[ -n "$pos" && "$pos" != "$last_pos" ]] && { echo "[nosana] queued ${pos}" | tee -a "$MINER_LOG"; msg "NOS: queued ${pos}"; last_pos="$pos"; }
      set_state status "nos - queued ${pos}"
      start_idle || true
    fi
    if echo "$logchunk" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
      set_state status "nos - job"; date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"; msg "NOS: job started"
      kill_idle_fast
    fi
    if echo "$logchunk" | grep -Eq "Nosana Node finished|Job .* completed|finished successfully|Flow .* (finished|completed)"; then
      echo "[nosana] job finished" | tee -a "$MINER_LOG"; msg "NOS: job finished"
    fi
  fi
  sleep 1
done
