Nosana wrapper v3.1.10 (HiveOS custom miner)
- Fixed monitor.sh quoting and simplified parsing (no stray tokens).
- h-stats.sh scrapes wallet/SOL/NOS; omits missing parts (no N/A).
- Status changes (queued/job) trigger balance refresh; idle passthrough or 999 kH/s.
- Idle miner log is spliced into main miner log for MOTD.
