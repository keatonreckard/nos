#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
CONF_FILE="$MINER_DIR/nosana.conf"
RAW_EXTRA_FILE="$MINER_DIR/extra.raw"
PARSED_DIR="$MINER_DIR/parsed"
KEY_FILE="/root/.nosana/nosana_key.json"

mkdir -p "$MINER_DIR" "$LOG_DIR" "$PARSED_DIR" "$RUN_DIR"
chmod 755 "$MINER_DIR"
touch "$LOG_DIR/nosana.log" "$LOG_DIR/debug.log" "$LOG_DIR/idle.log"

: "${CUSTOM_USER_CONFIG:=}"

# Save raw config exactly as passed
printf '%s' "$CUSTOM_USER_CONFIG" > "$CONF_FILE"
printf '%s' "$CUSTOM_USER_CONFIG" > "$RAW_EXTRA_FILE"

# Extract idle settings from either a bare snippet or a JSON object
RAW="$CUSTOM_USER_CONFIG"
TRIMMED="$(printf '%s' "$RAW" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"

if printf '%s' "$TRIMMED" | grep -q '"idleSettings"'; then
  if printf '%s' "$TRIMMED" | grep -q '^{'; then
    EXTRA_JSON="$TRIMMED"
  else
    EXTRA_JSON="{$TRIMMED}"
  fi
else
  EXTRA_JSON="{}"
fi

IDLE_COMMAND=$(printf '%s' "$EXTRA_JSON" | tr '\n' ' ' | sed -n 's/.*"idleSettings"[[:space:]]*:[[:space:]]*{[^}]*"command"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)
IDLE_ARGS=$(printf '%s' "$EXTRA_JSON" | tr '\n' ' ' | sed -n 's/.*"idleSettings"[[:space:]]*:[[:space:]]*{[^}]*"arguments"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)

printf '%s' "$IDLE_COMMAND" > "$PARSED_DIR/idle_command"
printf '%s' "$IDLE_ARGS"    > "$PARSED_DIR/idle_args"

# Init state
cat > "$STATE_FILE" <<EOF
status="nos - initializing"
queue=""
sol=""
nos=""
wallet=""
idle_enabled="$( [[ -n "$IDLE_COMMAND" ]] && echo 1 || echo 0 )"
EOF
chmod 664 "$STATE_FILE"

{
  echo "[$(date -Iseconds)] h-config: RAW_EXTRA length=$(printf %s "$RAW" | wc -c)"
  echo "[$(date -Iseconds)] h-config: parsed idle command: $IDLE_COMMAND"
  echo "[$(date -Iseconds)] h-config: parsed idle args:    $IDLE_ARGS"
} >> "$LOG_DIR/debug.log"

date +%s > "$MINER_DIR/nosana.start.time"
exit 0
