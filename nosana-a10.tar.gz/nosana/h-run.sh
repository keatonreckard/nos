#!/usr/bin/env bash
set -euo pipefail
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
DEBUG_LOG="$LOG_DIR/debug.log"
mkdir -p "$LOG_DIR"
touch "$LOG_DIR/nosana.log" "$DEBUG_LOG" "$LOG_DIR/idle.log"
# --- NOSANA MOTD panes: ensure single tees for node/idle logs ---
# Cleanup old tails
for f in /run/hive/.nosana_node_tail.pid /run/hive/.nosana_idle_tail.pid; do
  if [[ -f "$f" ]]; then pid="$(cat "$f" 2>/dev/null || true)"; [[ -n "$pid" ]] && kill "$pid" >/dev/null 2>&1 || true; rm -f "$f"; fi
done
# Truncate panes
: > /run/hive/miner.1 || true
: > /run/hive/miner.2 || true
# Start guarded tees
NODE_TEE_LOCK="/run/hive/.nosana_node_tail.lock"
(
  flock -n 9 || exit 0
  nohup stdbuf -oL tail -n 300 -F "$LOG_DIR/nosana.log" | \
  stdbuf -oL grep -a -v -E '\[XMR\]|SHARES:|Trainer:|\srx/|qubic|QUBIC|AVX|CUDA' \
  > /run/hive/miner.1 2>/dev/null & echo $! > /run/hive/.nosana_node_tail.pid
) 9>"$NODE_TEE_LOCK"

IDLE_TEE_LOCK="/run/hive/.nosana_idle_tail.lock"
(
  flock -n 9 || exit 0
  nohup stdbuf -oL tail -n 200 -F "$LOG_DIR/idle.log" \
  > /run/hive/miner.2 2>/dev/null & echo $! > /run/hive/.nosana_idle_tail.pid
) 9>"$IDLE_TEE_LOCK"
# --- end MOTD tees ---

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

echo "[$(date -Iseconds)] h-run: cleaning previous containers" | tee -a "$DEBUG_LOG"
docker rm -f nosana-node podman >/dev/null 2>&1 || true
pkill -9 -f "podman system service" 2>/dev/null || true
docker container prune -f >/dev/null 2>&1 || true

docker volume inspect podman-cache >/dev/null 2>&1 || docker volume create podman-cache >/dev/null
docker volume inspect podman-socket >/dev/null 2>&1 || docker volume create podman-socket >/dev/null

echo "[$(date -Iseconds)] h-run: starting podman sidecar" | tee -a "$DEBUG_LOG"
docker run -d --pull=always --gpus=all --name podman --device /dev/fuse \
  --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman --privileged -e ENABLE_GPU=true \
  nosana/podman:v1.1.0 unix:/podman/podman.sock >> "$DEBUG_LOG" 2>&1 || true
sleep 5

echo "[$(date -Iseconds)] h-run: starting nosana-node container" | tee -a "$DEBUG_LOG"
msg "NOS: node starting"
docker run -d --pull=always --name nosana-node --network host --gpus=all \
  --volume /root/.nosana/:/root/.nosana/ \
  --volume podman-socket:/root/.nosana/podman:ro \
  -e CLI_VERSION= nosana/nosana-cli:latest \
  node start --network "${SOL_NET_ENV:=mainnet}" >> "$DEBUG_LOG" 2>&1 || true
sleep 2
msg "NOS: node container launched"

exec bash "$MINER_DIR/monitor.sh"
