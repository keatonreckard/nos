#!/usr/bin/env bash
# nosana/h-stats.sh
# IMPORTANT: This file is *sourced* by the Hive agent (via /hive/miners/custom/h-stats.sh).
# It MUST print nothing. It must define:
#   - khs   : numeric total rate (1 while initializing/in job; queue position when queued)
#   - stats : full JSON string with hs, hs_units, temp, fan, uptime, ver, algo, bus_numbers (no "ar")
set -euo pipefail
export LC_ALL=C

# Avoid polluting stdout: DO NOT echo/printf anything in this script.
# Read-only paths
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

# Helper to escape JSON strings safely
_escape_json() {
  printf "%s" "${1:-}" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""
if [[ -f "$STATE_FILE" ]]; then
  # shellcheck disable=SC1090
  source "$STATE_FILE" || true
fi

# Collect recent logs (no output)
CLEAN=""
if [[ -s "$NOSANA_LOG" ]]; then
  CLEAN="$(tail -n 3000 "$NOSANA_LOG" | tr -d '\r' | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"
fi

# Extract wallet (best effort)
if [[ -z "${wallet:-}" && -n "$CLEAN" ]]; then
  wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
  [[ -z "${wallet:-}" ]] && wallet="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*(Public[[:space:]]*Key|Pubkey|Address)[[:space:]]*:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\2/p' | tail -n1)"
fi

# Balances (S/N fields)
if [[ -z "${sol:-}" && -n "$CLEAN" ]]; then
  sol="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
if [[ -z "${nos:-}" && -n "$CLEAN" ]]; then
  nos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi

# Determine human status (algo) and queue
algo="${status:-nos}"
if [[ -n "$CLEAN" ]]; then
  if printf "%s\n" "$CLEAN" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
    algo="nos - job"; queue=""
  else
    qpos="$(printf "%s\n" "$CLEAN" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
    if [[ -n "$qpos" ]]; then
      algo="nos - queued ${qpos}"; queue="$qpos"
    elif printf "%s\n" "$CLEAN" | grep -Eqi 'QUEUED'; then
      algo="nos - queued"
    fi
  fi
fi

# Uptime
now=$(date +%s)
if [[ -f "$MINER_DIR/job.start.time" ]]; then
  start_time=$(cat "$MINER_DIR/job.start.time")
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then
  start_time=$(cat "$MINER_DIR/idle.start.time")
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then
  start_time=$(cat "$MINER_DIR/nosana.start.time")
else
  read -r up _ < /proc/uptime
  start_time=$(( now - ${up%.*} ))
fi
uptime=$((now - start_time)); ((uptime<0)) && uptime=0

# GPU arrays (silent)
temp_json='[]'; fan_json='[]'; bus_json='[]'
if [[ -f /hive/bin/gpu-stats ]]; then
  # shellcheck disable=SC1091
  source /hive/bin/gpu-stats || true
  if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [[ "${#GPU_FAN[@]:-0}"  -gt 0 ]]; then  fan_json="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
  if [[ "${#BUS_IDS[@]:-0}"  -gt 0 ]]; then
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

# Build version string
ver_str=""
if [[ -n "${sol:-}" ]]; then printf -v solf "%.4f" "$sol"; ver_str+="S:${solf}"; fi
if [[ -n "${nos:-}" ]]; then printf -v nosf "%.4f" "$nos"; ver_str+="${ver_str:+ }N:${nosf}"; fi
if [[ -n "${wallet:-}" ]]; then ver_str+="${ver_str:+ }W:$(printf "%s" "$wallet" | cut -c1-5)"; fi

# khs rule: 1 while initializing or in a job; queue position number when queued
khs="1"
if echo "$algo" | grep -qi 'queued' && [[ -n "${queue:-}" ]]; then
  # queue like "3/6" -> take leading number
  qn="$(printf "%s" "$queue" | awk -F'/' '{print $1}')"
  if [[ "$qn" =~ ^[0-9]+$ ]]; then khs="$qn"; fi
fi

# Final JSON (no "ar" field; sanitized numeric hs)
algo_j="$(_escape_json "$algo")"
ver_j="$(_escape_json "$ver_str")"
stats="{\"hs\":[${khs}],\"hs_units\":\"khs\",\"temp\":${temp_json},\"fan\":${fan_json},\"uptime\":${uptime:-0},\"ver\":\"${ver_j}\",\"algo\":\"${algo_j}\",\"bus_numbers\":${bus_json}}"
