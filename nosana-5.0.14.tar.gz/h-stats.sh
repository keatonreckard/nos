#!/usr/bin/env bash
# nosana h-stats.sh — robust JSON for HiveOS custom miner panel
# - When NOS job is running: report 1 kH (avoids 0 issues)
# - When queued & no idle miner hashrate: use queue position as kH (e.g., 12/25 -> 12 kH)
# - Never output slashes in numbers; always numeric JSON with hs:[cur,avg]
# - Defensive defaults: ar:[0,0], temps/fans/bus may be empty arrays
# - Idle hashrate parser supports it/s, H/s, KH/s, MH/s, GH/s

set -euo pipefail
export LC_ALL=C

# --- Paths & logging ---
MINER_DIR="/hive/miners/custom/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"

mkdir -p "$LOG_DIR"
exec 3>&1                      # stdout copy (for final JSON)
exec 1>>"$LOG_DIR/debug.log"   # log stdout to file
exec 2>>"$LOG_DIR/debug.log"   # log stderr to file

# --- Helpers ---
trim() { sed 's/^[[:space:]]*//;s/[[:space:]]*$//' ; }
is_num() { [[ "$1" =~ ^[0-9]+([.][0-9]+)?$ ]]; }

to_khs_from_unit() {
  # $1=value, $2=unit (already uppercased, unit sans "/S")
  local v="${1:-0}" u="${2:-}"
  if ! is_num "$v"; then echo "0"; return; fi
  case "$u" in
    IT)   printf "%s" "$v" ;;                      # treat it/s as kH/s
    H)    awk -v x="$v" 'BEGIN{printf("%.6f", x/1000)}' ;;
    KH)   printf "%s" "$v" ;;
    MH)   awk -v x="$v" 'BEGIN{printf("%.6f", x*1000)}' ;;
    GH)   awk -v x="$v" 'BEGIN{printf("%.6f", x*1000*1000)}' ;;
    *)    printf "0" ;;
  esac
}

parse_idle_stats() {
  # Emits: khs|accepted|rejected  (numbers only)
  [[ -s "$IDLE_LOG" ]] || { echo "0|0|0"; return; }
  local tail_lines line val unit khs="0" acc="0" rej="0"
  tail_lines="$(tail -n 500 "$IDLE_LOG" | tr -d '\r')"

  # Find latest hashrate-like token
  line="$(printf "%s\n" "$tail_lines" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(it|h|kh|mh|gh)\/s' | tail -n1)"
  if [[ -n "${line:-}" ]]; then
    val="$(printf "%s" "$line" | sed -nE 's/^([0-9]+(\.[0-9]+)?).*/\1/p')"
    unit="$(printf "%s" "$line" | sed -nE 's/^[0-9]+(\.[0-9]+)?[[:space:]]*([[:alpha:]]+).*/\2/p' | tr '[:lower:]' '[:upper:]' | sed 's/S$//')"
    khs="$(to_khs_from_unit "${val:-0}" "${unit:-}")"
  fi

  # Shares A:R patterns
  if printf "%s\n" "$tail_lines" | grep -Eq '([0-9]+/[0-9]+|A:[0-9]+)'; then
    if printf "%s\n" "$tail_lines" | grep -Eo '([0-9]+)/([0-9]+)' >/dev/null; then
      local pair
      pair="$(printf "%s\n" "$tail_lines" | grep -Eo '([0-9]+)/([0-9]+)' | tail -n1)"
      acc="${pair%%/*}"; rej="${pair##*/}"
    else
      acc="$(printf "%s\n" "$tail_lines" | grep -Eo 'A:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)"
      rej="$(printf "%s\n" "$tail_lines" | grep -Eo 'R:[0-9]+' | tail -n1 | cut -d: -f2 2>/dev/null || echo 0)"
    fi
  fi

  # Ensure numeric
  is_num "$khs" || khs="0"
  [[ "$acc" =~ ^[0-9]+$ ]] || acc="0"
  [[ "$rej" =~ ^[0-9]+$ ]] || rej="0"
  echo "${khs}|${acc}|${rej}"
}

json_escape() {
  # Escape quotes/backslashes/newlines for JSON strings
  sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e ':a;N;$!ba;s/\n/\\n/g'
}

# --- Gather (cleaned) nosana log ---
clean=""
if [[ -s "$NOSANA_LOG" ]]; then
  clean="$(tail -n 3000 "$NOSANA_LOG" | tr -d '\r' | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"
else
  # Fallback to container logs if available
  if command -v docker >/dev/null 2>&1; then
    cont="$(docker logs --since 10m nosana-node 2>/dev/null || true)"
    [[ -n "${cont:-}" ]] && clean="$(printf "%s" "$cont" | tr -d '\r' | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g')"
  fi
fi

# --- Determine status & queue position ---
status="nos - initializing"
queue_pos=""
if printf "%s\n" "$clean" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
  status="nos - job"
else
  qp="$(printf "%s\n" "$clean" | sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' | tail -n1)"
  if [[ -n "${qp:-}" ]]; then
    status="nos - queued ${qp}"
    queue_pos="${qp}"
  elif printf "%s\n" "$clean" | grep -Eqi 'QUEUED'; then
    status="nos - queued"
  fi
fi

# --- Uptime calculation ---
now=$(date +%s)
if [[ -f "$MINER_DIR/job.start.time" ]]; then
  start_time=$(cat "$MINER_DIR/job.start.time")
elif [[ -f "$MINER_DIR/idle.start.time" ]]; then
  start_time=$(cat "$MINER_DIR/idle.start.time")
elif [[ -f "$MINER_DIR/nosana.start.time" ]]; then
  start_time=$(cat "$MINER_DIR/nosana.start.time")
else
  read -r up _ < /proc/uptime
  start_time=$(( now - ${up%.*} ))
fi
uptime=$((now - start_time)); ((uptime<0)) && uptime=0

# --- Wallet/balances (optional fields for ver) ---
wallet="$(printf "%s\n" "$clean" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$clean" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
fi
sol="$(printf "%s\n" "$clean" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
nos="$(printf "%s\n" "$clean" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
ver=""
if [[ -n "${sol:-}" ]]; then printf -v solf "%.4f" "$sol"; ver+="S:${solf}"; fi
if [[ -n "${nos:-}" ]]; then printf -v nosf "%.4f" "$nos"; ver+="${ver:+ }N:${nosf}"; fi
if [[ -n "${wallet:-}" ]]; then ver+="${ver:+ }W:$(printf "%s" "$wallet" | cut -c1-5)"; fi

# --- GPU info (best-effort) ---
temp_json='[]'; fan_json='[]'; bus_json='[]'
if [[ -f /hive/bin/gpu-stats ]]; then
  # shellcheck disable=SC1091
  source /hive/bin/gpu-stats || true
  if [[ "${#GPU_TEMP[@]:-0}" -gt 0 ]]; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [[ "${#GPU_FAN[@]:-0}" -gt 0 ]]; then  fan_json ="["$(printf "%s," "${GPU_FAN[@]}"  | sed 's/,$//')"]"; fi
  if [[ "${#BUS_IDS[@]:-0}" -gt 0 ]]; then
    bus_list=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); bus_list+=("$d"); done
    bus_json="["$(printf "%s," "${bus_list[@]}" | sed 's/,$//')"]"
  fi
fi

# --- Compute hashrate (kH/s) with requested defaults ---
khs="0"; acc="0"; rej="0"
if echo "$status" | grep -qi 'job'; then
  # While an actual NOS job is running, show 1 kH to avoid 0-related issues
  khs="1"
else
  # Queued (or idle). Try idle miner numbers first.
  IFS='|' read -r idle_khs idle_acc idle_rej <<<"$(parse_idle_stats)"
  if is_num "${idle_khs:-}"; then khs="${idle_khs}"; fi
  if [[ "${idle_acc:-}" =~ ^[0-9]+$ ]]; then acc="${idle_acc}"; fi
  if [[ "${idle_rej:-}" =~ ^[0-9]+$ ]]; then rej="${idle_rej}"; fi

  # If idle_khs missing/zero, fall back to queue position (X/Y -> X kH)
  if ! is_num "$khs" || awk -v x="$khs" 'BEGIN{exit !(x==0)}'; then
    if [[ -n "${queue_pos:-}" && "$queue_pos" =~ ^([0-9]+)/([0-9]+)$ ]]; then
      khs="${BASH_REMATCH[1]}"
    else
      khs="1"   # last resort non-zero
    fi
  fi
fi

# Ensure khs is numeric and >0
if ! is_num "$khs"; then khs="1"; fi
# Convert any floating tiny values to at least 1 kH
khs_int="$(awk -v x="$khs" 'BEGIN{v=int(x+0.5); if(v<1)v=1; print v}')"

# hs is [current, average] — we mirror the same value to avoid “x/y” formatting.
hs_field="[%s,%s]"
hs_json=$(printf "$hs_field" "$khs_int" "$khs_int")

# Shares array
ar_json="[$acc,$rej]"

# Build final JSON
algo_str="$(printf "%s" "$status" | json_escape)"
ver_str="$(printf "%s" "$ver" | json_escape)"

printf '[%s] h-stats: algo="%s" khs=%s ar=%s\n' "$(date -Iseconds)" "$status" "$khs_int" "$ar_json" 1>&1

printf '{"hs":%s,"hs_units":"khs","temp":%s,"fan":%s,"uptime":%s,"ver":"%s","ar":%s,"algo":"%s","bus_numbers":%s}\n' \
  "$hs_json" "$temp_json" "$fan_json" "$uptime" "$ver_str" "$ar_json" "$algo_str" "$bus_json" 1>&3
