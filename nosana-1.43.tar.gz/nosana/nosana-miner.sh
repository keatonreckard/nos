#!/bin/bash
# Nosana Miner Wrapper for HiveOS
log_std() { echo "$1" >> /tmp/nosana-miner.log; }
log_err() { echo "$1" >> /tmp/nosana-miner.log; }

DOCKER_IMAGE="nosana/nosana-cli:latest"
PODMAN_IMAGE="nosana/podman:v1.1.0"
LOG_FILE="/run/hive/miner.1"
NOSANA_HOME="/root/.nosana"
CONF_FILE="/hive/miners/custom/nosana/nosana.conf"
PID_FILE="/tmp/nosana-pid"
MINER_RUNNING="/tmp/nosana-miner-running"

# Kill previous instance if PID file exists
if [ -f "$PID_FILE" ]; then
  PREVIOUS_PID=$(cat "$PID_FILE")
  log_std "Killing previous PID $PREVIOUS_PID..."
  kill -9 "$PREVIOUS_PID" 2>/dev/null
  rm -f "$PID_FILE"
fi

# Write current PID
echo $$ > "$PID_FILE"
trap 'rm -f "$PID_FILE"; exit' EXIT INT TERM

if [ -f "$CONF_FILE" ]; then
  source "$CONF_FILE" 2>/dev/null
  if [ -n "$VERBOSE" ]; then
    IDLE_CMD=$(echo "$VERBOSE" | jq -r '.idleSettings.command // empty' 2>/dev/null)
    IDLE_ARGS=$(echo "$VERBOSE" | jq -r '.idleSettings.arguments // empty' 2>/dev/null)
  fi
  KEYPAIR_FROM_CONFIG=$(echo "$VERBOSE" | jq -r '.keypair // empty' 2>/dev/null)
fi

if ! lsb_release -a 2>/dev/null | grep -q "Ubuntu 20.04\|Ubuntu 22.04\|Ubuntu 24.04"; then
  log_err "Requires Ubuntu 20.04, 22.04, or 24.04."
  exit 1
fi
log_std "✅ Ubuntu compatible."

if ! command -v curl >/dev/null 2>&1 || ! command -v wget >/dev/null 2>&1 || ! command -v gnupg >/dev/null 2>&1 || ! command -v lsb-release >/dev/null 2>&1 || ! command -v jq >/dev/null 2>&1; then
  log_std "Installing tools..."
  apt update > /dev/null 2>&1
  apt install -y curl wget gnupg lsb-release jq > /dev/null 2>&1
fi

if ! command -v docker >/dev/null 2>&1; then
  log_std "Installing Docker..."
  curl -fsSL https://get.docker.com -o get-docker.sh
  sh get-docker.sh > /dev/null 2>&1
  usermod -aG docker root
  systemctl enable docker
  systemctl start docker
else
  log_std "✅ Docker installed."
fi

if ! command -v nvidia-smi >/dev/null 2>&1; then
  log_std "Installing NVIDIA drivers..."
  wget https://us.download.nvidia.com/XFree86/Linux-x86_64/$(curl -s https://www.nvidia.com/Download/API/lastestdriver.aspx | grep -oP 'version=\K[\d\.]+' | head -n 1)/NVIDIA-Linux-x86_64-$(curl -s https://www.nvidia.com/Download/API/lastestdriver.aspx | grep -oP 'version=\K[\d\.]+' | head -n 1).run -O NVIDIA.run
  chmod +x NVIDIA.run
  ./NVIDIA.run --silent --no-questions > /dev/null 2>&1
else
  log_std "✅ NVIDIA drivers installed."
fi

if ! command -v nvidia-ctk >/dev/null 2>&1; then
  log_std "Installing NVIDIA Container Toolkit..."
  curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
  curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
  apt-get update > /dev/null 2>&1
  apt-get install -y nvidia-container-toolkit > /dev/null 2>&1
  nvidia-ctk runtime configure --runtime=docker > /dev/null 2>&1
  systemctl restart docker
else
  log_std "✅ NVIDIA Container Toolkit installed."
fi
log_std "✅ NVIDIA Container Toolkit configured."

if ! docker volume ls | grep -q podman-cache; then
  docker volume create podman-cache > /dev/null 2>&1
fi
if ! docker volume ls | grep -q podman-socket; then
  docker volume create podman-socket > /dev/null 2>&1
fi

log_std "Killing all containers and processes..."
docker kill $(docker ps -q) 2>/dev/null || true
docker rm -f $(docker ps -aq) 2>/dev/null || true
killall -9 podman nosana-cli 2>/dev/null || true
pkill -9 -f "docker run.*nosana-node" 2>/dev/null || true
pkill -9 -f "docker run.*podman" 2>/dev/null || true

log_std "🔥 Starting podman..."
docker run -d --pull=always --gpus=all --name podman --device /dev/fuse --mount source=podman-cache,target=/var/lib/containers --volume podman-socket:/podman --privileged -e ENABLE_GPU=true "$PODMAN_IMAGE" unix:/podman/podman.sock > /tmp/podman-start.log 2>&1
if [ $? -ne 0 ]; then
  log_err "Podman failed. Check /tmp/podman-start.log:"
  cat /tmp/podman-start.log >> /tmp/nosana-miner.log
  exit 1
fi
log_std "Podman started."
sleep 5

if [ -n "$KEYPAIR_FROM_CONFIG" ]; then
  log_std "🔥 Using provided keypair..."
  mkdir -p "$NOSANA_HOME"
  echo "{\"keypair\": \"$KEYPAIR_FROM_CONFIG\"}" > "$NOSANA_HOME/nosana_key.json"
  log_std "✅ Keypair set."
elif [ ! -f "$NOSANA_HOME/nosana_key.json" ]; then
  log_std "🔥 Generating keypair..."
  mkdir -p "$NOSANA_HOME"
  OUTPUT=$(docker run --rm -v "$NOSANA_HOME:/root/.nosana" "$DOCKER_IMAGE" keygen 2>&1)
  if [ $? -ne 0 ]; then
    log_err "Keygen failed: $OUTPUT"
    exit 1
  fi
  echo "$OUTPUT" > "$NOSANA_HOME/nosana_key.json"
  if [ -z "$(jq -r '.keypair' "$NOSANA_HOME/nosana_key.json" 2>/dev/null)" ]; then
    log_err "Invalid keypair. Contents: $(cat "$NOSANA_HOME/nosana_key.json" 2>/dev/null)"
    exit 1
  fi
  log_std "✅ Keypair generated."
else
  log_std "✅ Using existing keypair."
fi

log_std "Starting node..."
docker run -d --pull=always --name nosana-node --network host --volume "$NOSANA_HOME:/root/.nosana" --volume podman-socket:/root/.nosana/podman:ro "$DOCKER_IMAGE" node start --network mainnet > /tmp/nosana-node-start.log 2>&1
if [ $? -ne 0 ]; then
  log_err "Node start failed. Check /tmp/nosana-node-start.log:"
  cat /tmp/nosana-node-start.log >> /tmp/nosana-miner.log
  exit 1
fi
sleep 10
if ! docker ps -q -f name=nosana-node | grep -q .; then
  log_err "Node failed. Logs: $(docker logs nosana-node 2>/dev/null || echo 'No logs')"
  cat /tmp/nosana-node-start.log >> /tmp/nosana-miner.log
  exit 1
fi
log_std "Node started."

docker logs -f nosana-node > "$LOG_FILE" 2>&1 &
LOGS_PID=$!

WALLET=$(jq -r '.keypair // "unknown"' "$NOSANA_HOME/nosana_key.json" 2>/dev/null)
if [ "$WALLET" = "unknown" ]; then
  log_err "Wallet read failed: $(cat "$NOSANA_HOME/nosana_key.json" 2>/dev/null)"
fi

while true; do
  if ! docker ps -q -f name=nosana-node | grep -q .; then
    log_err "Node stopped."
    kill $LOGS_PID 2>/dev/null
    exit 1
  fi

  SOL=$(grep -oP 'SOL balance:\s*\K[\d.]+(?=\s*SOL)' "$LOG_FILE" | head -n 1 || echo "unknown")
  NOS=$(grep -oP 'NOS balance:\s*\K[\d.]+(?=\s*NOS)' "$LOG_FILE" | head -n 1 || echo "unknown")
  QUEUE_STATUS=$(grep -oP 'QUEUED In market [0-9a-zA-Z]+ at position \K\d+/\d+' "$LOG_FILE" | tail -n 1)
  JOB_STATUS=$(grep -oP 'Job [0-9a-zA-Z]+ started successfully' "$LOG_FILE" | tail -n 1)
  BENCHMARK=$(grep -oP 'operation nn_benchmark' "$LOG_FILE" | tail -n 1)

  if [ -n "$QUEUE_STATUS" ] && [ -z "$JOB_STATUS" ]; then
    if [ -n "$IDLE_CMD" ] && [ ! -f "$MINER_RUNNING" ]; then
      log_std "Starting idle miner: $IDLE_CMD $IDLE_ARGS"
      eval "$IDLE_CMD $IDLE_ARGS" >> /tmp/nosana-miner.log 2>&1 &
      echo $! > "$MINER_RUNNING"
    fi
  elif [ -n "$JOB_STATUS" ]; then
    if [ -f "$MINER_RUNNING" ]; then
      log_std "Job started. Stopping idle miner..."
      kill $(cat "$MINER_RUNNING") 2>/dev/null
      rm -f "$MINER_RUNNING"
    fi
  fi

  sleep 5
done
