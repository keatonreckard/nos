#!/bin/bash
# Nosana miner stats for HiveOS
# Initialize variables
khs="0"
stats=""
wallet="None"
sol_balance="0.0"
nos_balance="0.0"
queue_position="0/0"
algo_status="nos - init"
# Function to join array with comma
join() { local IFS=","; echo "$*"; }
# Calculate uptime (seconds since nosana-node container started)
uptime=0
if docker ps -q -f name=nosana-node | grep -q .; then
  start_time=$(docker inspect --format='{{.State.StartedAt}}' nosana-node 2>/dev/null | xargs -I {} date -d {} +%s)
  current_time=$(date +%s)
  [ -n "$start_time" ] && uptime=$((current_time - start_time))
fi
# Parse stats from /run/hive/miner.1 if available
if [ -f /run/hive/miner.1 ]; then
  # Log file contents for debugging
  echo "Contents of /run/hive/miner.1:" >> /tmp/nosana-stats-debug.log
  cat /run/hive/miner.1 >> /tmp/nosana-stats-debug.log
  # Extract full wallet address
  wallet_raw=$(grep -oPi "Wallet:\s*\K\S+" /run/hive/miner.1 | head -n 1)
  wallet=$(echo "$wallet_raw" | sed 's/\x1B\[[0-9;]*[mK]//g; s/[\x00-\x1F]//g' || echo "None")
  echo "Raw wallet: $wallet_raw" >> /tmp/nosana-stats-debug.log
  echo "Cleaned wallet: $wallet" >> /tmp/nosana-stats-debug.log
  # Extract SOL balance (truncate to 4 decimal places)
  sol_balance_raw=$(grep -oPi "SOL\s*balance:\s*\K[\d.]+(?=\s*SOL)" /run/hive/miner.1 | head -n 1)
  cleaned_sol=$(echo "$sol_balance_raw" | sed 's/\x1B\[[0-9;]*[mK]//g; s/[\x00-\x1F]//g')
  echo "Raw sol_balance: $sol_balance_raw" >> /tmp/nosana-stats-debug.log
  echo "Cleaned sol_balance (pre-format): $cleaned_sol" >> /tmp/nosana-stats-debug.log
  if [[ $cleaned_sol =~ ^[0-9]+(\.[0-9]+)?$ ]]; then
    sol_balance=$(printf "%.4f" "$cleaned_sol")
  else
    sol_balance="0.0"
  fi
  echo "Formatted sol_balance: $sol_balance" >> /tmp/nosana-stats-debug.log
  # Extract NOS balance (truncate to 4 decimal places)
  nos_balance_raw=$(grep -oPi "NOS\s*balance:\s*\K[\d.]+(?=\s*NOS)" /run/hive/miner.1 | head -n 1)
  cleaned_nos=$(echo "$nos_balance_raw" | sed 's/\x1B\[[0-9;]*[mK]//g; s/[\x00-\x1F]//g')
  echo "Raw nos_balance: $nos_balance_raw" >> /tmp/nosana-stats-debug.log
  echo "Cleaned nos_balance (pre-format): $cleaned_nos" >> /tmp/nosana-stats-debug.log
  if [[ $cleaned_nos =~ ^[0-9]+(\.[0-9]+)?$ ]]; then
    nos_balance=$(printf "%.4f" "$cleaned_nos")
  else
    nos_balance="0.0"
  fi
  echo "Formatted nos_balance: $nos_balance" >> /tmp/nosana-stats-debug.log
  # Extract queue position
  queue_position_raw=$(grep -oPi "QUEUED.*at position\s*\K[0-9]+/[0-9]+" /run/hive/miner.1 | tail -n 1)
  queue_position=$(echo "$queue_position_raw" | sed 's/\x1B\[[0-9;]*[mK]//g; s/[\x00-\x1F]//g' || echo "0/0")
  echo "Raw queue_position: $queue_position_raw" >> /tmp/nosana-stats-debug.log
  echo "Cleaned queue_position: $queue_position" >> /tmp/nosana-stats-debug.log
  # Set khs to queue position if valid
  if [[ "$queue_position" =~ ^[0-9]+/[0-9]+$ ]]; then
    khs="$queue_position"
  else
    khs="0"
  fi
  # Determine algo status based on logs
  if grep -q "Job.*started successfully" /run/hive/miner.1; then
    if grep -q "operation nn_benchmark" /run/hive/miner.1; then
      algo_status="nos - bench"
    else
      algo_status="nos - job"
    fi
  elif grep -q "QUEUED.*at position" /run/hive/miner.1; then
    algo_status="nos - queued $queue_position"
  else
    algo_status="nos - init"
  fi
fi
# Default values if parsing fails
[ -z "$wallet" ] && wallet="None"
[ -z "$sol_balance" ] && sol_balance="0.0"
[ -z "$nos_balance" ] && nos_balance="0.0"
# Gather GPU stats using nvidia-smi
temp=()
fan=()
bus_numbers=()
if command -v nvidia-smi >/dev/null 2>&1; then
  mapfile -t temp < <(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader 2>/dev/null)
  mapfile -t fan < <(nvidia-smi --query-gpu=fan.speed --format=csv,noheader 2>/dev/null | sed 's/ %//g')
  mapfile -t bus_ids < <(nvidia-smi --query-gpu=pci.bus_id --format=csv,noheader 2>/dev/null | cut -d':' -f2 | cut -d':' -f1 | xargs -I {} printf "%d\n" 0x{})
fi
# Use default arrays if nvidia-smi fails or no data
if [ ${#temp[@]} -eq 0 ]; then
  temp=(0)
fi
if [ ${#fan[@]} -eq 0 ]; then
  fan=(0)
fi
if [ ${#bus_ids[@]} -eq 0 ]; then
  bus_numbers=(0)
else
  bus_numbers=("${bus_ids[@]}")
fi
# Set version string without wallet
ver="v1.0, Sol:$sol_balance, Nos:$nos_balance"
# Construct JSON stats for HiveOS dashboard
stats=$(cat <<EOF
{
  "hs": ["$khs"],
  "hs_units": "hs",
  "temp": [$(join ${temp[@]})],
  "fan": [$(join ${fan[@]})],
  "uptime": $uptime,
  "ver": "$ver",
  "algo": "$algo_status",
  "bus_numbers": [$(join ${bus_numbers[@]})]
}
EOF
)
# Output for HiveOS agent
echo "khs=$khs"
echo "stats=$stats"
