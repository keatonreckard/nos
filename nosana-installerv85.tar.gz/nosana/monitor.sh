#!/usr/bin/env bash
# nosana monitor v85
# - Shows full node boot lines (Network/Wallet/SOL/NOS/Provider)
# - Dedupes within-session only
# - Prefixes lines with [nosana-node]
# - Starts idle miner when QUEUED, stops it on job start/finish
# - Keeps miner log across restarts; truncates only on first run per session

set -u
export LC_ALL=C

MINER_DIR="${MINER_DIR:-/hive/miners/custom/nosana}"
LOG_DIR="${LOG_DIR:-/var/log/miner/nosana}"
RUN_DIR="${RUN_DIR:-/var/run}"
MINER_LOG="$LOG_DIR/nosana.log"
DEBUG_LOG="$LOG_DIR/debug.log"
IDLE_LOG="$LOG_DIR/idle.log"
SESSION_LOCK="$RUN_DIR/.nosana_session_started"
SEEN_FILE="$MINER_DIR/.node_seen"

mkdir -p "$LOG_DIR" "$RUN_DIR" 2>/dev/null || true
touch "$MINER_LOG" "$DEBUG_LOG" "$IDLE_LOG"

# Truncate log only once per boot/session
if [ ! -f "$SESSION_LOCK" ]; then
  : > "$MINER_LOG"
  : > "$DEBUG_LOG"
  touch "$SESSION_LOCK"
fi

# Reset dedupe for each miner start so balances always show
rm -f "$SEEN_FILE" 2>/dev/null || true
: > "$SEEN_FILE"

# Hive message helper (no-op if missing)
msg() { if [ -x /hive/bin/message ]; then /hive/bin/message info "$1" >/dev/null 2>&1 || true; fi; }

echo "[nosana] monitor started" | tee -a "$MINER_LOG"
msg "NOS: monitor started"

idle_running() { screen -ls 2>/dev/null | grep -qE '\.nosana-idle'; }
start_idle() { if ! idle_running; then bash "$MINER_DIR/idle-run.sh" >>"$DEBUG_LOG" 2>&1 || true; fi; }
stop_idle()  { if  idle_running; then bash "$MINER_DIR/idle-kill.sh" >>"$DEBUG_LOG" 2>&1 || true; fi; }

normalize_line() {
  # strip ANSI and carriage returns
  sed -E 's/\x1B\[[0-9;]*[A-Za-z]//g; s/\r//g'
}
drop_ascii() {
  # drop pure ascii-art and divider lines
  awk '{
    s=$0; gsub(/^[[:space:]]+|[[:space:]]+$/, "", s);
    if (s=="") next;
    if (s ~ /^[-=_]{3,}$/) next;
    if (s ~ /^[|\/\\_[:space:]]{5,}$/) next;
    print;
  }'
}
dedupe_and_prefix() {
  while IFS= read -r ln; do
    # trim spaces
    t="${ln#"${ln%%[![:space:]]*}"}"; t="${t%"${t##*[![:space:]]}"}"
    [ -z "$t" ] && continue
    if ! grep -Fxq -- "$t" "$SEEN_FILE" 2>/dev/null; then
      printf "%s\n" "$t" >> "$SEEN_FILE"
      printf "[nosana-node] %s\n" "$t"
    fi
  done
}

# Stream docker logs including boot chunk every start
# If docker is absent, fall back to podman logs.
get_logs() {
  if command -v docker >/dev/null 2>&1; then
    docker logs -f --since 0s nosana-node 2>&1
  elif command -v podman >/dev/null 2>&1; then
    podman logs -f --since 0s nosana-node 2>&1
  else
    echo "container runtime not found" >&2
    return 1
  fi
}

# Main pipeline
get_logs | normalize_line | drop_ascii | dedupe_and_prefix | tee -a "$MINER_LOG" | \
while IFS= read -r out; do
  case "$out" in
    *"QUEUED"*|*" In market "*position*)
      start_idle
      ;;
    *"Job "*started*|*" is running"*|*"Flow "*started*|*"Starting job"*|*"Executing"*"job"*)
      stop_idle
      ;;
    *"finished successfully"*|*"Job "*completed*|*"Flow "*finished*|*"Nosana Node finished"*)
      stop_idle
      ;;
  esac
done

# Keep process alive so Hive can tail this log
while true; do sleep 60; done