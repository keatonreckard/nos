#!/usr/bin/env bash
set -euo pipefail
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
DEBUG_LOG="$LOG_DIR/debug.log"
mkdir -p "$LOG_DIR"
touch "$LOG_DIR/nosana.log" "$DEBUG_LOG" "$LOG_DIR/idle.log"
# --- nosana node log tee cleanup (miner.1) ---
if [[ -f /run/hive/.nosana_node_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_node_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_node_tail.pid
fi
: > /run/hive/miner.1 || true
# ---------------------------------------------

# --- nosana idle cleanup: clear stale idle screen, tail, and motd feed ---
mkdir -p /run/hive || true
if screen -ls 2>/dev/null | grep -q '\.nosana-idle'; then
  screen -S nosana-idle -X quit || true
fi
if [[ -f /run/hive/.nosana_idle_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_idle_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_idle_tail.pid
fi
: > /run/hive/miner.2 || true
# ------------------------------------------------------------------------

nohup bash "$MINER_DIR/idle-tee.sh" "$LOG_DIR/idle.log" >/dev/null 2>&1 &
nohup stdbuf -oL tail -n +1 -F "$LOG_DIR/nosana.log" | stdbuf -oL grep -a -v -E '\[XMR\]|SHARES:|Trainer:|\srx/|qubic|QUBIC|AVX|CUDA' > /run/hive/miner.1 2>/dev/null & echo $! > /run/hive/.nosana_node_tail.pid
# --- nosana idle cleanup: clear stale idle screen, tail, and motd feed ---
mkdir -p /run/hive || true
if screen -ls 2>/dev/null | grep -q '\.nosana-idle'; then
  screen -S nosana-idle -X quit || true
fi
if [[ -f /run/hive/.nosana_idle_tail.pid ]]; then
  pid="$(cat /run/hive/.nosana_idle_tail.pid 2>/dev/null || echo)"
  if [[ -n "${pid:-}" ]]; then kill "$pid" >/dev/null 2>&1 || true; fi
  rm -f /run/hive/.nosana_idle_tail.pid
fi
: > /run/hive/miner.2 || true
# ------------------------------------------------------------------------


msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

echo "[$(date -Iseconds)] h-run: cleaning previous containers" | tee -a "$DEBUG_LOG"
docker rm -f nosana-node podman >/dev/null 2>&1 || true
pkill -9 -f "podman system service" 2>/dev/null || true
docker container prune -f >/dev/null 2>&1 || true

docker volume inspect podman-cache >/dev/null 2>&1 || docker volume create podman-cache >/dev/null
docker volume inspect podman-socket >/dev/null 2>&1 || docker volume create podman-socket >/dev/null

echo "[$(date -Iseconds)] h-run: starting podman sidecar" | tee -a "$DEBUG_LOG"
docker run -d --pull=always --gpus=all --name podman --device /dev/fuse \
  --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman --privileged -e ENABLE_GPU=true \
  nosana/podman:v1.1.0 unix:/podman/podman.sock >> "$DEBUG_LOG" 2>&1 || true
sleep 5

# a50: Recreate default Podman network with desired MTU using podman CLI (no manual JSON)
MTU_VAL="${NOSANA_MTU:-1420}"
echo "lowmtu" 1>/dev/null  # keep old log line style minimal

docker exec -e MTU="$MTU_VAL" -i podman sh <<'EOF'
set -eu
echo "[sidecar] ensuring default network 'podman' has mtu=$MTU"

# Try to remove any containers attached to 'podman' (best effort)
attached="$(podman ps -aq --filter network=podman || true)"
if [ -n "$attached" ]; then
  echo "$attached" | xargs -r podman rm -f >/dev/null 2>&1 || true
fi

# Remove and recreate the network with the requested MTU
podman network rm -f podman >/dev/null 2>&1 || true
podman network create --driver bridge --subnet 10.88.0.0/16 --gateway 10.88.0.1 -o mtu="$MTU" podman >/dev/null 2>&1 || true

echo "[sidecar] created default network 'podman' with mtu=$MTU"
podman network inspect podman | sed -n '1,80p' || true

echo "[sidecar] verify MTU via no-flag run:"
podman run --rm alpine sh -c "ip link show eth0 | grep mtu" || true
EOF

# a50: record miner start for uptime reset to 0
date +%s > /run/hive/nosana.start_ts || true


echo "[$(date -Iseconds)] h-run: starting nosana-node container" | tee -a "$DEBUG_LOG"
msg "NOS: node starting"
docker run -d --pull=always --name nosana-node --network host --gpus=all \
  --volume /root/.nosana/:/root/.nosana/ \
  --volume podman-socket:/root/.nosana/podman:ro \
  -e CLI_VERSION= nosana/nosana-cli:latest \
  node start --network "${SOL_NET_ENV:=mainnet}" >> "$DEBUG_LOG" 2>&1 || true
sleep 2
msg "NOS: node container launched"

exec bash "$MINER_DIR/monitor.sh"
