Nosana wrapper v3.1.15: stderr->debug; no awk on hot path; robust algo/version.
