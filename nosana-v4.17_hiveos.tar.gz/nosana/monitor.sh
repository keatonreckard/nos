#!/usr/bin/env bash
set -uo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
DEBUG_LOG="$LOG_DIR/debug.log"
MINER_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR" "$RUN_DIR"
touch "$MINER_LOG" "$DEBUG_LOG" "$IDLE_LOG"

# cached idle config (written by h-config.sh)
IDLE_COMMAND="$(cat "$MINER_DIR/parsed/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$MINER_DIR/parsed/idle_args" 2>/dev/null || true)"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

idle_running() {
  screen -ls 2>/dev/null | grep -q 'nosana-idle'
}

start_idle_tailer() {
  # stream idle.log lines into MINER_LOG so they show up in miner log screen
  local tpid="$RUN_DIR/nosana.idle.tpid"
  if [[ -f "$tpid" ]]; then
    local old; old="$(cat "$tpid" 2>/dev/null || true)"
    if [[ -n "$old" ]]; then kill "$old" 2>/dev/null || true; fi
    rm -f "$tpid"
  fi
  ( tail -n +1 -F "$IDLE_LOG" 2>/dev/null | sed -u 's/^/[idle] /' >> "$MINER_LOG" ) &
  echo $! > "$tpid"
}

stop_idle_tailer() {
  local tpid="$RUN_DIR/nosana.idle.tpid"
  if [[ -f "$tpid" ]]; then
    local pid; pid="$(cat "$tpid" 2>/dev/null || true)"
    [[ -n "$pid" ]] && kill "$pid" 2>/dev/null || true
    rm -f "$tpid"
  fi
}

start_idle() {
  local now cmd_raw args_raw cmd args cmd_dir cmd_base found
  now="$(date +%s)"
  cmd_raw="$(cat "$MINER_DIR/parsed/idle_command" 2>/dev/null || true)"
  args_raw="$(cat "$MINER_DIR/parsed/idle_args" 2>/dev/null || true)"

  # Fallback: parse nosana.conf for idleSettings.{command,arguments}
  if [[ -z "$cmd_raw" ]] && [[ -f "$MINER_DIR/nosana.conf" ]]; then
    raw="$(cat "$MINER_DIR/nosana.conf")"
    trimmed="$(printf '%s' "$raw" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
    if printf '%s' "$trimmed" | grep -q '"idleSettings"'; then
      if printf '%s' "$trimmed" | grep -q '^{'; then extra_json="$trimmed"; else extra_json="{$trimmed}"; fi
      cmd_raw="$(printf '%s' "$extra_json" | tr '\n' ' ' | sed -n 's/.*"idleSettings"[[:space:]]*:[[:space:]]*{[^}]*"command"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)"
      args_raw="$(printf '%s' "$extra_json" | tr '\n' ' ' | sed -n 's/.*"idleSettings"[[:space:]]*:[[:space:]]*{[^}]*"arguments"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)"
    fi
  fi

  # sanitize
  cmd="$(printf '%s' "$cmd_raw" | tr -d '\r' | sed -E 's/^[[:space:]]+//; s/[[:space:]]+$//')"
  args="$(printf '%s' "$args_raw" | tr -d '\r' | sed -E 's/^[[:space:]]+//')"

  # autodiscover if path not present
  if [[ -z "$cmd" || ! -e "$cmd" || -d "$cmd" ]]; then
    found="$(find /hive/miners/custom -maxdepth 4 -type f \( -name 'qli-Client*' -o -name 'Qli-Client*' -o -name 'client*' \) -print -quit 2>/dev/null || true)"
    if [[ -n "$found" ]]; then
      echo "[nosana] idle: auto-discovered binary at $found" | tee -a "$MINER_LOG"
      cmd="$found"
    fi
  fi

  if [[ -z "$cmd" || ! -e "$cmd" || -d "$cmd" ]]; then
    echo "[nosana] idle: command not found -> $(printf '%q' "$cmd_raw")" | tee -a "$MINER_LOG" "$DEBUG_LOG"
    printf '%s' "$cmd_raw" | od -An -t x1 | tr -d '\n' | sed 's/^/[nosana] idle: cmd_raw_hex=/' | tee -a "$MINER_LOG" "$DEBUG_LOG" >/dev/null
    echo >> "$MINER_LOG"
    return 1
  fi

  # Ensure executable
  if [[ ! -x "$cmd" ]]; then chmod +x "$cmd" 2>/dev/null || true; fi

  cmd_dir="$(dirname -- "$cmd")"
  cmd_base="$(basename -- "$cmd")"
  idle_running && return 0

  mkdir -p "$(dirname "$IDLE_LOG")"; touch "$IDLE_LOG"

  local STDBUF=""
  if command -v stdbuf >/dev/null 2>&1; then STDBUF="stdbuf -oL -eL"; fi

  echo "[nosana] start_idle(reason=queued)" | tee -a "$MINER_LOG"
  msg "NOS: idle miner starting"

  # Use screen logger and exec client
  screen -L -Logfile "$IDLE_LOG" -dmS nosana-idle bash -lc "cd "$cmd_dir" && { printf '--- idle launcher: cwd=%s\n' "$(pwd)"; exec $STDBUF ./"$cmd_base" $args; }"

  echo "[nosana] idle miner started: $cmd $args" | tee -a "$MINER_LOG"
  date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"

  # start interleaver
  start_idle_tailer
}

stop_idle() {
  if idle_running; then
    echo "[nosana] idle miner stop requested" | tee -a "$MINER_LOG"
    screen -S nosana-idle -X quit 2>/dev/null || true
    msg "NOS: idle miner stopped"
  fi
  stop_idle_tailer
}

set_state() {
  local key="$1"; shift
  local vesc="$*"
  # if switching to queued, start idle if not running
  if echo "$vesc" | grep -Eq '(^|[[:space:]])nos[[:space:]]*-[[:space:]]*queued'; then
    if ! idle_running; then
      echo "[nosana] set_state detected queued -> start_idle" | tee -a "$MINER_LOG"
      start_idle
    fi
  fi
  # if switching to job, stop idle
  if echo "$vesc" | grep -Eq '(^|[[:space:]])nos[[:space:]]*-[[:space:]]*job'; then
    stop_idle
  fi
  awk -v k="$key" -v v="$vesc" '
    BEGIN{done=0}
    $0 ~ ("^"k"=") { print k"=""v"""; done=1; next }
    { print }
    END{ if(!done) print k"=""v""" }
  ' "$STATE_FILE" > "$STATE_FILE.tmp" && mv "$STATE_FILE.tmp" "$STATE_FILE"
}

date +%s > "$MINER_DIR/nosana.start.time"
set_state status "nos - initializing"
echo "[nosana] monitor started" | tee -a "$MINER_LOG"; msg "NOS: monitor started"

bootstrap() {
  local bootlog
  bootlog="$(docker logs --since 60m nosana-node 2>&1 || true)"
  [[ -n "$bootlog" ]] && printf "%s\n" "$bootlog" | tee -a "$MINER_LOG"
  if printf '%s\n' "$bootlog" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
    set_state status "nos - queued"
    msg "NOS: queued"
    date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
  elif printf '%s\n' "$bootlog" | grep -Eqi 'Node is claiming job|claimed job|Job .* started|Flow .* started|is running'; then
    set_state status "nos - job"
    msg "NOS: job"
    date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
  fi
}
bootstrap

last_pos=""
while true; do
  logchunk="$(docker logs --since 10s nosana-node 2>&1 || true)"
  if [[ -n "$logchunk" ]]; then
    printf "%s\n" "$logchunk" | tee -a "$MINER_LOG"
    if echo "$logchunk" | grep -Eq "position [0-9]+/[0-9]+"; then
      pos="$(echo "$logchunk" | grep -E 'position [0-9]+/[0-9]+' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[^[:space:]]+).*/\1/')"
      if [[ -n "$pos" && "$pos" != "$last_pos" ]]; then
        echo "[nosana] queued $pos" | tee -a "$MINER_LOG"
        msg "NOS: queued ${pos}"
        last_pos="$pos"
      fi
      set_state status "nos - queued ${pos}"
      date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
    elif echo "$logchunk" | grep -Eiq '\bQUEUED\b'; then
      set_state status "nos - queued"
      date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
    fi
    if echo "$logchunk" | grep -Eqi 'Node is claiming job|Node has|claimed job|Job .* started|Flow .* started|is running'; then
      set_state status "nos - job"
      date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
      msg "NOS: job started"
    fi
    if echo "$logchunk" | grep -Eq "Nosana Node finished|Job .* completed|finished successfully|Flow .* (finished|completed)"; then
      echo "[nosana] job finished" | tee -a "$MINER_LOG"
      msg "NOS: job finished"
    fi
  fi
  sleep 5
done
