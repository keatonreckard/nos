#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"

mkdir -p "$LOG_DIR" "$RUN_DIR"

MINER_LOG="$LOG_DIR/nosana.log"
DEBUG_LOG="$LOG_DIR/debug.log"
IDLE_LOG="$LOG_DIR/idle.log"

# msg shim if hive's msg is not present
if ! command -v msg >/dev/null 2>&1 && ! type msg >/dev/null 2>&1; then
  msg() { echo "[nosana] $*" | tee -a "$MINER_LOG" >&2; }
fi

# Ensure logs exist
touch "$MINER_LOG" "$DEBUG_LOG" "$IDLE_LOG"

# ----- helpers -----
set_state() {
  local key="$1" val="$2"
  touch "$STATE_FILE"
  if grep -q "^${key}=" "$STATE_FILE" 2>/dev/null; then
    sed -i "s|^${key}=.*|${key}=\"${val}\"|" "$STATE_FILE"
  else
    printf '%s="%s"\n' "$key" "$val" >> "$STATE_FILE"
  fi
}

idle_running() {
  # screen session "idle" is used by idle-run.sh; fallback to process name
  if screen -ls 2>/dev/null | grep -q "[.]idle"; then
    return 0
  fi
  pgrep -f "/qli-Client|qubic|idle-run.sh" >/dev/null 2>&1 && return 0 || return 1
}

start_idle_stdout() {
  local pid_file="$RUN_DIR/idle-stdout.pid"
  if [[ -f "$pid_file" ]]; then
    local p
    p="$(cat "$pid_file" 2>/dev/null || true)"
    if [[ -n "${p:-}" ]] && kill -0 "$p" 2>/dev/null; then
      return 0
    fi
  fi
  (
    stdbuf -oL -eL tail -n0 -F "$IDLE_LOG" \
    | stdbuf -oL -eL tr '\r' '\n' \
    | stdbuf -oL -eL sed -u -r 's/\x1B\[[0-9;?]*[ -\/]*[@-~]//g' \
    | stdbuf -oL -eL awk '{ printf("[idle-miner] %s\n", $0); fflush(); }'
  ) &
  echo $! > "$pid_file"
  echo "[$(date -Iseconds)] monitor: idle-stdout tail started (pid=$(cat "$pid_file"))" >> "$DEBUG_LOG"
}

# ensure idle-bridge (appends idle to nosana.log) plus stdout fanout
bash "$MINER_DIR/idle-bridge.sh" start || true
start_idle_stdout || true

# ----- main watch loop -----
last_pos=""
while true; do
  logchunk="$(docker logs --since 10s nosana-node 2>&1 || true)"
  if [[ -n "$logchunk" ]]; then
    printf "%s\n" "$logchunk" | tee -a "$MINER_LOG"

    # Queue position updates
    if echo "$logchunk" | grep -Eqi 'position[[:space:]]+[0-9]+/[0-9]+'; then
      pos="$(echo "$logchunk" | grep -E 'position[[:space:]]+[0-9]+/[0-9]+' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/')"
      if [[ -n "$pos" && "$pos" != "$last_pos" ]]; then
        echo "[nosana] queued ${pos}" | tee -a "$MINER_LOG"
        msg "NOS: queued ${pos}"
        last_pos="$pos"
      fi
      set_state status "nos - queued ${pos}"
      date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
      # Ensure idle miner is running while queued
      if [[ -n "${IDLE_COMMAND:-}" ]] && ! idle_running; then
        if bash "$MINER_DIR/idle-run.sh"; then :; else echo "[nosana] idle start failed" | tee -a "$DEBUG_LOG" "$MINER_LOG"; fi
        bash "$MINER_DIR/idle-bridge.sh" start || true
        start_idle_stdout || true
      fi
    fi

    # Job start detection
    if echo "$logchunk" | grep -Eqi 'Node is claiming job|claimed job|Job .* started|Flow .* started| is running'; then
      set_state status "nos - job"
      date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
      if idle_running; then
        bash "$MINER_DIR/idle-kill.sh" || true
      fi
      msg "NOS: job started"
    fi

    # Job finished detection
    if echo "$logchunk" | grep -Eqi 'Nosana Node finished|Job .* completed|finished successfully|Flow .* finished|Flow .* completed'; then
      echo "[nosana] job finished" | tee -a "$MINER_LOG"
      msg "NOS: job finished"
    fi
  fi
  sleep 5
done
