#!/usr/bin/env bash
set -euo pipefail
# This wrapper simply executes the idle miner command if provided via env or state file.
STATE_FILE="/var/run/nosana.state"
LOG_DIR="/var/log/miner/nosana"
mkdir -p "$LOG_DIR"

idle_cmd=""
idle_args=""

# source state if present
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

# Prefer explicit environment variables if set
: "${IDLE_CMD:=}"
: "${IDLE_ARGS:=}"

if [[ -n "${IDLE_CMD:-}" ]]; then
  exec ${IDLE_CMD} ${IDLE_ARGS}  # idempotent; caller redirects stdout/stderr
elif [[ -n "${idle_command:-}" ]]; then
  exec ${idle_command} ${idle_args:-}
else
  echo "[idle-screen] No idle command configured. Provide IDLE_CMD/IDLE_ARGS env or write idle_command/idle_args to $STATE_FILE." >&2
  sleep 30
fi
