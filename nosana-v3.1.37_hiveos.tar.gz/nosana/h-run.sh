#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
PODMAN_DIR="/root/.nosana/podman"
PODMAN_SOCK="$PODMAN_DIR/podman.sock"

CUSTOM_LOG_BASENAME="${CUSTOM_LOG_BASENAME:-nosana}"

mkdir -p "$LOG_DIR" "$PODMAN_DIR" "$RUN_DIR"

ts() { date +'%Y-%m-%dT%H:%M:%S%z'; }

echo "[$(ts)] h-run: cleaning previous containers" | tee -a "$LOG_DIR/debug.log" >/dev/null || true
docker rm -f nos-podman nosana-node >/dev/null 2>&1 || true

echo "[$(ts)] h-run: starting podman sidecar" | tee -a "$LOG_DIR/debug.log" >/dev/null || true
# privileged to allow podman service to operate properly inside the sidecar
docker run -d --name nos-podman --restart unless-stopped \
  --privileged \
  -v "$PODMAN_DIR":/run/podman \
  nosana/podman:v1.1.0 >/dev/null

# wait for the socket to appear (max 30s)
for i in $(seq 1 30); do
  if [[ -S "$PODMAN_SOCK" ]]; then break; fi
  sleep 1
done
if [[ ! -S "$PODMAN_SOCK" ]]; then
  echo "[$(ts)] ERROR: podman.sock not created at $PODMAN_SOCK" | tee -a "$LOG_DIR/debug.log"
  exit 1
fi

echo "[$(ts)] h-run: starting nosana-node container" | tee -a "$LOG_DIR/debug.log" >/dev/null || true
docker run -d --name nosana-node --restart unless-stopped \
  --network host \
  -v /root/.nosana:/root/.nosana \
  -v "$PODMAN_DIR":/run/podman \
  -e NOSANA_PROVIDER=podman \
  nosana/nosana-cli:latest node run --log debug >/dev/null

# stream logs to file
( docker logs -f --since=0s nosana-node >> "$LOG_DIR/nosana.log" 2>&1 ) &

# keep the script/process attached for Hive
exec tail -F "$LOG_DIR/nosana.log"
