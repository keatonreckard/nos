#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
STATE_FILE="/var/run/nosana.state"
NOS_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
IDLE_PID_FILE="/var/run/nosana.idle.pid"

mkdir -p "$LOG_DIR"

log(){ echo "[$(date -Iseconds)] monitor: $*" >> "$LOG_DIR/debug.log"; }

start_idle() {
  if [[ -f "$IDLE_PID_FILE" ]] && kill -0 "$(cat "$IDLE_PID_FILE")" 2>/dev/null; then return; fi
  if [[ -x "$MINER_DIR/idle-screen.sh" ]]; then
    "$MINER_DIR/idle-screen.sh" >> "$IDLE_LOG" 2>&1 &
    echo $! > "$IDLE_PID_FILE"
    log "idle miner started pid=$(cat "$IDLE_PID_FILE")"
  else
    log "idle-screen.sh not executable"
  fi
}

stop_idle() {
  if [[ -f "$IDLE_PID_FILE" ]]; then
    kill "$(cat "$IDLE_PID_FILE")" 2>/dev/null || true
    rm -f "$IDLE_PID_FILE"
    log "idle miner stopped"
  fi
}

# ensure log exists or wait a bit
for i in $(seq 1 120); do
  [[ -s "$NOS_LOG" ]] && break
  sleep 1
done

# tail and react to state
tail -Fn0 "$NOS_LOG" | while read -r line; do
  if echo "$line" | grep -Eqi 'position[[:space:]]+[0-9]+/[0-9]+|QUEUED'; then
    start_idle
    # persist state hint
    echo 'status="nos - queued"' > "$STATE_FILE".mon.$$ || true
    cat "$STATE_FILE".mon.$$ >> "$STATE_FILE" 2>/dev/null || true
    rm -f "$STATE_FILE".mon.$$ || true
  elif echo "$line" | grep -Eqi 'claimed job|Job .* started|Flow .* resumed|is running'; then
    stop_idle
    echo 'status="nos - job"' > "$STATE_FILE".mon.$$ || true
    cat "$STATE_FILE".mon.$$ >> "$STATE_FILE" 2>/dev/null || true
    rm -f "$STATE_FILE".mon.$$ || true
  fi
done
