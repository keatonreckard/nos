#!/usr/bin/env bash
set -euo pipefail

RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
mkdir -p "$RUN_DIR" "$LOG_DIR"

log(){ echo "[$(date -Iseconds)] h-config: $*" >> "$LOG_DIR/debug.log"; }

# Read raw extra from known envs, fallbacks
RAW_EXTRA="${CUSTOM_MINER_CONFIG:-${EXTRA_CONFIG:-${CUSTOM_CONFIG:-}}}"
if [[ -z "$RAW_EXTRA" ]] && [[ -f /hive-config/wallet.conf ]]; then
  RAW_EXTRA="$(grep -A0 -E '^CUSTOM_' /hive-config/wallet.conf 2>/dev/null || true)"
fi

log "RAW_EXTRA length=${#RAW_EXTRA}"

# Heuristic: look for a path-like token that points to an idle miner binary and capture the rest as args.
idle_command="$(echo "$RAW_EXTRA" | tr '\n' ' ' | grep -Eo '/hive/miners/custom/[a-zA-Z0-9._/-]+' | head -n1 || true)"
idle_args="$(echo "$RAW_EXTRA"   | tr '\n' ' ' | sed -n 's#.*'"$idle_command"'[[:space:]]\+\(.*\)$#\1#p' | sed 's/[[:space:]]\+$//' || true)"

if [[ -n "$idle_command" ]]; then
  log "parsed idle command: $idle_command"
  log "parsed idle args: ${idle_args:0:120}"
  {
    echo "idle_command=\"$idle_command\""
    echo "idle_args=\"$idle_args\""
  } >> "$STATE_FILE"
fi
