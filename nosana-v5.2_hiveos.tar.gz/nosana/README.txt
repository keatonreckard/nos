Nosana wrapper v3.1.18: ANSI-stripped sed parsing for wallet/balances; robust algo; docker logs fallback.


v5.2 changes:
- Flip status back to 'nos - queued' after job finishes and (re)start idle.
- Keep nosana.log alive with a 15s heartbeat to avoid blank miner screen.
- Stronger QUEUED pattern matching, plus an idle watchdog to retry start if needed.
- If idle start fails quickly, log tail of idle.log to help debug.
