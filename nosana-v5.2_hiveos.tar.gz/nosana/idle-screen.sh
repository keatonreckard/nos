#!/usr/bin/env bash
screen -r nosana-idle || echo "Idle screen not running."
