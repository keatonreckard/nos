#!/usr/bin/env bash
# --- msg shim (only if not provided by Hive env) ---
if ! command -v msg >/dev/null 2>&1 && ! type msg >/dev/null 2>&1; then
  LOG_PATH="${CUSTOM_LOG_BASENAME:-/var/log/miner/nosana/nosana}.log"
  msg() { echo "[nosana] $*" | tee -a "$LOG_PATH" >&2; }
fi
# --- end msg shim ---
set -uo pipefail
export LC_ALL=C
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
DEBUG_LOG="$LOG_DIR/debug.log"
MINER_LOG="$LOG_DIR/nosana.log"
# ===== Idle screen fanout to STDOUT (for miner log / MOTD) =====
IDLE_STDOUT_PID_FILE="$RUN_DIR/idle-stdout.pid"
start_idle_stdout() {
  local pid=""
  if [[ -f "$IDLE_STDOUT_PID_FILE" ]]; then
    pid="$(cat "$IDLE_STDOUT_PID_FILE" 2>/dev/null || true)"
    if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
      return 0
    fi
  fi
  (
    stdbuf -oL -eL tail -n0 -F "$IDLE_LOG" \
    | stdbuf -oL -eL tr '\r' '\n' \
    | stdbuf -oL -eL sed -u -r 's/\x1B\[[0-9;?]*[ -\/]*[@-~]//g' \
    | stdbuf -oL -eL awk '{ printf("[idle-miner] %s\n", $0); fflush(); }'
  ) &
  echo $! > "$IDLE_STDOUT_PID_FILE"
  echo "[$(date -Iseconds)] monitor: idle-stdout tail started (pid=$(cat "$IDLE_STDOUT_PID_FILE"))" >> "$DEBUG_LOG"
}
stop_idle_stdout() {
  if [[ -f "$IDLE_STDOUT_PID_FILE" ]]; then
    local p="$(cat "$IDLE_STDOUT_PID_FILE" 2>/dev/null || true)"
    [[ -n "$p" ]] && kill "$p" 2>/dev/null || true
    rm -f "$IDLE_STDOUT_PID_FILE"
  fi
}
# ===== Ensure idle-bridge is running (writes to nosana.log) =====
bash "$MINER_DIR/idle-bridge.sh" start || true
# ===== Start STDOUT forwarder now that IDLE_LOG is defined =====
start_idle_stdout || true

# fan-out idle.log to STDOUT for MOTD/miner log (do not write to file; idle-bridge already appends)
IDLE_STDOUT_PID_FILE="$RUN_DIR/idle-stdout.pid"
start_idle_stdout() {
  local pid=""
  if [[ -f "$IDLE_STDOUT_PID_FILE" ]]; then
    pid="$(cat "$IDLE_STDOUT_PID_FILE" 2>/dev/null || true)"
    if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
      return 0
    fi
  fi
  ( stdbuf -oL -eL tail -n0 -F "$IDLE_LOG" \
    | stdbuf -oL -eL tr '\r' '\n' \
    | stdbuf -oL -eL sed -u -r 's/\x1B\[[0-9;?]*[ -\/]*[@-~]//g' \
    | stdbuf -oL -eL awk '{ printf("[idle-miner] %s\n", $0); fflush(); }' \
  ) &
  echo $! > "$IDLE_STDOUT_PID_FILE"
  echo "[$(date -Iseconds)] monitor: idle-stdout tail started (pid=$(cat "$IDLE_STDOUT_PID_FILE"))" >> "$DEBUG_LOG"
}
stop_idle_stdout() {
  if [[ -f "$IDLE_STDOUT_PID_FILE" ]]; then
    local p="$(cat "$IDLE_STDOUT_PID_FILE" 2>/dev/null || true)"
    [[ -n "$p" ]] && kill "$p" 2>/dev/null || true
    rm -f "$IDLE_STDOUT_PID_FILE"
  fi
}

# ensure idle-bridge is running early (rotation-safe forwarder)

IDLE_LOG="$LOG_DIR/idle.log"
mkdir -p "$LOG_DIR" "$RUN_DIR"; touch "$MINER_LOG" "$DEBUG_LOG" "$IDLE_LOG"
# Ensure no leftover idle miner from previous run
if screen -ls 2>/dev/null | grep -q "nosana-idle"; then
  bash "$MINER_DIR/idle-kill.sh" || true
  echo "[nosana] cleared idle on restart" | tee -a "$MINER_LOG"
  msg "NOS: idle miner cleared on restart"
fi


IDLE_COMMAND="$(cat "$MINER_DIR/parsed/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$MINER_DIR/parsed/idle_args" 2>/dev/null || true)"

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

set_state() {
  local key="$1" val="$2"
  local vesc="${val//\\/\\\\}"; vesc="${vesc//\"/\\\"}"
  mkdir -p "$(dirname "$STATE_FILE")"; touch "$STATE_FILE"
  awk -v k="$key" -v v="$vesc" '
    BEGIN{done=0}
    $0 ~ ("^"k"=") { print k"=\""v"\""; done=1; next }
    { print }
    END{ if(!done) print k"=\""v"\"" }
  ' "$STATE_FILE" > "$STATE_FILE.tmp" && mv "$STATE_FILE.tmp" "$STATE_FILE"
}

# helper to know if idle is running
idle_running() { screen -ls 2>/dev/null | grep -q "nosana-idle"; }

date +%s > "$MINER_DIR/nosana.start.time"
set_state status "nos - initializing"
echo "[nosana] monitor started" | tee -a "$MINER_LOG"; msg "NOS: monitor started"

bootstrap() {
  local bootlog
  bootlog="$(docker logs --since 60m nosana-node 2>&1 || true)"
  [[ -n "$bootlog" ]] && printf "%s\n" "$bootlog" | tee -a "$MINER_LOG"

  if printf '%s\n' "$bootlog" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
    set_state status "nos - job"
    date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
    # Kill idle immediately if running
    if idle_running; then bash "$MINER_DIR/idle-kill.sh" || true; fi
    msg "NOS: job"
  elif printf '%s\n' "$bootlog" | grep -Eqi 'QUEUED|position [0-9]+/[0-9]+'; then
    set_state status "nos - queued"
    date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
    # Start idle if not running
    if [[ -n "$IDLE_COMMAND" ]] && ! idle_running; then
      if bash "$MINER_DIR/idle-run.sh"; then :; else echo "[$(date -Iseconds)] monitor: idle start attempt failed" | tee -a "$DEBUG_LOG" "$MINER_LOG"; fi
      bash "$MINER_DIR/idle-bridge.sh" start || true
    fi
    msg "NOS: queued"
  fi
}
bootstrap

last_pos=""
while true; do
  logchunk="$(docker logs --since 10s nosana-node 2>&1 || true)"
  if [[ -n "$logchunk" ]]; then
    printf "%s\n" "$logchunk" | tee -a "$MINER_LOG"
    if echo "$logchunk" | grep -Eq "position [0-9]+/[0-9]+"; then
      pos="$(echo "$logchunk" | grep -E 'position [0-9]+/[0-9]+' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/')"
      if [[ -n "$pos" && "$pos" != "$last_pos" ]]; then
        echo "[nosana] queued ${pos}"" | tee -a "$MINER_LOG"; msg "NOS: queued ${pos}"
        last_pos="$pos"
      fi
      set_state status "nos - queued ${pos}"
      date +%s > "$MINER_DIR/idle.start.time"; rm -f "$MINER_DIR/job.start.time"
      # Simple rule: if queued => idle must be running
      if [[ -n "$IDLE_COMMAND" ]] && ! idle_running; then
        if bash "$MINER_DIR/idle-run.sh"; then :; else echo "[$(date -Iseconds)] monitor: idle start attempt failed" | tee -a "$DEBUG_LOG" "$MINER_LOG"; msg "NOS: idle failed"; fi
      bash "$MINER_DIR/idle-bridge.sh" start || true
      fi
    fi

    if echo "$logchunk" | grep -Eqi 'Node is claiming job|Node has found job|claimed job|Job .* started|Flow .* started|is running'; then
      set_state status "nos - job"
      date +%s > "$MINER_DIR/job.start.time"; rm -f "$MINER_DIR/idle.start.time"
      # Kill idle immediately (no graceful shutdown)
      if idle_running; then
        bash "$MINER_DIR/idle-kill.sh" || true
      fi
      msg "NOS: job started"
    fi

    if echo "$logchunk" | grep -Eq "Nosana Node finished|Job .* completed|finished successfully|Flow .* (finished|completed)"; then
      echo "[nosana] job finished" | tee -a "$MINER_LOG"; msg "NOS: job finished"
    fi
  fi
  sleep 5
done
