#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="$LOG_DIR/idle.log"
NOSANA_LOG="$LOG_DIR/nosana.log"
DEBUG_LOG="$LOG_DIR/debug.log"
PARSED_DIR="$MINER_DIR/parsed"
IDLE_SCREEN="${IDLE_SCREEN:-idle-miner}"
RUN_DIR="/run/hive"
MOTD_MINER2="$RUN_DIR/miner.2"
MOTD_STATUS2="$RUN_DIR/miner_status.2"

# ==== MOTD (miner.2) relay for idle miner ====
MOTD_RUN_DIR="/run/hive"
MOTD_MINER2="${MOTD_MINER2:-$MOTD_RUN_DIR/miner.2}"
MOTD_STATUS2="${MOTD_STATUS2:-$MOTD_RUN_DIR/miner_status.2}"
IDLE_MOTD_PID_FILE="/var/run/idle.motd.pid"

ensure_motd_dirs() { mkdir -p "$MOTD_RUN_DIR"; }

idle_motd_header() {
  local name="${IDLE_SCREEN:-idle-miner}"
  printf "\r\nMiner:   \033[0;36m%s\033[0m\r\n" "$name"
  printf "Version: \033[1;36mN/A\033[0m\r\n"
  printf "Path:    %s\r\n\r\n" "$IDLE_BIN"
}

start_idle_motd_relay() {
  ensure_motd_dirs
  echo '{"status":"running"}' > "$MOTD_STATUS2"
  { idle_motd_header; echo "Idle miner starting, streaming last 120 lines of idle.log..."; echo; } > "$MOTD_MINER2"
  if [[ -f "$IDLE_MOTD_PID_FILE" ]] && kill -0 "$(cat "$IDLE_MOTD_PID_FILE")" 2>/dev/null; then
    return 0
  fi
  (
    while :; do
      {
        idle_motd_header
        echo "---- idle.log (tail -n 120) ----"
        tail -n 120 "$IDLE_LOG" 2>/dev/null || true
        echo
      } > "$MOTD_MINER2"
      sleep 2
    done
  ) &
  echo $! > "$IDLE_MOTD_PID_FILE"
  touch "$MOTD_RUN_DIR/MINER_RUN" 2>/dev/null || true
}

stop_idle_motd_relay() {
  if [[ -f "$IDLE_MOTD_PID_FILE" ]]; then
    pid="$(cat "$IDLE_MOTD_PID_FILE" 2>/dev/null)"
    [[ -n "$pid" ]] && kill "$pid" 2>/dev/null || true
    rm -f "$IDLE_MOTD_PID_FILE"
  fi
  echo '{"status":"stopped"}' > "$MOTD_STATUS2" 2>/dev/null || true
  printf "\r\nIdle miner stopped.\r\n" > "$MOTD_MINER2" 2>/dev/null || true
}
# =============================================
CUR_MINER="$RUN_DIR/cur_miner"
CUR_MINER_BAK="$RUN_DIR/cur_miner.nosana.bak"

for d in /var/log/miner "$LOG_DIR" "$PARSED_DIR"; do mkdir -p "$d" 2>/dev/null || true; done
: > "$IDLE_LOG" || true
mkdir -p "/var/log/miner/miner2" 2>/dev/null || true
ln -sf "$IDLE_LOG" "/var/log/miner/miner2/miner.log" 2>/dev/null || true

: > "$NOSANA_LOG" || true
: > "$DEBUG_LOG" || true

msg() { [[ -x /hive/bin/message ]] && /hive/bin/message info "$1" || true; }

IDLE_COMMAND="$(cat "$PARSED_DIR/idle_command" 2>/dev/null || true)"
IDLE_ARGS="$(cat "$PARSED_DIR/idle_args" 2>/dev/null || true)"

if [[ -z "${IDLE_COMMAND:-}" ]]; then
  echo "[$(date -Iseconds)] idle-run: no idle command set" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  msg "NOS: idle start failed (no command)"; exit 1
fi

# Preflight binary checks
IDLE_DIR="$(dirname "$IDLE_COMMAND")"
IDLE_BIN="$(basename "$IDLE_COMMAND")"
if [[ ! -e "$IDLE_COMMAND" ]]; then
  echo "[$(date -Iseconds)] idle-run: binary not found: $IDLE_COMMAND" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  msg "NOS: idle start failed (binary missing)"; exit 3
fi
if [[ ! -x "$IDLE_COMMAND" ]]; then chmod +x "$IDLE_COMMAND" 2>/dev/null || true; fi

{
  echo "[$(date -Iseconds)] idle-run preflight"
  echo "  whoami=$(whoami)  pwd=$(pwd)"
  echo "  idle_dir=$IDLE_DIR idle_bin=$IDLE_BIN"
  ls -l "$IDLE_COMMAND" || true
  command -v screen || echo "screen not in PATH"
  command -v awk || echo "awk not in PATH"
  which bash || true
  if command -v file >/dev/null 2>&1; then file "$IDLE_COMMAND" || true; fi
} | tee -a "$DEBUG_LOG" "$NOSANA_LOG"

# Nuke previous session if present
if screen -ls 2>/dev/null | grep -q "\.${IDLE_SCREEN}"; then
  screen -S "$IDLE_SCREEN" -X quit || true
  sleep 0.2
fi

printf "[idle-miner] start: %s\n" "$(printf "%s" "$IDLE_COMMAND $IDLE_ARGS" | sed -E 's/(AccessToken=)[^ ]+/\1***/g; s/(--access-token[ =])[A-Za-z0-9._-]+/\1***/g; s/(--ClientSettings:AccessToken=)[^ ]+/\1***/g')" | tee -a "$NOSANA_LOG"

# Run from the binary's directory; exec ./binary to satisfy relative lookups
screen -dmS "$IDLE_SCREEN" bash -c '
  set -o pipefail
  cd "'"$IDLE_DIR"'"
  exec "./'"$IDLE_BIN"'" '"$IDLE_ARGS"' 2>&1 \
    | awk "{print \"[idle] \" \$0}" \
    | tee -a "'"$IDLE_LOG"'" \
    | tee -a "'"$NOSANA_LOG"'"
'

# Verify: check session and process
sleep 1
session_ok=0
proc_ok=0
if screen -ls 2>/dev/null | grep -q "\.${IDLE_SCREEN}"; then session_ok=1; fi
# Try to detect the process quickly
if pgrep -f -- "$IDLE_BIN" >/dev/null 2>&1; then proc_ok=1; fi

if [[ $session_ok -eq 1 || $proc_ok -eq 1 ]]; then
  echo "[$(date -Iseconds)] idle-run: idle miner started (session_ok=$session_ok proc_ok=$proc_ok)" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
ensure_motd_window_2
  start_idle_motd_relay
  msg "NOS: idle miner started"; exit 0
else
  echo "[$(date -Iseconds)] idle-run: failed to start (session_ok=$session_ok proc_ok=$proc_ok)" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  echo "Last 50 lines of idle.log:" | tee -a "$DEBUG_LOG" "$NOSANA_LOG"
  tail -n 50 "$IDLE_LOG" 2>/dev/null | tee -a "$DEBUG_LOG" "$NOSANA_LOG" || true
  stop_idle_motd_relay
  msg "NOS: idle miner failed to start"; exit 2
fi
