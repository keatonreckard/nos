#!/usr/bin/env bash
set -euo pipefail
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
install -m 0755 "$PKG_DIR/h-stats.sh" "/hive/miners/custom/nosana/h-stats.sh"
echo "[nosana] installed miner h-stats.sh -> /hive/miners/custom/nosana/h-stats.sh"
install -m 0755 "$PKG_DIR/h-stats-wrapper.sh" "/hive/miners/custom/h-stats.sh"
echo "[nosana] installed stats wrapper -> /hive/miners/custom/h-stats.sh"
