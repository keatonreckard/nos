#!/usr/bin/env bash
# HiveOS custom miner stats wrapper (v8.1.19_hiveos)
# For manual tests: sources nosana/h-stats.sh (which defines $khs and $stats), then prints $stats.
set -euo pipefail
MINER_DIR="${MINER_DIR:-/hive/miners/custom}"

load_and_print() {
  # shellcheck disable=SC1090
  source "$1"
  if [[ -n "${stats:-}" ]]; then
    printf '%s\n' "$stats"
    exit 0
  fi
  printf '%s\n' '{"hs":[0],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"","ar":[0,0],"algo":"nos - initializing","bus_numbers":[]}'
  exit 0
}

if [[ -n "${CUSTOM_MINER:-}" && -f "$MINER_DIR/$CUSTOM_MINER/h-stats.sh" ]]; then
  load_and_print "$MINER_DIR/$CUSTOM_MINER/h-stats.sh"
fi

if [[ -f "$MINER_DIR/nosana/h-stats.sh" ]]; then
  load_and_print "$MINER_DIR/nosana/h-stats.sh"
fi

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "$SELF_DIR/nosana/h-stats.sh" ]]; then
  load_and_print "$SELF_DIR/nosana/h-stats.sh"
fi

printf '%s\n' '{"hs":[0],"hs_units":"khs","temp":[],"fan":[],"uptime":0,"ver":"","ar":[0,0],"algo":"nos - initializing","bus_numbers":[]}'
