#!/usr/bin/env bash
# Simple tail+prefix bridge from idle.log into nosana.log. One instance only.
set -euo pipefail

LOG_DIR="/var/log/miner/nosana"
IDLE_LOG="${IDLE_LOG:-$LOG_DIR/idle.log}"
MINER_LOG="${MINER_LOG:-$LOG_DIR/nosana.log}"
PID_FILE="/var/run/idle-bridge.pid"

mkdir -p "$LOG_DIR" /var/run
touch "$MINER_LOG" "$IDLE_LOG"

# prevent multiple
if [[ -f "$PID_FILE" ]]; then
  oldpid="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [[ -n "$oldpid" && -e "/proc/$oldpid" ]]; then
    exit 0
  fi
fi

( tail -n0 -F "$IDLE_LOG" 2>/dev/null | awk '{print "[idle-miner] " $0}' >> "$MINER_LOG" ) &
echo $! > "$PID_FILE"
