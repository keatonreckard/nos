#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
START_FILE="$MINER_DIR/nosana.start.time"

NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR" "$RUN_DIR"
exec 2>>"$LOG_DIR/debug.log"

# Defaults
status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""; idle_enabled=0

# Load state if available
[[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true

# Read logs (strip CR + ANSI)
read_log() {
  local f="$1"
  [[ -s "$f" ]] || return 0
  sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g' "$f" | tr -d '\r'
}

NOSANA_CLEAN="$(read_log "$NOSANA_LOG")"
IDLE_CLEAN="$(read_log "$IDLE_LOG")"

# ---- Parse Wallet/SOL/NOS (prefer state, else log) ----
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "$NOSANA_CLEAN" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
  [[ -z "$wallet" ]] && wallet="$(printf "%s\n" "$NOSANA_CLEAN" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
fi
if [[ -z "${sol:-}" ]]; then
  sol="$(printf "%s\n" "$NOSANA_CLEAN" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
if [[ -z "${nos:-}" ]]; then
  nos="$(printf "%s\n" "$NOSANA_CLEAN" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi

# ---- Determine node state (initializing / queued / job) ----
algo_base="nos - initializing"
khs=1

# queued?
queued_line="$(printf "%s\n" "$NOSANA_CLEAN" | grep -E 'QUEUED[[:space:]]+In market .* at position [0-9]+/[0-9]+' | tail -n1 || true)"
if [[ -n "$queued_line" ]]; then
  pos="$(sed -nE 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/p' <<<"$queued_line")"
  [[ -n "$pos" ]] && algo_base="nos - queued $pos" || algo_base="nos - queued"
fi

# job?
# Heuristics: presence of "Job started"|"Starting job"|"Executor started"|"Running job"|"Starting container for job"
job_line="$(printf "%s\n" "$NOSANA_CLEAN" | grep -E 'Job (started|running)|Starting (job|container)|Executor started|Running health check.*OK.*starting job' | tail -n1 || true)"
if [[ -n "$job_line" ]]; then
  algo_base="nos - job"
fi

# ---- Idle miner algo + per-device hashrates ----
# We expose GPU and CPU separately for qubic; for XMR it's CPU-only.
algo_idle=""
hs_units="hs"
hs_arr=()
temp_arr=()
fan_arr=()
bus_arr=()

# Helper to extract "avg it/s" from last matching line
extract_avg_its() {
  local pattern="$1"
  local src="$2"
  local ln="$(printf "%s\n" "$src" | grep -E "$pattern" | grep -E 'avg it/s' | tail -n1 || true)"
  [[ -z "$ln" ]] && echo "0" && return 0
  # Grab the last "avg it/s" number
  echo "$ln" | grep -oE '[0-9]+[.]?[0-9]* avg it/s' | tail -n1 | awk '{print $1}'
}

if [[ "$algo_base" != "nos - job" ]]; then
  # Decide between XMR vs qubic based on presence of [XMR] in last 50 lines
  last50="$(printf "%s\n" "$IDLE_CLEAN" | tail -n 50)"
  if echo "$last50" | grep -q '\[XMR\]'; then
    algo_idle="idle xmr"
    cpu_hs="$(extract_avg_its '\[XMR\]' "$IDLE_CLEAN")"
    # XMR is CPU only
    hs_arr+=("$cpu_hs")
  else
    algo_idle="idle qubic"
    # QUBIC: GPU + CPU from [CUDA] and (AVX512|AVX2|GENERIC)
    gpu_hs="$(extract_avg_its '\[CUDA\]' "$IDLE_CLEAN")"
    cpu_hs="$(extract_avg_its '\[(AVX512|AVX2|GENERIC)\]' "$IDLE_CLEAN")"
    # Put GPU first, CPU second
    hs_arr+=("$gpu_hs" "$cpu_hs")
  fi
fi

# ---- Compute total khs from hs_arr unless job/initializing (1 kH/s) ----
if [[ "$algo_base" == "nos - job" || "$algo_base" == "nos - initializing" ]]; then
  khs=1
  # Represent 1 kH/s as 1000 hs
  hs_arr=(1000)
else
  sum_hs=0
  for v in "${hs_arr[@]:-}"; do
    [[ -z "$v" ]] && v=0
    # integer add; v can be float but awk fallback below
    sum_hs=$(awk -v a="$sum_hs" -v b="$v" 'BEGIN{printf "%.6f", a+b}')
  done
  # hs are in it/s; 1000 it/s == 1 khs
  khs=$(awk -v s="$sum_hs" 'BEGIN{printf "%.6f", s/1000.0}')
fi

# ---- Build version string "S:<sol> N:<nos> W:<wallet5>" ----
w5=""; [[ -n "${wallet:-}" ]] && w5="${wallet:0:5}"
ver=""
if [[ -n "${sol:-}" || -n "${nos:-}" || -n "$w5" ]]; then
  ver="S:${sol:-0} N:${nos:-0} W:${w5:------}"
fi

# ---- Algo final (append idle suffix only when not job/initializing and we have hs) ----
algo="$algo_base"
if [[ "$algo_base" != "nos - job" && "$algo_base" != "nos - initializing" && -n "${algo_idle:-}" ]]; then
  algo="$algo_base - $algo_idle"
fi

# ---- Uptime (since start file) ----
uptime=0
if [[ -f "$START_FILE" ]]; then
  now=$(date +%s)
  started=$(cat "$START_FILE" 2>/dev/null || echo 0)
  if [[ "$started" =~ ^[0-9]+$ && "$now" -gt "$started" ]]; then
    uptime=$(( now - started ))
  fi
fi

# ---- Emit
# hs as JSON array
hs_json="[]"
if [[ "${#hs_arr[@]}" -gt 0 ]]; then
  hs_json="$(printf '%s\n' "${hs_arr[@]}" | jq -sc '.')"
fi

stats="$(jq -nc \
  --argjson hs "$hs_json" \
  --arg hs_units "$hs_units" \
  --argjson temp "[]" \
  --argjson fan "[]" \
  --arg uptime "$uptime" \
  --arg ver "$ver" \
  --arg algo "$algo" \
  --argjson bus_numbers "[]" \
  '{hs: $hs, hs_units: $hs_units, temp: $temp, fan: $fan, uptime: ($uptime|tonumber), ver: $ver, algo: $algo, bus_numbers: $bus_numbers}' \
)"

echo "$khs"
echo "$stats"
