#!/usr/bin/env bash
# tolerant stats
set +e

RUN_DIR="/var/run"
STATE="$RUN_DIR/nosana.state"
NOSLOG="/var/log/miner/nosana/nosana.log"

status="nos - initializing"
wallet=""
sol=""
nos=""
queue=""

if [ -f "$STATE" ]; then
  # shellcheck disable=SC1090
  . "$STATE"
else
  # fallback parse
  cleaned=$(tr -d '\r' < "$NOSLOG" 2>/dev/null)
  [ -n "$cleaned" ] || cleaned=""
  w=$(echo "$cleaned" | sed -n 's/.*Wallet:[[:space:]]*\([A-Za-z0-9]\{32,64\}\).*/\1/p' | tail -n1)
  s=$(echo "$cleaned" | sed -n 's/.*SOL balance:[[:space:]]*\([0-9.]\+\).*/\1/p' | tail -n1)
  n=$(echo "$cleaned" | sed -n 's/.*NOS balance:[[:space:]]*\([0-9.]\+\).*/\1/p' | tail -n1)
  q=$(echo "$cleaned" | sed -n 's/.*QUEUED.*position \([0-9]\+\/[0-9]\+\).*/\1/p' | tail -n1)
  [ -n "$w" ] && wallet="$w"
  [ -n "$s" ] && sol="$s"
  [ -n "$n" ] && nos="$n"
  [ -n "$q" ] && queue="$q" && status="nos - queued $q"
  if echo "$cleaned" | grep -Eiq 'claimed job|started successfully|is resuming|resumed|is running'; then
    status="nos - job"
  fi
fi

# gpu arrays
temp_json='[]'; fan_json='[]'; bus_json='[]'
if [ -f /hive/bin/gpu-stats ]; then
  # shellcheck disable=SC1091
  . /hive/bin/gpu-stats 2>/dev/null
  if [ "${#GPU_TEMP[@]}" -gt 0 ] 2>/dev/null; then temp_json="["$(printf "%s," "${GPU_TEMP[@]}" | sed 's/,$//')"]"; fi
  if [ "${#GPU_FAN[@]}" -gt 0 ] 2>/dev/null; then fan_json="["$(printf "%s," "${GPU_FAN[@]}" | sed 's/,$//')"]"; fi
  if [ "${#BUS_IDS[@]}" -gt 0 ] 2>/dev/null; then
    buses=(); for b in "${BUS_IDS[@]}"; do d=$((16#${b%%:*})); buses+=("$d"); done
    bus_json="["$(printf "%s," "${buses[@]}" | sed 's/,$//')"]"
  fi
fi

format4() { awk -v n="${1:-0}" 'BEGIN{printf("%.4f", n+0)}'; }
sol4="N/A"; [ -n "$sol" ] && sol4="$(format4 "$sol")"
nos4="N/A"; [ -n "$nos" ] && nos4="$(format4 "$nos")"
wal5="N/A"; [ -n "$wallet" ] && wal5="$(printf '%s' "$wallet" | cut -c1-5)"

ver="S:${sol4} N:${nos4} W:${wal5}"
[ -n "$queue" ] && ver="$ver Q:${queue}"

khs="0"; ar_acc="0"; ar_rej="0"
uptime=$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 0)

stats=$(cat <<JSON
{"hs":[${khs}],"hs_units":"khs","temp":${temp_json},"fan":${fan_json},"uptime":${uptime},"ver":"${ver}","ar":[${ar_acc},${ar_rej}],"algo":"${status}","bus_numbers":${bus_json}}
JSON
)

echo "$khs"
echo "$stats"
exit 0
