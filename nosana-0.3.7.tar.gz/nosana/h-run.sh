#!/usr/bin/env bash
set -u

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
DEBUG="$LOG_DIR/debug.log"
NOSLOG="$LOG_DIR/nosana.log"

mkdir -p "$LOG_DIR"
touch "$DEBUG" "$NOSLOG"

echo "[$(date -Iseconds)] h-run: cleaning previous containers" | tee -a "$DEBUG"
docker rm -f nosana-node podman >/dev/null 2>&1 || true
pkill -9 -f "podman system service" >/dev/null 2>&1 || true
screen -S nosana-idle -X quit >/dev/null 2>&1 || true

# Make sure docker is up
systemctl start docker >/dev/null 2>&1 || true

echo "[$(date -Iseconds)] h-run: starting podman sidecar" | tee -a "$DEBUG"
docker volume inspect podman-cache >/dev/null 2>&1 || docker volume create podman-cache >/dev/null
docker volume inspect podman-socket >/dev/null 2>&1 || docker volume create podman-socket >/dev/null
docker run -d --pull=always --gpus=all --name podman --device /dev/fuse \
  --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman --privileged -e ENABLE_GPU=true \
  nosana/podman:v1.1.0 unix:/podman/podman.sock >> "$DEBUG" 2>&1 || true

sleep 4

echo "[$(date -Iseconds)] h-run: starting nosana-node container" | tee -a "$DEBUG"
docker run -d \
  --pull=always \
  --name nosana-node \
  --network host \
  --gpus all \
  --volume /root/.nosana/:/root/.nosana/ \
  --volume podman-socket:/root/.nosana/podman:ro \
  nosana/nosana-cli:latest node start --network "${SOL_NET_ENV:=mainnet}" >> "$DEBUG" 2>&1 || true

# Stream docker logs to file in the background
( while true; do docker logs --since 1s -f nosana-node >> "$NOSLOG" 2>&1 || true; sleep 2; done ) & echo $! > /var/run/nosana_logs.pid

# start monitor (keeps a background wait)
bash "$MINER_DIR/monitor.sh" >> "$DEBUG" 2>&1 &

# keep foreground
tail -f "$NOSLOG"
