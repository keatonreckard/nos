Nosana HiveOS wrapper v0.3.7
Idle miner via screen session 'nosana-idle'. State in /var/run/nosana.state
