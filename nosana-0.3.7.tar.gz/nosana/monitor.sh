#!/usr/bin/env bash
set -u

MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
NOSLOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"
STATE="/var/run/nosana.state"
RAW_EXTRA="$MINER_DIR/extra.raw"

ensure_state() {
  [ -f "$STATE" ] || echo 'status="nos - initializing"' > "$STATE"
}

get_idle_cmd() {
  # Extract idleSettings.command and arguments from RAW_EXTRA (JSON-ish). Be tolerant of spaces.
  local raw="$(cat "$RAW_EXTRA" 2>/dev/null)"
  local cmd args
  cmd="$(echo "$raw" | sed -n 's/.*"idleSettings"[^{]*{[^}]*"command"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | tail -n1)"
  args="$(echo "$raw" | sed -n 's/.*"idleSettings"[^{]*{[^}]*"arguments"[[:space:]]*":[[:space:]]*"\([^"]*\)".*/\1/p' | tail -n1)"
  echo "$cmd|$args"
}

idle_start() {
  local pair cmd args
  pair="$(get_idle_cmd)"
  cmd="${pair%%|*}"; args="${pair#*|}"
  [ -z "$cmd" ] && return 0
  if ! screen -ls | grep -q "\.nosana-idle"; then
    echo "[nosana] idle start: $cmd $args" >> "$IDLE_LOG"
    screen -S nosana-idle -dm bash -lc "$cmd $args >> \"$IDLE_LOG\" 2>&1"
  fi
}

idle_stop() {
  if screen -ls | grep -q "\.nosana-idle"; then
    screen -S nosana-idle -X quit || true
    echo "[nosana] idle stop" >> "$IDLE_LOG"
  fi
}

update_state_from_line() {
  local L="$1"
  local w s n q
  if echo "$L" | grep -Eq 'Wallet:[[:space:]]+[A-Za-z0-9]{32,64}'; then
    w="$(echo "$L" | sed -n 's/.*Wallet:[[:space:]]*\([A-Za-z0-9]\{32,64\}\).*/\1/p')"
    [ -n "$w" ] && sed -i "s/^wallet=.*/wallet=\"$w\"/;t; $ a wallet=\"$w\"" "$STATE"
  fi
  if echo "$L" | grep -Eq 'SOL balance:[[:space:]]*[0-9]'; then
    s="$(echo "$L" | sed -n 's/.*SOL balance:[[:space:]]*\([0-9.]\+\).*/\1/p')"
    [ -n "$s" ] && sed -i "s/^sol=.*/sol=\"$s\"/;t; $ a sol=\"$s\"" "$STATE"
  fi
  if echo "$L" | grep -Eq 'NOS balance:[[:space:]]*[0-9]'; then
    n="$(echo "$L" | sed -n 's/.*NOS balance:[[:space:]]*\([0-9.]\+\).*/\1/p')"
    [ -n "$n" ] && sed -i "s/^nos=.*/nos=\"$n\"/;t; $ a nos=\"$n\"" "$STATE"
  fi
  if echo "$L" | grep -Eq 'QUEUED.*position [0-9]+/[0-9]+'; then
    q="$(echo "$L" | sed -n 's/.*position \([0-9]\+\/[0-9]\+\).*/\1/p')"
    [ -n "$q" ] && sed -i "s/^queue=.*/queue=\"$q\"/;t; $ a queue=\"$q\"" "$STATE"
    sed -i "s/^status=.*/status=\"nos - queued $q\"/;t; $ a status=\"nos - queued $q\"" "$STATE"
    idle_start
  fi
  if echo "$L" | grep -Eiq 'claimed job|Job .* started|started successfully|is resuming|resumed|is running'; then
    sed -i "s/^status=.*/status=\"nos - job\"/;t; $ a status=\"nos - job\"" "$STATE"
    idle_stop
  fi
  if echo "$L" | grep -Eq 'finished successfully|RESTARTING'; then
    sed -i "s/^status=.*/status=\"nos - initializing\"/;t; $ a status=\"nos - initializing\"" "$STATE"
  fi
}

bootstrap_from_log() {
  # Load last 400 lines to seed state on start/restart
  tail -n 400 "$NOSLOG" 2>/dev/null | while IFS= read -r line; do
    update_state_from_line "$line"
  done
}

main() {
  ensure_state
  bootstrap_from_log
  tail -n0 -F "$NOSLOG" 2>/dev/null | while IFS= read -r line; do
    echo "$line" | sed 's/\r$//' >> "$LOG_DIR/monitor.tap" 2>/dev/null
    update_state_from_line "$line"
  done
}

main &
echo $$ > /var/run/nosana_monitor.pid
wait
