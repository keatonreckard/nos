#!/usr/bin/env bash
set -u
MINER_DIR="/hive/miners/custom/nosana"
LOG_DIR="/var/log/miner/nosana"
CONF_FILE="$MINER_DIR/nosana.conf"
RAW_EXTRA="$MINER_DIR/extra.raw"

mkdir -p "$MINER_DIR" "$LOG_DIR"
: "${CUSTOM_USER_CONFIG:=}"
# Hive auto-prefixes VERBOSE= in nosana.conf; we keep parity
echo -n "VERBOSE=" > "$CONF_FILE"; echo "$CUSTOM_USER_CONFIG" >> "$CONF_FILE"
echo "$CUSTOM_USER_CONFIG" > "$RAW_EXTRA"

# Touch logs
touch "$LOG_DIR/nosana.log" "$LOG_DIR/debug.log" "$LOG_DIR/idle.log"

exit 0
