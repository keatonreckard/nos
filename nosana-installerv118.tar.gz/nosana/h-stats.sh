#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

# ---- paths ----
MINER_DIR="/hive/miners/custom/nosana"

# --- LAST_CMD_ID detection ---
LAST_CMD_ID_SRC=""
if [ -n "${LAST_CMD_ID:-}" ]; then
  LAST_CMD_ID_SRC="$LAST_CMD_ID"
elif [ -f /run/hive/last_cmd_id ]; then
  LAST_CMD_ID_SRC="$(tr -cd '0-9' < /run/hive/last_cmd_id | head -c 18)"
elif [ -f /run/hive/command_id ]; then
  LAST_CMD_ID_SRC="$(tr -cd '0-9' < /run/hive/command_id | head -c 18)"
else
  LAST_CMD_ID_SRC="$(grep -Eo \"last_cmd_id\":[0-9]+ /var/log/hive-agent/agent-screen.log 2>/dev/null | tail -n1 | tr -cd '0-9')"
fi
# --- END LAST_CMD_ID detection ---


# === NOSANA_FORCE_STATE_BLOCK ===
NOW_TS=$(date +%s)
START_FILE="$MINER_DIR/nosana.start.time"
JOB_FILE="$MINER_DIR/job.start.time"
INIT_WINDOW=${INIT_WINDOW:-120}
read_ts_file() { [[ -f "$1" ]] && awk 'NR==1{print $1}' "$1" 2>/dev/null || echo ""; }
START_TS=$(read_ts_file "$START_FILE")
JOB_TS=$(read_ts_file "$JOB_FILE")
if [[ -n "$JOB_TS" ]]; then
  STATE_OVERRIDE="job"
elif [[ -n "$START_TS" ]] && (( NOW_TS - START_TS < INIT_WINDOW )); then
  STATE_OVERRIDE="init"
else
  STATE_OVERRIDE=""
fi
# === END NOSANA_FORCE_STATE_BLOCK ===
RUN_DIR="/var/run"
STATE_FILE="$RUN_DIR/nosana.state"
LOG_DIR="/var/log/miner/nosana"
NOSANA_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

mkdir -p "$LOG_DIR"
exec 2>>"$LOG_DIR/debug.log"

# Fallbacks
khs=0
stats=""
status="nos - initializing"; queue=""; sol=""; nos=""; wallet=""; idle_enabled=0
# Load previous state if present (to avoid losing version string between phases)
if [[ -f "$STATE_FILE" ]]; then
  # shellcheck disable=SC1090
  source "$STATE_FILE" || true
fi

# Read & clean logs (strip ANSI)
clean_log() {
  local file="$1"
  [[ -s "$file" ]] || return 1
  # read last slice and strip carriage returns + ANSI
  tail -n 4000 "$file" 2>/dev/null | tr -d '\r' | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g'
  return 0
}

NOS_CLEAN="$(clean_log "$NOSANA_LOG" || true)"
IDLE_CLEAN="$(clean_log "$IDLE_LOG" || true)"

# ---- Parse wallet / balances from nosana log ----
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*[Ww]allet:[[:space:]]*([A-HJ-NP-Za-km-z1-9]{32,48}).*/\1/p' | tail -n1)"
fi
if [[ -z "${wallet:-}" ]]; then
  wallet="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's#.*https://([A-HJ-NP-Za-km-z1-9]{32,48})\.node\.k8s\.prd\.nos\.ci.*#\1#p' | tail -n1)"
fi

if [[ -z "${sol:-}" ]]; then
  sol="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*SOL[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi
if [[ -z "${nos:-}" ]]; then
  nos="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*NOS[[:space:]]*balance:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/p' | tail -n1)"
fi

# Build version string (keep previous if data not found)
ver_build=""
if [[ -n "${sol:-}" || -n "${nos:-}" || -n "${wallet:-}" ]]; then
  shortw=""
  if [[ -n "${wallet:-}" ]]; then shortw="$(printf "%s" "$wallet" | cut -c1-5)"; fi
  ver_build="S:${sol:-0} N:${nos:-0} W:${shortw:-?????}"
fi
# If version string wasn't derivable now, keep old one if present
ver="${ver_build:-${ver:-}}"

# ---- Parse queue position ----
queue_txt="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*QUEUED.*position[[:space:]]*([0-9]+)\/([0-9]+).*/\1\/\2/p' | tail -n1)"
if [[ -z "$queue_txt" ]]; then
  queue_txt="$(printf "%s\n" "${NOS_CLEAN:-}" | sed -nE 's/.*queued[[:space:]]*([0-9]+)\/([0-9]+).*/\1\/\2/p' | tail -n1)"
fi

# ---- Determine idle mode (qubic vs xmr) ----
idle_mode=""
if [[ -n "${IDLE_CLEAN:-}" ]]; then
  # consider XMR mode if there are sufficiently many XMR lines recently
  xmr_count="$(printf "%s\n" "$IDLE_CLEAN" | tail -n 120 | grep -c '\[XMR\]' || true)"
  if [[ "${xmr_count:-0}" -ge 3 ]]; then
    idle_mode="xmr"
  else
    # default qubic if we see AVX/GENERIC or CUDA signatures
    if printf "%s\n" "$IDLE_CLEAN" | grep -Eq '\[(AVX512|AVX2|GENERIC|CUDA)\]'; then
      idle_mode="qubic"
    fi
  fi
fi

# ---- Extract idle hashrates (instant or avg it/s) ----
extract_avg() { # $1: pattern e.g. '\[CUDA\]'
  printf "%s\n" "${IDLE_CLEAN:-}" | grep -E "$1" | grep -E 'avg it/s' | tail -n1 | sed -nE 's/.*\|\s*([0-9]+)[[:space:]]+avg it\/s.*/\1/p'
}
extract_inst_gpu() {
  printf "%s\n" "${IDLE_CLEAN:-}" | grep -E '\[GPU\][[:space:]]+Trainer:[[:space:]]+GPU #[0-9]+:' | tail -n1 | sed -nE 's/.*GPU #[0-9]+:[[:space:]]*([0-9]+)[[:space:]]+it\/s.*/\1/p'
}

cpu_hs=""; gpu_hs=""
if [[ "$idle_mode" == "xmr" ]]; then
  cpu_hs="$(extract_avg '\[XMR\]')"
  [[ -z "${cpu_hs}" ]] && cpu_hs="0"
elif [[ "$idle_mode" == "qubic" ]]; then
  cpu_hs="$(extract_avg '\[(AVX512|AVX2|GENERIC)\]')"
  gpu_hs="$(extract_avg '\[CUDA\]')"
  if [[ -z "${gpu_hs}" ]]; then
    gpu_hs="$(extract_inst_gpu)"
  fi
  [[ -z "${cpu_hs}" ]] && cpu_hs="0"
  [[ -z "${gpu_hs}" ]] && gpu_hs="0"
fi

# ---- Build algo label ----
algo="nos - initializing"
if [[ -n "$queue_txt" ]]; then
  algo="nos - queued ${queue_txt}"
else
  # If we can detect non-queued, try to keep previous status string if available
  if [[ -n "${status:-}" ]]; then algo="${status}"; fi
fi
if [[ -n "$idle_mode" ]]; then
  algo="${algo} - idle ${idle_mode}"
fi
# Remove idle suffix during init/job
if [[ "$STATE_OVERRIDE" == "init" || "$STATE_OVERRIDE" == "job" ]]; then
  algo="${algo/ - idle */}"
fi

# ---- Build hashrates array & khs ----
hs_units="hs"
hs_json="[]"
if [[ "$idle_mode" == "xmr" ]]; then
  hs_json="$(jq -nc --argjson x "${cpu_hs:-0}" '[ $x ]')"
  # convert to khs (from it/s)
  khs="$(echo "scale=6; (${cpu_hs:-0}) / 1000" | bc)"
elif [[ "$idle_mode" == "qubic" ]]; then
  # order: [GPU, CPU], like your working qubic stats
  hs_json="$(jq -nc --argjson g "${gpu_hs:-0}" --argjson c "${cpu_hs:-0}" '[ $g, $c ]')"
  total_hs="$(echo "${gpu_hs:-0} + ${cpu_hs:-0}" | bc)"
  khs="$(echo "scale=6; ${total_hs} / 1000" | bc)"
else
  # Not in idle or no data: keep previous behavior (tiny non-zero or zero)
  khs="${khs:-0}"
  hs_json="[]"
fi

# ---- Uptime heuristic ----
uptime=0
if [[ -f "$NOSANA_LOG" ]]; then
  now="$(date +%s)"
  mt="$(stat --format='%Y' "$NOSANA_LOG" || echo "$now")"
  delta=$(( now - mt ))
  if (( delta < 86400 )); then uptime=$(( 120 + (86400 - delta) % 300 )); fi
fi

# ---- Emit stats ----
# temp / fan left empty; bus_numbers left empty (nulls) per current wrapper
stats="$(
# --- Final enforce for init/job + version truncation ---
# Force algo + khs for init/job
if [[ "$STATE_OVERRIDE" == "init" ]]; then
  algo="nos - initializing"
  khs=1
  hs_units="khs"
  hs_json="[]"
elif [[ "$STATE_OVERRIDE" == "job" ]]; then
  algo="nos - job"
  khs=1
  hs_units="khs"
  hs_json="[]"
fi

# Truncate SOL/NOS in version string to 3 decimals (no rounding)
# Expect ver like: S:<sol> N:<nos> W:<prefix>
if [[ -n "$ver" ]]; then
  sol_raw="$(printf "%s" "$ver" | sed -n 's/.*S:\([0-9.]*\).*/\1/p' | head -n1)"
  nos_raw="$(printf "%s" "$ver" | sed -n 's/.*N:\([0-9.]*\).*/\1/p' | head -n1)"
  w_raw="$(printf "%s" "$ver" | sed -n 's/.*W:\([A-Za-z0-9]*\).*/\1/p' | head -n1)"
  trunc3() { awk -v x="$1" 'BEGIN{ if (x == "" ) { print ""; exit } v=int(x*1000)/1000; printf "%.3f", v }'; }
  sol3="$(trunc3 "$sol_raw" 2>/dev/null)"
  nos3="$(trunc3 "$nos_raw" 2>/dev/null)"
  if [[ -n "$sol3$nos3$w_raw" ]]; then
    ver="S:${sol3} N:${nos3} W:${w_raw}"
  fi
fi
# --- End enforce ---
jq -nc \
  --argjson hs "${hs_json}" \
  --arg hs_units "${hs_units}" \
  --argjson temp '[]' \
  --argjson fan '[]' \
  --arg uptime "${uptime}" \
  --arg ver "${ver:-}" \
  --arg last_cmd_id "${LAST_CMD_ID_SRC:-}" \
  --arg algo "${algo}" \
  --argjson bus_numbers '[]' \
  '{ $hs, $hs_units, $temp, $fan, $uptime, $ver, $algo, $bus_numbers } + ( ($last_cmd_id|length) as $l | if $l == 0 then {} else {last_cmd_id: ($last_cmd_id|tonumber?)} end )'
)"

# --- Enforce khs/algo at output time ---
if [[ "$STATE_OVERRIDE" == "init" ]]; then
  khs=1; hs_units="khs"; algo="nos - initializing"
elif [[ "$STATE_OVERRIDE" == "job" ]]; then
  khs=1; hs_units="khs"; algo="nos - job"
fi
# Remove idle suffix during init/job
if [[ "$STATE_OVERRIDE" == "init" || "$STATE_OVERRIDE" == "job" ]]; then
  algo="${algo/ - idle */}"
fi
# --- End enforce ---

# --- Guard: ensure stats JSON has "algo"; rebuild minimal JSON if missing ---
if ! printf "%s" "$stats" | grep -q '"algo"'; then
  # Fallback minimal fields to keep Hive happy
  hs_json="${hs_json:-[]}"
  hs_units="${hs_units:-khs}"
  temp_json="[]"; fan_json="[]"; bus_json="[]"
  uptime="${uptime:-}"; ver="${ver:-}"; algo="${algo:-nos}"
  # Include last_cmd_id if available
  if [ -n "${LAST_CMD_ID_SRC:-}" ]; then
    stats="$(jq -n \
      --argjson hs "$hs_json" \
      --arg hs_units "$hs_units" \
      --argjson temp "$temp_json" \
      --argjson fan "$fan_json" \
      --arg uptime "${uptime}" \
      --arg ver "${ver}" \
      --arg algo "${algo}" \
      --argjson bus_numbers "$bus_json" \
      --arg last_cmd_id "${LAST_CMD_ID_SRC}" \
      '"{ $hs, $hs_units, $temp, $fan, $uptime, $ver, $algo, $bus_numbers } + {last_cmd_id: ($last_cmd_id|tonumber?)}"')"
  else
    stats="$(jq -n \
      --argjson hs "$hs_json" \
      --arg hs_units "$hs_units" \
      --argjson temp "$temp_json" \
      --argjson fan "$fan_json" \
      --arg uptime "${uptime}" \
      --arg ver "${ver}" \
      --arg algo "${algo}" \
      --argjson bus_numbers "$bus_json" \
      '"{ $hs, $hs_units, $temp, $fan, $uptime, $ver, $algo, $bus_numbers }"')"
  fi
fi
# --- End guard ---

# Output for Hive agent
echo "${khs:-0}"
echo "${stats}"
