#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

MINER_NAME="nosana"
MINER_DIR="/hive/miners/custom/${MINER_NAME}"
STATE_FILE="/var/run/${MINER_NAME}.state"
NOSANA_LOG="/run/hive/miner.1"
IDLE_LOG="/run/hive/miner.2"
IDLE_STATUS="/run/hive/miner_status.2"
START_STAMP="${MINER_DIR}/nosana.start.time"
JOB_STAMP="${MINER_DIR}/job.start.time"
IDLE_STAMP="${MINER_DIR}/idle.start.time"
INIT_GRACE=45

sanitize() { sed -u -e 's/\r/\n/g' -E -e 's/\x1B\[[0-9;?]*[ -\/]*[@-~]//g'; }
read_state() { [[ -f "$STATE_FILE" ]] && source "$STATE_FILE" || true; }
age_since() {
  local f="$1" now ts; now="$(date +%s)"
  [[ -f "$f" ]] && ts="$(cat "$f" 2>/dev/null)" || ts="$now"
  [[ "$ts" =~ ^[0-9]+$ ]] || ts="$now"
  echo $(( now - ts ))
}
queue_pos() {
  local l; l="$(tail -n 1500 "$NOSANA_LOG" 2>/dev/null | sanitize | grep -Eo 'position[[:space:]]+[0-9]+/[0-9]+' | tail -n 1 || true)"
  if [[ "$l" =~ position[[:space:]]+([0-9]+)/([0-9]+) ]]; then
    echo "${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
  fi
}
idle_up() {
  [[ -f "$IDLE_STATUS" ]] && grep -q '"running"' "$IDLE_STATUS" 2>/dev/null && return 0
  tail -n 50 "$IDLE_LOG" 2>/dev/null | sanitize | grep -qE '([0-9]+(\.[0-9]+)?)\s*(it/s|its|kH/s|KH/s|kh/s)' && return 0
  return 1
}
parse_idle_khs() {
  local block match its unit
  IDLE_KHS="0.00"
  block="$(tail -n 200 "$IDLE_LOG" 2>/dev/null | sanitize)"
  match="$(grep -Eo '([0-9]+([.][0-9]+)?)\s*(it/s|its|kH/s|KH/s|kh/s)' <<<"$block" | tail -n 1 || true)"
  if [[ -n "$match" ]]; then
    its="${match%% *}"; unit="${match##* }"
    case "$unit" in
      it/s|its) IDLE_KHS="$(awk -v n="$its" 'BEGIN{ printf "%.2f", n/1000.0 }')" ;;
      kH/s|KH/s|kh/s) IDLE_KHS="$(awk -v n="$its" 'BEGIN{ printf "%.2f", n }')" ;;
    esac
  fi
}
emit() {
  local khs="$1" up="$2" algo="$3"
  khs="$(awk -v n="$khs" 'BEGIN{ printf "%.2f", n+0 }')"
  [[ "$up" =~ ^[0-9]+$ ]] || up=0
  printf "%s\n" "$khs"
  printf '{"hs":[%s],"hs_units":"khs","temp":[],"fan":[],"uptime":%s,"ver":"","algo":"%s","bus_numbers":[]}\n' "$khs" "$up" "$algo"
}

read_state
status="${status:-nos - initializing}"
sa="$(age_since "$START_STAMP")"

# init grace always emits initializing
if (( sa < INIT_GRACE )); then
  emit "0" "$sa" "nos - initializing"
  exit 0
fi

# infer queued by log if not job
qpos="$(queue_pos || true)"
if [[ "${status}" != "nos - job" && -n "${qpos:-}" ]]; then
  status="nos - queued"
fi

case "$status" in
  "nos - job"|"nos - job running")
    emit "1" "$(age_since "$JOB_STAMP")" "nos - job running"
    ;;
  "nos - queued")
    parse_idle_khs || true
    if idle_up; then
      emit "$IDLE_KHS" "$(age_since "$START_STAMP")" "nos queued ${qpos:-?/?} - idle"
    else
      emit "0" "$(age_since "$START_STAMP")" "nos queued ${qpos:-?/?}"
    fi
    ;;
  *)
    emit "0" "$sa" "nos - initializing"
    ;;
esac
