#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
. "$(dirname "$0")/h-config.sh"

echo "$(date +%s)" > "$START_STAMP"
set_state "nos - initializing"
note "node starting"

# Always kill any previous idle miner first (avoid overlap)
idle_kill || true
note "cleared previous idle miner - if any"

# --- start podman sidecar (container) ---
if docker ps -a --format '{{.Names}}' | grep -q '^podman$'; then
  docker rm -f podman >/dev/null 2>&1 || true
fi
note "starting podman sidecar - container"
docker run -d \
  --pull=always \
  --gpus=all \
  --name podman \
  --device /dev/fuse \
  --mount source=podman-cache,target=/var/lib/containers \
  --volume podman-socket:/podman \
  --privileged \
  -e ENABLE_GPU=true \
  nosana/podman:v1.1.0 unix:/podman/podman.sock >/dev/null

# wait a bit for socket
sleep 2
if docker exec podman test -S /podman/podman.sock 2>/dev/null; then
  note "podman socket is up"
else
  note "podman socket not ready; continuing"
fi

# --- start nosana-node container (detached), feed ONLY to miner.1 via stdout ---
if docker ps -a --format '{{.Names}}' | grep -q '^nosana-node$'; then
  docker rm -f nosana-node >/dev/null 2>&1 || true
fi
note "starting nosana-node - podman provider via volume"
docker run -d \
  --pull=always \
  --name nosana-node \
  --network host \
  --volume /root/.nosana/:/root/.nosana/ \
  --volume podman-socket:/root/.nosana/podman:ro \
  -e CLI_VERSION= \
  nosana/nosana-cli:latest \
    node start --network mainnet >/dev/null

# Start a background logger that sanitizes docker logs -> stdout (miner.1)
(
  docker logs -f nosana-node 2>&1 | sanitize_stream
)&

# --- queue watcher & idle lifecycle ---
last_q=""
idle_started=0

(
  # polling loop reading sanitized stream from docker logs
  while true; do
    line="$(docker logs --since 1s --tail 200 nosana-node 2>/dev/null | sanitize_stream)"
    if [[ -n "$line" ]]; then
      # find last queue position in this batch
      qp="$(echo "$line" | grep -Eo 'position[[:space:]]+[0-9]+/[0-9]+' | tail -n 1 || true)"
      if [[ -n "$qp" ]]; then
        # extract just X/Y
        if [[ "$qp" =~ position[[:space:]]+([0-9]+)/([0-9]+) ]]; then
          cur="${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
          if [[ "$cur" != "$last_q" ]]; then
            last_q="$cur"
            note "queued ${cur}"
            set_state "nos - queued"
            # start idle if we have a command and not started
            if (( idle_started == 0 )) && [[ -n "${IDLE_CMD}" ]]; then
              if idle_start; then
                idle_started=1
                echo "$(date +%s)" > "$IDLE_STAMP"
                note "idle miner running at queued ${cur}"
              fi
            fi
          fi
        fi
      fi
      # Heuristic: if we were queued and now logs have no 'QUEUED' but show activity, kill idle
      if (( idle_started == 1 )); then
        if echo "$line" | grep -qE 'RUNNING JOB|JOB START|Starting worker|Downloading job'; then
          note "job starting; stopping idle miner"
          idle_kill || true
          idle_started=0
          echo "$(date +%s)" > "$JOB_STAMP"
          set_state "nos - job"
        fi
      fi
    fi
    sleep 2
  done
) &

# Keep script alive so agent captures stdout; wait on the logger
wait
