#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

# ---- constants/paths ----
MINER_NAME="nosana"
MINER_DIR="/hive/miners/custom/${MINER_NAME}"
RUNDIR="/run/hive"
LOGDIR="/var/log/miner/${MINER_NAME}"
STATE_FILE="/var/run/${MINER_NAME}.state"
MINER1="${RUNDIR}/miner.1"     # node logs (stdout of h-run.sh)
MINER2="${RUNDIR}/miner.2"     # idle miner logs
STATUS1="${RUNDIR}/miner_status.1"
STATUS2="${RUNDIR}/miner_status.2"

START_STAMP="${MINER_DIR}/nosana.start.time"
JOB_STAMP="${MINER_DIR}/job.start.time"
IDLE_STAMP="${MINER_DIR}/idle.start.time"

IDLE_SCREEN="nosana-idle"
IDLE_CMD="${NOS_IDLE_CMD:-}"   # set in farm variable "NOS_IDLE_CMD" or export in user env
IDLE_HINT='waiting for queued state to start idle miner'

# ---- setup dirs ----
mkdir -p "$LOGDIR" /var/run
touch "$STATUS1" "$STATUS2"
chmod 666 "$STATUS1" "$STATUS2" || true
# ensure run files exist so agent-screen doesn't complain
: >"$MINER1" || true
printf "%s\n" "$IDLE_HINT" >"$MINER2" 2>/dev/null || true

# ---- logging/helpers ----
ts() { date +"%Y-%m-%dT%H:%M:%S%z"; }
note() { echo "[$(ts)] NOS: $*"; }
die() { echo "[$(ts)] NOS: ERROR: $*" >&2; exit 1; }

sanitize_stream() {
  # CR to NL, strip ANSI
  sed -u -e 's/\r/\n/g' -E -e 's/\x1B\[[0-9;?]*[ -\/]*[@-~]//g'
}

queue_pos_from_line() {
  local s="$1"
  if [[ "$s" =~ position[[:space:]]+([0-9]+)/([0-9]+) ]]; then
    echo "${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
  fi
}

# write simple state shell file: exports "status"
set_state() {
  local new="$1"
  echo "status=${new}" > "$STATE_FILE"
}

# idle controls
idle_running() {
  screen -ls 2>/dev/null | grep -qE '\.'"$IDLE_SCREEN"'\b' && return 0
  pgrep -f -a 'qli-Client|xmrig' >/dev/null 2>&1 && return 0
  return 1
}

idle_kill() {
  local killed=0
  if screen -ls 2>/dev/null | grep -qE '\.'"$IDLE_SCREEN"'\b'; then
    screen -S "$IDLE_SCREEN" -X quit || true
    killed=1
  fi
  pkill -f 'qli-Client|xmrig' >/dev/null 2>&1 && killed=1 || true
  if (( killed )); then
    note "idle miner killed"
  fi
  printf "%s\n" "$IDLE_HINT" > "$MINER2" 2>/dev/null || true
  echo '{"status":"stopped"}' > "$STATUS2" 2>/dev/null || true
}

idle_start() {
  [[ -z "${IDLE_CMD}" ]] && return 1
  # Clear previous
  idle_kill || true
  : > "$MINER2" || true
  # Start in screen with file logging to miner.2
  # We sanitize output before it hits miner.2 to avoid motd artifacts
  screen -dmS "$IDLE_SCREEN" bash -lc "stdbuf -oL -eL ${IDLE_CMD} 2>&1 | sed -u -e 's/\r/\n/g' -E -e 's/\x1B\[[0-9;?]*[ -\/]*[@-~]//g' | tee -a '${MINER2}'"
  sleep 0.5
  if idle_running; then
    echo '{"status":"running"}' > "$STATUS2" 2>/dev/null || true
    echo "$(date +%s)" > "$IDLE_STAMP"
    note "idle miner started"
    return 0
  fi
  return 1
}
