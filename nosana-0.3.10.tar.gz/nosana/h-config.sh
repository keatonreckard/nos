#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

mkdir -p /var/log/miner/nosana
CONF_PATH="/hive/miners/custom/nosana/nosana.conf"
RAW_PATH="/hive/miners/custom/nosana/extra.raw"
echo "${CUSTOM_USER_CONFIG:-}" > "$RAW_PATH"

# keypair -> /root/.nosana/nosana_key.json
KEYPAIR_JSON=$(grep -Eo '"keypair"\s*:\s*\[[^]]+\]' "$RAW_PATH" || true)
if [[ -n "${KEYPAIR_JSON:-}" ]]; then
  mkdir -p /root/.nosana
  echo "${KEYPAIR_JSON#*:}" | sed 's/^[[:space:]]*//' > /root/.nosana/nosana_key.json
  chmod 600 /root/.nosana/nosana_key.json
fi

VER_LINE="$(echo "${CUSTOM_USER_CONFIG:-}" | sed -n '1p')"
if [[ "$VER_LINE" != VERBOSE=* ]]; then
  VER_LINE="VERBOSE=${CUSTOM_USER_CONFIG:-}"
fi
echo "$VER_LINE" > "$CONF_PATH"
