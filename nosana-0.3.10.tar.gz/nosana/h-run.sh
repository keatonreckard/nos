#!/usr/bin/env bash
set -euo pipefail

SELF_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_DIR="/var/log/miner/nosana"
STATE="/var/run/nosana.state"
mkdir -p "$LOG_DIR"

log(){ echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')] $*" | tee -a "$LOG_DIR/debug.log" ; }

cleanup(){
  log "h-run: cleanup: stopping idle screen + containers"
  screen -S nosana-idle -X quit >/dev/null 2>&1 || true
  docker rm -f nosana-node podman >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM

log "h-run: cleaning previous containers"
docker rm -f nosana-node podman >/dev/null 2>&1 || true

log "h-run: starting podman sidecar"
docker volume create podman-cache >/dev/null 2>&1 || true
docker volume create podman-socket >/dev/null 2>&1 || true
docker run -d --pull=always --gpus=all --name podman --device /dev/fuse   --mount source=podman-cache,target=/var/lib/containers   --volume podman-socket:/podman   --privileged -e ENABLE_GPU=true   nosana/podman:v1.1.0 unix:/podman/podman.sock >/dev/null 2>&1 || true

log "h-run: starting nosana-node container"
mkdir -p /root/.nosana
docker run -d --pull=always --name nosana-node --network host   --gpus all   -v /root/.nosana:/root/.nosana   -v podman-socket:/root/.nosana/podman:ro   nosana/nosana-cli:latest   node start >/dev/null 2>&1 || true

# Stream logs to file (background)
( docker logs -f nosana-node >>"$LOG_DIR/nosana.log" 2>&1 ) &
LOGS_PID=$!

# Seed state file
{
  echo 'status="nos - initializing"'
  echo 'queue=""'
  echo 'sol=""'
  echo 'nos=""'
  echo 'wallet=""'
  echo 'idle_enabled="0"'
} > "$STATE"

# Ensure single monitor, then start
pgrep -f "nosana/monitor.sh" >/dev/null 2>&1 && kill $(pgrep -f "nosana/monitor.sh") || true
nohup bash "$SELF_DIR/monitor.sh" >>"$LOG_DIR/debug.log" 2>&1 &
log "[nosana] monitor started"

# Keep foreground alive
tail -F "$LOG_DIR/nosana.log"
