#!/usr/bin/env bash
set -euo pipefail

STATE="/var/run/nosana.state"
LOG_DIR="/var/log/miner/nosana"
NOS_LOG="$LOG_DIR/nosana.log"
IDLE_LOG="$LOG_DIR/idle.log"

status="nos - initializing"
queue=""
sol=""
nos=""
wallet=""
idle_enabled="0"

[[ -f "$STATE" ]] && source "$STATE" || true

# Fallback parse
if [[ -z "${wallet:-}" || -z "${sol:-}" || -z "${nos:-}" ]]; then
  if [[ -s "$NOS_LOG" ]]; then
    tailtxt="$(tail -n 400 "$NOS_LOG")"
    [[ -z "${wallet:-}" ]] && wallet="$(echo "$tailtxt" | awk '/^[[:space:]]*Wallet:/{print $2}' | tail -n1)"
    [[ -z "${sol:-}"    ]] && sol="$(echo "$tailtxt" | awk '/^[[:space:]]*SOL balance:/{print $3}' | tail -n1)"
    [[ -z "${nos:-}"    ]] && nos="$(echo "$tailtxt" | awk '/^[[:space:]]*NOS balance:/{print $3}' | tail -n1)"
    if [[ -z "${queue:-}" ]]; then
      queue="$(echo "$tailtxt" | grep -E 'QUEUED.*position' | tail -n1 | sed -E 's/.*position[[:space:]]+([0-9]+\/[0-9]+).*/\1/')"
      [[ -n "$queue" ]] && status="nos - queued $queue"
    fi
  fi
fi

format4(){ awk -v n="${1:-0}" 'BEGIN{ if (n=="") n=0; printf("%.4f", n+0) }'; }
sol4="$(format4 "${sol:-}")"
nos4="$(format4 "${nos:-}")"
wal_short="$(echo "${wallet:-N/A}" | cut -c1-5)"
ver="S:${sol4:-N/A} N:${nos4:-N/A} W:${wal_short:-N/A}"
[[ -n "${queue:-}" ]] && ver="${ver} Q:${queue}"
algo="${status:-nos}"

# Idle miner stats when queued
khs="0"; ar_acc="0"; ar_rej="0"
if echo "$algo" | grep -qi 'queued'; then
  if [[ -s "$IDLE_LOG" ]]; then
    L="$(tail -n 400 "$IDLE_LOG")"
    if echo "$L" | grep -Eiq '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s'; then
      hs_val=$(echo "$L" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1 | awk '{print $1}')
      hs_unit=$(echo "$L" | grep -Eio '([0-9]+(\.[0-9]+)?)\s*(H|KH|MH|GH)/s' | tail -n1 | awk '{print $2}' | sed 's#/s##I')
      case "${hs_unit^^}" in
        H)  khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v/1000)}');;
        KH) khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v)}');;
        MH) khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v*1000)}');;
        GH) khs=$(awk -v v="$hs_val" 'BEGIN{printf("%.6f", v*1000*1000)}');;
      esac
    fi
    if echo "$L" | grep -Eiq 'A:[0-9]+'; then
      ar_acc="$(echo "$L" | grep -Eio 'A:[0-9]+' | tail -n1 | cut -d: -f2)"
      ar_rej="$(echo "$L" | grep -Eio 'R:[0-9]+' | tail -n1 | cut -d: -f2)"
    elif echo "$L" | grep -Eiq '[0-9]+/[0-9]+'; then
      ar_acc="$(echo "$L" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d/ -f1)"
      ar_rej="$(echo "$L" | grep -Eio '([0-9]+)\/([0-9]+)' | tail -n1 | cut -d/ -f2)"
    fi
  fi
fi

# GPU telemetry while on a job
temps="[]"; fans="[]"; buses="[]"
if echo "$algo" | grep -qi 'job'; then
  if [[ -f /hive/bin/gpu-stats ]]; then
    source /hive/bin/gpu-stats
    if [[ "${#temp[@]:-0}" -gt 0 ]]; then temps="$(printf '%s\n' "${temp[@]}" | jq -R . | jq -s .)"; fi
    if [[ "${#fan[@]:-0}" -gt 0 ]]; then fans="$(printf '%s\n' "${fan[@]}" | jq -R . | jq -s .)"; fi
    if [[ "${#busid[@]:-0}" -gt 0 ]]; then buses="$(printf '%s\n' "${busid[@]}" | sed 's/^0x//' | jq -R . | jq -s .)"; fi
  fi
fi

uptime=0; [[ -r /proc/uptime ]] && uptime="$(awk '{print int($1)}' /proc/uptime)"

stats=$(jq -nc   --argjson hs "[$khs]"   --arg hs_units "khs"   --argjson temp "$temps"   --argjson fan "$fans"   --arg uptime "$uptime"   --arg ver "$ver"   --argjson ar "[$ar_acc,$ar_rej]"   --arg algo "$algo"   --argjson bus_numbers "$buses"   '{hs:$hs,hs_units:$hs_units,temp:$temp,fan:$fan,uptime:($uptime|tonumber),ver:$ver,ar:$ar,algo:$algo,bus_numbers:$bus_numbers}'
)

echo "$khs"
echo "$stats"
exit 0
