Nosana HiveOS wrapper — version 0.3.10
